#!/bin/bash
# Runs as root after an update's files are in place (musicbox_update.py).
# Keeps the app helper's sudoers entry and daily update check current.
set -eu
MB_USER="$MB_USER" bash "$MB_DIR/install_admin.sh"

# Unplug protection is on by default from 2.5.2: once this update has finished
# and works, switch it on if it is off (one restart). Does nothing if it is on,
# if an install the app started is finishing anyway, or if maintenance mode was
# turned on on purpose. Not undone by going back a version.
if [ -z "${MB_SYSROOT:-}" ]; then
  systemctl stop musicbox-after-update.timer musicbox-after-update.service > /dev/null 2>&1 || true
  systemd-run --unit=musicbox-after-update --collect --quiet --on-active=5 \
    --setenv=MB_USER="$MB_USER" /usr/bin/python3 -I /usr/local/sbin/musicbox-admin _after_update || true
fi
