#!/usr/bin/env python3
"""soloist_bridge.py - lets the Music Box software talk to Spotify Soloist.

The box's programs (tiles, buttons, knob, web app) were written for
go-librespot's little web API on 127.0.0.1:3678. Spotify Soloist (Spotify's
official player for headless devices) has a different control channel: a
WebSocket. This bridge listens on 127.0.0.1:3678 with the same paths the box
already uses (/status, /player/play, /player/pause, ...) and passes each one
on to Soloist. Nothing else in the box has to change.

Standard library only (no pip installs). Runs as soloist-bridge.service.

    python3 soloist_bridge.py            # run the bridge
    python3 soloist_bridge.py --dump     # print Soloist's raw state once (for debugging)
"""
import base64
import json
import os
import socket
import struct
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

SOLOIST_WS = os.environ.get("SOLOIST_WS", "127.0.0.1:3679")
KEY_FILE = os.path.expanduser("~/musicbox/soloist.key")
NAME_CONFIG = os.path.expanduser("~/.config/go-librespot/config.yml")   # the box's Spotify name lives here
LISTEN = ("127.0.0.1", 3678)
DEBUG = os.environ.get("SOLOIST_BRIDGE_DEBUG") == "1"


def log(message):
    print(time.strftime("%H:%M:%S"), message, flush=True)


# --------------------------------------------------------------------------
# A very small WebSocket client (RFC 6455): text frames, ping/pong, close.
# --------------------------------------------------------------------------
class WSClosed(Exception):
    pass


class WebSocket:
    def __init__(self, addr, timeout=5):
        host, port = addr.rsplit(":", 1)
        self.sock = socket.create_connection((host, int(port)), timeout=timeout)
        key = base64.b64encode(os.urandom(16)).decode()
        request = (f"GET / HTTP/1.1\r\nHost: {addr}\r\nUpgrade: websocket\r\n"
                   f"Connection: Upgrade\r\nSec-WebSocket-Key: {key}\r\n"
                   f"Sec-WebSocket-Version: 13\r\n\r\n")
        self.sock.sendall(request.encode())
        reply = b""
        while b"\r\n\r\n" not in reply:
            chunk = self.sock.recv(1024)
            if not chunk:
                raise WSClosed("no handshake reply")
            reply += chunk
        head, _, self.buffer = reply.partition(b"\r\n\r\n")
        if b" 101 " not in head.split(b"\r\n", 1)[0]:
            raise WSClosed("handshake refused: " + head.split(b"\r\n", 1)[0].decode(errors="replace"))
        self.sock.settimeout(None)
        self.send_lock = threading.Lock()

    def _read(self, n):
        while len(self.buffer) < n:
            chunk = self.sock.recv(65536)
            if not chunk:
                raise WSClosed("connection closed")
            self.buffer += chunk
        data, self.buffer = self.buffer[:n], self.buffer[n:]
        return data

    def _send_frame(self, opcode, payload):
        header = bytes([0x80 | opcode])
        n = len(payload)
        if n < 126:
            header += bytes([0x80 | n])
        elif n < 65536:
            header += bytes([0x80 | 126]) + struct.pack(">H", n)
        else:
            header += bytes([0x80 | 127]) + struct.pack(">Q", n)
        mask = os.urandom(4)
        masked = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        with self.send_lock:
            self.sock.sendall(header + mask + masked)

    def send(self, obj):
        self._send_frame(0x1, json.dumps(obj).encode())

    def recv(self):
        """Next text message as a string."""
        parts = []
        while True:
            b1, b2 = self._read(2)
            fin, opcode = b1 & 0x80, b1 & 0x0F
            n = b2 & 0x7F
            if n == 126:
                n = struct.unpack(">H", self._read(2))[0]
            elif n == 127:
                n = struct.unpack(">Q", self._read(8))[0]
            mask = self._read(4) if b2 & 0x80 else None
            payload = self._read(n)
            if mask:
                payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
            if opcode == 0x8:
                raise WSClosed("closed by Soloist")
            if opcode == 0x9:
                self._send_frame(0xA, payload)
                continue
            if opcode == 0xA:
                continue
            parts.append(payload)
            if fin:
                return b"".join(parts).decode(errors="replace")

    def close(self):
        try:
            self.sock.close()
        except OSError:
            pass


# --------------------------------------------------------------------------
# Soloist connection: keeps the newest state, sends commands.
# --------------------------------------------------------------------------
class Soloist:
    def __init__(self):
        self.ws = None
        self.lock = threading.Lock()
        self.logged_in = False
        self.auth = {}
        self.state = {}          # newest playback_state (raw)
        self.state_at = 0.0
        self.last_error = ""
        self.waiters = []        # (command, Event, holder)

    # ---- connection loop ----
    def run(self):
        said = False
        while True:
            try:
                ws = WebSocket(SOLOIST_WS)
            except (OSError, WSClosed) as err:
                if not said:
                    log(f"Waiting for Soloist on {SOLOIST_WS} ({err})")
                    said = True
                time.sleep(2)
                continue
            log("Connected to Soloist")
            said = False
            with self.lock:
                self.ws = ws
            try:
                ws.send({"type": "command", "command": "get_auth_state"})
                while True:
                    self.handle(ws.recv())
            except (OSError, WSClosed) as err:
                log(f"Lost Soloist ({err}); reconnecting")
            finally:
                with self.lock:
                    self.ws = None
                    self.logged_in = False
                ws.close()
                time.sleep(1)

    def handle(self, text):
        try:
            msg = json.loads(text)
        except ValueError:
            return
        kind = msg.get("type", "")
        if DEBUG and kind != "position_sync":
            log("<- " + text[:400])
        if kind == "auth_state":
            self.auth = msg
            self.logged_in = bool(msg.get("logged_in"))
            if self.logged_in:
                self.request_state()
            else:
                self.state, self.state_at = {}, time.monotonic()
        elif kind == "playback_state":
            self.state = msg
            self.state_at = time.monotonic()
            self.logged_in = True
        elif kind == "error":
            self.last_error = str(msg.get("message", ""))
            log(f"Soloist said: {self.last_error}")
        elif kind in EVENT_FIELDS:
            # track_changed, playback_changed, volume_changed, position_sync ...
            # carry just the changed part; fold it into the saved state.
            for key in EVENT_FIELDS[kind]:
                if key in msg:
                    self.state[key] = msg[key]
            self.state_at = time.monotonic()
        for command, event, holder in list(self.waiters):
            if kind in ("command_result", "error") and (msg.get("command") in (None, command)):
                holder.append(msg)
                event.set()

    def send(self, obj):
        with self.lock:
            ws = self.ws
        if ws is None:
            raise ConnectionError("Soloist isn't running")
        ws.send(obj)

    def request_state(self):
        try:
            self.send({"type": "command", "command": "get_state"})
        except (OSError, ConnectionError):
            pass

    def command(self, name, wait=2.0, **fields):
        """Send a control command; returns (ok, message)."""
        event, holder = threading.Event(), []
        entry = (name, event, holder)
        self.waiters.append(entry)
        try:
            self.send(dict(type="command", command=name,
                           **{k: v for k, v in fields.items() if v is not None}))
            event.wait(wait)
        finally:
            self.waiters.remove(entry)
        self.request_state()
        if holder and holder[0].get("type") == "error":
            return False, str(holder[0].get("message", ""))
        return True, ""

    def fresh_state(self, max_age=1.5):
        if time.monotonic() - self.state_at > max_age:
            self.request_state()
            deadline = time.monotonic() + 0.8
            start = self.state_at
            while self.state_at == start and time.monotonic() < deadline:
                time.sleep(0.05)
        return self.state


# Which saved-state fields each Soloist change event updates
# (developer.spotify.com/documentation/soloist/reference/websocket-api).
EVENT_FIELDS = {
    "track_changed": ("item",),
    "playback_changed": ("status",),
    "volume_changed": ("volume",),
    "device_changed": ("is_active",),
    "context_changed": ("context",),
    "options_changed": ("options",),
    "position_sync": ("position",),
}


# --------------------------------------------------------------------------
# Turning Soloist's state into the shape the box expects (go-librespot /status)
# --------------------------------------------------------------------------
def dig(d, *path, default=None):
    for key in path:
        if not isinstance(d, dict):
            return default
        d = d.get(key)
    return default if d is None else d


def first(d, *keys, default=None):
    for k in keys:
        if isinstance(d, dict) and d.get(k) is not None:
            return d[k]
    return default


def entity_name(e):
    return dig(e, "decorations", "identity", "name", default="") or ""


def cover_url(*entities):
    order = {"xlarge": 4, "large": 3, "default": 2, "small": 1}
    for e in entities:
        covers = [c for c in dig(e, "decorations", "visual_identity", "cover", default=[]) or []
                  if isinstance(c, dict) and c.get("url")]
        if covers:
            # the box shows art at about 300-600 px: prefer "large", then bigger, then smaller
            covers.sort(key=lambda c: (order.get(c.get("size"), 0) == 3, order.get(c.get("size"), 0)), reverse=True)
            return covers[0]["url"]
    return ""


def position_now(pos):
    """Soloist sends a position anchor (position_ms at timestamp_ms, moving at
    speed); work out where the song is right now."""
    if not isinstance(pos, dict):
        return 0
    ms = float(pos.get("position_ms") or 0)
    stamp, speed = pos.get("timestamp_ms"), float(pos.get("speed") or 0)
    if stamp and speed:
        ms += max(0.0, time.time() * 1000 - float(stamp)) * speed
    return int(ms)


def to_status(sol):
    st = sol.fresh_state()
    item = st.get("item") if isinstance(st.get("item"), dict) else {}
    context = st.get("context") if isinstance(st.get("context"), dict) else {}
    state = str(st.get("status") or "idle")          # idle, playing, paused, buffering
    has_track = bool(item.get("uri")) and state != "idle"
    parent = dig(item, "decorations", "parent", "entity", default={}) or {}
    duration = int(dig(item, "decorations", "playback", "duration_ms", default=0) or 0)
    status = {
        "username": "soloist" if sol.logged_in else "",
        "device_name": sol.auth.get("device_name", ""),
        "volume": st.get("volume"),
        "volume_steps": 100,
        "paused": state == "paused",
        "stopped": not has_track,
        "context_uri": context.get("uri") or None,
        "shuffle_context": bool(dig(st, "options", "shuffle", default=False)),
    }
    if has_track:
        position = position_now(st.get("position"))
        if duration:
            position = min(position, duration)
        status["track"] = {
            "uri": item.get("uri", ""),
            "name": entity_name(item),
            "artist_names": [n for n in (entity_name(c) for c in
                             dig(item, "decorations", "creators", default=[]) or []) if n],
            "album_name": entity_name(parent),
            "album_cover_url": cover_url(item, parent),
            "position": position,
            "duration": duration,
        }
    return status


def device_name():
    try:
        with open(NAME_CONFIG) as f:
            for line in f:
                if line.startswith("device_name:"):
                    value = line.split(":", 1)[1].strip()
                    return json.loads(value) if value.startswith('"') else (value or "Music Box")
    except (OSError, ValueError):
        pass
    return "Music Box"


def has_key():
    try:
        return os.path.getsize(KEY_FILE) > 0
    except OSError:
        return False


def pairing_info():
    """What the app shows while Spotify isn't connected yet. The bridge always
    answers (even before Soloist runs), so the app can ask for the key."""
    return {"code": "soloist", "soloist": True, "needs_key": not has_key(),
            "running": sol.ws is not None, "name": device_name(),
            "problem": sol.last_error}


# --------------------------------------------------------------------------
# The go-librespot-shaped web API on 127.0.0.1:3678
# --------------------------------------------------------------------------
sol = Soloist()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def reply(self, obj=None, code=200):
        body = b"" if obj is None else json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        try:
            return json.loads(self.rfile.read(n) or b"{}")
        except ValueError:
            return {}

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        if path == "/":
            return self.reply({"playback_ready": bool(sol.ws is not None and sol.logged_in)})
        if path == "/status":
            return self.reply(to_status(sol) if sol.ws is not None and sol.logged_in else {"username": ""})
        if path == "/auth/code":
            return self.reply({} if sol.ws is not None and sol.logged_in else pairing_info())
        if sol.ws is None:
            return self.reply({"error": "soloist offline"}, 503)
        if path == "/player/volume":
            v = sol.fresh_state().get("volume")
            return self.reply({"value": v, "max": 100})
        if path == "/debug/raw":
            return self.reply({"auth": sol.auth, "state": sol.fresh_state(), "last_error": sol.last_error})
        return self.reply({"error": "unknown path"}, 404)

    def do_POST(self):
        path = self.path.split("?", 1)[0]
        b = self.body()
        if sol.ws is None:
            return self.reply({"error": "soloist offline"}, 503)
        try:
            if path == "/player/play":
                sol.command("activate", wait=1.0)
                ok, why = sol.command("play", wait=4.0, uri=b.get("uri"))
            elif path == "/player/resume":
                ok, why = sol.command("play")
            elif path == "/player/pause":
                ok, why = sol.command("pause")
            elif path == "/player/next":
                ok, why = sol.command("skip_next")
            elif path == "/player/prev":
                ok, why = sol.command("skip_prev")
            elif path == "/player/seek":
                ok, why = sol.command("seek", position_ms=int(b.get("position", 0)))
            elif path == "/player/shuffle_context":
                ok, why = sol.command("set_shuffle", enabled=bool(b.get("shuffle_context")))
            elif path == "/player/volume":
                v = int(b.get("volume", 0))
                if b.get("relative"):
                    v += int(sol.fresh_state().get("volume") or 0)
                ok, why = sol.command("set_volume", volume=max(0, min(100, v)))
            else:
                return self.reply({"error": "unknown path"}, 404)
        except (OSError, ConnectionError) as err:
            return self.reply({"error": str(err)}, 503)
        return self.reply(None if ok else {"error": why}, 200 if ok else 500)


def dump():
    threading.Thread(target=sol.run, daemon=True).start()
    for _ in range(50):
        if sol.ws is not None:
            break
        time.sleep(0.1)
    time.sleep(1.5)
    sol.request_state()
    time.sleep(1.0)
    print(json.dumps({"auth": sol.auth, "state": sol.state, "as_status": to_status(sol)}, indent=2))


def main():
    if "--dump" in sys.argv:
        return dump()
    threading.Thread(target=sol.run, daemon=True).start()
    server = ThreadingHTTPServer(LISTEN, Handler)
    log(f"Bridge listening on {LISTEN[0]}:{LISTEN[1]} -> Soloist {SOLOIST_WS}")
    server.serve_forever()


if __name__ == "__main__":
    main()
