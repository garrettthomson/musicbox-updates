#!/bin/bash
# Runs as root after an update's files are in place (musicbox_update.py).
# Keeps the app helper's sudoers entry and daily update check current.
set -eu
MB_USER="$MB_USER" bash "$MB_DIR/install_admin.sh"
