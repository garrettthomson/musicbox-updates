"""
musicbox_persist.py
The "save keeper" for unplug-proof mode.

In unplug-proof mode the Pi's system is read-only: everything it writes goes
to memory and disappears at the next restart, so pulling the plug can't
damage the memory card. A few things must survive a restart, though:

  - coins/tiles and settings (tokens.json, settings.json)
  - the Spotify pairing (go-librespot state) and optional developer sign-in
  - saved Wi-Fi networks

Every 15 seconds this checks those files. If one changed, it briefly unlocks
the memory card, saves the new copy safely (write, flush, swap in), and locks
it again: about a second of writing per change instead of all the time.

When unplug-proof mode is off (maintenance), it does nothing.
Runs as root:  /usr/bin/python3 musicbox_persist.py /home/<user>
"""

import os
import re
import signal
import subprocess
import sys
import time

HOME = sys.argv[1] if len(sys.argv) > 1 else "/home/hotdog"
CHECK_EVERY = 15

TRACK_FILES = [
    f"{HOME}/musicbox/tokens.json",
    f"{HOME}/musicbox/settings.json",
    f"{HOME}/musicbox/local_places.json",   # audiobook bookmarks
    f"{HOME}/musicbox/apple_music.json",   # Apple Music (Music Assistant) address and token
    f"{HOME}/musicbox/album_overrides.json",   # album names fixed in the app
    f"{HOME}/musicbox/stats.json",       # listening stats (saved every 10 min)
    f"{HOME}/musicbox/.spotify_token_cache",
    f"{HOME}/.config/go-librespot/state.json",
    f"{HOME}/.config/go-librespot/config.yml",
    f"{HOME}/musicbox/soloist.key",       # the owner's Soloist player key (Spotify)
    "/etc/hostname",                # the speaker's web address (renamed in the app)
    "/etc/hosts",
    "/etc/camilladsp/musicbox.yml",      # the sound preset picked in the app
    "/etc/camilladsp/current_preset",
]
TRACK_DIRS = [
    "/etc/NetworkManager/system-connections",
    f"{HOME}/musicbox/album_art",         # covers chosen in the app
    f"{HOME}/musicbox/tile_art",          # pictures chosen for tiles
]

# Folders saved with everything inside them (sub-folders too).
TRACK_TREES = [
    f"{HOME}/.local/share/soloist",       # Soloist's saved Spotify sign-in
]
SKIP_NAMES = {"soloist.pid", "ws.addr", "ws.port"}   # Soloist's running notes, not worth saving

stopping = False


def log(message):
    print(time.strftime("%H:%M:%S"), message, flush=True)


def lower_root():
    """Where the real memory card is mounted when the system is read-only."""
    try:
        with open("/proc/mounts") as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 4 and parts[1] == "/" and parts[2] == "overlay":
                    match = re.search(r"lowerdir=([^,]+)", parts[3])
                    if match:
                        return match.group(1).split(":")[0]
    except OSError:
        pass
    return None


def read(path):
    try:
        with open(path, "rb") as f:
            return f.read()
    except (FileNotFoundError, IsADirectoryError, NotADirectoryError):
        return None


def tracked_paths(lower):
    paths = list(TRACK_FILES)
    for d in TRACK_DIRS:
        names = set()
        for base in (d, lower + d):
            try:
                names.update(n for n in os.listdir(base)
                             if os.path.isfile(os.path.join(base, n)) and not n.endswith(".mbtmp"))
            except FileNotFoundError:
                pass
        paths += [os.path.join(d, n) for n in sorted(names)]
    for d in TRACK_TREES:
        found = set()
        for base in (d, lower + d):
            for root, _dirs, files in os.walk(base):
                rel = os.path.relpath(root, base)
                for n in files:
                    if n in SKIP_NAMES or n.endswith(".mbtmp"):
                        continue
                    found.add(os.path.normpath(os.path.join(d, rel, n)))
        paths += sorted(found)
    return paths


def find_changes(lower):
    changes = []
    for path in tracked_paths(lower):
        current, saved = read(path), read(lower + path)
        if current != saved:
            changes.append((path, current))
    return changes


def remount(lower, mode):
    subprocess.run(["mount", "-o", f"remount,{mode}", lower], check=True)


def save(lower, changes):
    remount(lower, "rw")
    try:
        for path, data in changes:
            dest = lower + path
            if data is None:
                if os.path.exists(dest):
                    os.remove(dest)
                    log(f"Removed {path}")
                continue
            if not os.path.isdir(os.path.dirname(dest)):
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                try:   # new folders belong to the same user as the live ones
                    pst = os.stat(os.path.dirname(path))
                    os.chown(os.path.dirname(dest), pst.st_uid, pst.st_gid)
                except OSError:
                    pass
            tmp = dest + ".mbtmp"
            with open(tmp, "wb") as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
            st = os.stat(path)
            os.chmod(tmp, st.st_mode & 0o7777)
            os.chown(tmp, st.st_uid, st.st_gid)
            os.replace(tmp, dest)
            fd = os.open(os.path.dirname(dest), os.O_RDONLY)
            os.fsync(fd)
            os.close(fd)
            log(f"Saved {path}")
        os.sync()
    finally:
        remount(lower, "ro")


def check_once():
    lower = lower_root()
    if not lower:
        return False          # not in unplug-proof mode: nothing to do
    changes = find_changes(lower)
    if changes:
        save(lower, changes)
    return True


def stop(*_):
    global stopping
    stopping = True


def main():
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    protected = lower_root() is not None
    log("Unplug-proof mode is ON. Watching for changes to save." if protected
        else "Unplug-proof mode is OFF (maintenance). Nothing to do.")
    while not stopping:
        try:
            check_once()
        except Exception as err:
            log(f"Save problem: {err}")
        for _ in range(CHECK_EVERY):
            if stopping:
                break
            time.sleep(1)
    try:
        check_once()          # one last save on a clean shutdown
    except Exception as err:
        log(f"Final save problem: {err}")


if __name__ == "__main__":
    main()
