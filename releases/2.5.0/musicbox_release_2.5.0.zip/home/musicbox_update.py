#!/usr/bin/python3
"""
musicbox_update.py
Box software updates from one central place.

How it works
  - Garrett publishes a release: a zip of the box software plus a small
    "manifest" (version, notes, the zip's address and SHA-256 fingerprint).
    The manifest is signed with Garrett's private release key.
  - Each box checks the manifest once a day (and when the owner taps "Check
    now"). The box only believes a manifest whose signature matches the public
    key built into this file, and only installs a zip whose fingerprint matches
    the signed manifest. So nobody else can push software to the boxes.
  - The check sends nothing about the box or its owner: it is a plain download
    of one public file (no box ID, no version, no account, no cookies).
  - Installing needs maintenance mode (system writable), like every update.
    It backs up every file it replaces, installs, restarts the box's programs,
    checks the app comes back with the new version, and puts the old files
    back by itself if anything goes wrong. The owner can also undo the last
    update from the app.

Commands
  python3 musicbox_update.py check [--force]          (as the box's user)
  sudo python3 musicbox_update.py apply --user NAME   (root; normally through
                                                      the app and musicbox-admin)
  sudo python3 musicbox_update.py apply-local ZIP --manifest M --user NAME
                                                     (first install from a zip)
  sudo python3 musicbox_update.py rollback --user NAME

Release zip layout
  release.json        {"version": "2.5.0"}
  home/...            files for ~/musicbox/...
  system/...          files for / (only musicbox helpers, units and sudoers)
  post_update.sh      optional; runs as root after the files are in place

Never in a release: the Spotify player (Soloist) itself or anyone's key.
Standard library only.
"""

import base64
import hashlib
import json
import os
import pwd
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.parse
import urllib.request
import zipfile

# Where boxes look for new releases. A public GitHub repository's "latest
# release" link always points at the newest manifest.
DEFAULT_MANIFEST_URL = ("https://github.com/garrettthomson/musicbox-updates/"
                        "releases/latest/download/manifest.json")
LIB = "/usr/local/lib/musicbox"
CONFIG_FILE = os.environ.get("MB_UPDATE_CONFIG", f"{LIB}/update_config.json")

# Garrett's release key (public half). Its private half signs each manifest.
PUBLIC_KEY_PEM = """-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAKQtKgvFqwwpw8BDA9v7lUJKpbnNj9JRdp4KMadOlYg0=
-----END PUBLIC KEY-----
"""

USER_AGENT = "MusicBoxUpdater/1"     # the same for every box: nothing identifying
MAX_MANIFEST = 64 * 1024
MAX_ZIP = 60 * 1024 * 1024
KEEP_BACKUPS = 3

# Test hooks (simulation only): a fake root for system files, another web address
# for the health check, and another systemctl.
SYSROOT = os.environ.get("MB_SYSROOT", "")
HEALTH_URL = os.environ.get("MB_HEALTH_URL", "http://127.0.0.1/api/now")
SYSTEMCTL = os.environ.get("MB_SYSTEMCTL", "systemctl")

SYSTEM_ALLOWED = (            # the only places a release may write outside ~/musicbox
    "usr/local/sbin/musicbox-",
    "usr/local/lib/musicbox/",
    "etc/systemd/system/musicbox-",
    "etc/systemd/system/soloist-",
    "etc/sudoers.d/musicbox",
)
HOME_NEVER = {               # owner data and secrets: a release never touches these
    "soloist.key", "tokens.json", "settings.json", "local_places.json", "apple_music.json",
    "album_overrides.json", "stats.json", "stats_queue.json", "stats_current.json",
    ".spotify_token_cache", "update_status.json", "update_result.json",
}
HOME_NEVER_DIRS = ("venv/", "update_backups/", "album_art/", "tile_art/", "Music/", "music/")

# Programs restarted after an update (only those installed on this box).
SERVICES = ["musicbox-web", "musicbox", "musicbox-buttons", "soloist-bridge",
            "musicbox-stats", "status-light", "musicbox-persist"]


# --------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------
def say(msg):
    print(msg, flush=True)


def step(n, total, msg):
    say(f"\n== {n}/{total}  {msg}")


class UpdateError(Exception):
    pass


def version_tuple(v):
    parts = re.findall(r"\d+", str(v or ""))
    return tuple(int(p) for p in parts[:4]) or (0,)


def box_dir(home):
    return os.path.join(home, "musicbox")


def installed_version(home):
    try:
        with open(os.path.join(box_dir(home), "musicbox_web.py")) as f:
            m = re.search(r'^APP_VERSION\s*=\s*"([^"]+)"', f.read(), re.M)
            return m.group(1) if m else "0"
    except OSError:
        return "0"


def manifest_url():
    if os.environ.get("MB_UPDATE_URL"):
        return os.environ["MB_UPDATE_URL"]
    try:
        with open(CONFIG_FILE) as f:
            return json.load(f).get("manifest_url") or DEFAULT_MANIFEST_URL
    except (OSError, ValueError):
        return DEFAULT_MANIFEST_URL


def fetch(url, limit, timeout=30):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "*/*"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = r.read(limit + 1)
    except Exception as err:
        raise UpdateError(f"Couldn't reach the update server ({str(err)[:120]}).")
    if len(data) > limit:
        raise UpdateError("The download was bigger than expected, so it was refused.")
    return data


def verify_signature(data, sig_b64):
    """True if Garrett's release key signed these bytes (Ed25519, via openssl)."""
    try:
        sig = base64.b64decode(sig_b64.strip(), validate=True)
    except (ValueError, TypeError):
        return False
    if len(sig) != 64:
        return False
    with tempfile.TemporaryDirectory() as t:
        paths = {n: os.path.join(t, n) for n in ("pub.pem", "data", "sig")}
        for name, content in (("pub.pem", PUBLIC_KEY_PEM.encode()), ("data", data), ("sig", sig)):
            with open(paths[name], "wb") as f:
                f.write(content)
        try:
            r = subprocess.run(["openssl", "pkeyutl", "-verify", "-pubin", "-inkey", paths["pub.pem"],
                                "-rawin", "-in", paths["data"], "-sigfile", paths["sig"]],
                               capture_output=True, timeout=30)
        except (OSError, subprocess.TimeoutExpired):
            return False
        return r.returncode == 0


def parse_manifest(data, sig_text, base_url=""):
    if not verify_signature(data, sig_text):
        raise UpdateError("The update's signature didn't match, so it was ignored.")
    try:
        m = json.loads(data)
        assert m.get("format") == 1
        assert re.fullmatch(r"\d+(\.\d+){1,3}", m["version"])
        z = m["zip"]
        assert re.fullmatch(r"[0-9a-f]{64}", z["sha256"]) and int(z["size"]) > 0
        z["url"] = urllib.parse.urljoin(base_url, z["url"]) if base_url else z["url"]
        assert z["url"].startswith(("https://", "http://127.0.0.1", "file:"))
    except (ValueError, KeyError, TypeError, AssertionError):
        raise UpdateError("The update's details were unreadable.")
    return m


def get_manifest():
    url = manifest_url()
    data = fetch(url, MAX_MANIFEST)
    sig = fetch(url + ".sig", 4096).decode("ascii", "replace")
    return parse_manifest(data, sig, url)


# --------------------------------------------------------------------------
# Check (as the box's user; the app and the daily timer use this)
# --------------------------------------------------------------------------
def status_file(home):
    return os.path.join(box_dir(home), "update_status.json")


def result_file(home):
    return os.path.join(box_dir(home), "update_result.json")


def read_json(path, default=None):
    try:
        with open(path) as f:
            return json.load(f)
    except (OSError, ValueError):
        return default if default is not None else {}


def write_json(path, data, owner=None):
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f, indent=1)
    if owner:
        os.chown(tmp, owner.pw_uid, owner.pw_gid)
    os.replace(tmp, path)


def check(home=None, write=True):
    home = home or os.path.expanduser("~")
    current = installed_version(home)
    out = {"checked": int(time.time()), "current": current, "available": False,
           "latest": "", "notes": "", "released": "", "error": ""}
    try:
        m = get_manifest()
        out.update(latest=m["version"], notes=str(m.get("notes", ""))[:2000],
                   released=str(m.get("released", ""))[:20],
                   available=version_tuple(m["version"]) > version_tuple(current))
        if out["available"] and version_tuple(current) < version_tuple(m.get("min_version", "0")):
            out["available"] = False
            out["error"] = (f"Version {m['version']} needs a by-hand update first "
                            f"(this box has {current}). Ask whoever set up the box.")
    except UpdateError as err:
        out["error"] = str(err)
    if write:
        try:
            write_json(status_file(home), out)
        except OSError:
            pass
    return out


def check_scheduled(home=None):
    """Daily timer: skip if the owner turned automatic checks off."""
    home = home or os.path.expanduser("~")
    settings = read_json(os.path.join(box_dir(home), "settings.json"))
    if settings.get("update_check", True) is False:
        say("Automatic update checks are off (Settings > Software updates).")
        return
    r = check(home)
    say(json.dumps(r))


# --------------------------------------------------------------------------
# Apply (root)
# --------------------------------------------------------------------------
def unplug_protection_on():
    if SYSROOT:
        return os.path.exists(os.path.join(SYSROOT, "OVERLAY_ON"))
    try:
        with open("/proc/mounts") as f:
            return any(l.split()[1:3] == ["/", "overlay"] for l in f if len(l.split()) > 2)
    except OSError:
        return False


def systemctl(*args, check_rc=False):
    r = subprocess.run([SYSTEMCTL, *args], capture_output=True, text=True, timeout=120)
    if check_rc and r.returncode != 0:
        raise UpdateError(f"systemctl {' '.join(args)} failed: {(r.stderr or r.stdout).strip()[:200]}")
    return r


def service_known(name):
    r = systemctl("is-enabled", name)
    return r.stdout.strip() in ("enabled", "static", "alias", "indirect", "generated", "enabled-runtime")


def dest_for(rel, home):
    """Where a file from the zip goes, or raise if it's not allowed."""
    rel = rel.replace("\\", "/")
    if rel.startswith("/") or ".." in rel.split("/"):
        raise UpdateError(f"Unsafe path in the update: {rel}")
    if rel.startswith("home/"):
        sub = rel[len("home/"):]
        if not sub or os.path.basename(sub) in HOME_NEVER or sub.startswith(HOME_NEVER_DIRS):
            raise UpdateError(f"The update tried to replace owner data ({sub}); refused.")
        return os.path.join(box_dir(home), sub)
    if rel.startswith("system/"):
        sub = rel[len("system/"):]
        if not sub.startswith(SYSTEM_ALLOWED):
            raise UpdateError(f"The update tried to write outside the box's own files ({sub}); refused.")
        return os.path.join(SYSROOT or "/", sub)
    if rel in ("release.json", "post_update.sh"):
        return None
    raise UpdateError(f"Unexpected file in the update: {rel}")


def unpack(zip_path, workdir, home):
    """Unzip safely; return (release_info, [(src, dest, rel)], post_script or None)."""
    try:
        zf = zipfile.ZipFile(zip_path)
    except zipfile.BadZipFile:
        raise UpdateError("The update file is damaged.")
    with zf:
        names = [i for i in zf.infolist() if not i.is_dir()]
        if sum(i.file_size for i in names) > 200 * 1024 * 1024:
            raise UpdateError("The update unpacks too big; refused.")
        # Allow one top folder (e.g. musicbox_release_2.5.0/...)
        tops = {i.filename.split("/", 1)[0] for i in names}
        prefix = ""
        if len(tops) == 1 and all("/" in i.filename for i in names):
            prefix = tops.pop() + "/"
        plan, post, info = [], None, None
        for i in names:
            rel = i.filename[len(prefix):]
            if os.path.basename(rel) in ("soloist.key",) or re.search(r"(^|/)soloist$", rel):
                raise UpdateError("The update contains Spotify's player or a key; refused.")
            dest = dest_for(rel, home)
            src = os.path.join(workdir, rel)
            os.makedirs(os.path.dirname(src), exist_ok=True)
            with zf.open(i) as s, open(src, "wb") as d:
                shutil.copyfileobj(s, d)
            if rel == "release.json":
                info = read_json(src, None)
            elif rel == "post_update.sh":
                post = src
            else:
                plan.append((src, dest, rel))
    if not info or "version" not in info:
        raise UpdateError("The update has no release.json.")
    return info, plan, post


def check_files(plan):
    for src, dest, rel in plan:
        if rel.endswith(".py"):
            try:
                with open(src, "rb") as f:
                    compile(f.read(), rel, "exec")
            except (SyntaxError, ValueError) as err:
                raise UpdateError(f"{rel} in the update has a mistake ({err}); nothing was changed.")
        if rel.startswith("system/etc/sudoers.d/") and not SYSROOT:
            r = subprocess.run(["visudo", "-cf", src], capture_output=True, text=True)
            if r.returncode != 0:
                raise UpdateError(f"{rel} in the update isn't valid; nothing was changed.")


def file_mode(rel, src):
    if rel.startswith("system/etc/sudoers.d/"):
        return 0o440
    if rel.startswith("system/usr/local/sbin/") or rel.endswith(".sh"):
        return 0o755
    return 0o644


def place(src, dest, mode, uid, gid):
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    tmp = dest + ".mbnew"
    shutil.copyfile(src, tmp)
    os.chmod(tmp, mode)
    try:
        os.chown(tmp, uid, gid)
    except PermissionError:
        if not SYSROOT:
            raise
    os.replace(tmp, dest)


def backup_dir(home):
    return os.path.join(box_dir(home), "update_backups")


def make_backup(plan, home, owner, from_v, to_v):
    root = backup_dir(home)
    os.makedirs(root, exist_ok=True)
    name = time.strftime("%Y%m%d-%H%M%S") + f"_{from_v}_to_{to_v}"
    bdir = os.path.join(root, name)
    os.makedirs(os.path.join(bdir, "files"))
    entries = []
    for n, (_, dest, rel) in enumerate(plan):
        e = {"dest": dest, "existed": os.path.isfile(dest)}
        if e["existed"]:
            st = os.stat(dest)
            e.update(mode=st.st_mode & 0o7777, uid=st.st_uid, gid=st.st_gid, copy=f"files/{n}")
            shutil.copy2(dest, os.path.join(bdir, e["copy"]))
        entries.append(e)
    write_json(os.path.join(bdir, "backup.json"),
               {"from": from_v, "to": to_v, "made": int(time.time()), "files": entries})
    for p in (root, bdir):
        try:
            os.chown(p, owner.pw_uid, owner.pw_gid)
        except PermissionError:
            pass
    # Keep only the newest few.
    olds = sorted(d for d in os.listdir(root) if os.path.isdir(os.path.join(root, d)))
    for d in olds[:-KEEP_BACKUPS]:
        shutil.rmtree(os.path.join(root, d), ignore_errors=True)
    return bdir


def restore_backup(bdir):
    info = read_json(os.path.join(bdir, "backup.json"), None)
    if not info:
        raise UpdateError("That backup is unreadable.")
    for e in info["files"]:
        if e["existed"]:
            place(os.path.join(bdir, e["copy"]), e["dest"], e["mode"], e["uid"], e["gid"])
        else:
            try:
                os.remove(e["dest"])
            except FileNotFoundError:
                pass
    return info


def restart_services(names):
    systemctl("daemon-reload")
    for s in names:
        systemctl("restart", s)


def app_version_answering(timeout):
    """Wait for the app to answer; return the version it reports (or '')."""
    end = time.time() + timeout
    while time.time() < end:
        try:
            req = urllib.request.Request(HEALTH_URL, headers={"User-Agent": USER_AGENT})
            with urllib.request.urlopen(req, timeout=4) as r:
                v = json.loads(r.read(200000)).get("version", "")
                if v:
                    return v
        except Exception:
            pass
        time.sleep(2)
    return ""


def healthy(expect_version, services, timeout=int(os.environ.get("MB_HEALTH_WAIT", "120"))):
    v = app_version_answering(timeout)
    if v != expect_version:
        return False, (f"the app came back as version {v}" if v else "the app didn't come back")
    time.sleep(5)
    down = [s for s in services if systemctl("is-active", s).stdout.strip() != "active"]
    if down:
        return False, "these didn't stay running: " + ", ".join(down)
    return True, ""


def run_post(post, owner, home, from_v, to_v):
    if not post:
        return
    say("   Running the update's own setup steps...")
    env = dict(os.environ, MB_USER=owner.pw_name, MB_HOME=home, MB_DIR=box_dir(home),
               MB_FROM=from_v, MB_TO=to_v, MB_SYSROOT=SYSROOT, PYTHONDONTWRITEBYTECODE="1")
    r = subprocess.run(["/bin/bash", post], env=env, cwd=os.path.dirname(post),
                       capture_output=True, text=True, timeout=900)
    for line in (r.stdout + r.stderr).strip().splitlines()[-30:]:
        say("   " + line)
    if r.returncode != 0:
        raise UpdateError("The update's setup steps failed.")


def owner_of(user):
    try:
        pw = pwd.getpwnam(user)
    except KeyError:
        raise UpdateError(f"No user called {user} on this box.")
    if pw.pw_uid == 0:
        raise UpdateError("Run the update for the box's user, not root.")
    return pw


def apply(user, zip_path=None, local_manifest=None, force=False):
    """The whole install. Returns 0 on success, 1 if nothing changed, 2 if rolled back."""
    owner = owner_of(user)
    home = owner.pw_dir
    total = 6
    result = {"when": int(time.time()), "ok": False, "from": installed_version(home), "to": "",
              "message": ""}

    def finish(code, message):
        result["message"] = message
        result["ok"] = code == 0
        try:
            write_json(result_file(home), result, owner)
        except OSError:
            pass
        say(("\nDONE: " if code == 0 else "\nSTOPPED: ") + message)
        return code

    work = tempfile.mkdtemp(prefix="musicbox-update-", dir="/var/tmp" if os.path.isdir("/var/tmp") else None)
    try:
        step(1, total, "Checking the box is ready and the update is genuine...")
        if os.geteuid() != 0 and not SYSROOT:
            return finish(1, "Installing needs the box's admin helper (root).")
        if unplug_protection_on():
            return finish(1, "Unplug protection is on. Turn on maintenance mode in Settings, "
                             "wait for the restart, then install again.")
        from_v = result["from"]
        if local_manifest:
            with open(local_manifest, "rb") as f:
                data = f.read()
            with open(local_manifest + ".sig") as f:
                m = parse_manifest(data, f.read())
        else:
            m = get_manifest()
        to_v = result["to"] = m["version"]
        if not force and version_tuple(to_v) <= version_tuple(from_v):
            return finish(1, f"This box already has version {from_v}; nothing to install.")
        if version_tuple(from_v) < version_tuple(m.get("min_version", "0")) and not force:
            return finish(1, f"Version {to_v} needs a by-hand update first (this box has {from_v}).")
        say(f"   This box has {from_v}; installing {to_v}.")

        step(2, total, "Downloading the update...")
        z = m["zip"]
        dl = os.path.join(work, "release.zip")
        if zip_path:
            shutil.copyfile(zip_path, dl)
        else:
            with open(dl, "wb") as f:
                f.write(fetch(z["url"], MAX_ZIP, timeout=300))
        size = os.path.getsize(dl)
        with open(dl, "rb") as f:
            digest = hashlib.sha256(f.read()).hexdigest()
        if size != int(z["size"]) or digest != z["sha256"]:
            return finish(1, "The download didn't match the signed fingerprint, so it wasn't installed.")
        say(f"   Got {size // 1024} KB, fingerprint matches.")

        step(3, total, "Checking the new files...")
        info, plan, post = unpack(dl, os.path.join(work, "x"), home)
        if info["version"] != to_v:
            return finish(1, "The update's files don't match its version; nothing was changed.")
        check_files(plan)
        web = [p for p in plan if p[2] == "home/musicbox_web.py"]
        if web:
            with open(web[0][0]) as f:
                if f'APP_VERSION = "{to_v}"' not in f.read():
                    return finish(1, "The update's app reports a different version; nothing was changed.")
        say(f"   {len(plan)} files look fine.")

        step(4, total, "Backing up the current software...")
        bdir = make_backup(plan, home, owner, from_v, to_v)
        say(f"   Saved in {bdir}")

        step(5, total, "Installing...")
        try:
            for src, dest, rel in plan:
                if rel.startswith("home/"):
                    place(src, dest, file_mode(rel, src), owner.pw_uid, owner.pw_gid)
                else:
                    place(src, dest, file_mode(rel, src), 0, 0)
            run_post(post, owner, home, from_v, to_v)
        except Exception as err:
            say(f"   Problem: {err}. Putting the old files back...")
            restore_backup(bdir)
            shutil.rmtree(bdir, ignore_errors=True)     # used up: the old files are back
            restart_services([s for s in SERVICES if service_known(s)])
            return finish(2, f"Installing failed ({str(err)[:150]}). The old version is back.")
        say("   Files in place.")

        step(6, total, "Restarting the box's programs and checking they work...")
        services = [s for s in SERVICES if service_known(s)]
        restart_services(services)
        ok, why = healthy(to_v, services)
        if not ok:
            say(f"   Not right: {why}. Putting the old version back...")
            restore_backup(bdir)
            shutil.rmtree(bdir, ignore_errors=True)     # used up: the old files are back
            restart_services(services)
            back_ok, back_why = healthy(from_v, services)
            if back_ok:
                return finish(2, f"The new version didn't start properly ({why}). "
                                 f"The box is back on {from_v}.")
            return finish(2, f"The new version didn't start properly ({why}) and the old one "
                             f"isn't answering yet either ({back_why}). Try Restart box.")
        try:   # the status page shows "up to date" right away
            write_json(status_file(home), dict(read_json(status_file(home)), current=to_v,
                                               available=False), owner)
        except OSError:
            pass
        return finish(0, f"Updated to {to_v}. Turn unplug protection back on when you're done.")
    except UpdateError as err:
        return finish(1, str(err))
    finally:
        shutil.rmtree(work, ignore_errors=True)


def rollback(user):
    owner = owner_of(user)
    home = owner.pw_dir
    root = backup_dir(home)

    def finish(code, message):
        try:
            write_json(result_file(home), {"when": int(time.time()), "ok": code == 0, "rollback": True,
                                           "from": "", "to": installed_version(home),
                                           "message": message}, owner)
        except OSError:
            pass
        say(("\nDONE: " if code == 0 else "\nSTOPPED: ") + message)
        return code

    say("\n== 1/2  Finding the last backup...")
    if unplug_protection_on():
        return finish(1, "Unplug protection is on. Turn on maintenance mode first.")
    try:
        backups = sorted(d for d in os.listdir(root) if os.path.isfile(os.path.join(root, d, "backup.json")))
    except FileNotFoundError:
        backups = []
    if not backups:
        return finish(1, "There's no earlier version saved on this box.")
    bdir = os.path.join(root, backups[-1])
    say("\n== 2/2  Putting the earlier version back and restarting...")
    try:
        info = restore_backup(bdir)
    except (UpdateError, OSError) as err:
        return finish(1, f"Couldn't put the earlier version back ({err}).")
    services = [s for s in SERVICES if service_known(s)]
    restart_services(services)
    ok, why = healthy(info["from"], services)
    shutil.rmtree(bdir, ignore_errors=True)    # used up
    try:
        write_json(status_file(home), dict(read_json(status_file(home)), current=info["from"]), owner)
    except OSError:
        pass
    if ok:
        return finish(0, f"Back on version {info['from']}.")
    return finish(2, f"Put {info['from']} back, but it isn't answering properly yet ({why}). Try Restart box.")


def main(argv):
    if not argv:
        print(__doc__)
        return 1
    cmd, rest = argv[0], argv[1:]

    def opt(name, default=None):
        if name in rest:
            i = rest.index(name)
            return rest[i + 1] if i + 1 < len(rest) else default
        return default

    if cmd == "check":
        if "--force" in rest:
            print(json.dumps(check(opt("--home")), indent=1))
        else:
            check_scheduled(opt("--home"))
        return 0
    if cmd == "apply":
        return apply(opt("--user") or os.environ.get("MB_USER", ""), force="--force" in rest)
    if cmd == "apply-local":
        if not rest or not opt("--manifest"):
            print("Use: apply-local ZIP --manifest manifest.json --user NAME")
            return 1
        return apply(opt("--user") or os.environ.get("SUDO_USER", ""), zip_path=rest[0],
                     local_manifest=opt("--manifest"), force="--force" in rest)
    if cmd == "rollback":
        return rollback(opt("--user") or os.environ.get("MB_USER", ""))
    print(__doc__)
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
