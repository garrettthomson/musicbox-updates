#!/bin/bash
# install_admin.sh - lets the phone app install Spotify's player and box
# software updates by itself (no terminal for the owner).
# Installs (root-owned): /usr/local/sbin/musicbox-admin, /usr/local/lib/musicbox/
# (update checker + Spotify player installer), a sudoers entry that lets the
# app start just those three jobs, and a daily update check.
#
# Run as root with MB_USER set (musicbox_install.sh and updates do this):
#   sudo MB_USER=$(whoami) bash ~/musicbox/install_admin.sh --copy-from ~/musicbox
# Without --copy-from it only sets up the sudoers entry and the daily check
# (an update has already put the files in place).
set -eu
ME="${MB_USER:?set MB_USER to the box user}"
H="$(getent passwd "$ME" | cut -d: -f6)"
R="${MB_SYSROOT:-}"
SC="${MB_SYSTEMCTL:-systemctl}"
LIB="$R/usr/local/lib/musicbox"
[ "$(id -u)" = 0 ] || [ -n "$R" ] || { echo "Run as root (sudo)."; exit 1; }

if [ "${1:-}" = "--copy-from" ]; then
  SRC="$2"
  OWN=""; [ -z "$R" ] && OWN="-o root -g root"
  install -d $OWN -m 755 "$R/usr/local/sbin" "$LIB" "$LIB/soloist"
  install $OWN -m 755 "$SRC/musicbox-admin" "$R/usr/local/sbin/musicbox-admin"
  install $OWN -m 644 "$SRC/musicbox_update.py" "$LIB/musicbox_update.py"
  for f in install_soloist.sh soloist_update.sh soloist_run.sh; do
    install $OWN -m 755 "$SRC/soloist/$f" "$LIB/soloist/$f"
  done
  install $OWN -m 644 "$SRC/soloist/soloist_bridge.py" "$LIB/soloist/soloist_bridge.py"
fi
[ -x "$R/usr/local/sbin/musicbox-admin" ] || { echo "musicbox-admin is missing"; exit 1; }

# The app may start these three jobs (plain, or "auto-": switch maintenance mode
# on and off by itself around the job), nothing else.
A=/usr/local/sbin/musicbox-admin
T=$(mktemp)
cat > "$T" <<SUDO
$ME ALL=(root) NOPASSWD: $A soloist-install, $A update-apply, $A update-rollback, $A auto-soloist-install, $A auto-update-apply, $A auto-update-rollback
SUDO
if [ -z "$R" ]; then visudo -cf "$T" > /dev/null; fi
install -d -m 755 "$R/etc/sudoers.d"
install -m 440 "$T" "$R/etc/sudoers.d/musicbox-admin"; rm -f "$T"

install -d -m 755 "$R/etc/systemd/system"
cat > "$R/etc/systemd/system/musicbox-update-check.service" <<UNIT
[Unit]
Description=Music Box: check for new box software (downloads one public file; sends nothing about the box)
Wants=network-online.target
After=network-online.target

[Service]
Type=oneshot
User=$ME
Nice=10
ExecStart=/usr/bin/python3 -I /usr/local/lib/musicbox/musicbox_update.py check --home $H
UNIT
cat > "$R/etc/systemd/system/musicbox-update-check.timer" <<'UNIT'
[Unit]
Description=Music Box: check for new box software once a day

[Timer]
OnBootSec=15min
OnCalendar=*-*-* 03:40
RandomizedDelaySec=2h
Persistent=true

[Install]
WantedBy=timers.target
UNIT
# Finishes an auto job after the box restarts into maintenance mode (does nothing otherwise).
cat > "$R/etc/systemd/system/musicbox-admin-resume.service" <<'UNIT'
[Unit]
Description=Music Box: finish an install the app started (maintenance mode on, job, protection back on)
Wants=network-online.target
After=network-online.target musicbox-web.service

[Service]
Type=simple
ExecStart=/usr/bin/python3 -I /usr/local/sbin/musicbox-admin _resume
TimeoutStopSec=30

[Install]
WantedBy=multi-user.target
UNIT
install -d -m 755 "$R/var/lib/musicbox-admin"
$SC daemon-reload
$SC enable musicbox-admin-resume.service > /dev/null 2>&1 || true
$SC enable musicbox-update-check.timer > /dev/null 2>&1 || true
$SC start musicbox-update-check.timer > /dev/null 2>&1 || true
echo "App helper installed: Spotify player install and software updates work from the app."
