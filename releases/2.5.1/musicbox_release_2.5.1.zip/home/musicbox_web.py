"""
musicbox_web.py
The Music Box phone app. Open http://<speaker name>.local (for example
http://avas-room.local) on any phone or computer on the same Wi-Fi.
http://musicbox-XXXX.local (XXXX = the box ID on the bottom sticker) always
works too, whatever the box is called.

  Now       what's playing, play/pause, back, next, and plain-English fixes
            when something needs attention                       (no PIN)
  Tiles     add tiles, change their music, rename, remove        (PIN)
  Settings  Wi-Fi, Spotify, volume limits, resume time, PIN,
            unplug protection, restart and shut down             (PIN)

First time: the app walks you through a short setup (PIN, naming the speaker,
Wi-Fi if needed, pairing the speaker with Spotify, and your first tile).

Setup mode: if the box can't find a Wi-Fi network it knows for about 90
seconds, it makes its own network called "Music Box Setup XXXX" (password:
musicbox). Join it from your phone and the setup page pops up (or open
http://10.42.0.1). Setup mode never runs forever: if nobody joins it for 20
minutes it switches off and the box just keeps trying its saved Wi-Fi.
Unplug and replug the box to get setup mode back.

Needs musicbox_common.py in the same folder. Runs as the musicbox-web service.
"""

import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import shutil
import socket
import subprocess
import tempfile
import threading
import urllib.parse
import time
from datetime import timedelta
from urllib.parse import parse_qs, urlparse

from flask import (Flask, Response, abort, jsonify, redirect, render_template,
                   request, send_file, session, url_for)
from jinja2 import DictLoader

from musicbox_common import (
    CLIENT_ID, SPEAKER_STATE, STATE_FILE, WRITE_REQUEST, NotSignedIn, SpeakerOffline,
    connect_spotify, describe, kind_of, link_token, tile_badge, play_chime, load_settings, load_tokens,
    make_auth, read_json, save_settings, save_tokens, signed_in, speaker_call,
    speaker_status, spotify_uri_from_link, write_json,
)
import musicbox_apple as apple
import musicbox_update as updates
import musicbox_local as local
from musicbox_about import about as album_about
from musicbox_naming import (
    NAME_MAX, address, apply_name, box_id, check_after_joining, check_name, clean_name,
    current_host, fallback_host, is_named, publisher, setup_ssid, slugify, speaker_name,
)

APP_VERSION = "2.5.1"        # open phones reload themselves when this changes
SPEAKER_SERVICE = "go-librespot"


def systemctl(action, service):
    subprocess.run(["sudo", "-n", "/usr/bin/systemctl", action, service])


# Spotify Soloist (Spotify's official player). The installer leaves this marker.
SOLOIST_MARK = os.path.expanduser("~/musicbox/soloist.enabled")
SOLOIST_KEY = os.path.expanduser("~/musicbox/soloist.key")
SOLOIST_DATA = os.path.expanduser("~/.local/share/soloist")


def soloist_mode():
    return os.path.exists(SOLOIST_MARK)


SOLOIST_BIN = os.path.expanduser("~/soloist/soloist")
SOLOIST_MACHINES = ("aarch64", "armv7l")      # Spotify's player has ARM builds for boxes


def soloist_installed():
    """Spotify's player has been downloaded and the box is set up to use it."""
    return soloist_mode() and os.path.exists(SOLOIST_BIN)


# --------------------------------------------------------------------------
# Jobs the app starts as root through /usr/local/sbin/musicbox-admin (installing
# Spotify's player, software updates). They run in the background, so the
# owner never needs a terminal, and survive the app restarting.
# --------------------------------------------------------------------------
ADMIN = "/usr/local/sbin/musicbox-admin"
JOB_DIR = "/run/musicbox-admin"
JOBS = ("soloist", "update")


AUTO_STATE = "/var/lib/musicbox-admin/auto.json"
RESUME_UNIT = "/etc/systemd/system/musicbox-admin-resume.service"


def admin_ready():
    return os.path.exists(ADMIN) and os.path.exists("/etc/sudoers.d/musicbox-admin")


def auto_ready():
    """The helper can switch maintenance mode on and off by itself around a job (2.5.1+)."""
    try:
        with open(ADMIN, errors="replace") as f:
            knows = "auto-update-apply" in f.read()
    except OSError:
        return False
    return knows and admin_ready() and os.path.exists(RESUME_UNIT)


def start_install(command):
    """Start an install job. With unplug protection on, the helper switches
    maintenance mode on by itself first and protection back on afterwards."""
    if auto_ready():
        return start_job("auto-" + command)   # the helper only switches modes when needed
    if unplug_proof_on():
        return False, ("Turn on maintenance mode first (Settings > Unplug protection). "
                       "The box restarts; then come back here.")
    return start_job(command)


def start_job(command):
    try:
        r = subprocess.run(["sudo", "-n", ADMIN, command], capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.TimeoutExpired) as err:
        return False, str(err)
    return r.returncode == 0, (r.stderr or r.stdout).strip()[:300]


def job_state(job):
    """What a background job is doing, in plain words, for the progress screens."""
    state = read_json(f"{JOB_DIR}/{job}.json", {}) or {}
    try:
        with open(f"{JOB_DIR}/{job}.log", errors="replace") as f:
            lines = f.read()[-60000:].splitlines()
    except OSError:
        lines = []
    steps = [l[3:].strip() for l in lines if l.startswith("== ")]
    errors = [l[len("STOPPED:"):].strip() for l in lines if l.startswith("STOPPED:")]
    done = [l[len("DONE:"):].strip() for l in lines if l.startswith("DONE:")]
    running = bool(state.get("running"))
    if running and time.time() - state.get("started", 0) > 15:
        # Make sure the job is really still going (a restart clears /run anyway).
        r = subprocess.run(["systemctl", "is-active", f"musicbox-job-{job}"], capture_output=True, text=True)
        running = r.stdout.strip() in ("active", "activating")
    num = total = 0
    m = re.match(r"(\d+)/(\d+)\s+(.*)", steps[-1]) if steps else None
    if m:
        num, total = int(m.group(1)), int(m.group(2))
    rc = state.get("rc")
    return {"exists": bool(state), "running": running, "command": state.get("command", ""),
            "ok": bool(state) and not running and rc == 0,
            "failed": bool(state) and not running and rc != 0,
            "step": re.sub(r"^\d+/\d+\s+", "", steps[-1]) if steps else "Starting...",
            "num": num, "total": total, "error": errors[-1] if errors else "",
            "done": done[-1] if done else "", "started": state.get("started", 0),
            "ended": state.get("ended", 0), "log": "\n".join(lines[-40:])}


AUTO_STEPS = {
    "pausing": "Pausing the box while it updates...",
    "working": "Getting ready...",
    "restoring": "Finishing: turning unplug protection back on...",
}
AUTO_NOTES = {
    "pausing": ("The box is restarting into maintenance mode (2 to 5 minutes). "
                "This page follows along by itself. Please don't unplug the box."),
    "working": ("Unplug protection comes back on by itself when this is done. "
                "Please don't unplug the box."),
    "restoring": ("The box restarts once more (up to 5 minutes). This page follows along by "
                  "itself. Please don't unplug the box."),
}


def auto_phase(job, run_state):
    """Where an install the helper started with maintenance mode switching is up to:
    pausing, working, restoring (still going), done or attention (finished), or None."""
    a = read_json(AUTO_STATE, {}) or {}
    if a.get("job") != job:
        return None, a
    stage = a.get("stage")
    if stage in ("pausing", "working"):
        if stage == "working" and not run_state["running"]:
            r = subprocess.run(["systemctl", "is-active", "musicbox-admin-resume"],
                               capture_output=True, text=True)
            if r.stdout.strip() not in ("active", "activating"):
                a["message"] = ("The box restarted before the job finished. It is staying in "
                                "maintenance mode: try again, or turn unplug protection back on "
                                "in Settings.")
                return "attention", a
        if time.time() - a.get("updated", 0) > 3 * 3600:
            return None, a                     # long stale: don't block the page
        return stage, a
    if stage not in ("restoring", "attention"):
        return None, a
    if run_state["exists"] and run_state["started"] > a.get("ended", 0) + 5:
        return None, a                         # a newer job ran by hand since
    if time.time() - a.get("ended", 0) > 12 * 3600:
        return None, a
    if stage == "restoring":
        if a.get("boot") and a["boot"] == boot_id():
            return "restoring", a              # the restart that turns protection on is coming
        if not unplug_proof_on():               # restarted since, but protection is off now
            a["message"] = a.get("message", "").replace(" Unplug protection is back on.", "")
        return "done", a
    return "attention", a


def boot_id():
    sim = os.environ.get("MB_SYSROOT")         # simulation tests only
    try:
        with open(os.path.join(sim, "boot_id") if sim else "/proc/sys/kernel/random/boot_id") as f:
            return f.read().strip()
    except OSError:
        return ""


def job_view(job):
    """job_state, plus the maintenance mode steps around it when the box switches
    maintenance mode on and off by itself."""
    s = job_state(job)
    phase, a = auto_phase(job, s)
    s["auto"] = phase
    s["note"] = ""
    if not phase:
        return s
    s["command"] = a.get("command") or s["command"]
    if phase in AUTO_STEPS:
        s.update(exists=True, ok=False, failed=False, note=AUTO_NOTES[phase])
        if phase != "working" or not s["exists"]:
            step = AUTO_STEPS[phase]
            if phase == "pausing" and job == "soloist":
                step = "Pausing the box while it installs Spotify's player..."
            s.update(step=step, num=0 if phase == "pausing" else s["num"],
                     total=0 if phase == "pausing" else s["total"])
        if phase == "restoring":
            s.update(num=1, total=1, log=a.get("log") or s["log"])
        s["running"] = True
        return s
    ok = phase == "done" and bool(a.get("ok"))
    message = a.get("message", "")
    s.update(exists=True, running=False, ok=ok, failed=not ok, auto_message=message,
             error="" if ok else message, done=message if ok else s["done"],
             log=s["log"] if s["log"] and phase == "attention" else (a.get("log") or s["log"]))
    return s


def apple_supported():
    """Apple Music runs through Music Assistant, which is too big for the small
    boards (Pi Zero 2 W, Pi 3). Offer it on a 64-bit Pi 4 or Pi 5 (any memory
    size), or any other 64-bit board with 2 GB or more."""
    if os.uname().machine != "aarch64":
        return False
    try:
        with open("/proc/device-tree/model") as f:
            model = f.read().strip("\x00\n ")
    except OSError:
        model = ""
    if model.startswith(("Raspberry Pi 4", "Raspberry Pi 5", "Raspberry Pi Compute Module 4",
                         "Raspberry Pi Compute Module 5", "Raspberry Pi 500", "Raspberry Pi 400")):
        return True
    if model.startswith("Raspberry Pi"):
        return False
    try:
        with open("/proc/meminfo") as f:
            kb = next(int(l.split()[1]) for l in f if l.startswith("MemTotal:"))
    except (OSError, StopIteration, ValueError):
        return False
    return kb // 1024 >= 1800


PORT = 80
HOTSPOT_NAME = "MusicBoxSetup"          # NetworkManager profile name
HOTSPOT_SSID_PREFIX = "Music Box Setup"  # phones see "Music Box Setup 3F2A"
HOTSPOT_PASSWORD = "musicbox"           # at least 8 characters
HOTSPOT_ADDRESS = "10.42.0.1"           # the box's address in setup mode
OFFLINE_BEFORE_SETUP = 90               # seconds without Wi-Fi before setup mode
SETUP_RETRY = 3 * 60                    # in setup mode, retry known Wi-Fi this often
SETUP_IDLE_LIMIT = 20 * 60              # nobody joined setup mode this long -> switch it off

app = Flask(__name__)
sp = connect_spotify()   # only used if the optional developer sign-in exists (search)


# --------------------------------------------------------------------------
# PIN
# --------------------------------------------------------------------------
def _settings_with_secret():
    settings = load_settings()
    if "secret" not in settings:
        settings["secret"] = secrets.token_hex(32)
        save_settings(settings)
    return settings


app.secret_key = _settings_with_secret()["secret"]
app.config.update(
    SESSION_COOKIE_SAMESITE="Strict",
    PERMANENT_SESSION_LIFETIME=timedelta(days=30),
)

failed_pins = {"count": 0, "until": 0.0}


def hash_pin(pin, salt):
    return hashlib.pbkdf2_hmac("sha256", pin.encode(), bytes.fromhex(salt), 100_000).hex()


def pin_is_set():
    return "pin_hash" in load_settings()


def check_pin(pin):
    settings = load_settings()
    if "pin_hash" not in settings:
        return False
    return hmac.compare_digest(hash_pin(pin, settings["pin_salt"]), settings["pin_hash"])


def set_pin(pin):
    settings = load_settings()
    settings["pin_salt"] = secrets.token_hex(16)
    settings["pin_hash"] = hash_pin(pin, settings["pin_salt"])
    save_settings(settings)


def needs_pin(view):
    """Decorator: send people to the PIN page first."""
    def wrapper(*args, **kwargs):
        if not pin_is_set():
            return redirect(url_for("pin_page", next=request.path))
        if not session.get("ok"):
            return redirect(url_for("pin_page", next=request.path))
        return view(*args, **kwargs)
    wrapper.__name__ = view.__name__
    return wrapper


@app.route("/pin", methods=["GET", "POST"])
def pin_page():
    next_page = request.values.get("next") or "/"
    if not next_page.startswith("/"):
        next_page = "/"
    first_time = not pin_is_set()
    error = ""
    if request.method == "POST":
        pin = request.form.get("pin", "").strip()
        if first_time:
            if not (pin.isdigit() and 4 <= len(pin) <= 8):
                error = "Use 4 to 8 numbers."
            elif pin != request.form.get("pin2", "").strip():
                error = "Those two didn't match."
            else:
                set_pin(pin)
                session.permanent = True
                session["ok"] = True
                return redirect(next_page)
        elif time.time() < failed_pins["until"]:
            error = "Too many tries. Wait a minute and try again."
        elif check_pin(pin):
            failed_pins["count"] = 0
            session.permanent = True
            session["ok"] = True
            return redirect(next_page)
        else:
            failed_pins["count"] += 1
            if failed_pins["count"] >= 5:
                failed_pins.update(count=0, until=time.time() + 60)
            error = "Wrong PIN."
    return render_template("pin.html", first_time=first_time, error=error, next=next_page)


@app.route("/lock", methods=["POST"])
def lock():
    session.clear()
    return redirect("/")


# --------------------------------------------------------------------------
# First-time setup
# --------------------------------------------------------------------------
def setup_done():
    settings = load_settings()
    if settings.get("setup_done"):
        return True
    # Boxes that were set up before the guide existed count as done.
    return "pin_hash" in settings and bool(load_tokens())


def mark_setup_done():
    settings = load_settings()
    settings["setup_done"] = True
    save_settings(settings)


SETUP_STEPS = ["name", "wifi", "spotify", "tile"]


def setup_step():
    """Which step of the first-time guide we're on."""
    if not is_named():
        return "name"
    if setup.hotspot_on:
        return "wifi"
    if not soloist_installed():
        return "spotify"                 # Spotify's player isn't on the box yet
    online, _ = speaker_account()
    if online and pairing_code():
        return "spotify"
    if not online:
        return "speaker"
    return "tile"


@app.route("/setup")
@needs_pin
def setup_page():
    if request.args.get("finish"):
        mark_setup_done()
        return redirect("/")
    if setup_done() and setup.hotspot_on:
        return redirect(url_for("wifi_page"))       # a set-up box that moved house
    step = setup_step()
    if step == "wifi":
        return redirect(url_for("wifi_page"))
    state = reader_state()
    tile = state.get("token")
    if step == "tile" and tile and state.get("known"):
        mark_setup_done()
        return redirect(url_for("tiles_page", saved=tile))
    if step == "name":
        return redirect(url_for("name_page", setup=1))
    return render_template("setup.html", tab="", step=step, pairing=pairing_code(),
                           keyerror=request.args.get("keyerror"),
                           need_install=not soloist_installed(), install=soloist_install_info(),
                           tile=tile, wifi=current_wifi(),
                           step_num=SETUP_STEPS.index("spotify" if step == "speaker" else step) + 1,
                           step_count=len(SETUP_STEPS))


@app.route("/setup/again", methods=["POST"])
@needs_pin
def setup_again():
    settings = load_settings()
    settings["setup_done"] = False
    save_settings(settings)
    return redirect(url_for("name_page", setup=1))


# --------------------------------------------------------------------------
# Speaker name
# --------------------------------------------------------------------------
NAME_IDEAS = ["Living Room", "Kitchen", "Playroom", "Bedroom", "Nursery", "Office"]


@app.route("/name", methods=["GET", "POST"])
@needs_pin
def name_page():
    in_setup = bool(request.values.get("setup")) and not setup_done()
    error, typed = "", ""
    if request.method == "POST":
        typed = request.form.get("name", "")
        name = clean_name(typed)
        online = not setup.hotspot_on and wifi_connected()
        if not name:
            error = "Type a name first."
        elif online and name != speaker_name():
            ok, error = check_name(name)
        if name and not error:
            old_host = current_host()
            if name == speaker_name() and is_named():
                new_host = old_host
            else:
                # Rename after this page has loaded: the old address stops working.
                from musicbox_naming import pick_host
                new_host = pick_host(name, online=online)

                def worker():
                    time.sleep(2)
                    _, err = apply_name(name, online=online,
                                        restart_speaker=lambda: systemctl("restart", SPEAKER_SERVICE))
                    if err:
                        print(f"Rename problem: {err}", flush=True)
                settings = load_settings()
                settings["speaker_name"] = name   # so the next page already shows it
                save_settings(settings)
                threading.Thread(target=worker, daemon=True).start()
            if in_setup:
                if setup.hotspot_on or new_host == old_host:
                    return redirect(url_for("setup_page"))
            if new_host == old_host:
                return redirect(url_for("settings_page", message="Name saved."))
            return render_template("renamed.html", tab="", name=name, host=new_host,
                                   fallback=fallback_host(), in_setup=in_setup)
    return render_template("name.html", tab="" if in_setup else "settings", in_setup=in_setup,
                           name=typed or (speaker_name() if is_named() else ""),
                           ideas=NAME_IDEAS, error=error, max_len=NAME_MAX,
                           host=current_host(), fallback=fallback_host(), box=box_id(),
                           setup_mode=setup.hotspot_on, step_count=len(SETUP_STEPS))


@app.route("/api/name-preview")
def api_name_preview():
    return jsonify(host=slugify(clean_name(request.args.get("name", "")) or "x"))


# --------------------------------------------------------------------------
# Now playing (no PIN)
# --------------------------------------------------------------------------
def reader_state():
    state = read_json(STATE_FILE, {})
    if time.time() - state.get("updated", 0) > 6 * 3600 and not state.get("token"):
        return {"reader_ok": state.get("reader_ok", True)}
    return state


def protection_installed():
    return os.path.exists("/etc/sudoers.d/musicbox") and os.path.exists("/usr/sbin/overlayroot-chroot")


@app.route("/")
def now_page():
    if not setup_done():
        return redirect(url_for("setup_page"))
    return render_template("now.html", tab="now", version=APP_VERSION)


now_cache = {"when": 0.0, "data": None}
now_lock = threading.Lock()


@app.route("/api/now")
def api_now():
    # Several open phones share one answer.
    with now_lock:
        if now_cache["data"] and time.time() - now_cache["when"] < 3:
            data = now_cache["data"]
        else:
            data = build_now()
            now_cache.update(when=time.time(), data=data)
    # The reader part changes fast and costs nothing, so it's always fresh.
    state = reader_state()
    tile = state.get("token")
    return jsonify(dict(data, tile=tile, new_tile=bool(tile and not state.get("known")),
                        teaching=bool(state.get("teaching")),
                        reader_ok=state.get("reader_ok", True) is not False))


@app.route("/api/about")
def api_about():
    """About the album that's playing right now (no PIN, like /api/now)."""
    with now_lock:
        data = now_cache["data"] if now_cache["data"] and time.time() - now_cache["when"] < 10 else None
    if data is None:
        data = build_now()
    if not data.get("on_box") or data.get("local") or data.get("apple") or setup.hotspot_on:
        return jsonify(status="none")
    return jsonify(album_about(data.get("artist", ""), data.get("album", ""), data.get("track", "")))


def build_now():
    info = {"version": APP_VERSION, "signed_in": True, "speaker": False,
            "playing": False, "wifi": current_wifi(), "setup_mode": setup.hotspot_on,
            "maintenance": protection_installed() and not unplug_proof_on()}
    upd = update_status()
    info["update"] = upd.get("latest", "") if upd["available"] else ""
    if setup.hotspot_on:
        return info
    if local.source() == "local":
        mine = local.now_playing()          # music from this box's own drive
        if mine:
            info.update(speaker=True, on_box=True, local=True, playing=mine["playing"],
                        track=mine["track"], artist=mine["artist"], album=mine["album"],
                        image=album_art_url(local.loaded_path()),
                        kind="Audiobook" if mine["book"] else "Local music")
            if mine["volume"] is not None:
                info["volume"] = mine["volume"]
            return info
    if apple.source() == "apple" and apple.configured():
        mine = apple.now_playing()         # Apple Music through Music Assistant
        if mine:
            info.update(speaker=True, on_box=True, apple=True, playing=mine["playing"],
                        track=mine["track"], artist=mine["artist"], album=mine["album"],
                        image=mine["image"], kind="Apple Music")
            if mine["volume"] is not None:
                info["volume"] = mine["volume"]
            return info
    try:
        status = speaker_status()          # asked inside the box, always current
    except SpeakerOffline:
        return info
    info["speaker"] = True
    if not status.get("username"):
        code = pairing_code()
        if code:
            info.update(signed_in=False, pairing=code)
            return info
    steps = status.get("volume_steps") or 100
    if status.get("volume") is not None:
        info["volume"] = round(status["volume"] * 100 / steps)
    track = status.get("track")
    if track and not status.get("stopped"):
        info.update(
            on_box=True,
            playing=not status.get("paused"),
            track=track.get("name", ""),
            artist=", ".join(track.get("artist_names") or []),
            album=track.get("album_name", ""),
            image=track.get("album_cover_url") or "",
            kind=kind_of(status.get("context_uri")),
        )
    return info


@app.after_request
def no_caching(response):
    # Always fetch fresh pages and status, never an old saved copy.
    if request.path not in ("/icon.png", "/manifest.json"):
        response.headers["Cache-Control"] = "no-store"
    return response


@app.route("/api/control/<action>", methods=["POST"])
def api_control(action):
    paths = {"play": "/player/resume", "pause": "/player/pause",
             "next": "/player/next", "back": "/player/prev"}
    if action not in paths:
        abort(404)
    if apple.source() == "apple" and apple.configured() and apple.state() in ("playing", "paused"):
        {"play": apple.resume, "pause": apple.pause, "next": apple.next_track,
         "back": apple.back}[action]()
        now_cache["when"] = 0.0
        return jsonify(ok=True)
    if local.source() == "local" and local.status().get("state") in ("play", "pause"):
        if action == "play":
            local.resume()
        elif action == "pause":
            local.pause_and_save()
        elif action == "next":
            local.next_track()
        else:
            local.back()
        now_cache["when"] = 0.0
        return jsonify(ok=True)
    try:
        speaker_call(paths[action])
    except SpeakerOffline:
        return jsonify(ok=False, message="Speaker is offline")
    now_cache["when"] = 0.0   # show the change on the next refresh
    return jsonify(ok=True)


last_fix = {"when": 0.0}


@app.route("/api/fix/restart-music", methods=["POST"])
def api_fix_music():
    """One-tap fix on the Now page. No PIN: it only restarts the music, and
    only once a minute, so it can't be used to bother the box."""
    if time.time() - last_fix["when"] > 60:
        last_fix["when"] = time.time()

        def worker():
            systemctl("restart", SPEAKER_SERVICE)
            systemctl("restart", "musicbox")
        threading.Thread(target=worker, daemon=True).start()
    now_cache["when"] = 0.0
    return jsonify(ok=True)


# --------------------------------------------------------------------------
# Home-screen icon
# --------------------------------------------------------------------------
ICON_PNG = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAIAAADdvvtQAAAXU0lEQVR42u2deZRVxZ3Hf7+qusvb+r2mu2mQFmRtBBM0mqjMCETJUZMJYpKJgI7GbZjELJPdmGgm7mucMTGemTGKWzRmkRhIjCZBc6JGcANkF5Vum9Ze6Lfdt9x7q37zxwWCwGSR95p7H/U9Hj3n2eedd6s+9dvqd6tw+SdngJbWuxXTQ6ClAdLSAGlpgLQ0QFpaGiAtDZCWBkhLA6SlpQHS0gBpaYC0NEBaWhogLQ2QlgZISwOkpaUB0tIAaWmAtDRAWhogLS0NkJYGSEsDpKUB0tLSAGlpgLQ0QFoaIC0tDZCWBkhLA6SlAdLS0gBpaYC0NEBaGiAtDZCWlgZISwOkpQHSOsQkIvzbERtnHog0QMPDDAIyACBSJH2gBuEHOUfGABCASCkNUB2GmDEikm5Fui4iMsMwm0Y0hhFCRLeQ9csOKcWEwS0bGSclNUA1QwcIPKfIOE+Ondg0YVrz1KNjbaPj7R0oRHSN/54Elfu2V3b0ZTevyb+6Pv/GJq+QFYkUck4y7BhhyK97Qs59pwiIrTNOGPeRRc1HHiNiCQAgJZXnQWP4MAJmGMgFIspqpdi9tes3D/c+/bjnFIxkGoDCvEhCDBAiAHjFfNsxM8fPO7flvccDMlkp7bLtiA0URNMuShAZt2xmmLnXNmz71YM9T/6SccEMK7QeLaQAIWPK85T0J378okmfuAg595ziTnfW6CJSoIjbMW7Htj+1fP0Pb/AKWRFPhtOd8bOnjwohPbJaMeKpo79849hT/9kvOdKtIuONZHL+ckyNjCnpyXIpPeU97cfNzm15pdTbxe1YCH0ZC+H4Kc8zEk3vu/TWkcfNdrM7ABEZh0NMiAy58HJD8VEdx152W6Zzhl9yQjgOYfQISvrv+dyVzUe+r5odQCHgEBYK4ZeKIpE65is32SPapFsJymAaoP835/KK+UmfuGjkcbOq2UEmDDjkhVzIsmO3tE9f/C0gwpAlniECCBnznWLbMTMnfvwit5Bjh7bt2Yshr5gb+YE54+ef5xbzyLkGaP+5LCCOn3cucg6RKucPy+rifqk49tRPxtpGK9cNTwmehWaAmFcqts44oeW9x3ulYqgWWVhyC9eNtY0+fO6ZftkJTzkjNBaIADkf95FFiCwMXp72UShcfNnpOHl+vL0jPEaIhWN1oXQrqbGTmo88xq+Uhn95EZFSSkoppVRKKaU454ZhCCGEEMF/g893/81BQCowQiMPaz36hIMySvtVOAJVxqRbTU84UsQSXjE3bNWOgBsAMAzDsiwwBAADzwXE7NBQtVrdWbokQIatra2ICIYBAOD7nuu6rktEiMiGcy6JMlPe2/34z0KSjYUDIAJEzEw9GmGYtkellIhoWZaI2aBUdnDHuvUbtmza3NXVtWnjJqlUV1dXsVDknBEBAHEuJkycgAATJ00cO25s55Qp4yeMHzVqFBiGqlYrlYpSijFW71o5MiY9t2niNJFMk5SAGqBdq4oZZqxtNElZb9cupRRCJNNpIOru6nr26WefeuoPGzZs6Hlze6VSVkoJIQDANE3GGBEgACAQUU/PdgBaseLJ4P+OHDly8pRJM2fOnD1n1qTJk4Vte6VStVJlvL4YkfStTIuRbHKHBtAwDvrmRgg2UxHJ941k0wnXLDEzLeR7dWJISsk5jzU1OdnsH//49NJHlq5a+Xx/Xz8iWrYVEBP4NUAgRfsGarv/TUSe51UqFd+XmUx62vRpZ5wx7+S5p4zq6PBKTqVS4bxeO3dEipv2C9d+bmDNSiOeOOjti6Ep1iGiEHVyYIF/STY3l/L5hx948J6771m3bh0AxOPxTHMm+AMikn9xu3uvqFkIkUqlEFFK+fzK55995tkxHWMWLDhrwcIF7R0drlN0XZfXpxiBjCEXIemFClO1tz7W2Pf9VCpVrlQffuBH9yy5d+2atZZlpdPpgBv5bnsk9sztE8kEIg7tGLr5plseeujHCxactfDshSNHj3ayWaxTYBSabflGbq8J7EpqRMtLL68+Z9E5X/7iVzZv2tzc3ByLxYJsvFapeACiYRgtLS3ZoexNN9585ryPPfrzRxLptBBCStnAg9ywAEkpLcuyY7Hbbr5l0VmLXn7x5ZaWlgAdVZ+4gYh83xdCtLa2DgwOfP6zX/j3Sz5fKDrJpibpSw1QlOT7fjKZHBgYvPD8i2684SbOeTKV9H1f1T/kDDAyDTOdTv/s54+c9YlPPr9yVbI54/u+Bigy9KRGtK1+efWZZ3xsxe9XBAXAYfYjQUjeMmLEtq6uRQvOfuj+B1Ij2g9O/VoD9Pd6rlRz869+sfSC8y/qH+jPZDK+7x+safN9Px6LCyG+ddnl/3XzDbF4PHi7TQMUYs+Vyfz4/h99evGnS6VSIp446I4jKD7F4/Hrr7n+im9dYdk2EQFpgMLquX796LKvffXrTU1NhmGEJP0JdtzaR7ffdefd119zXSLTKpXUAIUsY5cykUq9vOq5b33z8ng8jogqZC1pvue3trX+8M67Hrp3STKdbpjcvhEAUkqZlt331tufXvyZfD5vmqYKZUMjEcVisW9cetkfVjzZMAw1hAVC5IJ/49LLent7E4lEaCeGiBhjlmV94+uXvdXTY1o2Rb9zN/IASd9PpDO3f+/2Jx5/Isi5Qm4sLcvq6em57NJvCsEbIJiONkBKqngqtXrVqh/cfkcmk4mEU5BSpjPpJ5747QP33Z/INEe9SB1tgBhn1Ur1yu9c7bou45EpsSipUqnUd2/5z60bN1jxWKQrQxEGSEoZSzUte/TRlStXplIpJSMTTxCRYRoDAwP/8993GrYdoV/eUABxzkuF/JK777VtO3KVFenLdDq9fNnyTWvX2om4imw0HVWApJSxpqblv1y+du3aeCK+bwNhJBZAPp+/++57hWVF14tFFSDBRTGbXXL3PZZlRZGeYA00NTUt++WyDatX2/F4RJ8ikgApqexk4pk/Pr1u3bp4vI72H6G+Lz5wwXO53NKljwrLjqgXi2wMpOiRR34BCDXfmUQAhsAQCMAnkAREOz/BOqyERCLxm8ceH3r7LcM0oujIogcQEZm22dPdtWrlqnisxpafIUgCx6eSTxwhZWBCoMmx7FPRI1dRbTEiItMyt23b9vzzL1jR9GLRO0JFKWXYsaeffra/v7+GxcMAi6JHrRY7PmMemRbtNk8ZCAAVSX1VtTXvr8163Y60OAoGtZprBFRK/e53v//Q6adHsc8jegAhICj11FN/QMRajThD8BVIon/qsGe3WyMsRgSSSBIAQFLgqBg/utk4bYz94qC3tLtc8FRMoKTarAfbtp/708rcjgHbtqVU0ToKMmIujIiEwXM7dmxYv6FW+RdDcCXZHC/pTH58bCwh0PGo5JOrQBJIAo+g5FPRIwSY1W5+eXpyXFI4PjGszROZptnb2/vqq1tNy45cGBQ9gEzLfu3117dv326a5oEPNwL4CuKCfaYzMaPZyHsk9wiZd/8TfAIAeY9GWvyznckJSVGRtWGIcVYqldaueQUNM3JhUPQAQiG2bNpSLpdrdSaGJPrUxPjklMh5xP9ajMwRypLiAhdPSWRM5qlaxNQEiLhh40ZQoTgvoaGzMAJA1tXdrVQNpo4hOD6depgd2B6x7xci7vuiPkeoSGo22aIj4rIWHoeIOOfdXd3kechQA1TPCJoheO7GjZuEEAdo7QPn1Wqz2e1WeX/OCBknKcn3kbG9MArs0FEZY1raOHBHFoRBXdu6BgYHDRGxalAEC4k1eskLEaqSpqeNESbz92fOvGKO2zEjlfacIvn+XgwRAWdwXIupavNMGNEO1yil8UQkhMgODXVt6zrwCJoIEOHItNjvt5CSEz9xcccp85lpDbz0zJYHv+8V8yj+fB4PIriSJqZ4SqCndlauD+i5stmubV3HHHes53kRyuSj5sIQq9VqsVg8wAgaARRBXGC7zX2iPecrOFD3iI+eM+28r1uZVmEnjjh14fTFlysp8Z3fIAmaDNZicZ8O9EijWj2XBuhvGuuajDIB2AxTBr4jlEJUvmdmWjpOnl91BpXvAqlStrf1mJnNU2fsdbTlzm8wUdUiahnusxYP3Rio/p6SCYObFimFyAARCJAxbu2n95QAgA7p0WLRnOJarHgAj6gqaa/YmBlGZbCv/6Wn7VQrKUW+b6VHFLu3ZjetFu9kCAF8gqqkWkUsejd+mFyYEOJAI2gAhlD0qa+iBMM9v4yIuGltefD27c8+xmNxkUzlX9v4yh1X+eUScr47iN71DaqvogTigU998FyRuwJWRAsdz/NaW1snTJzQ09NzgIkYIigFrxb9GSOMvewACuEV8y/d+KVM5wxux7KbVvvlkojF93wPkAgMjt2OX/CVxZBq9Fzu7sOpNUD1w6gmQ0wABsM1Q95ph9l7VwKJUBgojKGNL5EiYcf2ome39X5phycVIK+N4dBBdP2jH0UgjEmTJkopD7DqTwQmhzdL8sVBL75vbwYREIlYwkgkAdle9CgCi2N3Sb64w42JA/VfiOi67piOMcGbtbqdo94mCMaOPbxGQStYDJd2l3tLcr/9PaQUKbVXokUAHIEAHnyjFPQoHnhLgJRyzJgxph2LXGd0BPfCfH/KlCmmWYPOBwIQDAqeumtryfHI5n+9R0wRMACL44OvlzbnfZujqkX4LKWcOrUTOI9cUSB6lWi3Wh0/YfzIkSNrUvJXBDGBrxf92zcV855KCFQEap9ORwIIPrc4cob3vVZ68u1q8Mc18cuWZR111HSQvt6NH45ErH3UqMlTJlcqlZqEC5IgLvANx79hXWHNkBcTmBAYtHYQ7YyOBUJcYMLA3rK8dUPhD33VvUvYB5yCTZ3a6dboiXQW9pcDF0LDmDnzxBW/X4EMoRYxgyKwORY8+sHm4rS0cVyLOTHFmwxmcwQAj6jgUXfJf2mH++IOz1VUK9sTOOVyuTxr9qy29lElJ3p7YdEDiDEmq9XZc2Z977bv1/BsFEUgEATiuqy3NuulBLZYvMlAAqhK6quqgqckQYxjTeKePQJoJKK5c0/BA66OaoD+VptfLVcmTZ581HuOWrVyVSKRqFXmEsxeTARWB94s+UFMzRAEosURd0VCtfXIbW1tJ848wauUdB1omKRICcueN++jXh16QANEEMBkGBcYF2hx5AhUU3R2W1PHcWbPmd0xbly1Uo1cABRVgBhjbsmZO/fkjo4Ot+rW62auXTDV72DnoJXszPnzSFEU6YkqQIjoVt2RHYcvWHhWsVhkPJrLgLNCoXDSrJNmzjqpXCxE0X9BdPuBGGeuU1yw4KyOw+tohOqcTwJj7MILz0fGonvIXVQB2mWEOhYuPKtQKNTpbsD6iXNeKBROOukf/2HWSaVCIaJGFCLdkcg4qzrFBYsWjhs3rhK1EhwRMc7/dfHFEM3QpxEAQkTPdUeOHn3pN75WqVQiFEMIIYaGhs4995yZc2aXClGNfiIPUOAInGz2o2fOn3/mGUM7hoIbu8OfQjqO0zm184tf+mIlgq9hNBRAAICMVcvlK759xeTOyU7JCXkwgYjBi8zX33BdqqlJRuoVsAYFCNFz3REtI2686XoEDHlDFmNscHDw65d+9bgTT3QKBRa12L8BAQocWTFfOPb446+6+jthTumFELlc7oILzj/vgvOdbJYL3gCD3yDvhXHBC0NDZ/3L+Z//wuf6+/qFEbpgyDCMgYGBOR+cc/X111TL5Yg7roYDKFjfTrb/ks9/9sKLL+h7u48xFh5TJITo7+//wPEfuOXWW6rlilIKG4WghnozFRHdSvXKa6665HOXOI4T3M910H8S5zybzc790Nw77/rfTCbt+17UM69GBohIlR3nm/9x5TXXXu04juu6B7FIzRgjoP7+/rPPOXvJfUuSiUSldgeraYDqxRBDLA71Lzhn0T33LWlpacnlckKI4XcZQohyuex7/tXXXnXVtVeVHcfzvAajBxrzcAVEznkxl5v1wTk/e+QnJ5/8wcHBQSnlsJUZOedBun7EEePu+9F9FyxeXHFKYfCnGqC/M7fP5VpbW++8+85rrr3asqzBwcHg83qjk8/nHce56OILf/rIT9///uOKOwaRYcNEzYcKQMF0VqvVSql07kUX/uRnDy86exEADA0NBf6lhjMaRMq70Zk9e9a999/z7Wuusi2rWChwIRp4kBv52WDX2+bFHYPjxx9xw603f+r88+5Zcs+yZcsHBwcTiYRpmsEN8++um333kVCe5+VzeWGI2XNmX3Dh+bNmnQQMi0NDjDHOeWOPcGgA2t+BujUzRUJUKhUqlzs7p1z/3ZvPPe/cXyz9xW8ee3zbtm1SqljMNk0zQIGIApj2RSqwWLuPdiAiz/PK5TIRtba1nf7h0+fNnzd71knAmFMoANXXV4aoxHXwfwIRcuEVsuW+7Va6xa/P/mLAR7lcplJp6tTOad++YvG/LV71/PMrfvf75/60sre313GcwGCYpgkAhhD4zpjX8zwAcF1X+lIqaVlWa1vrrNmz5s495fgTTxg7/ghQyikUgr3Seo4V95xCqa+HheNA4FBYIGTML1cqO/qwzgZ/T4wSifipp5926odPzw4MbN362uo1azdt2NDd/WZXV5eScmgoWy2VdqJMgAxbW1sBoKNjzGFjxkyd2nnUUdM7p3a2jxoFQvjlcjGbHZ5DDhkT1UK/mxtiTGgLtJsgIKVym9cc9o+nDcMRXcE0SymLuRwAxGKxY49937EnnACklOsGyVpXV3dx1255YFQmTpjAGMs0Z8xYDBgH6XvVqlMsBvn58MQ6RMQMM//GJreQMxJJCsFRHuEAiIgJI/fqelmtwHA19ASpU0CS4zhExYCtdDoNAMce2wbvMCfkVV0A8H0/wC4Ihoa7tEOEnOe2vELKD0kvbCgAIqW4aeff2FTs3poaN1lWyjCME7PXkWe+7wcRD73z9OfdQfRBTKxQcK+QG1zzHDdtCsdJQmGpA6HgnlPo+s3DzDAO7sV9u00L52xP1epovXe/zKQ04qm3nn0i9/pGbsVCchxnWAAKRqf36cdzWzdyK0bRvMK4vmRz7jmFbb/+MRdGeC7HDFEleqcR+vVD3I4BaYD2WmC+kUy/9cwTua3ruR2H0CwwFqYxkmYy/eaTv9z+1HKzqZl8X3Pz5xjRjhe6tmx+8PsilqAwra5w7YUREONi/Q9vKL75mkgkKZo3INVYSgXlsXV3XFUdGmR73BikAdpfPm+YXiG75rbLvWKex+IkD2k7REoB58KOr7/zuh3rXzCSKVLhWlQsfEMmRTyZ3bzmheu+4GYHjWSapA90KN5oQtLnls2E8codV3Y99hMjlQ6hSeZnTx8VvpEjbsfKb/f0PvN4cswRTROnkfQpeOGrQbtq9g0HkTEz3VzqeePlm7/69nO/M5sy4XTooQQoYMi0/FKh94+PyWolNXaS3dxGSpLvA9DOq5UbCiYCAiICpZAxM5VWnrv9yWVrvnd58c3XjGRTaMNBXP7JGeGtfCAjIK+Yj7WNPnzumR2nzI+1HUZEynNJ+iQlEQE2AjyMC+ScGSYy7hVzbz37222/fjC3dYOIJZgwwhb3RAagnT+Rc+W6ftmJt49pPfrE9JT3ZiZOMzMtRjKNjDfEhW/oFfNeMVd4Y1N2yyuDa57Lv7aRGQYPbngJd/wXAYACW4SMKdeVlRIAGMm0SDYlRh2OPAAIo2x9CJGV+3rc3JBbyJHyuWkHOxUUhWpqRFpaiUhKFMJIZYL0xM0OVPq3N4LxASACZhjIuZFIAiIpFWafFU2AdmNEcqdBEoYwzMYJoYmAIIo7gCLCQ06H9nW34ZC+tVlLA6SlAdLSAGlpgLS0NEBaGiAtDZCWBkhLSwOkpQHS0gBpaYC0tDRAWhogLQ2QlgZIS0sDpKUB0tIAaWmAtDRAWloaIC0NkJYGSEsDpKWlAdLSAGlpgLQ0QFpaGiAtDZCWBkhLA6SlpQHS0gBpaYC0NEBaGiAtLQ2QlgZISwOkdajp/wCFxXjTddgMewAAAABJRU5ErkJggg==")


@app.route("/icon.png")
def icon():
    return Response(ICON_PNG, mimetype="image/png",
                    headers={"Cache-Control": "max-age=86400"})


@app.route("/manifest.json")
def manifest():
    return jsonify(name=speaker_name(), short_name=speaker_name()[:12], start_url="/",
                   display="standalone", background_color="#f6f1e9",
                   theme_color="#b5562f",
                   icons=[{"src": "/icon.png", "sizes": "192x192", "type": "image/png"}])


# --------------------------------------------------------------------------
# Tiles
# --------------------------------------------------------------------------
@app.route("/tiles")
@needs_pin
def tiles_page():
    tokens = load_tokens()
    state = reader_state()
    on_reader = state.get("token")
    return render_template(
        "tiles.html", tab="tiles", tokens=tokens, on_reader=on_reader,
        on_reader_new=bool(on_reader and on_reader not in tokens),
        teaching=state.get("teaching"), reader_ok=state.get("reader_ok", True) is not False,
        saved=request.args.get("saved"), writing=request.args.get("writing"),
    )


@app.route("/coins")
@app.route("/coins/<path:_>")
def old_coins(_=None):
    return redirect(url_for("tiles_page"))


@app.route("/api/reader")
def api_reader():
    state = reader_state()
    return jsonify(token=state.get("token"), known=state.get("known"),
                   teaching=state.get("teaching"), write=state.get("write"),
                   reader_ok=state.get("reader_ok", True) is not False)


def ask_box_to_write(token_id, uri):
    """If the tile is sitting on the box, ask the tile program to save the
    music's link onto it. Returns the request id, or '' if the tile isn't there."""
    if local.is_local_uri(uri) or apple.is_apple_uri(uri):
        return ""          # a folder on this box's drive can't travel on the tile
    if reader_state().get("token") != token_id:
        return ""
    request_id = f"{time.time():.3f}"
    write_json(WRITE_REQUEST, {"token": token_id, "uri": uri, "id": request_id})
    return request_id


def save_tile(token_id, uri, name="", image=""):
    if not name:
        name, image = describe(sp, uri)
    link_token(token_id, uri, name, image)
    if not setup_done() and pin_is_set():
        mark_setup_done()
    return redirect(url_for("tiles_page", saved=token_id,
                            writing=ask_box_to_write(token_id, uri) or None))


@app.route("/tiles/<token_id>", methods=["GET", "POST"])
@needs_pin
def tile_music_page(token_id):
    query = request.values.get("q", "").strip()
    results, error = [], ""
    if request.method == "POST":
        uri = spotify_uri_from_link(request.form.get("link", ""))
        if not uri:
            error = ("That doesn't look like a Spotify link. In Spotify, open the album, "
                     "tap the three dots, then Share, then Copy link.")
        elif uri.split(":")[1] == "audiobook":
            error = ("That's an audiobook. Spotify doesn't let speakers like this one play "
                     "audiobooks yet. Albums, playlists, songs and podcasts all work.")
        else:
            return save_tile(token_id, uri)
    if query and signed_in():
        try:
            found = sp.search(q=query, type="album,playlist", limit=6)
            for album in (found.get("albums") or {}).get("items") or []:
                if not album:
                    continue
                artists = ", ".join(a["name"] for a in album.get("artists", []))
                results.append({
                    "uri": album["uri"], "kind": "Album",
                    "name": f"{album['name']} · {artists}" if artists else album["name"],
                    "image": (album.get("images") or [{}])[0].get("url", ""),
                })
            for pl in (found.get("playlists") or {}).get("items") or []:
                if not pl:
                    continue
                results.append({
                    "uri": pl["uri"], "kind": "Playlist", "name": pl["name"],
                    "image": (pl.get("images") or [{}])[0].get("url", ""),
                })
        except NotSignedIn:
            error = "Search needs the optional Spotify sign-in (Settings > Spotify)."
        except Exception as err:
            error = f"Search didn't work: {str(err)[:150]}"
    apple_on = apple_supported() and apple.configured()
    apple_results, apple_error = [], request.args.get("apple_error", "")
    aquery = request.args.get("aq", "").strip()
    if apple_on and aquery:
        try:
            apple_results = apple.search(aquery)
            if not apple_results:
                apple_error = "No Apple Music albums came back. Check Settings > Apple Music."
        except apple.AppleError as err:
            apple_error = f"Apple Music search didn't work: {str(err)[:150]}"
    current = load_tokens().get(token_id)
    try:
        shelves = artist_shelves(local.get_albums())
    except local.MPDError:
        shelves = []
    return render_template("tile_music.html", tab="tiles", token_id=token_id, query=query,
                           results=results, error=error, current=current,
                           can_search=signed_in(), shelves=shelves, dur=local.duration_text,
                           apple_on=apple_on, apple_results=apple_results,
                           apple_error=apple_error, aquery=aquery)


@app.route("/tiles/apple", methods=["POST"])
@needs_pin
def tile_apple():
    token_id = request.form["token"]
    uri = apple.parse_link(request.form.get("uri") or request.form.get("link", ""))
    if not uri:
        return redirect(url_for("tile_music_page", token_id=token_id, apple_error=(
            "That doesn't look like an Apple Music album or playlist link. In Apple Music, "
            "open it, tap the three dots, then Share, then Copy Link.")))
    name, image = request.form.get("name", ""), request.form.get("image", "")
    if not name and apple.configured():
        name, image = apple.describe_link(uri)
    return save_tile(token_id, uri, name or uri, image)


@app.route("/tiles/save", methods=["POST"])
@needs_pin
def tile_save():
    uri = request.form["uri"]
    if not spotify_uri_from_link(uri):
        abort(400)
    return save_tile(request.form["token"], uri, request.form.get("name", ""),
                     request.form.get("image", ""))


@app.route("/tiles/write", methods=["POST"])
@needs_pin
def tile_write():
    token_id = request.form["token"]
    entry = load_tokens().get(token_id)
    if not entry:
        abort(404)
    return redirect(url_for("tiles_page", writing=ask_box_to_write(token_id, entry["uri"]) or None,
                            saved=None))


@app.route("/tiles/rename", methods=["POST"])
@needs_pin
def tile_rename():
    tokens = load_tokens()
    token_id = request.form["token"]
    if token_id in tokens:
        tokens[token_id]["name"] = request.form.get("name", "").strip()[:80]
        save_tokens(tokens)
    return redirect(url_for("tile_page", token_id=token_id, renamed=1))


@app.route("/tile/<token_id>")
@needs_pin
def tile_page(token_id):
    tile = load_tokens().get(token_id)
    if not tile:
        return redirect(url_for("tiles_page"))
    return render_template("tile.html", tab="tiles", tid=token_id, t=tile,
                           on_reader=reader_state().get("token") == token_id,
                           renamed=request.args.get("renamed"), arterr=request.args.get("arterr"))


TILE_ART_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tile_art")
ART_EXTENSIONS = (".jpg", ".jpeg", ".png", ".webp", ".gif")


def album_art_url(key):
    """Web address of an album's cover picture, or '' if it has none."""
    if not key:
        return ""
    try:
        album = local.album_by_key(key)
        if album and local.cover_for(album):
            return "/art/album?key=" + urllib.parse.quote(key)
    except local.MPDError:
        pass
    return ""


@app.route("/art/album")
def art_album():
    try:
        album = local.album_by_key(request.args.get("key", ""))
        cover = local.cover_for(album) if album else None
    except local.MPDError:
        cover = None
    if not cover:
        return Response(status=404)
    return send_file(cover)


@app.route("/art/folder")
def art_folder():
    cover = local.find_cover(request.args.get("path", "").strip("/"))
    if not cover:
        abort(404)
    return send_file(cover)


def tile_art_file(token_id):
    if not re.fullmatch(r"[A-Za-z0-9]{2,40}", token_id or ""):
        return None
    for ext in ART_EXTENSIONS:
        path = os.path.join(TILE_ART_DIR, token_id + ext)
        if os.path.exists(path):
            return path
    return None


@app.route("/art/tile/<token_id>")
def art_tile(token_id):
    path = tile_art_file(token_id)
    if not path:
        abort(404)
    return send_file(path)


@app.route("/tile/<token_id>/art", methods=["POST"])
@needs_pin
def tile_art(token_id):
    tokens = load_tokens()
    entry = tokens.get(token_id)
    if not entry or not re.fullmatch(r"[A-Za-z0-9]{2,40}", token_id):
        abort(404)
    os.makedirs(TILE_ART_DIR, exist_ok=True)
    for ext in ART_EXTENSIONS:                      # drop any older picture
        try:
            os.remove(os.path.join(TILE_ART_DIR, token_id + ext))
        except OSError:
            pass
    if request.form.get("remove"):
        entry["image"] = album_art_url(local.path_of(entry["uri"])) if local.is_local_uri(entry["uri"]) else ""
        save_tokens(tokens)
        return redirect(url_for("tile_page", token_id=token_id, renamed=None))
    f = request.files.get("picture")
    name = (f.filename if f else "") or ""
    ext = os.path.splitext(name)[1].lower()
    if not f or ext not in ART_EXTENSIONS:
        return redirect(url_for("tile_page", token_id=token_id, arterr="Pick a picture (JPG or PNG)."))
    dest = os.path.join(TILE_ART_DIR, token_id + (".jpg" if ext == ".jpeg" else ext))
    raw = f.read(8 * 1024 * 1024 + 1)
    if len(raw) > 8 * 1024 * 1024:
        return redirect(url_for("tile_page", token_id=token_id, arterr="That picture is too big (8 MB at most)."))
    try:                                               # shrink phone photos if the box has Pillow
        import io
        from PIL import Image, ImageOps
        img = ImageOps.exif_transpose(Image.open(io.BytesIO(raw))).convert("RGB")
        img.thumbnail((700, 700))
        dest = os.path.join(TILE_ART_DIR, token_id + ".jpg")
        img.save(dest, "JPEG", quality=85)
    except ImportError:
        if len(raw) > 1_500_000:
            return redirect(url_for("tile_page", token_id=token_id,
                                    arterr="That picture is too big for this box (1.5 MB at most). Try a smaller one."))
        with open(dest, "wb") as out:
            out.write(raw)
    except Exception:
        return redirect(url_for("tile_page", token_id=token_id, arterr="That file isn't a picture the box can read."))
    entry["image"] = f"/art/tile/{token_id}?v={int(time.time())}"
    save_tokens(tokens)
    return redirect(url_for("tile_page", token_id=token_id, renamed=None))


def store_picture(upload, base):
    """Save an uploaded picture as base.jpg/.png (shrunk if Pillow is installed).
    Returns an error message, or None if it worked."""
    ext = os.path.splitext(upload.filename or "")[1].lower()
    if ext not in ART_EXTENSIONS:
        return "Pick a picture (JPG or PNG)."
    raw = upload.read(8 * 1024 * 1024 + 1)
    if len(raw) > 8 * 1024 * 1024:
        return "That picture is too big (8 MB at most)."
    os.makedirs(os.path.dirname(base), exist_ok=True)
    for old in ART_EXTENSIONS:
        try:
            os.remove(base + old)
        except OSError:
            pass
    try:
        import io
        from PIL import Image, ImageOps
        img = ImageOps.exif_transpose(Image.open(io.BytesIO(raw))).convert("RGB")
        img.thumbnail((700, 700))
        img.save(base + ".jpg", "JPEG", quality=85)
    except ImportError:
        if len(raw) > 1_500_000:
            return "That picture is too big for this box (1.5 MB at most). Try a smaller one."
        with open(base + (".jpg" if ext == ".jpeg" else ext), "wb") as out:
            out.write(raw)
    except Exception:
        return "That file isn't a picture the box can read."
    return None


@app.route("/music/cover", methods=["POST"])
@needs_pin
def music_cover():
    """Choose (or remove) the cover picture for an album."""
    key = request.form.get("key", "").strip("/")
    if not key or not local.safe_join(key.partition("|")[0]):
        abort(400)
    base = local.custom_cover_base(key)
    if request.form.get("remove"):
        for ext in ART_EXTENSIONS:
            try:
                os.remove(base + ext)
            except OSError:
                pass
    else:
        picture = request.files.get("picture")
        if not picture or not picture.filename:
            return redirect(url_for("music_album", key=key, error="Pick a picture first."))
        err = store_picture(picture, base)
        if err:
            return redirect(url_for("music_album", key=key, error=err))
    url = album_art_url(key)
    tokens = load_tokens()                         # tiles that play this album show it too
    for tid, entry in tokens.items():
        if entry.get("uri") == "local:" + key and not tile_art_file(tid):
            entry["image"] = url
    save_tokens(tokens)
    return redirect(url_for("music_album", key=key, message="Cover saved." if url else "Cover removed."))


@app.route("/tiles/delete", methods=["POST"])
@needs_pin
def tile_delete():
    tokens = load_tokens()
    tokens.pop(request.form["token"], None)
    save_tokens(tokens)
    return redirect(url_for("tiles_page"))


# --------------------------------------------------------------------------
# Local music: files on a USB stick or on the box's memory card
# --------------------------------------------------------------------------
UPLOAD_TEMP = os.path.join(os.path.dirname(os.path.abspath(__file__)), "uploads_tmp")
os.makedirs(UPLOAD_TEMP, exist_ok=True)
tempfile.tempdir = UPLOAD_TEMP      # big uploads wait on the memory card, not in memory
UPLOAD_EXTRAS = (".jpg", ".jpeg", ".png", ".cue")
SPACE_RESERVE = 300 * 1024 * 1024   # always leave this much free on the memory card


def safe_name(text):
    text = re.sub(r'[\x00-\x1f<>:"|?*\\]', "_", text or "").strip(". ")
    return text[:100]


def safe_folder(text):
    """'Bedtime / Stories' -> 'Bedtime/Stories'; never leaves the music folder."""
    parts = [safe_name(p) for p in (text or "").replace("\\", "/").split("/")]
    parts = [p for p in parts if p and p not in (".", "..")]
    if not parts or parts[0].lower() == "usb":
        parts = ["Uploads"] + parts[1:] if parts and parts[0].lower() == "usb" else ["Uploads"]
    return "/".join(parts[:3])


def music_free_bytes():
    try:
        return shutil.disk_usage(local.MUSIC_DIR).free
    except OSError:
        return 0


def artist_shelves(albums):
    """[(artist, [albums oldest first])] in the order albums() already sorted them."""
    shelves = []
    for a in albums:
        name = a["artist"] or "Unknown artist"
        if shelves and shelves[-1][0] == name:
            shelves[-1][1].append(a)
        else:
            shelves.append((name, [a]))
    return shelves


@app.route("/music")
@needs_pin
def music_page():
    os.makedirs(local.MUSIC_DIR, exist_ok=True)
    albums, player_ok = [], True
    try:
        albums = local.get_albums()
    except local.MPDError:
        player_ok = False
    state = reader_state()
    return render_template(
        "music.html", tab="tiles", shelves=artist_shelves([a for a in albums if not a["book"]]),
        books=[a for a in albums if a["book"]], player_ok=player_ok, dur=local.duration_text,
        album_count=len(albums), usb=local.usb_present(), locked=unplug_proof_on(),
        free_gb=round(music_free_bytes() / 1e9, 1), on_reader=state.get("token"),
        message=request.args.get("message"), error=request.args.get("error"))


@app.route("/music/album")
@needs_pin
def music_album():
    key = request.args.get("key", "").strip("/")
    try:
        album = local.album_by_key(key)
        songs = local.songs_in(key) if album else []
    except local.MPDError:
        album, songs = None, []
    if not album:
        return back_to_music(error="That album isn't on the box any more.")
    tracks = [{"n": local.number_of(s.get("Track")) or i + 1,
               "title": s.get("Title") or os.path.splitext(os.path.basename(s["file"]))[0],
               "length": local.duration_text(local.seconds_of(s)) if local.seconds_of(s) else ""}
              for i, s in enumerate(songs)]
    state = reader_state()
    return render_template(
        "album.html", tab="tiles", a=album, tracks=tracks, dur=local.duration_text,
        art=album_art_url(key), remembered=key in local.load_places(), locked=unplug_proof_on(),
        on_reader=state.get("token"), message=request.args.get("message"),
        error=request.args.get("error"), has_custom=bool(local.custom_cover(key)))


def back_to_music(**kw):
    return redirect(url_for("music_page", **kw))


@app.route("/music/upload", methods=["POST"])
@needs_pin
def music_upload():
    if unplug_proof_on():
        return back_to_music(error="Unplug protection is on, so new files wouldn't be kept. "
                                   "Turn on maintenance mode in Settings first, or use a USB stick.")
    files = [f for f in request.files.getlist("files") if f and f.filename]
    if not files:
        return back_to_music(error="Pick some music files first.")
    if (request.content_length or 0) + SPACE_RESERVE > music_free_bytes():
        return back_to_music(error="There isn't enough room on the box's memory card for that. "
                                   "Try a USB stick instead.")
    fallback = safe_folder(request.form.get("folder"))     # only for files with no album tag
    if not local.safe_join(fallback):
        abort(400)
    incoming = os.path.join(UPLOAD_TEMP, f"incoming-{int(time.time() * 1000)}")
    os.makedirs(incoming, exist_ok=True)
    skipped = 0
    try:
        for f in files:
            name = safe_name(os.path.basename(f.filename.replace("\\", "/")))
            if not name.lower().endswith(local.AUDIO_EXTENSIONS + UPLOAD_EXTRAS):
                skipped += 1
                continue
            f.save(os.path.join(incoming, unique_incoming(incoming, name)))
        result = local.file_batch(incoming, fallback)
    finally:
        shutil.rmtree(incoming, ignore_errors=True)
    skipped += result["skipped"]
    if result["added"]:
        local.update_in_background()
    names = [(f"{a} \u00b7 {b}" if a else b) for a, b in result["albums"]]
    msg = f"Added {result['added']} track{'s' if result['added'] != 1 else ''}"
    if names:
        msg += " to " + ", ".join(names[:3]) + (f" and {len(names) - 3} more" if len(names) > 3 else "")
    msg += "."
    if skipped:
        msg += f" Skipped {skipped} that weren't music."
    return back_to_music(message=msg) if result["added"] else back_to_music(error="Nothing was added. " + msg)


def unique_incoming(folder, name):
    return local.unique_name(folder, name)


@app.route("/music/details", methods=["POST"])
@needs_pin
def music_details():
    """Show an album under a different name/artist/year (the files stay as they are)."""
    key = request.form.get("key", "").strip("/")
    if not key or not local.safe_join(key.partition("|")[0]):
        abort(400)
    local.set_override(key, request.form.get("album", ""), request.form.get("artist", ""),
                       request.form.get("year", ""))
    info = local.album_by_key(key)
    if info:                                       # tiles that play it carry the new name
        tokens = load_tokens()
        for entry in tokens.values():
            if entry.get("uri") == "local:" + key:
                entry["name"] = f"{info['album']} \u00b7 {info['artist']}" if info["artist"] else info["album"]
                entry["album"], entry["artist"] = info["album"], info["artist"]
        save_tokens(tokens)
    return redirect(url_for("music_album", key=key, message="Details saved."))


@app.route("/music/delete", methods=["POST"])
@needs_pin
def music_delete():
    rel = request.form.get("path", "").strip("/")
    full = local.safe_join(rel)
    if unplug_proof_on():
        return back_to_music(error="Turn on maintenance mode in Settings to remove files.")
    if not rel or "|" in rel or rel.split("/")[0] == "USB" or not full or not os.path.isdir(full):
        abort(400)
    shutil.rmtree(full, ignore_errors=True)
    local.forget_place(rel)
    local.update_in_background()
    return back_to_music(message=f"Removed {rel}.")


@app.route("/music/play", methods=["POST"])
@needs_pin
def music_play():
    rel = request.form.get("path", "").strip("/")
    try:
        try:
            speaker_call("/player/pause")
        except SpeakerOffline:
            pass
        local.play_path(rel)
    except (local.NoMusic, local.MPDError) as err:
        return back_to_music(error=str(err))
    now_cache["when"] = 0.0
    return redirect("/")


@app.route("/music/restart", methods=["POST"])
@needs_pin
def music_restart():
    rel = request.form.get("path", "").strip("/")
    local.forget_place(rel)
    return back_to_music(message=f"{os.path.basename(rel)} will start from the beginning next time.")


@app.route("/music/rescan", methods=["POST"])
@needs_pin
def music_rescan():
    local.update(wait=True)
    return back_to_music(message="Looked for new music.")


@app.route("/tiles/local", methods=["POST"])
@needs_pin
def tile_local():
    rel = request.form.get("path", "").strip("/")
    if not rel or not local.safe_join(rel.partition("|")[0]):
        abort(400)
    folder, sep, album_name = rel.partition("|")
    if not local.safe_join(folder):
        abort(400)
    uri = local.make_uri(folder, album_name if sep else None)
    info = None
    try:
        info = local.album_by_key(rel)
    except local.MPDError:
        pass
    name = (f"{info['album']} \u00b7 {info['artist']}" if info and info["artist"]
            else info["album"] if info else os.path.basename(folder))
    link_token(request.form["token"], uri, name, album_art_url(rel), on_tile=False)
    if info:                                  # so the tile can find its album again if files move
        tokens = load_tokens()
        tokens[request.form["token"]].update(album=info["album"], artist=info["artist"],
                                            kind="Audiobook" if info["book"] else "Album")
        save_tokens(tokens)
    if not setup_done() and pin_is_set():
        mark_setup_done()
    return redirect(url_for("tiles_page", saved=request.form["token"]))


# --------------------------------------------------------------------------
# Wi-Fi (NetworkManager, through the nmcli command)
# --------------------------------------------------------------------------
def nm(*args, timeout=30):
    try:
        result = subprocess.run(["nmcli", *args], capture_output=True, text=True,
                                timeout=timeout)
        return result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired:
        return 1, "", "timed out"


def split_terse(line):
    """nmcli -t output uses ':' between fields and '\\:' inside them."""
    parts, cur, escaped = [], "", False
    for ch in line:
        if escaped:
            cur += ch
            escaped = False
        elif ch == "\\":
            escaped = True
        elif ch == ":":
            parts.append(cur)
            cur = ""
        else:
            cur += ch
    parts.append(cur)
    return parts


def current_wifi():
    code, out, _ = nm("-t", "-f", "ACTIVE,SSID", "device", "wifi", "list", "--rescan", "no",
                      timeout=10)
    for line in out.splitlines():
        fields = split_terse(line)
        if len(fields) >= 2 and fields[0] == "yes":
            return fields[1]
    return ""


def wifi_connected():
    """True if wlan0 is joined to a normal network (not our setup hotspot)."""
    code, out, _ = nm("-t", "-f", "DEVICE,STATE,CONNECTION", "device", timeout=10)
    for line in out.splitlines():
        fields = split_terse(line)
        if len(fields) >= 3 and fields[0] == "wlan0":
            return fields[1] == "connected" and fields[2] != HOTSPOT_NAME
    return False


nearby_cache = {"list": [], "when": 0.0, "channel": 6}


def scan_nearby(fresh=True):
    """Networks around the box. fresh=False reads NetworkManager's last list,
    which is instant; a fresh scan can take up to 30 seconds."""
    code, out, _ = nm("-t", "-f", "SSID,SIGNAL,SECURITY,CHAN", "device", "wifi", "list",
                      "--rescan", "yes" if fresh else "no", timeout=30 if fresh else 8)
    best, crowd = {}, {1: 0, 6: 0, 11: 0}
    for line in out.splitlines():
        fields = split_terse(line)
        if len(fields) >= 4 and fields[3].isdigit():
            chan = int(fields[3])
            for c in crowd:                 # 2.4 GHz channels overlap 4 either side
                if abs(chan - c) < 5:
                    crowd[c] += 1 + int(fields[1] or 0) / 25
        if len(fields) < 3 or not fields[0] or fields[0].startswith(HOTSPOT_SSID_PREFIX):
            continue
        ssid, signal, security = fields[0], int(fields[1] or 0), fields[2]
        if ssid not in best or signal > best[ssid]["signal"]:
            best[ssid] = {"ssid": ssid, "signal": signal,
                          "secure": bool(security and security != "--")}
    if out.strip():
        nearby_cache["channel"] = min(crowd, key=crowd.get)
    if best:
        nearby_cache.update(list=sorted(best.values(), key=lambda n: -n["signal"]),
                            when=time.time())
    return nearby_cache["list"]


scan_lock = threading.Lock()


def scan_in_background():
    """Refresh the nearby list without making anyone wait for it."""
    def worker():
        if scan_lock.acquire(blocking=False):
            try:
                scan_nearby()
            finally:
                scan_lock.release()
    threading.Thread(target=worker, daemon=True).start()


@app.route("/api/wifi/nearby")
@needs_pin
def api_wifi_nearby():
    return jsonify(nearby=nearby_cache["list"], scanning=scan_lock.locked())


def saved_networks():
    code, out, _ = nm("-t", "-f", "NAME,TYPE", "connection", "show", timeout=10)
    networks = []
    for line in out.splitlines():
        fields = split_terse(line)
        if len(fields) >= 2 and fields[1] == "802-11-wireless" and fields[0] != HOTSPOT_NAME:
            _, ssid, _ = nm("-g", "802-11-wireless.ssid", "connection", "show", fields[0],
                            timeout=10)
            networks.append({"profile": fields[0], "ssid": ssid.strip() or fields[0]})
    return networks


def save_network(ssid, password):
    """Create (or replace) a saved network. Returns an error message or ''."""
    profile = f"Music Box: {ssid}"
    nm("connection", "delete", "id", profile, timeout=15)
    args = ["connection", "add", "type", "wifi", "ifname", "wlan0",
            "con-name", profile, "ssid", ssid, "connection.autoconnect", "yes"]
    if password:
        args += ["wifi-sec.key-mgmt", "wpa-psk", "wifi-sec.psk", password]
    code, _, err = nm(*args, timeout=20)
    return "" if code == 0 else (err.strip() or "Couldn't save that network.")


def join_later(ssid):
    """Leave setup mode and join the new network (after the page has loaded)."""
    def worker():
        time.sleep(3)
        setup.stop_hotspot()
        code, _, err = nm("connection", "up", "id", f"Music Box: {ssid}", timeout=45)
        if code != 0:
            print(f"Couldn't join {ssid}: {err.strip()}", flush=True)
        elif wifi_connected():
            check_after_joining()
    threading.Thread(target=worker, daemon=True).start()


@app.route("/wifi", methods=["GET", "POST"])
@needs_pin
def wifi_page():
    message, error = "", ""
    if request.method == "POST":
        ssid = (request.form.get("ssid_typed") or request.form.get("ssid") or "").strip()
        password = request.form.get("password", "")
        if not ssid:
            error = "Pick a network or type its name."
        elif password and len(password) < 8:
            error = "Wi-Fi passwords are at least 8 characters."
        else:
            error = save_network(ssid, password)
            if not error:
                if setup.hotspot_on:
                    join_later(ssid)
                    return render_template("joining.html", tab="", ssid=ssid, host=address(),
                                           fallback=fallback_host() + ".local",
                                           first_time=not setup_done())
                message = (f"Saved {ssid}. The box will use it whenever it's "
                           "nearby.")
    if setup.hotspot_on:
        nearby = nearby_cache["list"]          # can't scan while hosting the hotspot
    else:
        # This used to wait for a full Wi-Fi scan (up to 30 seconds), so tapping
        # Wi-Fi in Settings looked like it did nothing. Now the page opens at once
        # with the last known list, and a fresh scan fills in a moment later.
        nearby = scan_nearby(fresh=False) or nearby_cache["list"]
        scan_in_background()
    return render_template("wifi.html", tab="" if setup.hotspot_on else "settings",
                           nearby=nearby, saved=saved_networks(),
                           current=current_wifi(), setup_mode=setup.hotspot_on,
                           first_time=not setup_done(), step_count=len(SETUP_STEPS),
                           message=message, error=error)


@app.route("/wifi/forget", methods=["POST"])
@needs_pin
def wifi_forget():
    profile = request.form["profile"]
    code, out, _ = nm("-t", "-f", "NAME", "connection", "show", "--active", timeout=10)
    active = [split_terse(line)[0] for line in out.splitlines()]
    if profile not in active and profile != HOTSPOT_NAME:
        nm("connection", "delete", "id", profile, timeout=15)
    return redirect(url_for("wifi_page"))


def has_saved_networks():
    return bool(saved_networks())


def phones_on_hotspot():
    """How many phones are joined to our setup network right now."""
    try:
        r = subprocess.run(["iw", "dev", "wlan0", "station", "dump"], capture_output=True,
                           text=True, timeout=5)
        if r.returncode == 0:
            return r.stdout.count("Station ")
    except (OSError, subprocess.TimeoutExpired):
        pass
    try:                     # no "iw": fall back to who answered us lately
        r = subprocess.run(["ip", "neigh", "show", "dev", "wlan0"], capture_output=True,
                           text=True, timeout=5)
        return sum(1 for l in r.stdout.splitlines()
                   if l.startswith("10.42.0.") and any(w in l for w in ("REACHABLE", "DELAY", "PROBE")))
    except (OSError, subprocess.TimeoutExpired):
        return 0


class SetupMode:
    """Watches Wi-Fi. No known network for a while -> start the setup hotspot.

    The hotspot must never hang around for days (on 2026-11-12 a box stuck in
    setup mode wrecked the Wi-Fi of the box next to it), so:
      - while a phone is joined (or used the page in the last 2 minutes) it stays on;
      - otherwise, every 3 minutes it steps aside for 45 seconds to look for a saved network;
      - after 20 minutes with nobody joined it switches off for good and the box
        just keeps trying its saved Wi-Fi. Unplug/replug brings setup mode back.
    """

    def __init__(self):
        self.hotspot_on = False
        self.started = 0.0
        self.last_visit = 0.0
        self.last_peek = 0.0
        self.idle_since = 0.0
        self.gave_up = False
        self.has_saved = True
        self.offline_since = None

    def start_hotspot(self):
        scan_nearby()   # remember what's around; can't scan once the hotspot is up
        self.has_saved = has_saved_networks()
        nm("connection", "delete", "id", HOTSPOT_NAME, timeout=15)
        # Plain WPA2 (no WPA3/PMF): some phones won't join the Pi's hotspot otherwise.
        code, _, err = nm("connection", "add", "type", "wifi", "ifname", "wlan0",
                          "con-name", HOTSPOT_NAME, "autoconnect", "no", "ssid", setup_ssid(),
                          "802-11-wireless.mode", "ap", "802-11-wireless.band", "bg",
                          "802-11-wireless.channel", str(nearby_cache.get("channel", 6)),
                          "ipv4.method", "shared", "ipv4.addresses", f"{HOTSPOT_ADDRESS}/24",
                          "ipv6.method", "disabled",
                          "wifi-sec.key-mgmt", "wpa-psk", "wifi-sec.psk", HOTSPOT_PASSWORD,
                          "wifi-sec.proto", "rsn", "wifi-sec.pairwise", "ccmp",
                          "wifi-sec.group", "ccmp", "wifi-sec.pmf", "disable", timeout=20)
        if code == 0:
            code, _, err = nm("connection", "up", "id", HOTSPOT_NAME, timeout=30)
        if code == 0:
            now = time.time()
            self.hotspot_on, self.started, self.last_peek, self.idle_since = True, now, now, now
            print(f"No known Wi-Fi. Setup mode on: join '{setup_ssid()}' "
                  f"(channel {nearby_cache.get('channel', 6)}).", flush=True)
        else:
            print(f"Couldn't start setup mode: {err.strip()}", flush=True)

    def stop_hotspot(self):
        nm("connection", "down", "id", HOTSPOT_NAME, timeout=20)
        self.hotspot_on = False

    def peek_for_wifi(self):
        """Step out of setup mode briefly. True if a saved network came back."""
        print("Setup mode: checking for known Wi-Fi...", flush=True)
        self.stop_hotspot()
        nm("device", "wifi", "rescan", timeout=15)
        for _ in range(9):
            time.sleep(5)
            if wifi_connected():
                return True
        return False

    def tick(self, now):
        if not self.hotspot_on:
            if wifi_connected():
                self.offline_since = None
                if self.gave_up:
                    print("Back on Wi-Fi.", flush=True)
                self.gave_up = False
                return
            self.offline_since = self.offline_since or now
            if not self.gave_up and now - self.offline_since > OFFLINE_BEFORE_SETUP:
                self.start_hotspot()
            return
        # Setup mode is on.
        in_use = phones_on_hotspot() > 0 or now - self.last_visit < 120
        if in_use:
            self.idle_since = now
            return
        limit = SETUP_IDLE_LIMIT if self.has_saved else 3 * SETUP_IDLE_LIMIT
        if now - self.idle_since > limit:
            print(f"Nobody used setup mode for {limit // 60} minutes; switching it off. "
                  "The box keeps trying its saved Wi-Fi. Replug it to get setup mode back.",
                  flush=True)
            self.stop_hotspot()
            self.gave_up = True
            nm("device", "connect", "wlan0", timeout=30)    # let saved networks autoconnect
            return
        if self.has_saved and now - self.last_peek > SETUP_RETRY:
            if self.peek_for_wifi():
                print("Back on Wi-Fi.", flush=True)
                self.offline_since = None
            else:
                idle_since = self.idle_since          # the peek doesn't reset the 20 minutes
                self.start_hotspot()
                self.idle_since = idle_since
            self.last_peek = time.time()

    def loop(self):
        while True:
            try:
                self.tick(time.time())
            except Exception as err:
                print(f"Wi-Fi watcher hiccup: {err}", flush=True)
            time.sleep(10)


setup = SetupMode()


class SpeakerKeeper:
    """Every 2 minutes, make sure the speaker program is answering.
    If it misses two checks in a row, restart it."""
    CHECK_EVERY = 120

    def loop(self):
        missing = 0
        while True:
            time.sleep(self.CHECK_EVERY)
            try:
                speaker_call("/")
                missing = 0
            except SpeakerOffline:
                missing += 1
                if missing >= 2:
                    print("Speaker not answering; restarting it", flush=True)
                    systemctl("restart", SPEAKER_SERVICE)
                    missing = 0


keeper = SpeakerKeeper()


class Listening:
    """Listening stats for Settings > Listening. Nothing leaves the box.
    Every 30 seconds: if music is playing, add half a minute to today, to the
    album, to the tile on the box, and to the hour of day. A tile set down
    counts as one play. Saved to stats.json every 10 minutes (few card writes)."""
    EVERY = 30
    SAVE_EVERY = 600
    KEEP_DAYS = 120

    def __init__(self):
        self.stats = read_json(STATS_FILE, {})
        for k, v in (("days", {}), ("albums", {}), ("tiles", {}), ("hours", [0.0] * 24)):
            self.stats.setdefault(k, v)
        self.last_token = None
        self.lock = threading.Lock()

    def tick(self):
        now = time.localtime()
        day = time.strftime("%Y-%m-%d", now)
        token = (reader_state() or {}).get("token")
        try:
            status = speaker_status()
        except SpeakerOffline:
            return
        track = status.get("track")
        playing = bool(track) and not status.get("paused") and not status.get("stopped")
        with self.lock:
            st = self.stats
            d = st["days"].setdefault(day, {"minutes": 0.0, "plays": 0})
            if token and token != self.last_token and token in load_tokens():
                d["plays"] += 1
                t = st["tiles"].setdefault(token, {"minutes": 0.0, "plays": 0})
                t["plays"] += 1
            self.last_token = token
            if playing:
                step = self.EVERY / 60
                d["minutes"] += step
                st["hours"][now.tm_hour] += step
                album = f"{track.get('album_name', '')}\u2009\u2014\u2009{', '.join(track.get('artist_names') or [])}"
                st["albums"][album] = st["albums"].get(album, 0.0) + step
                if token:
                    st["tiles"].setdefault(token, {"minutes": 0.0, "plays": 0})["minutes"] += step

    def save(self):
        with self.lock:
            days = sorted(self.stats["days"])
            for old in days[:-self.KEEP_DAYS]:
                self.stats["days"].pop(old, None)
            if len(self.stats["albums"]) > 300:
                top = sorted(self.stats["albums"].items(), key=lambda kv: -kv[1])[:200]
                self.stats["albums"] = dict(top)
            write_json(STATS_FILE, self.stats)

    def loop(self):
        last_save = time.time()
        while True:
            time.sleep(self.EVERY)
            try:
                self.tick()
                if time.time() - last_save > self.SAVE_EVERY:
                    self.save()
                    last_save = time.time()
            except Exception as err:
                print(f"Stats hiccup: {err}", flush=True)


STATS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stats.json")
listening = Listening()


@app.route("/listening/share", methods=["POST"])
@needs_pin
def listening_share():
    settings = load_settings()
    settings["share_stats"] = request.form.get("share") == "on"
    save_settings(settings)
    return redirect(url_for("listening_page"))


@app.route("/listening")
@needs_pin
def listening_page():
    with listening.lock:
        st = json.loads(json.dumps(listening.stats))
    today = time.time()
    days = []
    for i in range(13, -1, -1):
        key = time.strftime("%Y-%m-%d", time.localtime(today - i * 86400))
        d = st["days"].get(key, {})
        days.append({"label": time.strftime("%a", time.localtime(today - i * 86400))[0],
                     "date": key, "minutes": round(d.get("minutes", 0)), "plays": d.get("plays", 0)})
    week = days[-7:]
    tokens = load_tokens()
    tiles = sorted(({"name": (tokens.get(t) or {}).get("name") or "Removed tile",
                     "image": (tokens.get(t) or {}).get("image", ""),
                     "plays": v.get("plays", 0), "minutes": round(v.get("minutes", 0))}
                    for t, v in st["tiles"].items()), key=lambda x: (-x["plays"], -x["minutes"]))[:8]
    albums = [{"name": k, "minutes": round(v)} for k, v in
              sorted(st["albums"].items(), key=lambda kv: -kv[1])[:8] if v >= 1]
    hours = st["hours"]
    peak = max(range(24), key=lambda h: hours[h]) if any(hours) else None
    return render_template("listening.html", tab="settings", days=days,
                           most=max([d["minutes"] for d in days] + [1]),
                           week_minutes=sum(d["minutes"] for d in week),
                           week_plays=sum(d["plays"] for d in week),
                           tiles=tiles, albums=albums, hours=[round(h) for h in hours],
                           hour_max=max(hours + [1]), peak=peak,
                           share=load_settings().get("share_stats", True))


@app.before_request
def note_setup_visitors():
    if setup.hotspot_on:
        setup.last_visit = time.time()
        # Phones check a web address when they join a network. Sending every
        # strange address to our Wi-Fi page makes the setup screen pop up.
        host = request.host.split(":")[0]
        mine = (HOTSPOT_ADDRESS, address(), current_host(), fallback_host() + ".local")
        if host not in mine:
            return redirect(f"http://{HOTSPOT_ADDRESS}/setup")


# --------------------------------------------------------------------------
# Spotify account
# --------------------------------------------------------------------------
login = {"auth": None}


def speaker_account():
    """(online, username) for the speaker inside the box."""
    try:
        return True, speaker_status().get("username", "")
    except SpeakerOffline:
        return False, ""


def pairing_code():
    """While the speaker waits to be paired: {"url", "code"}; otherwise None."""
    try:
        reply = speaker_call("/auth/code")
        return reply if reply.get("code") else None
    except SpeakerOffline:
        return None


@app.route("/apple", methods=["GET", "POST"])
@needs_pin
def apple_page():
    if not apple_supported():
        return render_template("apple.html", tab="settings", unsupported=True, url="",
                               has_token=False, message="", error="")
    message = error = ""
    report = ""
    if request.method == "POST":
        if "token" in request.form:
            token = request.form["token"].strip()
            apple.save_config(url=request.form.get("url", "") or apple.DEFAULT_URL,
                              token=token if token else None)
            message = "Saved."
        if request.form.get("action") == "remove":
            apple.save_config(token="", player_id="")
            message = "Apple Music turned off on this box."
        if request.form.get("action") == "test" or message == "Saved.":
            lines, ok = [], True
            try:
                found = apple.players()
                me = apple.find_player()
                lines.append(f"Music Assistant answered. Speakers it knows: "
                             f"{', '.join((p.get('display_name') or p.get('name') or '?') for p in found) or 'none'}.")
                if not me:
                    ok = False
                    lines.append(f"No speaker called '{apple.PLAYER_NAME}' yet. Is squeezelite running?")
                else:
                    lines.append(f"Found the speaker '{me.get('display_name') or me.get('name')}'.")
                if not apple.search("the beatles", 3):
                    ok = False
                    lines.append("Search found no Apple Music albums. Sign in to Apple Music inside Music Assistant.")
            except apple.AppleError as err:
                ok = False
                lines.append(str(err))
            report = " ".join(lines)
            if ok:
                message = "Apple Music is ready. " + report
                report = ""
            else:
                message, error = "", report
                report = ""
    cfg = apple.load_config()
    return render_template("apple.html", tab="settings", url=cfg["url"], has_token=bool(cfg["token"]),
                           message=message, error=error)


@app.route("/spotify")
@app.route("/account")
@needs_pin
def account_page():
    user, problem = "", ""
    if signed_in():
        try:
            me = sp.current_user()
            user = me.get("display_name") or me.get("id", "")
        except NotSignedIn:
            problem = "Not signed in."
        except Exception as err:
            problem = str(err)[:200]
            if "403" in problem or "not registered" in problem.lower():
                problem = ("Spotify says this account isn't on your app's User "
                           "Management list. Add it at developer.spotify.com, "
                           "Dashboard > your app > Settings > User Management.")
    return render_template("account.html", tab="settings", user=user, problem=problem,
                           signed_in=signed_in(), speaker=speaker_account()[0],
                           speaker_user=speaker_account()[1], pairing=pairing_code(),
                           client_id=CLIENT_ID, soloist=soloist_mode(),
                           need_install=not soloist_installed(), install=soloist_install_info(),
                           keyerror=request.args.get("keyerror"),
                           message=request.args.get("message", "")[:200])


def soloist_install_info():
    """For the 'Install Spotify's player' card."""
    return {"protected": unplug_proof_on(), "admin": admin_ready(), "auto": auto_ready(),
            "supported": os.uname().machine in SOLOIST_MACHINES, "job": job_view("soloist"),
            "installed": soloist_installed()}


@app.route("/spotify/install", methods=["GET", "POST"])
@needs_pin
def soloist_install_page():
    back = request.values.get("back", "/spotify")
    if back not in ("/spotify", "/setup"):
        back = "/spotify"
    error = ""
    if request.method == "POST":
        info = soloist_install_info()
        if info["job"]["running"]:
            return redirect(url_for("soloist_install_page", back=back))
        if not info["admin"]:
            error = ("This box is missing the app's install helper. Whoever set up the box needs to "
                     "install the latest box software once.")
        elif not info["supported"]:
            error = "Spotify's player doesn't run on this kind of box."
        else:
            ok, why = start_install("soloist-install")
            if not ok:
                error = why if why.startswith("Turn on") else f"Couldn't start the install ({why or 'no answer'})."
            else:
                time.sleep(1)
                return redirect(url_for("soloist_install_page", back=back))
    return render_template("soloist_install.html", tab="settings", back=back, error=error,
                           install=soloist_install_info())


@app.route("/api/job/<job>")
def api_job(job):
    if job not in JOBS:
        abort(404)
    if not session.get("ok"):
        return jsonify(error="locked"), 403
    state = job_view(job)
    if job == "soloist":
        state["installed"] = soloist_installed()
        state["has_key"] = os.path.exists(SOLOIST_KEY) and os.path.getsize(SOLOIST_KEY) > 0
    return jsonify(state)


# --------------------------------------------------------------------------
# Software updates (central releases, signed by Garrett; see musicbox_update.py)
# --------------------------------------------------------------------------
UPDATE_BACKUPS = os.path.expanduser("~/musicbox/update_backups")


def update_status():
    s = read_json(updates.status_file(os.path.expanduser("~")), {}) or {}
    s["current"] = APP_VERSION
    s["available"] = bool(s.get("latest")) and \
        updates.version_tuple(s["latest"]) > updates.version_tuple(APP_VERSION) and not s.get("error")
    return s


def last_backup():
    try:
        names = sorted(d for d in os.listdir(UPDATE_BACKUPS)
                       if os.path.isfile(os.path.join(UPDATE_BACKUPS, d, "backup.json")))
    except OSError:
        return None
    return read_json(os.path.join(UPDATE_BACKUPS, names[-1], "backup.json"), None) if names else None


@app.route("/updates", methods=["GET", "POST"])
@needs_pin
def updates_page():
    message, error = "", ""
    settings = load_settings()
    if request.method == "POST":
        action = request.form.get("action", "")
        if action == "check":
            r = updates.check(os.path.expanduser("~"))
            if r.get("error"):
                error = r["error"]
            elif r.get("available"):
                message = f"Version {r['latest']} is ready to install."
            else:
                message = "This box is up to date."
        elif action == "auto":
            settings["update_check"] = request.form.get("value") == "on"
            save_settings(settings)
            message = ("The box checks for updates once a day." if settings["update_check"]
                       else "Automatic checks off. You can still check here.")
        elif action in ("install", "rollback"):
            if job_view("update")["running"]:
                return redirect(url_for("updates_page"))
            if not admin_ready():
                error = "This box is missing the app's update helper. Install the latest box software by hand once."
            else:
                ok, why = start_install("update-apply" if action == "install" else "update-rollback")
                if ok:
                    time.sleep(1)
                    return redirect(url_for("updates_page"))
                error = why if why.startswith("Turn on") else f"Couldn't start ({why or 'no answer'})."
        settings = load_settings()
    return render_template("updates.html", tab="settings", status=update_status(),
                           result=read_json(updates.result_file(os.path.expanduser("~")), {}) or {},
                           job=job_view("update"), protected=unplug_proof_on(),
                           admin=admin_ready(), auto_ready=auto_ready(), backup=last_backup(),
                           can_protect=protection_installed(),
                           auto=settings.get("update_check", True), version=APP_VERSION,
                           message=message, error=error)


@app.route("/account/signin")
@needs_pin
def account_signin():
    login["auth"] = make_auth()
    url = login["auth"].get_authorize_url() + "&show_dialog=true"
    return render_template("signin.html", tab="settings", url=url, error="")


@app.route("/account/finish", methods=["POST"])
@needs_pin
def account_finish():
    pasted = request.form.get("pasted", "").strip()
    code = (parse_qs(urlparse(pasted).query).get("code") or [""])[0]
    auth = login.get("auth")
    if not auth or not code:
        return render_template(
            "signin.html", tab="settings",
            url=(auth.get_authorize_url() + "&show_dialog=true") if auth else "",
            error="That address doesn't have a sign-in code in it. Copy the whole "
                  "address from the page that wouldn't load.")
    try:
        auth.get_access_token(code=code, check_cache=False)
    except Exception as err:
        return render_template("signin.html", tab="settings",
                               url=auth.get_authorize_url() + "&show_dialog=true",
                               error=f"Spotify didn't accept that: {str(err)[:150]}. "
                                     "Tap the sign-in button again for a fresh code.")
    login["auth"] = None
    return redirect(url_for("account_page", message="Signed in. You're all set."))


@app.route("/account/soloist-key", methods=["POST"])
@needs_pin
def soloist_key():
    key = "".join(request.form.get("key", "").split())
    back = request.form.get("back") or url_for("account_page")
    if not back.startswith("/"):
        back = url_for("account_page")
    if not (16 <= len(key) <= 512) or not all(c.isprintable() for c in key):
        return redirect(back + ("&" if "?" in back else "?") + "keyerror=1")
    tmp = SOLOIST_KEY + ".tmp"
    with open(os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "w") as f:
        f.write(key + "\n")
    os.replace(tmp, SOLOIST_KEY)
    systemctl("restart", SPEAKER_SERVICE)
    time.sleep(2)
    return redirect(back)


@app.route("/account/speaker-signout", methods=["POST"])
@needs_pin
def speaker_signout():
    systemctl("stop", SPEAKER_SERVICE)
    if soloist_mode():
        import shutil
        shutil.rmtree(SOLOIST_DATA, ignore_errors=True)   # Soloist's saved sign-in
        os.makedirs(SOLOIST_DATA, exist_ok=True)
        systemctl("start", SPEAKER_SERVICE)
        time.sleep(3)
        return redirect(url_for("account_page",
                                message="Spotify disconnected. Connect again from the Spotify app."))
    try:
        os.remove(SPEAKER_STATE)          # the speaker's saved sign-in
    except FileNotFoundError:
        pass
    systemctl("start", SPEAKER_SERVICE)
    time.sleep(4)                         # give it a moment to make a pairing code
    return redirect(url_for("account_page",
                            message="Speaker signed out. Pair it with the code below."))


# --------------------------------------------------------------------------
# Settings and power
# --------------------------------------------------------------------------
def unplug_proof_on():
    """True when the system is read-only (root is an overlay)."""
    if os.environ.get("MB_SYSROOT"):         # simulation tests only
        return os.path.exists(os.path.join(os.environ["MB_SYSROOT"], "OVERLAY_ON"))
    try:
        with open("/proc/mounts") as f:
            return any(l.split()[1:3] == ["/", "overlay"] for l in f if len(l.split()) > 2)
    except OSError:
        return False


@app.route("/maintenance/<mode>", methods=["POST"])
@needs_pin
def maintenance(mode):
    if mode not in ("on", "off"):
        abort(404)
    # Maintenance ON = unplug-proof OFF (system writable), and the reverse.
    flag = "1" if mode == "on" else "0"

    def worker():
        time.sleep(2)
        subprocess.run(["sudo", "-n", "/usr/bin/raspi-config", "nonint", "do_overlayfs", flag])
        # do_overlayfs leaves /boot/firmware read-only; unlock it too in maintenance mode
        # so config.txt edits stick. (Needs the disable_bootro sudoers entry; harmless if missing.)
        if mode == "on":
            subprocess.run(["sudo", "-n", "/usr/bin/raspi-config", "nonint", "disable_bootro"])
        subprocess.run(["sudo", "-n", "/usr/sbin/shutdown", "-r", "now"])
    threading.Thread(target=worker, daemon=True).start()
    return render_template("power.html", tab="settings", action="maintenance-" + mode)


@app.route("/settings", methods=["GET", "POST"])
@needs_pin
def settings_page():
    message, error = request.args.get("message", "")[:80], ""
    settings = load_settings()
    if request.method == "POST":
        if "volume_min" in request.form:
            try:
                low = max(0, min(100, int(request.form["volume_min"])))
                high = max(0, min(100, int(request.form["volume_max"])))
                if low > high:
                    error = "The lowest volume has to be below the highest."
                else:
                    settings.update(volume_min=low, volume_max=high)
                    save_settings(settings)
                    message = "Volume limits saved. The knob follows them right away."
            except ValueError:
                error = "Use whole numbers from 0 to 100."
        elif "line_out" in request.form and settings.get("product") == "pad":
            settings["line_out"] = "fixed" if request.form["line_out"] == "fixed" else "variable"
            save_settings(settings)
            message = ("The Pad stays at full volume now. Use your stereo's knob."
                       if settings["line_out"] == "fixed" else
                       "The Pad's knob and your phone set the volume again.")
        elif "resume_minutes" in request.form:
            try:
                minutes = max(0, min(240, int(request.form["resume_minutes"])))
                settings["resume_minutes"] = minutes
                save_settings(settings)
                message = "Saved."
            except ValueError:
                error = "Use a whole number of minutes."
        elif "startup_sound" in request.form:
            settings["startup_sound"] = request.form["startup_sound"] == "on"
            save_settings(settings)
            message = ("The box plays the chime when it's ready." if settings["startup_sound"]
                       else "Startup sound off.")
        elif "new_pin" in request.form:
            new_pin = request.form["new_pin"].strip()
            if not check_pin(request.form.get("old_pin", "").strip()):
                error = "Your current PIN wasn't right."
            elif not (new_pin.isdigit() and 4 <= len(new_pin) <= 8):
                error = "Use 4 to 8 numbers."
            else:
                set_pin(new_pin)
                message = "PIN changed."
        settings = load_settings()
    online, _ = speaker_account()
    spotify_line = ("Needs setting up" if not soloist_installed() else
                    "Not answering right now" if not online else
                    "Waiting to be connected" if pairing_code() else "Connected")
    upd = update_status()
    update_line = (f"{upd['latest']} ready" if upd["available"] else f"Up to date ({APP_VERSION})"
                   if upd.get("checked") and not upd.get("error") else APP_VERSION)
    return render_template("settings.html", tab="settings",
                           protected=unplug_proof_on(), wifi=current_wifi(),
                           speaker_host=address(),
                           sound_line=next((p["label"] for p in list_presets()
                                            if p["name"] == current_preset()), ""),
                           spotify_line=spotify_line, version=APP_VERSION, update_line=update_line,
                           apple_ok=apple_supported(),
                           apple_line="Set up" if apple.configured() else "Experimental",
                           startup_sound=settings.get("startup_sound", True),
                           resume_minutes=settings["resume_minutes"],
                           volume_min=settings["volume_min"], volume_max=settings["volume_max"],
                           is_pad=settings.get("product") == "pad",
                           line_out=settings.get("line_out", "variable"),
                           message=message, error=error)


# --------------------------------------------------------------------------
# Sound presets (CamillaDSP). Same files the `eq` command uses:
# /etc/camilladsp/musicbox.<name>.yml, copied over musicbox.yml by a root helper.
# --------------------------------------------------------------------------
EQ_DIR = "/etc/camilladsp"
PRESET_HELPER = "/usr/local/sbin/musicbox-set-preset"
PRESET_INFO = {   # name -> (label, one line, order). Unknown presets still show up.
    "echo": ("Full", "Big, warm sound tuned to match an Amazon Echo. The everyday pick.", 1),
    "echo_harmonics": ("Full + deeper bass", "Adds bass you can hear on small speakers, without straining them.", 2),
    "echo_harmonics_strong": ("Full + extra deep bass", "The same trick, stronger. Best for music with lots of bass.", 3),
    "echo_nolim": ("Full, no limiter", "Full without the loudness guard. Can crackle when turned way up.", 4),
    "split": ("Split", "Both speakers share the bass, one plays the highs.", 5),
    "flat": ("Flat", "No tuning. Useful for testing.", 9),
}


def list_presets():
    try:
        names = sorted(f[len("musicbox."):-len(".yml")] for f in os.listdir(EQ_DIR)
                       if f.startswith("musicbox.") and f.endswith(".yml") and f != "musicbox.yml")
    except OSError:
        return []
    names = [n for n in names if re.fullmatch(r"[a-z0-9_]{1,40}", n) and not n.startswith("before")]
    presets = []
    for n in names:
        label, line, order = PRESET_INFO.get(n, (n.replace("_", " ").capitalize(), "", 7))
        presets.append({"name": n, "label": label, "line": line, "order": order})
    return sorted(presets, key=lambda p: (p["order"], p["label"]))


def current_preset():
    try:
        with open(os.path.join(EQ_DIR, "current_preset")) as f:
            name = f.read().strip()
            if name:
                return name
    except OSError:
        pass
    try:                                  # picked with `eq` before: find the matching file
        with open(os.path.join(EQ_DIR, "musicbox.yml"), "rb") as f:
            live = f.read()
        for p in list_presets():
            with open(os.path.join(EQ_DIR, f"musicbox.{p['name']}.yml"), "rb") as f:
                if f.read() == live:
                    return p["name"]
    except OSError:
        pass
    return ""


@app.route("/sound", methods=["GET", "POST"])
@needs_pin
def sound_page():
    if load_settings().get("product") == "pad":
        return redirect("/settings")   # a Pad has no speakers, so no speaker presets
    message, error = "", ""
    presets = list_presets()
    if request.method == "POST":
        name = request.form.get("preset", "")
        if name not in [p["name"] for p in presets]:
            error = "That preset isn't on this box."
        elif not os.path.exists(PRESET_HELPER):
            error = "The sound helper isn't installed yet (run the update script)."
        else:
            try:
                r = subprocess.run(["sudo", "-n", PRESET_HELPER, name], capture_output=True,
                                   text=True, timeout=30)
                if r.returncode == 0:
                    label = next(p["label"] for p in presets if p["name"] == name)
                    message = f"Sound set to {label}."
                    now_cache["when"] = 0.0
                else:
                    error = (r.stderr or r.stdout).strip()[:200] or "Couldn't switch the sound."
            except subprocess.TimeoutExpired:
                error = "Switching took too long. Try Restart music in Settings."
    return render_template("sound.html", tab="settings", presets=presets, current=current_preset(),
                           message=message, error=error)


@app.route("/api/chime", methods=["POST"])
@needs_pin
def api_chime():
    threading.Thread(target=play_chime, daemon=True).start()
    return jsonify(ok=True)


@app.route("/power/<action>", methods=["POST"])
@needs_pin
def power(action):
    commands = {
        "restart-music": [["sudo", "-n", "/usr/bin/systemctl", "restart", SPEAKER_SERVICE],
                          ["sudo", "-n", "/usr/bin/systemctl", "restart", "musicbox"]],
        "reboot": [["sudo", "-n", "/usr/sbin/shutdown", "-r", "now"]],
        "shutdown": [["sudo", "-n", "/usr/sbin/shutdown", "-h", "now"]],
    }
    if action not in commands:
        abort(404)

    def worker():
        time.sleep(2)
        for command in commands[action]:
            subprocess.run(command)
    threading.Thread(target=worker, daemon=True).start()
    return render_template("power.html", tab="settings", action=action)


@app.errorhandler(404)
def not_found(_):
    if setup.hotspot_on:
        return redirect(f"http://{HOTSPOT_ADDRESS}/setup")
    return redirect("/")


# --------------------------------------------------------------------------
# Pages
# --------------------------------------------------------------------------
# Small line icons, drawn here so the app works with no internet (setup mode).
_ICON_PATHS = {
    "play": '<path d="M8 5.2v13.6a.8.8 0 0 0 1.2.7l11-6.8a.8.8 0 0 0 0-1.4l-11-6.8A.8.8 0 0 0 8 5.2z" fill="currentColor" stroke="none"/>',
    "pause": '<rect x="6.5" y="5" width="4" height="14" rx="1.2" fill="currentColor" stroke="none"/><rect x="13.5" y="5" width="4" height="14" rx="1.2" fill="currentColor" stroke="none"/>',
    "prev": '<path d="M18.5 6.2v11.6a.7.7 0 0 1-1.1.6L9.6 12.6a.7.7 0 0 1 0-1.2l7.8-5.8a.7.7 0 0 1 1.1.6z" fill="currentColor" stroke="none"/><path d="M6 6v12"/>',
    "next": '<path d="M5.5 6.2v11.6a.7.7 0 0 0 1.1.6l7.8-5.8a.7.7 0 0 0 0-1.2L6.6 5.6a.7.7 0 0 0-1.1.6z" fill="currentColor" stroke="none"/><path d="M18 6v12"/>',
    "now": '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="2.2"/>',
    "tiles": '<rect x="3.5" y="3.5" width="7" height="7" rx="1.8"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.8"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.8"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.8"/>',
    "settings": '<path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>',
    "wifi": '<path d="M2.5 9a14 14 0 0 1 19 0M5.5 12.3a9.5 9.5 0 0 1 13 0M8.6 15.6a5 5 0 0 1 6.8 0"/><circle cx="12" cy="19" r="1" fill="currentColor" stroke="none"/>',
    "music": '<path d="M9 18V5.5l11-2V16"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/>',
    "volume": '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11"/>',
    "chevron": '<path d="M9.5 6l6 6-6 6"/>',
    "back": '<path d="M14.5 6l-6 6 6 6"/>',
    "check": '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    "alert": '<path d="M12 4l9 16H3z"/><path d="M12 10v4.5"/><circle cx="12" cy="17.3" r=".6" fill="currentColor"/>',
    "plus": '<path d="M12 5v14M5 12h14"/>',
    "power": '<path d="M12 3.5v8"/><path d="M7 6.5a7.5 7.5 0 1 0 10 0"/>',
    "restart": '<path d="M4.5 12a7.5 7.5 0 1 0 2.2-5.3"/><path d="M4.5 4.5v4h4"/>',
    "shield": '<path d="M12 3.5l7.5 3v5.5c0 4.5-3.2 7.6-7.5 8.5-4.3-.9-7.5-4-7.5-8.5V6.5z"/>',
    "lock": '<rect x="5" y="10.5" width="14" height="10" rx="2.5"/><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5"/>',
    "link": '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
    "pencil": '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    "trash": '<path d="M4.5 7h15M9.5 7V4.5h5V7M6.5 7l1 13h9l1-13"/>',
    "list": '<path d="M9 6.5h11M9 12h11M9 17.5h11"/><circle cx="4.5" cy="6.5" r="1" fill="currentColor"/><circle cx="4.5" cy="12" r="1" fill="currentColor"/><circle cx="4.5" cy="17.5" r="1" fill="currentColor"/>',
    "save": '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M8 4v5h7V4M8 20v-6h8v6"/>',
}


def icon(name, size=24, cls=""):
    from markupsafe import Markup
    return Markup(
        f'<svg class="icon {cls}" width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" '
        f'stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" '
        f'aria-hidden="true">{_ICON_PATHS[name]}</svg>')


app.jinja_env.globals["icon"] = icon
app.jinja_env.filters["kind"] = kind_of
app.jinja_env.filters["badge"] = tile_badge


@app.context_processor
def speaker_context():
    return {"box_name": speaker_name(), "box_id": box_id(), "setup_ssid": setup_ssid(),
            "box_address": address(), "box_fallback": fallback_host() + ".local"}
app.jinja_env.globals["icon_svgs"] = {name: str(icon(name)) for name in _ICON_PATHS}

PAGES = {}

PAGES["base.html"] = """<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{{ box_name }}</title>
<link rel="manifest" href="/manifest.json">
<link rel="apple-touch-icon" href="/icon.png">
<link rel="icon" href="/icon.png">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="apple-mobile-web-app-title" content="{{ box_name }}">
<meta name="theme-color" content="#F3F4F0" media="(prefers-color-scheme: light)" id="tc-light">
<meta name="theme-color" content="#14161A" media="(prefers-color-scheme: dark)" id="tc-dark">
<script>
/* Appearance: "auto", "light" or "dark", remembered on this phone. */
function applyTheme(t) {
  const root = document.documentElement;
  if (t === "light" || t === "dark") root.dataset.theme = t; else delete root.dataset.theme;
  const color = t === "dark" ? "#14161A" : "#F3F4F0";
  for (const id of ["tc-light", "tc-dark"]) {
    const m = document.getElementById(id);
    if (!m) continue;
    if (t === "light" || t === "dark") { m.content = color; m.removeAttribute("media"); }
    else { m.content = id === "tc-dark" ? "#14161A" : "#F3F4F0";
           m.media = id === "tc-dark" ? "(prefers-color-scheme: dark)" : "(prefers-color-scheme: light)"; }
  }
}
let savedTheme = "auto";
try { savedTheme = localStorage.getItem("theme") || "auto"; } catch (e) {}
applyTheme(savedTheme);
</script>
<style>
:root{
  --paper:#F3F4F0; --surface:#FFFFFF; --sunk:#E9EBE5; --ink:#1E2127; --muted:#666C66;
  --line:#DADDD5; --raised:#FFFFFF; --marigold:#F5B82E; --marigold-press:#E3A515; --on-marigold:#1E2127;
  --link:#8A5A00; --good:#2C7A57; --bad:#BC3F2B;
  --shadow-tile:0 1px 2px rgba(30,33,39,.10),0 8px 24px -8px rgba(30,33,39,.28);
  --r-lg:22px; --r-md:14px; --r-sm:10px;
  --font:ui-rounded,"SF Pro Rounded",system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;
}
@media (prefers-color-scheme:dark){:root:not([data-theme=light]){
  --paper:#14161A; --surface:#1E2126; --sunk:#262A30; --ink:#ECEDE9; --muted:#9BA09A;
  --line:#30343B; --raised:#3A3F47; --link:#F5B82E; --good:#6FCB9C; --bad:#F08A78;
  --shadow-tile:0 1px 2px rgba(0,0,0,.4),0 10px 28px -8px rgba(0,0,0,.7); color-scheme:dark;
}}
:root[data-theme=dark]{
  --paper:#14161A; --surface:#1E2126; --sunk:#262A30; --ink:#ECEDE9; --muted:#9BA09A;
  --line:#30343B; --raised:#3A3F47; --link:#F5B82E; --good:#6FCB9C; --bad:#F08A78;
  --shadow-tile:0 1px 2px rgba(0,0,0,.4),0 10px 28px -8px rgba(0,0,0,.7); color-scheme:dark;
}
:root[data-theme=light]{color-scheme:light}
*{box-sizing:border-box}
html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--paper);color:var(--ink);font:400 16px/1.45 var(--font);
  -webkit-font-smoothing:antialiased}
main{max-width:540px;margin:0 auto;padding:calc(14px + env(safe-area-inset-top)) 18px 112px}
h1{font-size:30px;line-height:1.1;font-weight:800;letter-spacing:-.02em;margin:10px 0 18px}
h2{font-size:15px;font-weight:700;color:var(--muted);margin:28px 4px 8px}
p{margin:0}
a{color:var(--link)}
.muted{color:var(--muted)}
.small{font-size:14px}
.icon{flex:none;display:block}
:focus-visible{outline:3px solid var(--marigold);outline-offset:2px}

/* Buttons */
.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:48px;
  padding:0 20px;border-radius:999px;border:0;font:700 16px var(--font);text-decoration:none;
  cursor:pointer;background:var(--marigold);color:var(--on-marigold);-webkit-tap-highlight-color:transparent}
.btn:active{background:var(--marigold-press)}
.btn.plain{background:var(--sunk);color:var(--ink)}
.btn.wide{display:flex;width:100%}
.btn.small{min-height:38px;padding:0 14px;font-size:15px}
.btn[disabled]{opacity:.6}

/* Grouped lists (Settings, tile details) */
.group{background:var(--surface);border-radius:var(--r-md);overflow:hidden;margin:0 0 12px}
.item{display:flex;align-items:center;gap:14px;min-height:56px;padding:12px 16px;width:100%;
  border:0;background:none;color:var(--ink);font:inherit;text-align:left;text-decoration:none}
.item+.item,.item+form .item,form+.item,form+form .item{border-top:1px solid var(--line)}
.item .label{flex:1;min-width:0}
.item .value{color:var(--muted);font-size:15px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:55%}
.item .chev{color:var(--muted)}
.item.danger{color:var(--bad)}
.item .badge{width:32px;height:32px;border-radius:9px;display:grid;place-items:center;
  background:var(--sunk);color:var(--ink)}
button.item{cursor:pointer}
button.item.action{justify-content:center;color:var(--link);font-weight:700}
.note{font-size:14px;color:var(--muted);margin:0 6px 4px;line-height:1.4}
.progress{display:flex;gap:6px;margin:18px 0 6px}
.progress span{flex:1;height:6px;border-radius:3px;background:var(--line)}
.progress span.on{background:var(--marigold)}
.stepnum{color:var(--muted);font-weight:700;font-size:14px}
.chips{display:flex;flex-wrap:wrap;gap:8px}
.chips button{border:1.5px solid var(--line);background:var(--surface);color:var(--ink);border-radius:999px;
  padding:8px 14px;font:inherit;font-size:15px;cursor:pointer}
.addr{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:15px;word-break:break-all}
form{margin:0}
.pad{padding:16px}
.seg{display:flex;background:var(--sunk);border-radius:999px;padding:3px;gap:2px}
.seg button{flex:1;min-height:40px;border:0;border-radius:999px;background:none;color:var(--muted);
  font:600 15px var(--font);cursor:pointer}
.seg button[aria-checked=true]{background:var(--raised);color:var(--ink);box-shadow:0 1px 3px rgba(0,0,0,.15)}
.group.pad .seg{margin:0}
.switch{flex:none;width:50px;height:30px;border-radius:999px;background:var(--line);position:relative;transition:background .15s}
.switch::after{content:"";position:absolute;top:3px;left:3px;width:24px;height:24px;border-radius:50%;
  background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.25);transition:transform .15s}
.switch.on{background:var(--good)}
.switch.on::after{transform:translateX(20px)}
.stack>*+*{margin-top:12px}

/* Inputs */
input[type=text],input[type=password],input[type=number],input[type=search],input[type=url],select{
  width:100%;min-height:48px;padding:0 14px;border:1.5px solid var(--line);border-radius:var(--r-sm);
  background:var(--paper);color:var(--ink);font:16px var(--font)}
input:focus,select:focus{border-color:var(--marigold);outline:none}
input.num{width:84px;text-align:center;font-weight:700}

/* Messages */
.toast{display:flex;gap:10px;align-items:center;padding:12px 14px;border-radius:var(--r-md);
  background:color-mix(in srgb,var(--good) 14%,var(--surface));margin:0 0 14px;font-weight:600}
.toast.bad{background:color-mix(in srgb,var(--bad) 14%,var(--surface))}
.toast .icon{color:var(--good)}
.toast.bad .icon{color:var(--bad)}

/* Alerts on Now */
.alerts{background:var(--surface);border-radius:var(--r-md);overflow:hidden;margin:0 0 16px}
.alert{display:flex;gap:12px;padding:14px 16px;align-items:flex-start}
.alert+.alert{border-top:1px solid var(--line)}
.alert .dot{width:34px;height:34px;border-radius:50%;display:grid;place-items:center;flex:none;
  background:color-mix(in srgb,var(--bad) 16%,transparent);color:var(--bad)}
.alert.go .dot{background:color-mix(in srgb,var(--marigold) 30%,transparent);color:var(--ink)}
.alert.calm .dot{background:var(--sunk);color:var(--muted)}
.alert .body{flex:1;min-width:0}
.alert .body b{display:block}
.alert .body .small{margin-top:2px}
.alert .btn{margin-top:10px}
.code{font-size:34px;font-weight:800;letter-spacing:.12em;margin:8px 0 2px;font-variant-numeric:tabular-nums}

/* Tiles: square art, like the real ones */
.art{display:block;width:100%;aspect-ratio:1;object-fit:cover;border-radius:var(--r-md);
  background:var(--sunk);box-shadow:var(--shadow-tile)}
.art.blank{display:grid;place-items:center;color:var(--muted)}

/* Bottom tabs */
nav.tabs{position:fixed;left:0;right:0;bottom:0;z-index:5;display:flex;justify-content:center;
  background:color-mix(in srgb,var(--paper) 88%,transparent);backdrop-filter:blur(16px);
  -webkit-backdrop-filter:blur(16px);border-top:1px solid var(--line);
  padding:6px 8px calc(6px + env(safe-area-inset-bottom))}
nav.tabs a{flex:1;max-width:140px;display:flex;flex-direction:column;align-items:center;gap:3px;
  color:var(--muted);text-decoration:none;font-size:12px;font-weight:600;padding:4px 0}
nav.tabs a span.pill{display:grid;place-items:center;width:56px;height:30px;border-radius:999px}
nav.tabs a.on{color:var(--ink)}
nav.tabs a.on span.pill{background:var(--marigold);color:var(--on-marigold)}
.backlink{display:inline-flex;align-items:center;gap:2px;color:var(--ink);text-decoration:none;
  font-weight:600;margin:4px 0 0 -6px}
@media (prefers-reduced-motion:reduce){*{transition:none!important;animation:none!important}}
{% block style %}{% endblock %}
</style></head><body><main>
{% block body %}{% endblock %}
</main>
{% if tab %}<nav class="tabs">
<a href="/" class="{{ 'on' if tab=='now' }}"><span class="pill">{{ icon('now') }}</span>Now</a>
<a href="/tiles" class="{{ 'on' if tab=='tiles' }}"><span class="pill">{{ icon('tiles') }}</span>Tiles</a>
<a href="/settings" class="{{ 'on' if tab=='settings' }}"><span class="pill">{{ icon('settings') }}</span>Settings</a>
</nav>{% endif %}
</body></html>"""

PAGES["pin.html"] = """{% extends "base.html" %}
{% block style %}
.mark{width:64px;height:64px;border-radius:18px;margin:28px 0 4px;box-shadow:var(--shadow-tile)}
{% endblock %}{% block body %}
<img class="mark" src="/icon.png" alt="">
{% if first_time %}
<h1>Welcome to your Music Box</h1>
<form method="post" class="stack">
<input type="hidden" name="next" value="{{ next }}">
<p class="muted">Setup takes about 5 minutes: a PIN, a name for your speaker, your Wi-Fi, Spotify, and your first tile.</p>
<p class="muted small">The box shares anonymous usage (on/off and how long tiles play, never song names) with its maker. You can turn that off in Settings &gt; Listening.</p>
<p>First, choose a PIN. Grown-ups use it to change tiles and settings. Playing music never needs it.</p>
<input type="password" name="pin" inputmode="numeric" autocomplete="new-password" placeholder="4 to 8 numbers" aria-label="PIN" autofocus>
<input type="password" name="pin2" inputmode="numeric" autocomplete="new-password" placeholder="Same PIN again" aria-label="PIN again">
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}{{ error }}</div>{% endif %}
<button class="btn wide">Save PIN</button>
</form>
{% else %}
<h1>Enter your PIN</h1>
<form method="post" class="stack">
<input type="hidden" name="next" value="{{ next }}">
<input type="password" name="pin" inputmode="numeric" autocomplete="current-password" placeholder="PIN" aria-label="PIN" autofocus>
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}{{ error }}</div>{% endif %}
<button class="btn wide">Unlock</button>
<p class="muted small">Forgot it? Whoever set up the box can reset it.</p>
</form>
{% endif %}
{% endblock %}"""

PAGES["soloist_pair.html"] = """{% if pairing.needs_key %}
<div class="group pad stack">
<b>Step 1: your Spotify player key</b>
<p>The box plays through Spotify's own player, which needs a free key from your <b>Spotify Premium</b> account. On a phone or computer:</p>
<ol style="margin:0 0 0 20px;padding:0">
<li>Open <a href="https://developer.spotify.com/dashboard/soloist" target="_blank" rel="noopener">developer.spotify.com/dashboard/soloist</a> and log in with your Spotify Premium account.</li>
<li>Accept the terms if it asks, then generate a key.</li>
<li>Copy the key and paste it here.</li>
</ol>
{% if keyerror %}<div class="toast bad">That doesn't look like a whole key. Copy it again and paste the full thing.</div>{% endif %}
<form method="post" action="/account/soloist-key" class="stack">
<input type="hidden" name="back" value="{{ back }}">
<input type="password" name="key" autocomplete="off" placeholder="Paste your key" aria-label="Soloist key" required>
<button class="btn wide">Save key</button>
</form>
</div>
<p class="note">The key stays on this box. Don't share it; each person makes their own.</p>
{% else %}
<div class="group pad stack">
<b>Connect your Spotify account</b>
{% if pairing.running %}
<p>On your phone (on the same Wi-Fi), open the <b>Spotify</b> app, play any song, tap the <b>speaker icon</b>, and pick <b>{{ pairing.name }}</b>.</p>
<p class="muted small" id="wait">The box connects to that account and remembers it. This page moves on by itself.</p>
{% else %}
<p>Starting Spotify's player on the box. This takes up to a minute.</p>
<p class="muted small">Still stuck after a minute? The key may be wrong. Paste it again below.</p>
{% endif %}
{% if pairing.problem %}<p class="muted small">Spotify's player said: {{ pairing.problem }}</p>{% endif %}
</div>
{% if not pairing.running %}<script>setTimeout(() => location.reload(), 5000)</script>{% endif %}
<details style="margin-top:10px"><summary class="small" style="color:var(--link);cursor:pointer;margin:0 6px">Change the player key</summary>
<form method="post" action="/account/soloist-key" class="group pad stack" style="margin-top:10px">
<input type="hidden" name="back" value="{{ back }}">
<input type="password" name="key" autocomplete="off" placeholder="Paste your key" aria-label="Soloist key" required>
<button class="btn plain wide">Save new key</button>
</form></details>
{% endif %}"""

PAGES["soloist_install_card.html"] = """<div class="group pad stack">
<b>Step 1: put Spotify's player on the box</b>
<p>The box plays Spotify through Spotify's own player. It downloads straight from Spotify onto this box and takes 2 to 5 minutes. After that you add your free player key and pick the box in the Spotify app.</p>
{% if install.job.running %}
<a class="btn wide" href="/spotify/install?back={{ back }}">Installing... see progress</a>
{% elif not install.supported %}
<p class="small muted">Spotify's player doesn't run on this kind of box. Local music still works.</p>
{% elif not install.admin %}
<p class="small muted">This box needs the latest box software before it can install Spotify's player from the app. Ask whoever set up the box.</p>
{% elif install.protected and not install.auto %}
<p class="small">First, switch on maintenance mode so the install can be saved. The box restarts (2 to 5 minutes); then come back to this page.</p>
<form method="post" action="/maintenance/on" onsubmit="return confirm('Restart in maintenance mode? Come back here after the restart to install.')">
<button class="btn wide">Turn on maintenance mode</button></form>
{% elif install.protected %}
<form method="post" action="/spotify/install" onsubmit="return confirm('Install now? The box pauses and restarts twice (about 10 minutes in all).')"><input type="hidden" name="back" value="{{ back }}">
<button class="btn wide">Install Spotify's player</button></form>
<p class="small muted">The box pauses music and restarts into maintenance mode to install, then turns unplug protection back on by itself. About 10 minutes in all.</p>
{% if install.job.failed and install.job.error %}<p class="small muted">Last try stopped: {{ install.job.error }}</p>{% endif %}
{% else %}
<form method="post" action="/spotify/install"><input type="hidden" name="back" value="{{ back }}">
<button class="btn wide">Install Spotify's player</button></form>
{% if install.job.failed and install.job.error %}<p class="small muted">Last try stopped: {{ install.job.error }}</p>{% endif %}
{% endif %}
</div>
<p class="note">Needs a Spotify Premium account. Nothing about your account leaves the box except to Spotify.</p>"""

PAGES["jobprogress.html"] = """<div class="group pad stack" id="job">
<div class="bar"><span id="jobbar" style="width:{{ (100 * job.num / job.total) if job.total else 4 }}%"></span></div>
<p id="jobstep"><b>{{ job.step }}</b></p>
<p class="small muted" id="jobnote">{{ job.note or "Keep this page open, or come back to it later. Please don't unplug the box." }}</p>
</div>
<div id="jobend"></div>
<details style="margin-top:10px"><summary class="small" style="color:var(--link);cursor:pointer;margin:0 6px">Details</summary>
<pre class="small" id="joblog" style="white-space:pre-wrap;overflow-wrap:anywhere;max-height:300px;overflow:auto">{{ job.log }}</pre></details>"""

PAGES["jobscript.html"] = """<script>
(function(){
  const JOB = {{ jobname|tojson }};
  function esc(s){ return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[c]); }
  async function poll(){
    let d;
    try { const r = await fetch("/api/job/" + JOB, {cache: "no-store"}); if (!r.ok) throw 0; d = await r.json(); }
    catch (e) { document.getElementById("jobnote").textContent = "Waiting for the box to answer (it may be restarting). This page reconnects by itself."; return setTimeout(poll, 3000); }
    document.getElementById("jobbar").style.width = (d.total ? Math.max(4, 100 * d.num / d.total) : 4) + "%";
    document.getElementById("jobstep").innerHTML = "<b>" + esc(d.step) + "</b>";
    document.getElementById("joblog").textContent = d.log;
    if (d.running || !d.exists) { document.getElementById("jobnote").textContent = d.note || "Keep this page open, or come back to it later. Please don't unplug the box."; return setTimeout(poll, d.auto ? 3000 : 2000); }
    jobFinished(d);
  }
  setTimeout(poll, 1500);
})();
</script>"""

PAGES["soloist_install.html"] = """{% extends "base.html" %}
{% block style %}.bar{height:10px;border-radius:6px;background:var(--sunk);overflow:hidden}
.bar span{display:block;height:100%;background:var(--marigold);transition:width .4s}{% endblock %}
{% block body %}
<a class="backlink" href="{{ back }}">{{ icon('back', 22) }}{{ 'Setup' if back == '/setup' else 'Spotify' }}</a>
<h1>Installing Spotify's player</h1>
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
{% if not install.job.exists and not error %}
<p>Nothing is installing right now.</p><a class="btn wide" href="{{ back }}">Back</a>
{% elif error and not install.job.running %}
{% set back = back %}{% include "soloist_install_card.html" %}
{% else %}
{% set job = install.job %}{% include "jobprogress.html" %}
<script>
function jobFinished(d){
  const end = document.getElementById("jobend");
  if (d.ok) {
    document.getElementById("jobnote").textContent = "";
    end.innerHTML = `<div class="toast">{{ icon('check', 20) }}<span>${d.auto_message ? esc(d.auto_message) : "Spotify's player is on the box."}</span></div>
      <div class="group pad stack"><b>Next: ${d.has_key ? "pick this box in the Spotify app" : "add your Spotify player key"}</b>
      <p class="small">${d.has_key ? "Your key is already saved. Open Spotify on your phone, tap the speaker icon, and pick this box." : "It's free and takes a minute. The next page shows you how."}</p>
      <a class="btn wide" href="{{ back }}">Continue</a></div>`;
  } else {
    document.getElementById("jobnote").textContent = "";
    end.innerHTML = `<div class="toast bad">{{ icon('alert', 20) }}<span>${d.error ? esc(d.error) : "The install stopped. Open Details below to see why."}</span></div>
      <form method="post" action="/spotify/install"><input type="hidden" name="back" value="{{ back }}"><button class="btn wide">Try again</button></form>`;
  }
  function esc(s){ return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[c]); }
}
</script>
{% set jobname = "soloist" %}{% include "jobscript.html" %}
{% if install.job.ok or install.job.failed %}<script>/* already finished: the first poll shows the result */</script>{% endif %}
{% endif %}
{% endblock %}"""

PAGES["updates.html"] = """{% extends "base.html" %}
{% block style %}.bar{height:10px;border-radius:6px;background:var(--sunk);overflow:hidden}
.bar span{display:block;height:100%;background:var(--marigold);transition:width .4s}
.notes{white-space:pre-wrap}{% endblock %}
{% block body %}
<a class="backlink" href="/settings">{{ icon('back', 22) }}Settings</a>
<h1>Software updates</h1>
{% if message %}<div class="toast">{{ icon('check', 20) }}<span>{{ message }}</span></div>{% endif %}
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}

{% if job.running %}
<h2>{{ 'Going back to the earlier version' if job.command == 'update-rollback' else 'Installing the update' }}</h2>
{% include "jobprogress.html" %}
<script>function jobFinished(d){ location.replace("/updates"); }</script>
{% set jobname = "update" %}{% include "jobscript.html" %}
{% else %}

{% if job.auto in ('done', 'attention') %}
<div class="toast {{ '' if job.ok else 'bad' }}">{{ icon('check' if job.ok else 'alert', 20) }}<span>{{ job.auto_message }}</span></div>
{% elif result.message and job.exists %}
<div class="toast {{ '' if result.ok else 'bad' }}">{{ icon('check' if result.ok else 'alert', 20) }}<span>{{ result.message }}{% if result.ok and not protected and can_protect %} Turn unplug protection back on in Settings when you're done.{% endif %}</span></div>
{% endif %}

<div class="group">
<div class="item"><span class="badge">{{ icon('settings', 18) }}</span><span class="label">This box</span><span class="value">Version {{ version }}</span></div>
{% if status.available %}
<div class="item"><span class="badge" style="color:var(--good)">{{ icon('plus', 18) }}</span><span class="label"><b>Version {{ status.latest }} is ready</b>{% if status.released %}<br><span class="small muted">Released {{ status.released }}</span>{% endif %}</span></div>
{% elif status.checked and not status.error %}
<div class="item"><span class="badge" style="color:var(--good)">{{ icon('check', 18) }}</span><span class="label">Up to date</span></div>
{% endif %}
</div>
{% if status.error %}<p class="note">Last check: {{ status.error }}</p>{% endif %}

{% if status.available %}
{% if status.notes %}<div class="group pad"><b>What's new</b><p class="small notes">{{ status.notes }}</p></div>{% endif %}
<div class="group pad stack">
{% if not admin %}
<p class="small">This box is missing the update helper. Whoever set up the box needs to install the latest box software by hand once.</p>
{% elif protected and auto_ready %}
<p class="small">The box pauses music and restarts into maintenance mode to install, then turns unplug protection back on by itself. About 10 minutes in all. It keeps a copy of the current version and goes back to it by itself if the new one doesn't start properly.</p>
<form method="post" onsubmit="return confirm('Install version {{ status.latest }} now? The box pauses and restarts twice (about 10 minutes in all).')"><input type="hidden" name="action" value="install"><button class="btn wide">Install {{ status.latest }}</button></form>
{% elif protected %}
<p class="small">To install, switch on maintenance mode so the update can be saved. The box restarts (2 to 5 minutes); then come back here and tap Install.</p>
<form method="post" action="/maintenance/on" onsubmit="return confirm('Restart in maintenance mode? Come back here after the restart to install.')"><button class="btn wide">Turn on maintenance mode</button></form>
{% else %}
<p class="small">Takes a minute or two. The box keeps a copy of the current version and goes back to it by itself if the new one doesn't start properly. Music may stop for a moment.</p>
<form method="post" onsubmit="return confirm('Install version {{ status.latest }} now?')"><input type="hidden" name="action" value="install"><button class="btn wide">Install {{ status.latest }}</button></form>
{% endif %}
</div>
{% endif %}

<form method="post" class="group"><input type="hidden" name="action" value="check">
<button class="item"><span class="badge">{{ icon('restart', 18) }}</span><span class="label">Check now</span>{% if status.checked %}<span class="value" data-when="{{ status.checked }}"></span>{% endif %}</button></form>

<form method="post" class="group"><input type="hidden" name="action" value="auto"><input type="hidden" name="value" value="{{ 'off' if auto else 'on' }}">
<button class="item"><span class="badge">{{ icon('check' if auto else 'alert', 18) }}</span><span class="label">Check once a day<br><span class="small muted">{{ 'On. Tap to turn off.' if auto else 'Off. Tap to turn on.' }}</span></span></button></form>
<p class="note">Checking downloads one small public file from the Music Box update page. It sends nothing about this box, its music or its owner. Updates are only installed when you tap Install, and only if they carry the Music Box release signature.</p>

{% if backup %}
<details style="margin-top:22px"><summary class="small" style="color:var(--link);cursor:pointer;margin:0 6px">Go back to version {{ backup['from'] }}</summary>
<div class="group pad stack" style="margin-top:10px">
<p class="small">Undoes the last update. Your tiles, settings, Wi-Fi and Spotify stay as they are.</p>
{% if protected and not auto_ready %}<p class="small muted">Needs maintenance mode first (Settings &gt; Unplug protection).</p>
{% elif admin %}{% if protected %}<p class="small muted">The box restarts into maintenance mode for this and turns unplug protection back on by itself.</p>{% endif %}<form method="post" onsubmit="return confirm('Go back to version {{ backup['from'] }}?')"><input type="hidden" name="action" value="rollback"><button class="btn plain wide">Go back to {{ backup['from'] }}</button></form>{% endif %}
</div></details>
{% endif %}
{% endif %}
<script>
document.querySelectorAll("[data-when]").forEach(el => {
  const t = new Date(1000 * +el.dataset.when);
  el.textContent = "Last " + t.toLocaleDateString([], {month: "short", day: "numeric"}) + " " + t.toLocaleTimeString([], {hour: "numeric", minute: "2-digit"});
});
</script>
{% endblock %}"""

PAGES["progress.html"] = """<div class="progress">{% for i in range(step_count) %}<span class="{{ 'on' if i < step_num }}"></span>{% endfor %}</div>
<p class="stepnum">Step {{ step_num }} of {{ step_count }}</p>"""

PAGES["setup.html"] = """{% extends "base.html" %}
{% block style %}
.slot{width:180px;aspect-ratio:1;margin:8px auto 18px;border-radius:var(--r-md);
  border:2.5px dashed var(--line);display:grid;place-items:center;color:var(--muted)}
.slot.found{border-color:var(--marigold);color:var(--ink);background:color-mix(in srgb,var(--marigold) 18%,transparent)}
{% endblock %}{% block body %}
{% include "progress.html" %}
{% if step == "spotify" and need_install %}
<h1>Connect Spotify</h1>
{% set back = "/setup" %}{% include "soloist_install_card.html" %}
<p class="note"><a href="/setup?finish=1">Skip Spotify for now</a> (local music and radio still work)</p>
{% elif step == "spotify" and pairing and pairing.soloist %}
<h1>Connect Spotify</h1>
{% set back = "/setup" %}{% include "soloist_pair.html" %}
{% elif step == "spotify" %}
<h1>Connect Spotify</h1>
<div class="group pad stack">
<p>The box plays from a Spotify Premium account. On your phone, open
<a href="{{ pairing.url }}" target="_blank" rel="noopener">spotify.com/pair</a>, sign in, and type this code:</p>
<p class="code">{{ pairing.code }}</p>
<p class="muted small" id="wait">This page moves on by itself once Spotify says yes.</p>
</div>
<p class="note">Your Spotify password only goes to Spotify. The box never sees it.</p>
{% elif step == "speaker" %}
<h1>Waking up the speaker</h1>
<div class="group pad stack"><p>This takes up to a minute after plugging in. This page moves on by itself.</p>
<button class="btn plain small" onclick="fix(this)">{{ icon('restart', 18) }}Restart music</button></div>
{% else %}
<h1>Add your first tile</h1>
{% if tile %}
<div class="slot found">{{ icon('check', 56) }}</div>
<p style="text-align:center;margin-bottom:16px">Tile found. Now give it some music.</p>
<a class="btn wide" href="/tiles/{{ tile }}">Pick its music</a>
{% else %}
<div class="slot">{{ icon('tiles', 48) }}</div>
<p style="text-align:center">Set a blank tile on the box.<br><span class="muted">This page notices it right away.</span></p>
{% endif %}
{% endif %}
<p style="margin-top:28px;text-align:center"><a href="/setup?finish=1" class="muted small">Skip setup for now</a></p>
<script>
async function fix(b){ b.disabled = true; await fetch("/api/fix/restart-music",{method:"POST"}); }
const step = {{ step|tojson }}, tile = {{ (tile or "")|tojson }};
setInterval(async () => {
  try {
    const d = await (await fetch("/api/now")).json();
    if (step === "spotify" && d.signed_in) location.reload();
    if (step === "speaker" && d.speaker) location.reload();
    if (step === "tile" && (d.tile || "") !== tile) location.reload();
  } catch (e) {}
}, 2500);
</script>
{% endblock %}"""

PAGES["now.html"] = """{% extends "base.html" %}
{% block style %}
.top{display:flex;align-items:baseline;justify-content:space-between;gap:12px}
.top h1{margin-bottom:14px}
.net{display:flex;align-items:center;gap:6px;color:var(--muted);font-size:14px;font-weight:600;
  max-width:50%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.stage{position:relative;isolation:isolate;padding:22px 0 0}
.glow{position:absolute;z-index:-1;left:8%;right:8%;top:10px;aspect-ratio:1;border-radius:40px;
  background-size:cover;background-position:center;filter:blur(42px) saturate(1.5);opacity:.55}
.stage .art{width:min(84%,44vh);margin:0 auto;border-radius:var(--r-lg)}
.glow{left:50%!important;right:auto!important;width:min(84%,44vh);transform:translateX(-50%)}
.meta{text-align:center;margin:26px 8px 0}
.meta .title{font-size:24px;font-weight:800;letter-spacing:-.01em;line-height:1.2;
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.meta .kind{color:var(--muted);font-size:13px;font-weight:700;margin-bottom:4px}
.meta .by{font-size:17px;font-weight:600;margin-top:4px}
.meta .album{color:var(--muted);font-size:15px;margin-top:2px}
.meta .by,.meta .album{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.transport{display:flex;align-items:center;justify-content:center;gap:28px;margin:22px 0 4px}
.transport button{border:0;background:none;color:var(--ink);cursor:pointer;display:grid;place-items:center;
  width:64px;height:64px;border-radius:50%;-webkit-tap-highlight-color:transparent}
.transport button:active{background:var(--sunk)}
.transport .main{width:84px;height:84px;background:var(--marigold);color:var(--on-marigold);
  box-shadow:0 6px 18px -6px color-mix(in srgb,var(--marigold) 80%,transparent)}
.transport .main:active{background:var(--marigold-press)}
.vol{display:flex;align-items:center;gap:12px;margin:22px 10px 0;color:var(--muted)}
.ticks{flex:1;display:flex;gap:3px;height:16px;align-items:flex-end}
.ticks i{flex:1;height:100%;border-radius:2px;background:var(--line)}
.ticks i.on{background:var(--ink)}
.vol b{color:var(--ink);font-variant-numeric:tabular-nums;min-width:2ch;text-align:right}
.idle{text-align:center;padding:16px 0 0}
.idle .slot{width:72%;margin:0 auto 22px;aspect-ratio:1;border-radius:var(--r-lg);
  border:2.5px dashed var(--line);display:grid;place-items:center;color:var(--muted)}
.idle h2{all:unset;display:block;font-size:22px;font-weight:800}
#about{margin-top:26px}
#about h2{margin-top:0}
#about .facts{color:var(--muted);font-size:14px;font-weight:600;margin:-4px 6px 12px}
#about .blurb{font-size:15px;line-height:1.5}
#about .src{font-size:13px;margin-top:8px}
#about dl{margin:0;display:grid;grid-template-columns:auto 1fr;gap:8px 14px;font-size:15px}
#about dt{color:var(--muted);font-weight:600}
#about dd{margin:0}
#about .sub{font-size:13px;font-weight:700;color:var(--muted);margin:0 0 8px;text-transform:uppercase;letter-spacing:.04em}
#about .sub .len{float:right;text-transform:none;letter-spacing:0;font-weight:600}
#about ol.tracks{list-style:none;margin:0;padding:0;font-size:15px}
#about ol.tracks li{display:flex;gap:12px;align-items:baseline;padding:7px 8px;margin:0 -8px;border-radius:var(--r-sm)}
#about ol.tracks .n{color:var(--muted);font-variant-numeric:tabular-nums;min-width:2ch;text-align:right;font-size:13px;font-weight:600}
#about ol.tracks .t{flex:1;min-width:0}
#about ol.tracks .d{color:var(--muted);font-variant-numeric:tabular-nums;font-size:13px}
#about ol.tracks li.on{background:color-mix(in srgb,var(--marigold) 22%,var(--surface));font-weight:700}
#about ol.tracks li.on .n,#about ol.tracks li.on .d{color:var(--ink)}
#about .disc{font-size:13px;font-weight:700;color:var(--muted);margin:12px 0 4px}
#about details.more summary{cursor:pointer;color:var(--link);font-weight:600;font-size:14px;padding:8px 0 0;list-style:none}
#about details.more summary::-webkit-details-marker{display:none}
#about details.more[open] summary{display:none}
{% endblock %}{% block body %}
<header class="top"><h1>{{ box_name }}</h1><span class="net" id="net"></span></header>
<div id="alerts"></div>
<section id="stage"><div class="idle"><div class="slot"></div></div></section>
<section id="about"></section>
<script>
const VERSION = {{ version|tojson }};
const ICON = {{ icon_svgs|tojson }};
const $ = s => document.querySelector(s);
const esc = s => String(s || "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
let shown = "";
async function control(action){
  await fetch("/api/control/" + action, {method: "POST"});
  setTimeout(refresh, 450);
}
async function fixMusic(btn){
  btn.disabled = true; btn.textContent = "Restarting...";
  await fetch("/api/fix/restart-music", {method: "POST"});
  setTimeout(refresh, 15000);
}
function alert_(kind, icon, title, body, action){
  return `<div class="alert ${kind}"><span class="dot">${ICON[icon]}</span><div class="body">
    <b>${title}</b>${body ? `<p class="small muted">${body}</p>` : ""}${action || ""}</div></div>`;
}
function render(html){ if (html !== shown) { $("#stage").innerHTML = html; shown = html; } }
async function refresh(){
  let d;
  try { d = await (await fetch("/api/now", {cache: "no-store"})).json(); }
  catch (e) {
    $("#alerts").innerHTML = `<div class="alerts">${alert_("", "wifi", "Can't reach the music box",
      "Make sure this phone is on the same Wi-Fi as the box. Just plugged in? Give it a minute.")}</div>`;
    return;
  }
  if (d.version && d.version !== VERSION) { location.reload(); return; }
  $("#net").innerHTML = d.wifi && !d.setup_mode ? ICON.wifi.replace('width="24" height="24"', 'width="16" height="16"') + esc(d.wifi) : "";

  let a = "";
  if (d.setup_mode) a += alert_("", "wifi", "The box needs Wi-Fi",
      "It couldn't find a network it knows.", `<a class="btn small" href="/wifi">Set up Wi-Fi</a>`);
  else if (!d.speaker) a += alert_("", "music", "The speaker isn't answering",
      "Normal for about a minute after plugging in.",
      `<button class="btn small" onclick="fixMusic(this)">Restart music</button>`);
  else if (!d.signed_in && d.pairing && d.pairing.soloist) a += alert_("go", "link", "Connect Spotify",
      d.pairing.needs_key ? "The box needs your Spotify player key first."
        : `On your phone, open Spotify, tap the speaker icon, and pick <b>${esc(d.pairing.name)}</b>.`,
      `<a class="btn small" href="/account">Show me how</a>`);
  else if (!d.signed_in && d.pairing) a += alert_("go", "link", "Connect Spotify",
      `On your phone, open <a href="${esc(d.pairing.url)}" target="_blank" rel="noopener">spotify.com/pair</a> and type this code:`,
      `<p class="code">${esc(d.pairing.code)}</p>`);
  if (!d.reader_ok) a += alert_("", "alert", "The tile reader isn't answering",
      "Unplug the box, count to 10, and plug it back in.");
  if (d.new_tile) a += alert_("go", "plus", "New tile on the box",
      d.teaching ? "Pick its music here, or play something on " + esc({{ box_name|tojson }}) + " from the Spotify app in the next minute." : "Pick its music and it's ready to go.",
      `<a class="btn small" href="/tiles/${esc(d.tile)}">Pick its music</a>`);
  if (d.update) a += alert_("calm", "restart", "Software update ready",
      `Version ${esc(d.update)} is available for this box.`,
      `<a class="btn small plain" href="/updates">See what's new</a>`);
  if (d.maintenance) a += alert_("calm", "shield", "Unplug protection is off",
      "Fine while installing updates. Turn it back on when you're done.",
      `<a class="btn small plain" href="/settings#protection">Open settings</a>`);
  $("#alerts").innerHTML = a ? `<div class="alerts">${a}</div>` : "";

  if (!d.on_box) {
    render(`<div class="idle"><div class="slot">${ICON.tiles.replace(/"24"/g, '"56"')}</div>
      <h2>Set a tile on the box</h2><p class="muted">It starts playing right away.</p></div>`);
    return;
  }
  const art = d.image
    ? `<div class="glow" style="background-image:url('${esc(d.image)}')"></div><img class="art" src="${esc(d.image)}" alt="">`
    : `<div class="art blank" style="width:84%;margin:0 auto">${ICON.music}</div>`;
  let vol = "";
  if (d.volume !== undefined) {
    const lit = Math.round(d.volume / 5);
    vol = `<div class="vol" aria-label="Volume ${d.volume}">${ICON.volume}<div class="ticks">` +
      Array.from({length: 20}, (_, i) => `<i class="${i < lit ? "on" : ""}" style="height:${40 + i * 3}%"></i>`).join("") +
      `</div><b>${d.volume}</b></div>`;
  }
  render(`<div class="stage">${art}
    <div class="meta">${d.kind ? `<div class="kind">Playing ${esc(d.kind.toLowerCase())}</div>` : ""}<div class="title">${esc(d.track)}</div><div class="by">${esc(d.artist)}</div>
    <div class="album">${esc(d.album)}</div></div>
    <div class="transport">
      <button onclick="control('back')" aria-label="Back">${ICON.prev.replace(/"24"/g, '"32"')}</button>
      <button class="main" onclick="control('${d.playing ? "pause" : "play"}')" aria-label="${d.playing ? "Pause" : "Play"}">${(d.playing ? ICON.pause : ICON.play).replace(/"24"/g, '"34"')}</button>
      <button onclick="control('next')" aria-label="Next">${ICON.next.replace(/"24"/g, '"32"')}</button>
    </div>${vol}</div>`);
}
/* About this album: fetched once per album, hidden when nothing is known. */
let aboutKey = "", aboutTimer = null;
function credits(rows) {
  return `<dl>${rows.map(r => `<dt>${esc(r.role)}</dt><dd>${r.names.map(esc).join(", ")}</dd>`).join("")}</dl>`;
}
function mmss(ms) {
  if (!ms) return "";
  const s = Math.round(ms / 1000);
  return s >= 3600 ? `${Math.floor(s / 3600)}:${String(Math.floor(s / 60) % 60).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`
    : `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}
/* Track list, with the song that's on now highlighted. Long lists (box sets)
   show the first 15 and a "Show all" link, unless the song on now is further down. */
function trackList(list) {
  if (!list || !list.length) return "";
  const discs = new Set(list.map(t => t.disc)).size > 1;
  const total = list.reduce((sum, t) => sum + (t.ms || 0), 0);
  const on = list.findIndex(t => t.playing);
  const cut = list.length > 20 && on < 15 ? 15 : list.length;
  const rows = part => {
    let h = "", disc = null;
    for (const t of part) {
      if (discs && t.disc !== disc) { if (h) h += "</ol>"; h += `<p class="disc">Disc ${esc(t.disc)}</p><ol class="tracks">`; disc = t.disc; }
      else if (!h) h += `<ol class="tracks">`;
      h += `<li class="${t.playing ? "on" : ""}"${t.playing ? ' aria-current="true"' : ""}><span class="n">${esc(t.n)}</span>` +
        `<span class="t">${esc(t.title)}</span><span class="d">${t.playing ? ICON.volume.replace(/"24"/g, '"14"') : mmss(t.ms)}</span></li>`;
    }
    return h + "</ol>";
  };
  let h = `<div class="group pad"><p class="sub">Tracks${total ? `<span class="len">${list.length} songs &middot; ${mmss(total)}</span>` : ""}</p>${rows(list.slice(0, cut))}`;
  if (cut < list.length) h += `<details class="more"><summary>Show all ${list.length} songs</summary>${rows(list.slice(cut))}</details>`;
  return h + "</div>";
}
async function loadAbout(key, tries) {
  clearTimeout(aboutTimer);
  let a;
  try { a = await (await fetch("/api/about", {cache: "no-store"})).json(); } catch (e) { return; }
  if (key !== aboutKey) return;
  if (a.status === "loading") { if (tries < 40) aboutTimer = setTimeout(() => loadAbout(key, tries + 1), 3000); return; }
  if (a.status !== "ok") { $("#about").innerHTML = ""; return; }
  const facts = [a.year, a.label, a.type && a.type !== "Album" ? a.type : ""].filter(Boolean).map(esc).join(" &middot; ");
  const wiki = a.wiki || a.artist_wiki;
  let h = `<h2>About this ${a.type === "EP" ? "EP" : a.type === "Single" ? "single" : "album"}</h2>`;
  if (facts) h += `<p class="facts">${facts}</p>`;
  if (wiki) h += `<div class="group pad">${a.artist_wiki && !a.wiki ? `<p class="sub">About ${esc(a.artist_wiki.name)}</p>` : ""}
    <p class="blurb">${esc(wiki.text)}</p>
    <p class="src muted">From <a href="${esc(wiki.link)}" target="_blank" rel="noopener">Wikipedia</a> (CC BY-SA)</p></div>`;
  h += trackList(a.tracklist);
  if (a.track_credits && a.track_credits.length)
    h += `<div class="group pad"><p class="sub">This song</p>${credits(a.track_credits)}</div>`;
  if (a.credits && a.credits.length)
    h += `<div class="group pad"><p class="sub">Album credits</p>${credits(a.credits)}</div>`;
  h += `<p class="note">${(a.tracklist || []).length ? "Tracks and credits" : "Credits"} from <a href="${esc(a.mb)}" target="_blank" rel="noopener">MusicBrainz</a>, the free music encyclopedia.</p>`;
  $("#about").innerHTML = (facts || wiki || (a.tracklist || []).length || (a.credits || []).length || (a.track_credits || []).length) ? h : "";
}
const _refresh = refresh;
refresh = async function () {
  await _refresh();
  const t = document.querySelector("#stage .meta");
  const key = t ? t.textContent : "";
  if (!t) { aboutKey = ""; $("#about").innerHTML = ""; return; }
  if (key !== aboutKey) { aboutKey = key; loadAbout(key, 0); }
};
refresh();
setInterval(() => { if (!document.hidden) refresh(); }, 4000);
document.addEventListener("visibilitychange", () => { if (!document.hidden) refresh(); });
</script>
{% endblock %}"""

PAGES["tiles.html"] = """{% extends "base.html" %}
{% block style %}
.head{display:flex;align-items:baseline;justify-content:space-between}
.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:22px 16px}
@media (min-width:500px){.grid{grid-template-columns:repeat(3,1fr)}}
.tile{display:block;color:var(--ink);text-decoration:none;min-width:0}
.tile .name{font-weight:700;font-size:15px;line-height:1.25;margin-top:10px;
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.tile .where{display:flex;align-items:center;gap:4px;font-size:13px;color:var(--muted);margin-top:3px}
.tile .where.any{color:var(--good)}
.tile.here .art{outline:3px solid var(--marigold);outline-offset:3px}
.tile.new .art{box-shadow:none;border:2.5px dashed var(--marigold);background:color-mix(in srgb,var(--marigold) 14%,transparent);color:var(--ink)}
.tile .chev{display:none}
.tile .kind{font-size:12px;font-weight:700;color:var(--muted);margin-top:10px}
.tile .kind+.name{margin-top:1px}
html[data-view=list] .tile .kind{margin-top:0}
.viewswitch{display:inline-flex;background:var(--sunk);border-radius:999px;padding:3px;gap:2px}
.viewswitch button{border:0;background:none;color:var(--muted);width:40px;height:32px;border-radius:999px;
  display:grid;place-items:center;cursor:pointer}
.viewswitch button[aria-pressed=true]{background:var(--raised);color:var(--ink);box-shadow:0 1px 3px rgba(0,0,0,.15)}
.count{margin:-8px 4px 14px}
/* Compact list view */
html[data-view=list] .grid{display:block;background:var(--surface);border-radius:var(--r-md);overflow:hidden}
html[data-view=list] .tile{display:flex;align-items:center;gap:14px;padding:10px 14px}
html[data-view=list] .tile+.tile{border-top:1px solid var(--line)}
html[data-view=list] .tile .art{width:48px;flex:none;border-radius:8px;box-shadow:none}
html[data-view=list] .tile .art .icon{width:22px;height:22px}
html[data-view=list] .tile .txt{flex:1;min-width:0}
html[data-view=list] .tile .name{margin-top:0;-webkit-line-clamp:1}
html[data-view=list] .tile .where{margin-top:1px}
html[data-view=list] .tile .chev{display:block;color:var(--muted)}
html[data-view=list] .tile.here{background:color-mix(in srgb,var(--marigold) 14%,transparent)}
html[data-view=list] .tile.here .art{outline:none}
html[data-view=list] .tile.new .art{border-width:2px}
.empty{text-align:center;padding:30px 10px}
.empty .art{width:120px;margin:0 auto 16px;box-shadow:none;border:2.5px dashed var(--line);background:none}
{% endblock %}{% block body %}
<script>try { document.documentElement.dataset.view = localStorage.getItem("tileView") || "grid"; } catch (e) {}</script>
<div class="head"><h1>Tiles</h1>{% if tokens %}<div class="viewswitch" role="group" aria-label="View">
<button type="button" data-v="grid" aria-label="Album view" title="Album view">{{ icon('tiles', 20) }}</button>
<button type="button" data-v="list" aria-label="List view" title="List view">{{ icon('list', 20) }}</button></div>{% endif %}</div>
{% if tokens %}<p class="count muted small">{{ tokens|length }} tile{{ 's' if tokens|length != 1 }} · <a href="/music">Local music</a></p>{% else %}<p class="count small"><a href="/music">Local music</a></p>{% endif %}
{% if writing %}
<div class="toast" id="writing">{{ icon('save', 20) }}Saving onto the tile. Keep it on the box for a moment.</div>
{% elif request.args.get('failed') %}
<div class="toast bad">{{ icon('alert', 20) }}<span>Saved for this box, but it didn't save onto the tile. Keep the tile still and try again from its page.</span></div>
{% elif saved %}<div class="toast">{{ icon('check', 20) }}Saved. Set the tile on the box to play it.</div>{% endif %}
{% if not reader_ok %}
<div class="alerts"><div class="alert"><span class="dot">{{ icon('alert', 20) }}</span><div class="body">
<b>The tile reader isn't answering</b><p class="small muted">Unplug the box, count to 10, and plug it back in.</p></div></div></div>
{% endif %}

{% if tokens or on_reader_new %}
<div class="grid">
{% if on_reader_new %}
<a class="tile new" href="/tiles/{{ on_reader }}">
<div class="art blank">{{ icon('plus', 40) }}</div>
<div class="txt"><div class="name">New tile on the box</div><div class="where">Tap to pick its music</div></div>
<span class="chev">{{ icon('chevron', 18) }}</span></a>
{% endif %}
{% for tid, t in tokens.items() %}
<a class="tile {{ 'here' if tid == on_reader }}" href="/tile/{{ tid }}">
{% if t.image %}<img class="art" src="{{ t.image }}" alt="" loading="lazy">{% else %}<div class="art blank">{{ icon('music', 36) }}</div>{% endif %}
<div class="txt"><div class="kind">{{ t|badge }}</div><div class="name">{{ t.name or "Untitled tile" }}</div>
{% if tid == on_reader %}<div class="where">{{ icon('now', 14) }}On the box now</div>
{% endif %}</div>
<span class="chev">{{ icon('chevron', 18) }}</span>
</a>
{% endfor %}
</div>
{% if teaching and on_reader_new %}<p class="note" style="margin-top:20px">Shortcut: play any album on {{ box_name }} from the Spotify app in the next minute and the new tile learns it.</p>{% endif %}
{% else %}
<div class="empty"><div class="art"></div><b>No tiles yet</b><p class="muted">Set a blank tile on the box and it shows up here.</p></div>
{% endif %}
<script>
function showView(v) {
  document.documentElement.dataset.view = v;
  document.querySelectorAll(".viewswitch button").forEach(b => b.setAttribute("aria-pressed", b.dataset.v === v));
  try { localStorage.setItem("tileView", v); } catch (e) {}
}
document.querySelectorAll(".viewswitch button").forEach(b => b.onclick = () => showView(b.dataset.v));
showView(document.documentElement.dataset.view || "grid");
let last = {{ (on_reader or "")|tojson }};
const writing = {{ (writing or "")|tojson }};
setInterval(async () => {
  try {
    const d = await (await fetch("/api/reader")).json();
    if (writing && d.write && d.write.id === writing) {
      location.replace(d.write.ok ? "/tiles?saved=1" : "/tiles?failed=1");
      return;
    }
    if (!writing && (d.token || "") !== last) location.replace("/tiles");
  } catch (e) {}
}, 1500);
{% if writing %}setTimeout(() => location.replace("/tiles?failed=1"), 15000);{% endif %}
</script>
{% endblock %}"""

PAGES["tile.html"] = """{% extends "base.html" %}
{% block style %}
.hero{width:62%;margin:14px auto 18px}
.kindline{text-align:center;color:var(--muted);font-size:14px;font-weight:700;margin-bottom:2px}
.title{text-align:center;font-size:22px;font-weight:800;line-height:1.25;margin:0 8px}
.where{display:flex;justify-content:center;align-items:center;gap:5px;color:var(--muted);font-size:14px;margin:6px 0 22px}
.where.any{color:var(--good)}
{% endblock %}{% block body %}
<a class="backlink" href="/tiles">{{ icon('back', 22) }}Tiles</a>
{% if renamed %}<div class="toast" style="margin-top:12px">{{ icon('check', 20) }}Renamed.</div>{% endif %}
<div class="hero">{% if t.image %}<img class="art" src="{{ t.image }}" alt="">{% else %}<div class="art blank">{{ icon('music', 44) }}</div>{% endif %}</div>
<p class="kindline">{{ t|badge }}</p>
<p class="title">{{ t.name or "Untitled tile" }}</p>
{% if on_reader %}<p class="where">{{ icon('now', 15) }}On the box now</p>
{% else %}<p class="where"></p>{% endif %}

<div class="group">
<a class="item" href="/tiles/{{ tid }}"><span class="badge">{{ icon('music', 18) }}</span><span class="label">Change its music</span><span class="chev">{{ icon('chevron', 18) }}</span></a>
</div>

{% if t.uri.startswith("local:") %}
{% if arterr %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ arterr }}</span></div>{% endif %}
<h2>Picture</h2>
<form method="post" action="/tile/{{ tid }}/art" enctype="multipart/form-data" class="group pad stack">
<input type="file" name="picture" accept="image/*" aria-label="Picture" required>
<button class="btn plain wide">Use this picture</button>
{% if t.image %}<button class="btn plain wide" name="remove" value="1" formnovalidate>Remove picture</button>{% endif %}
</form>
<p class="note">Or put a picture named cover.jpg in the music folder and link the tile again.</p>
{% endif %}

<h2>Name</h2>
<form method="post" action="/tiles/rename" class="group pad" style="display:flex;gap:10px">
<input type="hidden" name="token" value="{{ tid }}">
<input type="text" name="name" value="{{ t.name }}" aria-label="Tile name">
<button class="btn plain">Rename</button></form>

<div class="group" style="margin-top:28px">
<form method="post" action="/tiles/delete" onsubmit="return confirm('Remove this tile from the list?')">
<input type="hidden" name="token" value="{{ tid }}">
<button class="item danger"><span class="badge" style="color:var(--bad)">{{ icon('trash', 18) }}</span><span class="label">Remove tile</span></button></form>
</div>
<p class="note" style="margin-top:18px">Tile ID {{ tid }}</p>
{% endblock %}"""

PAGES["tile_music.html"] = """{% extends "base.html" %}
{% block style %}
.current{display:flex;align-items:center;gap:14px}
.current .art{width:64px;flex:none;border-radius:var(--r-sm)}
ol.how{margin:0;padding:0;list-style:none;counter-reset:s}
ol.how li{counter-increment:s;display:flex;gap:12px;align-items:flex-start;padding:6px 0}
ol.how li::before{content:counter(s);flex:none;width:26px;height:26px;border-radius:50%;
  background:var(--sunk);display:grid;place-items:center;font-weight:800;font-size:14px}
.result{display:flex;align-items:center;gap:12px}
.result .art{width:56px;flex:none;border-radius:var(--r-sm);box-shadow:none}
.result .label{flex:1;min-width:0;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
{% endblock %}{% block body %}
<a class="backlink" href="{{ '/tile/' ~ token_id if current else '/tiles' }}">{{ icon('back', 22) }}{{ "Tile" if current else "Tiles" }}</a>
<h1>{{ "Change its music" if current else "Pick its music" }}</h1>
{% if current %}<div class="group pad current">
{% if current.image %}<img class="art" src="{{ current.image }}" alt="">{% else %}<div class="art blank">{{ icon('music') }}</div>{% endif %}
<div style="min-width:0"><div class="small muted">Plays this {{ (current.uri|kind or "music")|lower }} now</div><b>{{ current.name or current.uri }}</b></div></div>{% endif %}
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
<h2>Spotify</h2>
<form method="post" class="group pad stack" id="paste">
<ol class="how">
<li><span>In Spotify, open an album, playlist, song, artist or podcast.</span></li>
<li><span>Tap the three dots, then <b>Share</b>, then <b>Copy link</b>.</span></li>
<li><span>Paste it here.</span></li></ol>
<button type="button" class="btn wide" id="pastebtn" hidden>{{ icon('link', 20) }}Paste link</button>
<input type="url" name="link" placeholder="https://open.spotify.com/album/..." aria-label="Spotify link" autocomplete="off">
<button class="btn plain wide">Save</button>
</form>
{% if can_search %}
<h2>Search Spotify</h2>
<form method="get" style="display:flex;gap:10px"><input type="search" name="q" value="{{ query }}" placeholder="Album, artist, or playlist" aria-label="Search">
<button class="btn plain">Search</button></form>
{% if results %}<div class="group" style="margin-top:12px">
{% for r in results %}
<form method="post" action="/tiles/save">
<input type="hidden" name="token" value="{{ token_id }}"><input type="hidden" name="uri" value="{{ r.uri }}">
<input type="hidden" name="name" value="{{ r.name }}"><input type="hidden" name="image" value="{{ r.image }}">
<button class="item result">{% if r.image %}<img class="art" src="{{ r.image }}" alt="">{% else %}<span class="art blank"></span>{% endif %}
<span class="label">{{ r.name }}<br><span class="small muted" style="font-weight:400">{{ r.kind }}</span></span>
<span class="btn small">Use</span></button></form>
{% endfor %}</div>{% endif %}
{% endif %}
{% if apple_on %}
<h2>Apple Music <span class="small muted" style="font-weight:400">experimental</span></h2>
{% if apple_error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ apple_error }}</span></div>{% endif %}
<form method="post" action="/tiles/apple" class="group pad stack">
<input type="hidden" name="token" value="{{ token_id }}">
<p class="small muted">In Apple Music, open an album or playlist, tap the three dots, <b>Share</b>, <b>Copy Link</b>, and paste it here.</p>
<input type="url" name="link" placeholder="https://music.apple.com/us/album/..." aria-label="Apple Music link" autocomplete="off">
<button class="btn plain wide">Save</button>
</form>
<form method="get" style="display:flex;gap:10px;margin-top:12px"><input type="search" name="aq" value="{{ aquery }}" placeholder="Search Apple Music albums" aria-label="Search Apple Music">
<button class="btn plain">Search</button></form>
{% if apple_results %}<div class="group" style="margin-top:12px">
{% for r in apple_results %}
<form method="post" action="/tiles/apple">
<input type="hidden" name="token" value="{{ token_id }}"><input type="hidden" name="uri" value="{{ r.uri }}">
<input type="hidden" name="name" value="{{ r.name }}{% if r.artist %} · {{ r.artist }}{% endif %}"><input type="hidden" name="image" value="{{ r.image }}">
<button class="item result">{% if r.image %}<img class="art" src="{{ r.image }}" alt="">{% else %}<span class="art blank"></span>{% endif %}
<span class="label">{{ r.name }}<br><span class="small muted" style="font-weight:400">{{ r.artist }}{% if r.year %} · {{ r.year }}{% endif %}</span></span>
<span class="btn small">Use</span></button></form>
{% endfor %}</div>{% endif %}
{% endif %}
<h2>Local music</h2>
{% if shelves %}<div class="group">
{% for artist, albums in shelves %}{% for f in albums %}
<form method="post" action="/tiles/local">
<input type="hidden" name="token" value="{{ token_id }}"><input type="hidden" name="path" value="{{ f.key }}">
<button class="item result"><span class="art blank" style="position:relative;overflow:hidden">{{ icon('music', 24) }}<img src="/art/album?key={{ f.key|urlencode }}" alt="" loading="lazy" onerror="this.remove()" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:inherit"></span>
<span class="label">{{ f.album }}<br><span class="small muted" style="font-weight:400">{{ f.artist or "Unknown artist" }}{% if f.year %} · {{ f.year }}{% endif %} · {{ f.tracks }} track{{ 's' if f.tracks != 1 }}{% if f.book %} · Audiobook{% endif %}</span></span>
<span class="btn small">Use</span></button></form>
{% endfor %}{% endfor %}</div>
{% else %}<p class="note">Nothing yet. <a href="/music">Add music</a> from a USB stick or your phone.</p>{% endif %}
<script>
const box = document.querySelector("#paste input[name=link]");
const btn = document.getElementById("pastebtn");
if (navigator.clipboard && navigator.clipboard.readText) {
  btn.hidden = false;
  btn.onclick = async () => {
    try {
      box.value = (await navigator.clipboard.readText()).trim();
      if (box.value.includes("spotify")) document.getElementById("paste").submit();
    } catch (e) { box.focus(); }
  };
}
</script>
{% endblock %}"""

PAGES["music.html"] = """{% extends "base.html" %}
{% block style %}
.row{display:flex;align-items:center;gap:12px}
.row .art{width:48px;height:48px;flex:none;border-radius:var(--r-sm);box-shadow:none}
.row .label{flex:1;min-width:0;font-weight:700}
.row .label .small{font-weight:400}
.row .art{position:relative;display:grid;place-items:center;overflow:hidden}
.row .art img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
h3.artist{font-size:14px;font-weight:800;color:var(--muted);margin:22px 4px 8px;text-transform:uppercase;letter-spacing:.04em}
.acts{display:flex;gap:8px;flex-wrap:wrap;padding:0 14px 12px 74px}
.acts form{margin:0}
.acts .btn{font-size:14px}
{% endblock %}{% block body %}
<a class="backlink" href="/tiles">{{ icon('back', 22) }}Tiles</a>
<h1>Local music</h1>
{% if message %}<div class="toast">{{ icon('check', 20) }}<span>{{ message }}</span></div>{% endif %}
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
{% if not player_ok %}<div class="toast bad">{{ icon('alert', 20) }}<span>The music player for this box isn't running. Restart the box and try again.</span></div>{% endif %}
<p>Play your own music files: put them on a USB stick and plug it into the box, or add them from your phone. Then give a tile a folder.</p>
<div class="group">
<div class="item"><span class="badge">{{ icon('save', 18) }}</span><span class="label">USB stick</span><span class="value">{{ "Plugged in" if usb else "Not plugged in" }}</span></div>
<div class="item"><span class="badge">{{ icon('music', 18) }}</span><span class="label">Room on the box</span><span class="value">{{ free_gb }} GB</span></div>
</div>
{% if album_count %}
<input type="search" id="find" placeholder="Search artist or album" aria-label="Search your music" style="margin:4px 0 6px">
{% for artist, albums in shelves %}
<div class="shelf"><h3 class="artist">{{ artist }}</h3>
<div class="group">
{% for f in albums %}
<a class="item row" href="/music/album?key={{ f.key|urlencode }}" data-find="{{ (artist ~ ' ' ~ f.album)|lower }}">
<span class="art blank">{{ icon('music', 22) }}<img src="/art/album?key={{ f.key|urlencode }}" alt="" loading="lazy" onerror="this.remove()"></span>
<span class="label">{{ f.album }}<br><span class="small muted">{% if f.year %}{{ f.year }} · {% endif %}{{ f.tracks }} track{{ 's' if f.tracks != 1 }}{% if f.seconds %} · {{ dur(f.seconds) }}{% endif %}{% if f.usb %} · USB{% endif %}</span></span>
<span class="chev">{{ icon('chevron', 18) }}</span></a>
{% endfor %}</div></div>
{% endfor %}
{% if books %}<div class="shelf"><h3 class="artist">Audiobooks</h3><div class="group">
{% for f in books %}
<a class="item row" href="/music/album?key={{ f.key|urlencode }}" data-find="{{ ((f.artist or '') ~ ' ' ~ f.album)|lower }}">
<span class="art blank">{{ icon('music', 22) }}<img src="/art/album?key={{ f.key|urlencode }}" alt="" loading="lazy" onerror="this.remove()"></span>
<span class="label">{{ f.album }}<br><span class="small muted">{% if f.artist %}{{ f.artist }} · {% endif %}{{ dur(f.seconds) }}{% if f.usb %} · USB{% endif %}</span></span>
<span class="chev">{{ icon('chevron', 18) }}</span></a>
{% endfor %}</div></div>{% endif %}
<script>
document.getElementById("find").addEventListener("input", e => {
  const q = e.target.value.trim().toLowerCase();
  document.querySelectorAll("[data-find]").forEach(r => r.hidden = q && !r.dataset.find.includes(q));
  document.querySelectorAll(".shelf").forEach(s => s.hidden = ![...s.querySelectorAll("[data-find]")].some(r => !r.hidden));
});
</script>
{% if not on_reader %}<p class="note">To give a tile an album, set the tile on the box and open the album, or pick it from the tile's page.</p>{% endif %}
{% else %}<div class="group pad"><p class="muted">No music yet. Plug in a USB stick, or add files below.</p></div>{% endif %}
<form method="post" action="/music/rescan"><button class="btn plain wide" style="margin-top:12px">Look for new music</button></form>

<h2>Add from this phone or computer</h2>
{% if locked %}<div class="group pad"><p>Unplug protection is on, so files added here wouldn't be kept. Use a USB stick, or turn on maintenance mode in <a href="/settings">Settings</a>, add your music, then turn protection back on.</p></div>
{% else %}
<form method="post" action="/music/upload" enctype="multipart/form-data" class="group pad stack" id="up">
<input type="text" name="folder" placeholder="Folder name (only for files with no album tag)" aria-label="Folder name">
<input type="file" name="files" multiple accept="audio/*,.m4b,.flac,.opus,.mp3,.m4a,image/*" aria-label="Music files" required>
<button class="btn wide" id="upbtn">Add music</button>
<p class="small muted" id="upnote" hidden>Sending. Keep this page open until it finishes. Long audiobooks take a few minutes.</p>
</form>
<p class="note">The box files each song under Artist / Album using its tags (artist, album, year), so just pick the files. Files with no album tag go into the folder named above. Albums play in track order, and long ones (about 90 minutes or more) are treated as audiobooks that pick up where they left off.</p>
<script>
document.getElementById("up").addEventListener("submit", () => {
  document.getElementById("upbtn").disabled = true;
  document.getElementById("upnote").hidden = false;
});
</script>
{% endif %}
{% endblock %}"""

PAGES["album.html"] = """{% extends "base.html" %}
{% block style %}
.hero{width:62%;margin:14px auto 18px;aspect-ratio:1;position:relative}
.hero .art{width:100%;height:100%;object-fit:cover}
.hero .blank{display:grid;place-items:center}
.title{text-align:center;font-size:22px;font-weight:800;line-height:1.25;margin:0 8px}
.by{text-align:center;color:var(--muted);font-size:15px;font-weight:600;margin:4px 0 18px}
ol.tracks{list-style:none;margin:0;padding:0}
ol.tracks li{display:flex;gap:12px;align-items:baseline;padding:11px 14px}
ol.tracks li+li{border-top:1px solid var(--line)}
ol.tracks .n{color:var(--muted);min-width:2ch;text-align:right;font-variant-numeric:tabular-nums;font-size:14px}
ol.tracks .t{flex:1;min-width:0}
ol.tracks .d{color:var(--muted);font-size:14px;font-variant-numeric:tabular-nums}
.acts2{display:flex;gap:10px;flex-wrap:wrap;margin:0 0 22px}
.acts2 form{flex:1;min-width:140px;margin:0}
{% endblock %}{% block body %}
<a class="backlink" href="/music">{{ icon('back', 22) }}Local music</a>
{% if message %}<div class="toast">{{ icon('check', 20) }}<span>{{ message }}</span></div>{% endif %}
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
<div class="hero">{% if art %}<img class="art" src="{{ art }}" alt="">{% else %}<div class="art blank">{{ icon('music', 44) }}</div>{% endif %}</div>
<p class="title">{{ a.album }}</p>
<p class="by">{{ a.artist or "Unknown artist" }}{% if a.year %} · {{ a.year }}{% endif %}{% if a.book %} · Audiobook{% endif %}</p>
<div class="acts2">
{% if on_reader %}<form method="post" action="/tiles/local"><input type="hidden" name="token" value="{{ on_reader }}"><input type="hidden" name="path" value="{{ a.key }}"><button class="btn wide">Use for the tile on the box</button></form>{% endif %}
<form method="post" action="/music/play"><input type="hidden" name="path" value="{{ a.key }}"><button class="btn plain wide">Play now</button></form>
{% if a.book and remembered %}<form method="post" action="/music/restart"><input type="hidden" name="path" value="{{ a.key }}"><button class="btn plain wide">Start over</button></form>{% endif %}
</div>
{% if not on_reader %}<p class="note" style="margin-top:-8px">To give a tile this album, set the tile on the box and open this page again, or pick it from the tile's page.</p>{% endif %}
<h2>{{ tracks|length }} track{{ 's' if tracks|length != 1 }}{% if a.seconds %} · {{ dur(a.seconds) }}{% endif %}</h2>
<div class="group"><ol class="tracks">
{% for t in tracks %}<li><span class="n">{{ t.n }}</span><span class="t">{{ t.title }}</span><span class="d">{{ t.length }}</span></li>{% endfor %}
</ol></div>
<h2>Cover</h2>
<form method="post" action="/music/cover" enctype="multipart/form-data" class="group pad stack">
<input type="hidden" name="key" value="{{ a.key }}">
<input type="file" name="picture" accept="image/*" aria-label="Cover picture" required>
<button class="btn plain wide">{{ "Change cover" if art else "Add cover" }}</button>
{% if has_custom %}<button class="btn plain wide" name="remove" value="1" formnovalidate>Remove my cover</button>{% endif %}
</form>
<p class="note">Pick a picture from your phone. It's saved on the box, so it works for USB albums too.</p>
<h2>Details</h2>
<form method="post" action="/music/details" class="group pad stack">
<input type="hidden" name="key" value="{{ a.key }}">
<input type="text" name="album" value="{{ a.album }}" placeholder="Album" aria-label="Album">
<input type="text" name="artist" value="{{ a.artist }}" placeholder="Artist" aria-label="Artist">
<input type="text" name="year" value="{{ a.year or '' }}" placeholder="Year" inputmode="numeric" aria-label="Year">
<button class="btn plain wide">Save details</button>
</form>
<p class="note">This changes how the album is listed and sorted here. The music files aren't changed.</p>
{% if not a.usb and not a.multi and not locked %}
<div class="group" style="margin-top:28px"><form method="post" action="/music/delete" onsubmit="return confirm('Remove this album from the box?')">
<input type="hidden" name="path" value="{{ a.folder }}"><button class="item danger"><span class="badge" style="color:var(--bad)">{{ icon('trash', 18) }}</span><span class="label">Remove album from the box</span></button></form></div>
{% endif %}
<p class="note">Folder: {{ a.folder }}</p>
{% endblock %}"""

PAGES["wifi.html"] = """{% extends "base.html" %}{% block body %}
{% if not setup_mode %}<a class="backlink" href="/settings">{{ icon('back', 22) }}Settings</a>{% endif %}
{% if setup_mode and first_time %}{% with step_num = 2 %}{% include "progress.html" %}{% endwith %}{% endif %}
<h1>{{ "Connect to your Wi-Fi" if setup_mode and first_time else "Wi-Fi" }}</h1>
{% if setup_mode %}<p style="margin-bottom:18px">{% if first_time %}Pick your home network so {{ box_name }} can reach Spotify.{% else %}The box couldn't find a Wi-Fi network it knows, so it made its own. Pick your home network to get it online.{% endif %}</p>{% endif %}
{% if message %}<div class="toast">{{ icon('check', 20) }}<span>{{ message }}</span></div>{% endif %}
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
{% if not setup_mode %}
<div class="group"><div class="item"><span class="badge">{{ icon('wifi', 18) }}</span><span class="label">Connected to</span><span class="value">{{ current or "Nothing" }}</span></div></div>
{% endif %}
<h2>{{ "Your network" if setup_mode else "Add a network" }}</h2>
<form method="post" class="group pad stack" autocomplete="off">
{% if nearby %}<select name="ssid" aria-label="Network">
<option value="">Choose a network</option>
{% for n in nearby %}<option value="{{ n.ssid }}">{{ n.ssid }}{% if not n.secure %} (open){% endif %}</option>{% endfor %}
</select>
<details><summary class="small" style="color:var(--link);cursor:pointer">Not listed? Type the name</summary>
<input type="text" name="ssid_typed" placeholder="Network name" style="margin-top:10px" aria-label="Network name"></details>
{% else %}<input type="text" name="ssid_typed" placeholder="Network name" aria-label="Network name">{% endif %}
<input type="password" name="password" placeholder="Password (blank for open networks)" aria-label="Password">
<button class="btn wide">{{ "Join" if setup_mode else "Save network" }}</button>
</form>
{% if not setup_mode %}<script>
(function () {
  const sel = document.querySelector('select[name="ssid"]');
  let tries = 0;
  async function poll() {
    try {
      const d = await (await fetch("/api/wifi/nearby", {cache: "no-store"})).json();
      if (sel && d.nearby.length && document.activeElement !== sel && !sel.value) {
        const keep = sel.options[0].outerHTML;
        sel.innerHTML = keep + d.nearby.map(n => {
          const o = document.createElement("option"); o.value = n.ssid;
          o.textContent = n.ssid + (n.secure ? "" : " (open)"); return o.outerHTML; }).join("");
      }
      if (d.scanning && ++tries < 15) setTimeout(poll, 2000);
    } catch (e) {}
  }
  setTimeout(poll, 1500);
})();
</script>{% endif %}
<p class="note">The box uses 2.4 GHz Wi-Fi, which most home routers have. For an iPhone hotspot, turn on Maximize Compatibility.</p>
{% if not setup_mode %}
<h2>Saved networks</h2>
<div class="group">
{% for n in saved %}
<div class="item"><span class="label">{{ n.ssid }}</span>
{% if n.ssid == current %}<span class="value" style="color:var(--good)">Connected</span>
{% else %}<form method="post" action="/wifi/forget" onsubmit='return confirm({{ ("Forget " ~ n.ssid ~ "?")|tojson }})'>
<input type="hidden" name="profile" value="{{ n.profile }}"><button class="btn small plain" style="color:var(--bad)">Forget</button></form>{% endif %}</div>
{% else %}<div class="item muted">None yet</div>{% endfor %}
</div>
<p class="note">Taking the box somewhere new? Add that Wi-Fi here before you go. Or plug it in there: after about 2 minutes it makes a network called {{ setup_ssid }} (password musicbox) so you can add it. If nobody joins within 20 minutes it switches that off again; unplug and replug the box to bring it back.</p>
{% endif %}
{% endblock %}"""

PAGES["joining.html"] = """{% extends "base.html" %}
{% block style %}
ol.how{margin:0;padding:0;list-style:none;counter-reset:s}
ol.how li{counter-increment:s;display:flex;gap:12px;padding:6px 0}
ol.how li::before{content:counter(s);flex:none;width:26px;height:26px;border-radius:50%;
  background:var(--sunk);display:grid;place-items:center;font-weight:800;font-size:14px}
{% endblock %}{% block body %}
<h1>Joining {{ ssid }}</h1>
<div class="group pad stack">
<p>Your phone drops off {{ setup_ssid }} in a few seconds. That's expected.</p>
<ol class="how">
<li><span>Put your phone back on <b>{{ ssid }}</b>.</span></li>
<li><span>Wait a minute, then open <a class="addr" href="http://{{ host }}">http://{{ host }}</a>{% if first_time %} to finish setup{% endif %}.</span></li></ol>
</div>
<p class="note">Screenshot this page so you have the address. If it doesn't open, try <span class="addr">http://{{ fallback }}</span> (it always works), and make sure the address starts with http, not https.</p>
<p class="note">If the password was wrong, {{ setup_ssid }} comes back in about 2 minutes. Join it again and retry.</p>
{% endblock %}"""

PAGES["name.html"] = """{% extends "base.html" %}{% block body %}
{% if in_setup %}{% with step_num = 1 %}{% include "progress.html" %}{% endwith %}
{% else %}<a class="backlink" href="/settings">{{ icon('back', 22) }}Settings</a>{% endif %}
<h1>{{ "Name your speaker" if in_setup else "Speaker name" }}</h1>
<p style="margin-bottom:16px">This is what Spotify shows in its list of speakers, and what this app calls the box.</p>
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
<form method="post" class="group pad stack" autocomplete="off">
<input type="hidden" name="setup" value="{{ '1' if in_setup else '' }}">
<input type="text" name="name" id="name" value="{{ name }}" maxlength="{{ max_len }}" placeholder="For example: Ava's Room" aria-label="Speaker name" required>
<div class="chips">{% for idea in ideas %}<button type="button" data-n="{{ idea }}">{{ idea }}</button>{% endfor %}</div>
<p class="small muted">Web address: <span class="addr" id="addr">http://{{ host }}.local</span></p>
<button class="btn wide">{{ "Next" if in_setup else "Save name" }}</button>
</form>
<p class="note">Box ID {{ box }}. <span class="addr">http://{{ fallback }}.local</span> always reaches this box, whatever its name.{% if not in_setup %} After a rename, re-add the app to your home screen from the new address.{% endif %}</p>
<script>
(function () {
  const input = document.getElementById("name"), addr = document.getElementById("addr");
  let timer;
  function preview() {
    clearTimeout(timer);
    timer = setTimeout(async () => {
      if (!input.value.trim()) return;
      try {
        const d = await (await fetch("/api/name-preview?name=" + encodeURIComponent(input.value))).json();
        addr.textContent = "http://" + d.host + ".local";
      } catch (e) {}
    }, 250);
  }
  input.addEventListener("input", preview);
  document.querySelectorAll(".chips button").forEach(b => b.onclick = () => { input.value = b.dataset.n; preview(); });
  if (input.value) preview();
})();
</script>
{% endblock %}"""

PAGES["renamed.html"] = """{% extends "base.html" %}
{% block style %}
.wait{text-align:center;padding-top:40px}
.spin{width:44px;height:44px;margin:0 auto 22px;border-radius:50%;border:4px solid var(--line);
  border-top-color:var(--marigold);animation:spin 1s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
{% endblock %}{% block body %}
<div class="wait"><div class="spin"></div>
<h1>Now called {{ name }}</h1>
<p>Its new address is</p>
<p><a class="addr" style="font-size:20px" href="http://{{ host }}.local/{{ 'setup' if in_setup else 'settings' }}">http://{{ host }}.local</a></p>
<p class="muted small">This page moves there in about 15 seconds. Spotify shows the new name within a minute.</p>
</div>
<p class="note">If the new address doesn't open, use <span class="addr">http://{{ fallback }}.local</span>, which always works.</p>
<script>
setTimeout(() => location.replace("http://{{ host }}.local/{{ 'setup' if in_setup else 'settings' }}"), 15000);
</script>
{% endblock %}"""

PAGES["sound.html"] = """{% extends "base.html" %}{% block body %}
<a class="backlink" href="/settings">{{ icon('back', 22) }}Settings</a>
<h1>Sound</h1>
{% if message %}<div class="toast">{{ icon('check', 20) }}<span>{{ message }}</span></div>{% endif %}
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
{% if presets|length > 1 %}
<form method="post" class="group" id="presets">
{% for p in presets %}
<button class="item" name="preset" value="{{ p.name }}" {% if p.name == current %}aria-current="true"{% endif %}>
<span class="label">{% if p.name == current %}<b>{{ p.label }}</b>{% else %}{{ p.label }}{% endif %}{% if p.line %}<br><span class="small muted">{{ p.line }}</span>{% endif %}</span>
{% if p.name == current %}<span class="value" style="color:var(--good)">{{ icon('check', 20) }}</span>{% endif %}
</button>
{% endfor %}
</form>
<p class="note">Music pauses for about 2 seconds while the box switches. It remembers your pick after a restart.</p>
<script>
document.getElementById("presets").addEventListener("submit", () => {
  document.querySelectorAll("#presets button").forEach(b => b.style.opacity = .5);
});
</script>
{% else %}
<div class="group pad"><p>This box has one sound setting, tuned for its speakers.</p></div>
{% endif %}
{% endblock %}"""

PAGES["listening.html"] = """{% extends "base.html" %}
{% block style %}
.bars{display:flex;align-items:flex-end;gap:5px;height:120px;padding:16px 16px 0}
.bars div{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%;gap:6px}
.bars i{display:block;width:100%;border-radius:4px 4px 2px 2px;background:var(--marigold);min-height:2px}
.bars span{font-size:12px;color:var(--muted);font-weight:700;padding-bottom:10px}
.hours{display:flex;align-items:flex-end;gap:2px;height:56px;padding:14px 16px 0}
.hours i{flex:1;background:var(--ink);opacity:.75;border-radius:2px;min-height:2px}
.hlabels{display:flex;justify-content:space-between;font-size:12px;color:var(--muted);padding:6px 16px 12px}
.big{display:flex;gap:12px}
.big .group{flex:1;margin:0}
.big b{display:block;font-size:30px;font-weight:800;font-variant-numeric:tabular-nums}
.thumb{width:40px;height:40px;border-radius:8px;object-fit:cover;flex:none;background:var(--sunk)}
{% endblock %}{% block body %}
<a class="backlink" href="/settings">{{ icon('back', 22) }}Settings</a>
<h1>Listening</h1>
<div class="big">
<div class="group pad"><b>{{ (week_minutes / 60)|round(1) if week_minutes >= 60 else week_minutes }}</b><span class="muted small">{{ "hours" if week_minutes >= 60 else "minutes" }} this week</span></div>
<div class="group pad"><b>{{ week_plays }}</b><span class="muted small">tiles played this week</span></div>
</div>
<h2>Last 2 weeks</h2>
<div class="group"><div class="bars" role="img" aria-label="Minutes of music per day">
{% for d in days %}<div title="{{ d.date }}: {{ d.minutes }} min, {{ d.plays }} tiles"><i style="height:{{ (d.minutes / most * 100)|round }}%"></i><span>{{ d.label }}</span></div>{% endfor %}
</div></div>
{% if peak is not none %}
<h2>Time of day</h2>
<div class="group"><div class="hours" role="img" aria-label="Listening by hour">
{% for h in hours %}<i style="height:{{ (h / hour_max * 100)|round }}%"></i>{% endfor %}</div>
<div class="hlabels"><span>12a</span><span>6a</span><span>12p</span><span>6p</span><span>11p</span></div></div>
<p class="note">Busiest around {{ ((peak + 11) % 12) + 1 }} {{ "am" if peak < 12 else "pm" }}.</p>
{% endif %}
<h2>Favorite tiles</h2>
<div class="group">
{% for t in tiles %}<div class="item">{% if t.image %}<img class="thumb" src="{{ t.image }}" alt="">{% else %}<span class="thumb"></span>{% endif %}
<span class="label">{{ t.name }}<br><span class="small muted">{{ t.plays }} play{{ "s" if t.plays != 1 }} &middot; {{ t.minutes }} min</span></span></div>
{% else %}<div class="item muted">No tiles played yet</div>{% endfor %}
</div>
{% if albums %}<h2>Most played</h2>
<div class="group">{% for a in albums %}<div class="item"><span class="label">{{ a.name }}</span><span class="value">{{ a.minutes }} min</span></div>{% endfor %}</div>{% endif %}
<p class="note">Counted on this box since the update, including music started from the Spotify app.</p>
<h2>Help improve Music Box</h2>
<div class="group">
<form method="post" action="/listening/share"><input type="hidden" name="share" value="{{ 'off' if share else 'on' }}">
<button class="item"><span class="label">Share anonymous usage<br><span class="small muted">Whether the box is on, its software version, and how long each tile plays (tiles are sent as scrambled codes)</span></span>
<span class="switch {{ 'on' if share }}" role="switch" aria-checked="{{ 'true' if share else 'false' }}"></span></button></form>
</div>
<p class="note">Never shared: song, album or tile names, the speaker's name, your Wi-Fi, or your Spotify account.</p>
{% endblock %}"""

PAGES["apple.html"] = """{% extends "base.html" %}{% block body %}
<a class="backlink" href="/settings">{{ icon('back', 22) }}Settings</a>
<h1>Apple Music</h1>
{% if message %}<div class="toast">{{ icon('check', 20) }}<span>{{ message }}</span></div>{% endif %}
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
{% if unsupported %}
<p class="note">Apple Music isn't available on this box. It needs more powerful hardware than this box has. Spotify and your own music work as usual.</p>
{% else %}
<p class="note">Experimental. Apple doesn't support speakers like this one, so this works through a free program called Music Assistant that runs on the box. It needs an Apple Music subscription, and Apple may break it at any time.</p>
<form method="post" class="group pad stack">
<ol class="how">
<li><span>Install Music Assistant on the box (<code>install_apple_music.sh</code>).</span></li>
<li><span>Open Music Assistant at <b>http://{{ request.host.split(':')[0] }}:8095</b>, add the Apple Music provider and sign in.</span></li>
<li><span>In Music Assistant, make an access token (profile menu, Long-lived access token) and paste it below.</span></li></ol>
<label class="small muted">Music Assistant address</label>
<input type="url" name="url" value="{{ url }}" aria-label="Music Assistant address">
<label class="small muted">Access token {% if has_token %}(saved; leave blank to keep it){% endif %}</label>
<input type="password" name="token" value="" placeholder="{{ 'saved' if has_token else 'paste token' }}" autocomplete="off" aria-label="Access token">
<button class="btn wide">Save and test</button>
</form>
{% if has_token %}
<form method="post" class="group pad stack"><input type="hidden" name="action" value="test"><button class="btn plain wide">Test again</button></form>
<form method="post" class="group pad stack"><input type="hidden" name="action" value="remove"><button class="btn plain wide">Turn off Apple Music</button></form>
{% endif %}
{% endif %}
{% endblock %}"""

PAGES["account.html"] = """{% extends "base.html" %}{% block body %}
<a class="backlink" href="/settings">{{ icon('back', 22) }}Settings</a>
<h1>Spotify</h1>
{% if message %}<div class="toast">{{ icon('check', 20) }}<span>{{ message }}</span></div>{% endif %}
{% if need_install %}
{% set back = "/spotify" %}{% include "soloist_install_card.html" %}
{% elif pairing and pairing.soloist %}
{% set back = "/account" %}{% include "soloist_pair.html" %}
{% elif pairing %}
<div class="group pad stack">
<b>Connect Spotify</b>
<p>On your phone, open <a href="{{ pairing.url }}" target="_blank" rel="noopener">spotify.com/pair</a>, sign in, and type this code:</p>
<p class="code">{{ pairing.code }}</p>
</div>
<p class="note">Your password only goes to Spotify. Codes expire after a few minutes; reload this page for a new one.</p>
{% elif speaker %}
<div class="group">
<div class="item"><span class="badge" style="color:var(--good)">{{ icon('check', 18) }}</span><span class="label">Connected</span>{% if speaker_user %}<span class="value">{{ speaker_user }}</span>{% endif %}</div>
<form method="post" action="/account/speaker-signout" onsubmit="return confirm('Disconnect Spotify? You will connect it again {{ 'from the Spotify app' if soloist else 'with a code' }}.')">
<button class="item danger"><span class="badge" style="color:var(--bad)">{{ icon('power', 18) }}</span><span class="label">Disconnect</span></button></form>
</div>
<p class="note">To switch Spotify accounts, disconnect, then connect again {{ 'by picking this box in the Spotify app' if soloist else 'with the code that appears' }}.</p>
{% else %}
<div class="group">
<div class="item"><span class="badge" style="color:var(--bad)">{{ icon('alert', 18) }}</span><span class="label">The speaker isn't answering</span></div>
<form method="post" action="/power/restart-music"><button class="item"><span class="badge">{{ icon('restart', 18) }}</span><span class="label">Restart music</span></button></form>
</div>
{% endif %}
{% if not need_install %}
<details style="margin-top:28px"><summary class="small" style="color:var(--link);cursor:pointer;margin:0 6px">Advanced: reinstall Spotify's player</summary>
<div class="group pad stack" style="margin-top:10px">
<p class="small">Downloads Spotify's player again from Spotify and sets it up fresh. Your key and Spotify connection stay. Use it if Spotify stops working after a restart.</p>
{% if install.protected and not install.auto %}<p class="small muted">Needs maintenance mode first (Settings &gt; Unplug protection).</p>
{% else %}{% if install.protected %}<p class="small muted">The box restarts into maintenance mode for this and turns unplug protection back on by itself (about 10 minutes).</p>{% endif %}<form method="post" action="/spotify/install"><input type="hidden" name="back" value="/spotify"><button class="btn plain small">Reinstall Spotify's player</button></form>{% endif %}
</div></details>
{% endif %}
<details style="margin-top:12px"><summary class="small" style="color:var(--link);cursor:pointer;margin:0 6px">Advanced: search inside the app</summary>
<div class="group pad stack" style="margin-top:10px">
<p class="small">Optional. Pasting links works without this. Searching inside the app needs a free Spotify developer app (Client ID {{ client_id }}).</p>
{% if user %}<p class="small">Search is on, signed in as <b>{{ user }}</b>.</p>
{% elif problem %}<div class="toast bad">{{ problem }}</div>{% endif %}
<a class="btn plain small" href="/account/signin">{{ "Sign in again" if user else "Turn on search" }}</a>
</div></details>
{% endblock %}"""

PAGES["signin.html"] = """{% extends "base.html" %}
{% block style %}
ol.how{margin:0;padding:0;list-style:none;counter-reset:s}
ol.how li{counter-increment:s;display:flex;gap:12px;padding:8px 0}
ol.how li::before{content:counter(s);flex:none;width:26px;height:26px;border-radius:50%;
  background:var(--sunk);display:grid;place-items:center;font-weight:800;font-size:14px}
{% endblock %}{% block body %}
<a class="backlink" href="/spotify">{{ icon('back', 22) }}Spotify</a>
<h1>Turn on search</h1>
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
<div class="group pad">
<ol class="how">
<li><span>Open Spotify's sign-in page and approve. Your password goes to Spotify only.<br>
<a class="btn small" style="margin-top:10px" href="{{ url }}" target="_blank" rel="noopener">Open Spotify sign-in</a></span></li>
<li><span>You land on a page that won't load (something like "can't connect to 127.0.0.1"). That's expected.</span></li>
<li><span>Copy that page's whole web address and paste it below. It holds a one-time code, not your password.</span></li>
</ol>
<form method="post" action="/account/finish" class="stack" style="margin-top:12px">
<input type="text" name="pasted" placeholder="http://127.0.0.1:8888/callback?code=..." autocomplete="off" aria-label="Address">
<button class="btn wide">Finish</button></form>
</div>
<p class="note">The account must be on your developer app's User Management list.</p>
{% endblock %}"""

PAGES["settings.html"] = """{% extends "base.html" %}{% block body %}
<h1>Settings</h1>
{% if message %}<div class="toast">{{ icon('check', 20) }}<span>{{ message }}</span></div>{% endif %}
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
<div class="group">
<a class="item" href="/name"><span class="badge">{{ icon('music', 18) }}</span><span class="label">Speaker name</span><span class="value">{{ box_name }}</span><span class="chev">{{ icon('chevron', 18) }}</span></a>
{% if not is_pad %}<a class="item" href="/sound"><span class="badge">{{ icon('volume', 18) }}</span><span class="label">Sound</span><span class="value">{{ sound_line or "Choose" }}</span><span class="chev">{{ icon('chevron', 18) }}</span></a>{% endif %}
<a class="item" href="/music"><span class="badge">{{ icon('music', 18) }}</span><span class="label">Local music</span><span class="value">USB and uploads</span><span class="chev">{{ icon('chevron', 18) }}</span></a>
<a class="item" href="/wifi"><span class="badge">{{ icon('wifi', 18) }}</span><span class="label">Wi-Fi</span><span class="value">{{ wifi or "Not connected" }}</span><span class="chev">{{ icon('chevron', 18) }}</span></a>
<a class="item" href="/spotify"><span class="badge">{{ icon('music', 18) }}</span><span class="label">Spotify</span><span class="value">{{ spotify_line }}</span><span class="chev">{{ icon('chevron', 18) }}</span></a>
<a class="item" href="/updates"><span class="badge">{{ icon('restart', 18) }}</span><span class="label">Software updates</span><span class="value">{{ update_line }}</span><span class="chev">{{ icon('chevron', 18) }}</span></a>
{% if apple_ok %}<a class="item" href="/apple"><span class="badge">{{ icon('music', 18) }}</span><span class="label">Apple Music</span><span class="value">{{ apple_line }}</span><span class="chev">{{ icon('chevron', 18) }}</span></a>
{% else %}<div class="item" aria-disabled="true" style="opacity:.45;cursor:default"><span class="badge">{{ icon('music', 18) }}</span><span class="label">Apple Music</span><span class="value">Needs upgraded hardware</span></div>{% endif %}
</div>

<div class="group">
<a class="item" href="/listening"><span class="badge">{{ icon('now', 18) }}</span><span class="label">Listening</span><span class="value">Stats</span><span class="chev">{{ icon('chevron', 18) }}</span></a>
</div>

{% if is_pad %}
<h2>Volume control</h2>
<div class="group">
<form method="post"><input type="hidden" name="line_out" value="variable">
<button class="item" {% if line_out != 'fixed' %}aria-current="true"{% endif %}><span class="label">Pad's knob</span><span class="value">Knob and phone set the volume</span>{% if line_out != 'fixed' %}<span class="chev">{{ icon('check', 18) }}</span>{% endif %}</button></form>
<form method="post"><input type="hidden" name="line_out" value="fixed">
<button class="item" {% if line_out == 'fixed' %}aria-current="true"{% endif %}><span class="label">Stereo's knob</span><span class="value">Pad stays at full volume</span>{% if line_out == 'fixed' %}<span class="chev">{{ icon('check', 18) }}</span>{% endif %}</button></form>
</div>
<p class="note">Pick which knob you'll turn. "Stereo's knob" sends the cleanest signal and turns the Pad's knob off. Turn your stereo down before you pick it: the Pad jumps to full right away.</p>
{% endif %}
{% if not (is_pad and line_out == 'fixed') %}
<h2>Volume limits</h2>
<form method="post" class="group">
<div class="item"><span class="label">Lowest</span><input class="num" type="number" name="volume_min" value="{{ volume_min }}" min="0" max="100" aria-label="Lowest volume"></div>
<div class="item"><span class="label">Highest</span><input class="num" type="number" name="volume_max" value="{{ volume_max }}" min="0" max="100" aria-label="Highest volume"></div>
<button class="item action">Save limits</button>
</form>
<p class="note">The knob and any phone stay between these (0 to 100). The lowest keeps the box from seeming broken; the highest keeps little hands from cranking it.</p>
{% endif %}

<h2>Pick up where it left off</h2>
<form method="post" class="group">
<div class="item"><span class="label">Within</span><input class="num" type="number" name="resume_minutes" value="{{ resume_minutes }}" min="0" max="240" aria-label="Minutes"><span class="muted">min</span></div>
<button class="item action">Save</button>
</form>
<p class="note">Put the same tile back within this time and it keeps going. After that it starts over.</p>

<h2>Startup sound</h2>
<div class="group">
<form method="post"><input type="hidden" name="startup_sound" value="{{ 'off' if startup_sound else 'on' }}">
<button class="item"><span class="badge">{{ icon('volume', 18) }}</span><span class="label">Chime when ready</span>
<span class="switch {{ 'on' if startup_sound }}" role="switch" aria-checked="{{ 'true' if startup_sound else 'false' }}"></span></button></form>
<button type="button" class="item action" onclick="this.disabled=true;fetch('/api/chime',{method:'POST'}).finally(()=>setTimeout(()=>this.disabled=false,2500))">Play it</button>
</div>
<p class="note">Plays once after the box is plugged in, as soon as it's ready for a tile.</p>

<h2>Appearance</h2>
<div class="group pad">
<div class="seg" role="radiogroup" aria-label="Appearance">
<button type="button" role="radio" data-t="auto">Automatic</button>
<button type="button" role="radio" data-t="light">Light</button>
<button type="button" role="radio" data-t="dark">Dark</button>
</div></div>
<p class="note">Automatic follows this phone's own setting. Each phone remembers its choice.</p>
<script>
(function () {
  const buttons = document.querySelectorAll(".seg button");
  function mark(t) { buttons.forEach(b => b.setAttribute("aria-checked", b.dataset.t === t)); }
  buttons.forEach(b => b.onclick = () => {
    try { localStorage.setItem("theme", b.dataset.t); } catch (e) {}
    applyTheme(b.dataset.t); mark(b.dataset.t);
  });
  mark(savedTheme);
})();
</script>

<h2>Power</h2>
<div class="group">
<form method="post" action="/power/restart-music"><button class="item"><span class="badge">{{ icon('music', 18) }}</span><span class="label">Restart music<br><span class="small muted">Fixes most problems in about 20 seconds</span></span></button></form>
<form method="post" action="/power/reboot" onsubmit="return confirm('Restart the whole box?')"><button class="item"><span class="badge">{{ icon('restart', 18) }}</span><span class="label">Restart box</span></button></form>
<form method="post" action="/power/shutdown" onsubmit="return confirm('Shut the box down?')"><button class="item danger"><span class="badge" style="color:var(--bad)">{{ icon('power', 18) }}</span><span class="label">Shut down</span></button></form>
</div>
<p class="note">{% if protected %}With unplug protection on, simply unplugging is fine too.{% else %}After Shut down, wait 30 seconds before unplugging.{% endif %}</p>

<h2 id="protection">Unplug protection</h2>
<div class="group">
<div class="item"><span class="badge" style="color:{{ 'var(--good)' if protected else 'var(--bad)' }}">{{ icon('shield', 18) }}</span>
<span class="label">{% if protected %}On<br><span class="small muted">Pulling the plug can't hurt the box</span>{% else %}Off (maintenance mode)<br><span class="small muted">Updates can be installed</span>{% endif %}</span></div>
{% if protected %}
<form method="post" action="/maintenance/on" onsubmit="return confirm('Restart in maintenance mode? Only needed for updates.')">
<button class="item"><span class="badge">{{ icon('restart', 18) }}</span><span class="label">Turn on maintenance mode</span></button></form>
{% else %}
<form method="post" action="/maintenance/off" onsubmit="return confirm('Turn unplug protection back on? The box restarts, which can take a few minutes.')">
<button class="item"><span class="badge" style="background:var(--marigold);color:var(--on-marigold)">{{ icon('shield', 18) }}</span><span class="label"><b>Turn unplug protection on</b></span></button></form>
{% endif %}
</div>
<p class="note">{% if protected %}Tiles, settings, Wi-Fi and Spotify still save within about 15 seconds of a change. Maintenance mode is only for installing updates.{% else %}Use Shut down before unplugging while this is off.{% endif %}</p>

<h2>PIN</h2>
<form method="post" class="group" autocomplete="off">
<div class="item"><input type="password" name="old_pin" inputmode="numeric" placeholder="Current PIN" aria-label="Current PIN"></div>
<div class="item"><input type="password" name="new_pin" inputmode="numeric" placeholder="New PIN (4 to 8 numbers)" aria-label="New PIN"></div>
<button class="item action">Change PIN</button>
</form>
<form method="post" action="/lock" class="group"><button class="item"><span class="badge">{{ icon('lock', 18) }}</span><span class="label">Lock this phone</span></button></form>

<h2>Setup</h2>
<form method="post" action="/setup/again" class="group" onsubmit="return confirm('Walk through setup again? Your tiles, Wi-Fi and Spotify stay as they are.')">
<button class="item"><span class="badge">{{ icon('restart', 18) }}</span><span class="label">Run setup again</span></button></form>

<p class="note" style="margin-top:22px">Put the app on your home screen: in Safari, tap Share, then Add to Home Screen.<br>
Address: <span class="addr">http://{{ speaker_host }}</span> &middot; also <span class="addr">http://{{ box_fallback }}</span><br>
Box ID {{ box_id }} &middot; Music Box app {{ version }}</p>
{% endblock %}"""

PAGES["power.html"] = """{% extends "base.html" %}
{% block style %}
.wait{text-align:center;padding-top:60px}
.spin{width:44px;height:44px;margin:0 auto 22px;border-radius:50%;border:4px solid var(--line);
  border-top-color:var(--marigold);animation:spin 1s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
{% endblock %}{% block body %}
<div class="wait">
{% if action != "shutdown" %}<div class="spin"></div>{% endif %}
{% if action == "shutdown" %}<h1>Shutting down</h1>
<p>Wait about 30 seconds, until the green light on the Pi stops blinking, then unplug it.</p>
{% elif action == "reboot" %}<h1>Restarting</h1><p class="muted">About a minute. This page reconnects by itself.</p>
{% elif action == "maintenance-on" %}<h1>Restarting in maintenance mode</h1><p class="muted">2 to 5 minutes. This page reconnects by itself.</p>
{% elif action == "maintenance-off" %}<h1>Turning unplug protection on</h1><p class="muted">Up to 5 minutes. Please don't unplug it meanwhile. This page reconnects by itself.</p>
{% else %}<h1>Restarting music</h1><p class="muted">About 20 seconds. This page goes back to Now by itself.</p>{% endif %}
</div>
{% if action != "shutdown" %}<script>
setTimeout(function wait(){
  fetch("/api/now", {cache: "no-store"}).then(r => r.ok ? location.replace("/") : setTimeout(wait, 3000))
    .catch(() => setTimeout(wait, 3000));
}, {{ 20000 if action == "restart-music" else 30000 }});
</script>{% endif %}
{% endblock %}"""

app.jinja_loader = DictLoader(PAGES)


if __name__ == "__main__":
    threading.Thread(target=setup.loop, daemon=True).start()
    threading.Thread(target=keeper.loop, daemon=True).start()
    threading.Thread(target=publisher.loop, daemon=True).start()
    threading.Thread(target=listening.loop, daemon=True).start()
    app.run(host="0.0.0.0", port=PORT, threaded=True)
