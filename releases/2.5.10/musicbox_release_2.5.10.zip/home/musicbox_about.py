"""
musicbox_about.py
"About this album" for the Now page: year, label, track list, credits and a
short Wikipedia summary, looked up once per album and saved on the box.

Sources (both free, no account):
  - MusicBrainz (musicbrainz.org): release year, label, credits. Their rule is
    at most 1 request per second with a named app, so lookups go one at a
    time with a pause, and every album is only ever looked up once.
  - Wikipedia, found through the link MusicBrainz keeps to Wikidata. The text
    is CC BY-SA, so the app shows "From Wikipedia" with a link.
Nothing about the listener is sent: only the artist and album names.
If nothing is found the card simply doesn't show.
"""

import json
import os
import re
import threading
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request

from musicbox_common import HERE, read_json, write_json

CACHE_FILE = os.path.join(HERE, "about_cache.json")
USER_AGENT = "MusicBoxSpeaker/2.2 (home NFC speaker)"
MB = "https://musicbrainz.org/ws/2"
RETRY_AFTER = 2 * 60            # a lookup that failed (offline? busy?) is retried after this
NOT_FOUND_AFTER = 30 * 86400    # "nothing found" is rechecked after a month
MAX_CACHE = 500

_lock = threading.Lock()
_busy = set()
_last_mb = [0.0]

ROLE_NAMES = [   # (MusicBrainz relation type, what we call it) in display order
    ("composer", "Written by"), ("writer", "Written by"), ("lyricist", "Lyrics by"),
    ("producer", "Produced by"), ("vocal", "Vocals"), ("instrument", "Musicians"),
    ("performer", "Musicians"), ("arranger", "Arranged by"), ("conductor", "Conductor"),
    ("orchestra", "Orchestra"), ("mix", "Mixed by"), ("recording", "Recorded by"),
    ("engineer", "Engineered by"), ("mastering", "Mastered by"),
]
ROLE_ORDER = {t: i for i, (t, _) in enumerate(ROLE_NAMES)}
ROLE_LABEL = dict(ROLE_NAMES)


def key_for(artist, album):
    return f"{_simple(artist.split(',')[0])}|{_simple(clean_album(album))}"


_EXTRA = r"(remaster|deluxe|edition|anniversary|expanded|mono|stereo|bonus|special)"


def clean_album(album):
    """Spotify adds "(Remastered 2004)", "(Deluxe Edition)", "25 Super Deluxe
    Edition" etc. MusicBrainz names the album plainly."""
    album = re.sub(r"\s*[\(\[][^)\]]*" + _EXTRA + r"[^)\]]*[\)\]]", "", album, flags=re.I)
    album = re.sub(r"\s+[-:\u2013]\s+.*" + _EXTRA + r".*$", "", album, flags=re.I)
    # "Thriller 25 Super Deluxe Edition" -> "Thriller"
    album = re.sub(r"\s+(\d+(st|nd|rd|th)?\s+)?((super|anniversary|expanded|special|legacy)\s+)*(deluxe|anniversary|expanded|legacy|special)(\s+(edition|version))?\s*$",
                   "", album, flags=re.I)
    album = re.sub(r"\s+\(?remaster(ed)?(\s+\d{4})?\)?\s*$", "", album, flags=re.I)
    return album.strip() or album


# --------------------------------------------------------------------------
# Web requests
# --------------------------------------------------------------------------
def _get_json(url, timeout=30):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def log(message):
    print(f"About: {message}", flush=True)


def _mb(path, **params):
    """One MusicBrainz request, never more than one a second."""
    wait = 1.1 - (time.time() - _last_mb[0])
    if wait > 0:
        time.sleep(wait)
    params["fmt"] = "json"
    url = f"{MB}/{path}?{urllib.parse.urlencode(params)}"
    for attempt in range(3):
        try:
            return _get_json(url)
        except urllib.error.HTTPError as err:
            if err.code in (429, 503) and attempt < 2:    # MusicBrainz busy: wait and retry
                time.sleep(3 * (attempt + 1))
                continue
            raise
        finally:
            _last_mb[0] = time.time()


def _lucene(text):
    return re.sub(r'([+\-&|!(){}\[\]^"~*?:\\/])', r"\\\1", text)


def _simple(text):
    return re.sub(r"[^a-z0-9]+", "", unicodedata.normalize("NFKD", text or "").casefold())


# --------------------------------------------------------------------------
# Wikipedia (via Wikidata)
# --------------------------------------------------------------------------
def _wiki_summary(relations):
    qid, title = "", ""
    for rel in relations or []:
        url = (rel.get("url") or {}).get("resource", "")
        if rel.get("type") == "wikidata":
            qid = url.rstrip("/").rsplit("/", 1)[-1]
        elif rel.get("type") == "wikipedia" and "en.wikipedia.org/wiki/" in url:
            title = urllib.parse.unquote(url.split("/wiki/", 1)[1])
    if not title and qid.startswith("Q"):
        data = _get_json(f"https://www.wikidata.org/wiki/Special:EntityData/{qid}.json")
        title = (((data.get("entities", {}).get(qid) or {}).get("sitelinks") or {})
                 .get("enwiki") or {}).get("title", "")
    if not title:
        return None
    page = _get_json("https://en.wikipedia.org/api/rest_v1/page/summary/"
                     + urllib.parse.quote(title.replace(" ", "_"), safe=""))
    text = (page.get("extract") or "").strip()
    if not text or page.get("type") == "disambiguation":
        return None
    if len(text) > 700:
        text = text[:700].rsplit(". ", 1)[0] + "."
    link = ((page.get("content_urls") or {}).get("mobile") or {}).get("page") \
        or f"https://en.wikipedia.org/wiki/{urllib.parse.quote(title.replace(' ', '_'))}"
    return {"text": text, "link": link}


# --------------------------------------------------------------------------
# Credits
# --------------------------------------------------------------------------
def _add_credits(credits, relations):
    for rel in relations or []:
        kind = rel.get("type", "")
        artist = (rel.get("artist") or {}).get("name")
        if not artist or kind not in ROLE_LABEL:
            continue
        label = ROLE_LABEL[kind]
        detail = ", ".join(re.sub(r"\s*\(.*?\)", "", a) for a in rel.get("attributes") or []
                           if a not in ("additional", "guest", "co", "executive", "lead vocals"))
        if kind == "producer" and "executive" in (rel.get("attributes") or []):
            label = "Executive producer"
        name = f"{artist} ({detail})" if detail and label in ("Musicians", "Vocals") else artist
        bucket = credits.setdefault(label, [ROLE_ORDER.get(kind, 99), []])
        if name not in bucket[1]:
            bucket[1].append(name)


def _credit_list(credits, limit_names=8):
    rows = sorted(credits.items(), key=lambda kv: kv[1][0])
    out = []
    for label, (_, names) in rows:
        extra = len(names) - limit_names
        out.append({"role": label, "names": names[:limit_names] + ([f"and {extra} more"] if extra > 0 else [])})
    return out


# --------------------------------------------------------------------------
# Track list
# --------------------------------------------------------------------------
def _release_order(r):
    """Earliest first; on the same date prefer a CD or digital release with a
    full date (vinyl sides and partial dates make odder track lists)."""
    date = r.get("date") or "9999"
    fmt = " ".join((m.get("format") or "") for m in r.get("media") or [])
    return (date[:4], 0 if ("CD" in fmt or "Digital" in fmt) else 1, len(date) < 10, date)


def _track_list(release):
    """[{"disc": 1, "n": 1, "title": ..., "ms": 293000}, ...] from a release
    looked up with inc=recordings."""
    out = []
    for d, medium in enumerate(release.get("media") or [], 1):
        for i, track in enumerate(medium.get("tracks") or [], 1):
            rec = track.get("recording") or {}
            title = track.get("title") or rec.get("title")
            if not title:
                continue
            out.append({"disc": medium.get("position") or d, "n": track.get("position") or i,
                        "title": title, "ms": track.get("length") or rec.get("length") or 0})
    return out


def _track_keys(name):
    """Ways a Spotify track name can match a MusicBrainz title:
    "Billie Jean - 2008 Remaster", "Thriller (Single Version)", etc."""
    name = name or ""
    keys = {_simple(name), _simple(name.split(" - ")[0]),
            _simple(re.sub(r"\s*[\(\[][^)\]]*[\)\]]", "", name)),
            _simple(re.sub(r"\s*[\(\[][^)\]]*[\)\]]", "", name.split(" - ")[0]))}
    keys.discard("")
    return keys


def _mark_playing(tracklist, track):
    """Copy of the track list with "playing": true on the song that's on now."""
    want = _track_keys(track)
    hit = None
    for i, t in enumerate(tracklist):            # exact title first
        if _simple(t["title"]) == _simple(track):
            hit = i
            break
    if hit is None:
        for i, t in enumerate(tracklist):
            if want & _track_keys(t["title"]):
                hit = i
                break
    return [dict(t, playing=(i == hit)) for i, t in enumerate(tracklist)]


# --------------------------------------------------------------------------
# The lookup
# --------------------------------------------------------------------------
def _pick_group(found, title, loose=False):
    """Best release group for a Spotify album name, or None."""
    want = _simple(title)
    best, best_rank = None, None
    for g in found.get("release-groups", []):
        score = int(g.get("score", 0) or 0)
        name = _simple(g.get("title"))
        if not name:
            continue
        if name == want:
            fit = 0
        elif want.startswith(name) and len(name) >= 4:
            fit = 1                         # "Thriller 25 ..." vs "Thriller"
        elif score >= 97 and not loose:    # loose searches score everything high
            fit = 2
        else:
            continue
        kind = 0 if g.get("primary-type") == "Album" else 1 if g.get("primary-type") == "EP" else 2
        rank = (fit, kind, -score)
        if best_rank is None or rank < best_rank:
            best, best_rank = g, rank
    return best


def lookup(artist, album):
    """Returns the album info, {} when nothing matched. Raises only if even the
    first search fails (offline, MusicBrainz down)."""
    first_artist = artist.split(",")[0].strip()
    title = clean_album(album)
    found = _mb("release-group/", query=f'releasegroup:"{_lucene(title)}" AND artist:"{_lucene(first_artist)}"',
                limit=10)
    group = _pick_group(found, title)
    if not group and title != album:
        found = _mb("release-group/", query=f'releasegroup:"{_lucene(album)}" AND artist:"{_lucene(first_artist)}"',
                    limit=10)
        group = _pick_group(found, album)
    if not group:
        # Looser search: Spotify names like "Millennium 2.0" or "Album (Bonus
        # Track Version)" don't match MusicBrainz's "Millennium" as a phrase.
        # Search the title's words instead, and also just its first part.
        words = re.sub(r"[\(\[].*$", "", title).strip() or title
        for t in dict.fromkeys([words, re.split(r"\s+(?:\d+(?:\.\d+)?|vol\.?\s*\d+)\b", words, flags=re.I)[0]]):
            terms = " ".join(_lucene(w) for w in t.split())
            found = _mb("release-group/", query=f'releasegroup:({terms}) AND artist:"{_lucene(first_artist)}"', limit=10)
            group = _pick_group(found, title, loose=True)
            if group:
                break
    if not group:
        log(f"no MusicBrainz match for {first_artist} / {title}")
        return {}
    info = {"title": group.get("title", title), "year": (group.get("first-release-date") or "")[:4],
            "type": group.get("primary-type", ""), "mb": f"https://musicbrainz.org/release-group/{group['id']}",
            "tracks": {}, "tracklist": [], "credits": [], "wiki": None}
    try:
        group = _mb(f"release-group/{group['id']}", inc="url-rels+artist-credits")
        info["year"] = (group.get("first-release-date") or "")[:4] or info["year"]
    except (urllib.error.URLError, OSError, ValueError) as err:
        log(f"release group details failed: {err}")

    # Label, track list and credits from one official release (the earliest).
    # Big albums make a big answer, so this step is allowed to fail on its own,
    # and the track list is then fetched again without the credits.
    release_id = None
    try:
        releases = _mb("release", **{"release-group": group["id"], "status": "official", "limit": 50})
        rel_list = sorted(releases.get("releases", []), key=_release_order)
        if rel_list:
            release_id = rel_list[0]["id"]
            release = _mb(f"release/{release_id}",
                          inc="labels+recordings+artist-rels+recording-level-rels+work-rels+work-level-rels")
            info["tracklist"] = _track_list(release)
            labels = [li["label"]["name"] for li in release.get("label-info") or [] if li.get("label")]
            if labels and labels[0] != "[no label]":
                info["label"] = labels[0]
            album_credits = {}
            _add_credits(album_credits, release.get("relations"))
            for medium in release.get("media") or []:
                for track in medium.get("tracks") or []:
                    rec = track.get("recording") or {}
                    credits = {}
                    _add_credits(credits, rec.get("relations"))
                    for rel in rec.get("relations") or []:
                        if rel.get("type") == "performance" and rel.get("work"):
                            _add_credits(credits, rel["work"].get("relations"))
                    if credits:
                        info["tracks"][_simple(track.get("title") or rec.get("title"))] = _credit_list(credits)
            info["credits"] = _credit_list(album_credits)
    except (urllib.error.URLError, OSError, ValueError) as err:
        log(f"credits failed: {err}")
    if release_id and not info["tracklist"]:
        try:
            info["tracklist"] = _track_list(_mb(f"release/{release_id}", inc="recordings"))
        except (urllib.error.URLError, OSError, ValueError) as err:
            log(f"track list failed: {err}")
    try:
        info["wiki"] = _wiki_summary(group.get("relations"))
    except (urllib.error.URLError, OSError, ValueError) as err:
        log(f"Wikipedia failed: {err}")
    if not info["wiki"]:                          # no album article: try the artist's
        try:
            ac = (group.get("artist-credit") or [{}])[0].get("artist") or {}
            if ac.get("id"):
                a = _mb(f"artist/{ac['id']}", inc="url-rels")
                wiki = _wiki_summary(a.get("relations"))
                if wiki:
                    info["artist_wiki"] = dict(wiki, name=a.get("name", ""))
        except (urllib.error.URLError, OSError, ValueError) as err:
            log(f"artist Wikipedia failed: {err}")
    log(f"found {info['title']} ({info['year']}): {len(info['tracklist'])} tracks, {len(info['credits'])} credit rows, "
        f"{len(info['tracks'])} tracks with credits, wiki={'yes' if info['wiki'] else 'no'}")
    return info


def _store(key, entry):
    with _lock:
        cache = read_json(CACHE_FILE, {})
        cache[key] = entry
        if len(cache) > MAX_CACHE:              # drop the oldest
            for old in sorted(cache, key=lambda k: cache[k].get("when", 0))[:len(cache) - MAX_CACHE]:
                cache.pop(old, None)
        write_json(CACHE_FILE, cache)


def _worker(key, artist, album):
    old = read_json(CACHE_FILE, {}).get(key) or {}
    try:
        info = lookup(artist, album)
    except Exception as err:                    # offline, rate-limited, odd reply: try later
        log(f"lookup failed for {artist} / {album}: {err!r}")
        info = None
    try:
        if not info and old.get("status") == "ok":
            # A refresh (to add the track list) failed: keep what we had.
            _store(key, dict(old, tracklist_tried=time.time()))
        elif info is None:
            _store(key, {"when": time.time(), "info": {}, "status": "error"})
        else:
            _store(key, {"when": time.time(), "info": info, "status": "ok" if info else "none"})
    finally:
        _busy.discard(key)


def about(artist, album, track=""):
    """What the Now page shows. {"status": "loading"|"none"|"ok", ...}"""
    if not artist or not album:
        return {"status": "none"}
    key = key_for(artist, album)
    entry = read_json(CACHE_FILE, {}).get(key)
    age = time.time() - (entry or {}).get("when", 0)
    stale = (not entry or (entry["status"] == "error" and age > RETRY_AFTER)
             or (entry["status"] == "none" and age > NOT_FOUND_AFTER)
             # saved before the box showed track lists: look it up once more
             or (entry["status"] == "ok" and "tracklist" not in (entry.get("info") or {})
                 and time.time() - entry.get("tracklist_tried", 0) > RETRY_AFTER))
    if stale and key not in _busy and len(_busy) < 2:
        _busy.add(key)
        threading.Thread(target=_worker, args=(key, artist, album), daemon=True).start()
    if not entry or (stale and key in _busy and entry["status"] != "ok"):
        return {"status": "loading"}
    info = entry.get("info") or {}
    if not info:
        return {"status": "none"}
    out = {k: v for k, v in info.items() if k not in ("tracks", "tracklist")}
    out["tracklist"] = _mark_playing(info.get("tracklist") or [], track)
    out["status"] = "ok"
    tracks = info.get("tracks") or {}
    out["track_credits"] = tracks.get(_simple(track)) or tracks.get(_simple(clean_album(track))) \
        or tracks.get(_simple(track.split(" - ")[0])) or []
    return out
