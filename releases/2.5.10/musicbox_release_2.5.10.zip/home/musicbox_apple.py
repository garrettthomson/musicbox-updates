"""
musicbox_apple.py   (PROTOTYPE, for the owner's own box)
Apple Music on the box, through Music Assistant (MA), an open-source music
server that runs next to the box programs. MA signs in to Apple Music and
streams it; the box tells MA what to play when a tile is set down, the same
way it tells go-librespot for Spotify.

  A tile's link looks like   apple:album:1440857781     (album)
                             apple:playlist:pl.u-abc123 (playlist)
  (the number is the one at the end of a music.apple.com album link)

Apple does not support this: MA's own docs say playback is "not officially
supported by Apple, use at your own risk". Treat it as an experiment.

Uses only Python's standard library (the button program imports it too).
Everything about MA's API names is in COMMANDS below, so if a name is wrong
on a real server, fix it in that one table. `python3 musicbox_apple.py check`
tries each command and says which ones the server rejects.
"""

import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

HERE = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(HERE, "apple_music.json")     # MA address + access token
PREFIX = "apple:"
DEFAULT_URL = "http://127.0.0.1:8095"
PLAYER_NAME = "Music Box"                                # the speaker's name inside MA

# MA command names (from MA's docs where marked "docs", otherwise from memory of
# its source: check them with `check`).
COMMANDS = {
    "players": "players/all",                       # unverified
    "queue": "player_queues/get",                   # unverified
    "play_media": "player_queues/play_media",       # docs
    "pause": "player_queues/pause",                 # unverified
    "resume": "player_queues/play",                 # unverified
    "next": "player_queues/next",                   # unverified
    "previous": "player_queues/previous",           # unverified
    "stop": "player_queues/stop",                   # unverified
    "shuffle": "player_queues/shuffle",             # unverified
    "repeat": "player_queues/repeat",               # unverified
    "seek": "player_queues/seek",                   # unverified
    "volume": "players/cmd/volume_set",             # unverified
    "item_by_uri": "music/item_by_uri",             # docs
    "search": "music/search",                       # unverified
}
# The ways MA might spell an Apple Music item's address (first one that exists wins).
URI_FORMS = ("apple_music://{kind}/{id}",)


class AppleError(Exception):
    pass


# --------------------------------------------------------------------------
# Settings
# --------------------------------------------------------------------------
def load_config():
    try:
        with open(CONFIG_FILE) as f:
            data = json.load(f)
    except (OSError, ValueError):
        data = {}
    data.setdefault("url", DEFAULT_URL)
    data.setdefault("token", "")
    data.setdefault("player_id", "")
    return data


def save_config(url=None, token=None, player_id=None):
    data = load_config()
    if url is not None:
        data["url"] = url.strip().rstrip("/") or DEFAULT_URL
    if token is not None:
        data["token"] = token.strip()
    if player_id is not None:
        data["player_id"] = player_id
    tmp = CONFIG_FILE + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, CONFIG_FILE)


def configured():
    """True once an access token has been saved (cheap: no network)."""
    return bool(load_config().get("token"))


# --------------------------------------------------------------------------
# Talking to Music Assistant
# --------------------------------------------------------------------------
def call(command, timeout=8, **args):
    """Run one MA command over its HTTP API. Returns the result."""
    cfg = load_config()
    body = json.dumps({"message_id": uuid.uuid4().hex[:12], "command": command, "args": args}).encode()
    request = urllib.request.Request(
        cfg["url"] + "/api", data=body, method="POST",
        headers={"Content-Type": "application/json", "Authorization": "Bearer " + cfg["token"]})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read()
    except urllib.error.HTTPError as err:
        detail = err.read()[:200].decode("utf-8", "replace")
        raise AppleError(f"{command}: HTTP {err.code} {detail}")
    except (urllib.error.URLError, OSError) as err:
        raise AppleError(f"Music Assistant isn't answering ({err})")
    try:
        data = json.loads(raw) if raw.strip() else None
    except ValueError:
        raise AppleError(f"{command}: reply wasn't JSON")
    if isinstance(data, dict) and ("error_code" in data or "details" in data and "result" not in data):
        raise AppleError(f"{command}: {data.get('details') or data.get('error_code')}")
    if isinstance(data, dict) and "result" in data and ("message_id" in data or len(data) <= 3):
        return data["result"]
    return data


def reachable():
    try:
        call(COMMANDS["players"], timeout=4)
        return True
    except AppleError:
        return False


def players():
    result = call(COMMANDS["players"])
    return result if isinstance(result, list) else []


def find_player():
    """The box's own speaker inside MA: the saved one, or the one named 'Music Box'
    (or the only Squeezelite/Slimproto player)."""
    cfg = load_config()
    found = players()
    if cfg.get("player_id"):
        for p in found:
            if p.get("player_id") == cfg["player_id"]:
                return p
    named = [p for p in found if PLAYER_NAME.lower() in (p.get("display_name") or p.get("name") or "").lower()]
    pool = named or [p for p in found if (p.get("provider") or "").lower() in ("squeezelite", "slimproto")]
    available = [p for p in pool if p.get("available", True)]
    chosen = (available or pool or [None])[0]
    if chosen and chosen.get("player_id") != cfg.get("player_id"):
        save_config(player_id=chosen["player_id"])
    return chosen


def player_id():
    p = find_player()
    if not p:
        raise AppleError("The box's speaker isn't showing up in Music Assistant yet")
    return p["player_id"]


# --------------------------------------------------------------------------
# Tile links
# --------------------------------------------------------------------------
def parse_link(text):
    """A music.apple.com link (or apple:album:ID) -> 'apple:album:ID', or None."""
    text = (text or "").strip()
    match = re.fullmatch(r"apple:(album|playlist):([A-Za-z0-9.\-_]+)", text)
    if match:
        return text
    try:
        parsed = urllib.parse.urlparse(text)
    except ValueError:
        return None
    if "music.apple.com" not in (parsed.netloc or ""):
        return None
    parts = [p for p in parsed.path.split("/") if p]
    for kind in ("album", "playlist"):
        if kind in parts:
            ident = parts[-1]
            if kind == "album" and not ident.isdigit():
                return None
            if kind == "playlist" and not ident.startswith("pl."):
                return None
            return f"apple:{kind}:{ident}"
    return None


def is_apple_uri(uri):
    return bool(uri) and uri.startswith(PREFIX)


def split_uri(uri):
    _, kind, ident = uri.split(":", 2)
    return kind, ident


def ma_item_uri(uri):
    """The address MA uses for this tile's album/playlist (checked against the server)."""
    kind, ident = split_uri(uri)
    last = None
    for form in URI_FORMS:
        candidate = form.format(kind=kind, id=ident)
        try:
            item = call(COMMANDS["item_by_uri"], uri=candidate)
        except AppleError as err:
            last = err
            continue
        if item:
            return (item.get("uri") if isinstance(item, dict) else None) or candidate
    raise AppleError(f"Music Assistant can't find {uri}" + (f" ({last})" if last else ""))


# --------------------------------------------------------------------------
# Playing
# --------------------------------------------------------------------------
def play(uri):
    """Start a tile's album/playlist from the top. Raises AppleError on trouble."""
    pid = player_id()
    media = ma_item_uri(uri)
    for name, args in (("shuffle", {"shuffle_enabled": False}), ("repeat", {"repeat_mode": "off"})):
        try:
            call(COMMANDS[name], queue_id=pid, **args)
        except AppleError:
            pass                                       # nice to have, not needed
    call(COMMANDS["play_media"], queue_id=pid, media=media)
    remember_loaded(uri)
    set_source("apple")


def queue():
    return call(COMMANDS["queue"], queue_id=player_id()) or {}


def state():
    """'playing', 'paused', 'idle' or '' (unknown / MA down)."""
    try:
        q = queue()
    except AppleError:
        return ""
    value = str(q.get("state") or "").lower()
    return {"playing": "playing", "paused": "paused", "idle": "idle", "off": "idle"}.get(value, value)


def is_playing():
    return state() == "playing"


def pause():
    try:
        call(COMMANDS["pause"], queue_id=player_id())
        return True
    except AppleError:
        return False


def resume():
    try:
        call(COMMANDS["resume"], queue_id=player_id())
        set_source("apple")
        return True
    except AppleError:
        return False


def next_track():
    try:
        call(COMMANDS["next"], queue_id=player_id())
    except AppleError:
        pass


def back():
    """Restart the song; press again near the start for the one before."""
    try:
        pid = player_id()
        elapsed = float(queue().get("elapsed_time") or 0)
        if elapsed > 3:
            call(COMMANDS["seek"], queue_id=pid, position=0)
        else:
            call(COMMANDS["previous"], queue_id=pid)
    except (AppleError, ValueError):
        pass


def get_volume():
    try:
        value = find_player().get("volume_level")
        return None if value is None else int(round(float(value)))
    except (AppleError, AttributeError, ValueError):
        return None


def set_volume(percent):
    try:
        call(COMMANDS["volume"], player_id=player_id(), volume_level=max(0, min(100, int(percent))))
    except AppleError:
        pass


def paused_on(uri):
    """True if this tile's album is the loaded queue and it is paused."""
    try:
        q = queue()
    except AppleError:
        return False
    return str(q.get("state") or "").lower() == "paused" and loaded_uri() == uri


# What is loaded (the queue can't tell us which tile started it).
LOADED_FILE = "/dev/shm/musicbox-apple-loaded"


def loaded_uri():
    try:
        with open(LOADED_FILE) as f:
            return f.read().strip()
    except OSError:
        return ""


def remember_loaded(uri):
    try:
        with open(LOADED_FILE, "w") as f:
            f.write(uri)
    except OSError:
        pass


def now_playing():
    """What the phone app shows while Apple Music plays, or None."""
    try:
        q = queue()
    except AppleError:
        return None
    st = str(q.get("state") or "").lower()
    if st not in ("playing", "paused"):
        return None
    item = q.get("current_item") or {}
    media = item.get("media_item") or {}
    artists = media.get("artists") or []
    album = media.get("album") or {}
    image = ""
    for holder in (item, media, album):
        img = holder.get("image") or {}
        if isinstance(img, dict) and img.get("path"):
            image = img["path"]
            break
    if not image:
        for img in ((media.get("metadata") or {}).get("images") or []):
            if isinstance(img, dict) and img.get("path"):
                image = img["path"]
                break
    return {
        "playing": st == "playing",
        "track": item.get("name") or media.get("name") or "",
        "artist": ", ".join(a.get("name", "") for a in artists if isinstance(a, dict)) or "",
        "album": album.get("name", "") if isinstance(album, dict) else "",
        "image": image if image.startswith("http") else "",
        "volume": get_volume(),
    }


# --------------------------------------------------------------------------
# Finding music
# --------------------------------------------------------------------------
def search(text, limit=8):
    """Albums from Apple Music matching text: [{uri, name, artist, image}]."""
    result = call(COMMANDS["search"], search_query=text, media_types=["album"], limit=limit)
    albums = (result or {}).get("albums") if isinstance(result, dict) else []
    out = []
    for a in albums or []:
        provider = " ".join(str(a.get(k, "")) for k in ("provider", "provider_domain", "uri")).lower()
        if "apple" not in provider:
            continue
        item_id = str(a.get("item_id") or "")
        if not item_id and a.get("uri"):
            item_id = str(a["uri"]).rstrip("/").rsplit("/", 1)[-1]
        if not item_id.isdigit():
            continue
        artists = a.get("artists") or []
        img = ((a.get("metadata") or {}).get("images") or [{}])[0].get("path", "") if a.get("metadata") else ""
        out.append({"uri": f"apple:album:{item_id}", "name": a.get("name", ""),
                    "artist": ", ".join(x.get("name", "") for x in artists if isinstance(x, dict)),
                    "image": img if str(img).startswith("http") else "",
                    "year": a.get("year") or 0})
    return out


def describe_link(uri):
    """(name, image) for a tile link, looked up from MA; ('', '') if it can't."""
    try:
        kind, ident = split_uri(uri)
        item = call(COMMANDS["item_by_uri"], uri=URI_FORMS[0].format(kind=kind, id=ident))
    except (AppleError, ValueError):
        return "", ""
    if not isinstance(item, dict):
        return "", ""
    artists = ", ".join(x.get("name", "") for x in item.get("artists") or [] if isinstance(x, dict))
    name = item.get("name", "")
    images = ((item.get("metadata") or {}).get("images") or [{}])
    img = images[0].get("path", "") if images else ""
    return (f"{name} · {artists}" if artists else name), (img if str(img).startswith("http") else "")


# --------------------------------------------------------------------------
# Which source is playing (shared with musicbox_local, same file)
# --------------------------------------------------------------------------
SOURCE_FILE = "/dev/shm/musicbox-source"


def set_source(name):
    try:
        with open(SOURCE_FILE, "w") as f:
            f.write(name)
    except OSError:
        pass


def source():
    try:
        with open(SOURCE_FILE) as f:
            return f.read().strip() or "spotify"
    except OSError:
        return "spotify"


def watch(others_playing, stop=lambda: False):
    """If something else starts (Spotify from a phone, local music), pause Apple Music."""
    votes = 0
    while not stop():
        time.sleep(3)
        try:
            if not configured() or source() == "apple":
                votes = 0
                continue
            if others_playing() and is_playing():
                votes += 1
                if votes >= 2:
                    pause()
                    votes = 0
            else:
                votes = 0
        except Exception:
            pass


# --------------------------------------------------------------------------
# Checking a real server
# --------------------------------------------------------------------------
def check():
    """Try the read-only commands against the server; print what works."""
    print("Music Assistant:", load_config()["url"])
    problems = 0

    def attempt(label, fn):
        nonlocal problems
        try:
            result = fn()
            print(f"  OK    {label}")
            return result
        except AppleError as err:
            problems += 1
            print(f"  FAIL  {label}: {err}")
        return None
    found = attempt("list players", players)
    if found is not None:
        names = ", ".join(f"{p.get('display_name') or p.get('name')} [{p.get('provider')}]" for p in found) or "none"
        print("        players:", names)
    me = attempt(f"find the '{PLAYER_NAME}' speaker", find_player)
    if me is None and found is not None:
        problems += 1
        print(f"  FAIL  no speaker named '{PLAYER_NAME}' (is squeezelite running?)")
    if me:
        attempt("read the queue", queue)
        attempt("read the volume", get_volume)
    res = attempt("search Apple Music", lambda: search("the beatles", 3))
    if res is not None and not res:
        print("        search worked but returned no Apple Music albums: sign in to Apple Music in MA")
    print("Everything answered." if not problems else f"{problems} problem(s). Send Claude this output.")
    return problems


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "check"
    if cmd == "check":
        sys.exit(1 if check() else 0)
    elif cmd == "play" and len(sys.argv) > 2:
        play(parse_link(sys.argv[2]) or sys.argv[2])
    elif cmd == "pause":
        print(pause())
    elif cmd == "state":
        print(state(), now_playing())
    else:
        print(__doc__)
