#!/bin/bash
# install_admin.sh - lets the phone app install Spotify's player and box
# software updates by itself (no terminal for the owner).
# Installs (root-owned): /usr/local/sbin/musicbox-admin, /usr/local/lib/musicbox/
# (update checker + Spotify player installer), a sudoers entry that lets the
# app start just those three jobs (and the hidden troubleshooting switch), a
# daily update check, and the start-up check that keeps unplug protection on.
#
# Run as root with MB_USER set (musicbox_install.sh and updates do this):
#   sudo MB_USER=$(whoami) bash ~/musicbox/install_admin.sh --copy-from ~/musicbox
# Without --copy-from it only sets up the sudoers entry and the daily check
# (an update has already put the files in place).
set -eu
ME="${MB_USER:?set MB_USER to the box user}"
H="$(getent passwd "$ME" | cut -d: -f6)"
R="${MB_SYSROOT:-}"
SC="${MB_SYSTEMCTL:-systemctl}"
LIB="$R/usr/local/lib/musicbox"
[ "$(id -u)" = 0 ] || [ -n "$R" ] || { echo "Run as root (sudo)."; exit 1; }

if [ "${1:-}" = "--copy-from" ]; then
  SRC="$2"
  OWN=""; [ -z "$R" ] && OWN="-o root -g root"
  install -d $OWN -m 755 "$R/usr/local/sbin" "$LIB" "$LIB/soloist"
  install $OWN -m 755 "$SRC/musicbox-admin" "$R/usr/local/sbin/musicbox-admin"
  install $OWN -m 644 "$SRC/musicbox_update.py" "$LIB/musicbox_update.py"
  for f in install_soloist.sh soloist_update.sh soloist_run.sh; do
    install $OWN -m 755 "$SRC/soloist/$f" "$LIB/soloist/$f"
  done
  install $OWN -m 644 "$SRC/soloist/soloist_bridge.py" "$LIB/soloist/soloist_bridge.py"
  [ -f "$SRC/install_player.sh" ] && install $OWN -m 755 "$SRC/install_player.sh" "$LIB/install_player.sh"
  [ -f "$SRC/factory_reset.sh" ] && install $OWN -m 755 "$SRC/factory_reset.sh" "$LIB/factory_reset.sh"
fi
[ -x "$R/usr/local/sbin/musicbox-admin" ] || { echo "musicbox-admin is missing"; exit 1; }

# The app may start these three jobs (plain, or "auto-": switch maintenance mode
# on and off by itself around the job), nothing else.
A=/usr/local/sbin/musicbox-admin
# Factory reset (2.5.9): only the exact option words the app sends.
RESET=""
for t in keep-tiles erase-tiles; do for m in keep-music erase-music; do for a in shut-down restart; do
  RESET="$RESET, $A factory-reset $t,$m,$a, $A auto-factory-reset $t,$m,$a"
done; done; done
# (commas inside an argument must be escaped for sudoers)
RESET=$(printf '%s' "$RESET" | sed -E 's/(-tiles|-music),/\1\\,/g')
T=$(mktemp)
cat > "$T" <<SUDO
$ME ALL=(root) NOPASSWD: $A soloist-install, $A update-apply, $A update-rollback, $A auto-soloist-install, $A auto-update-apply, $A auto-update-rollback, $A player-install, $A auto-player-install, $A player-start, $A maintenance-on, $A protect-on, $A music-open, $A music-close$RESET
SUDO
if [ -z "$R" ]; then visudo -cf "$T" > /dev/null; fi
install -d -m 755 "$R/etc/sudoers.d"
install -m 440 "$T" "$R/etc/sudoers.d/musicbox-admin"; rm -f "$T"

install -d -m 755 "$R/etc/systemd/system"
cat > "$R/etc/systemd/system/musicbox-update-check.service" <<UNIT
[Unit]
Description=Music Box: check for new box software (downloads one public file; sends nothing about the box)
Wants=network-online.target
After=network-online.target

[Service]
Type=oneshot
User=$ME
Nice=10
ExecStart=/usr/bin/python3 -I /usr/local/lib/musicbox/musicbox_update.py check --home $H
UNIT
cat > "$R/etc/systemd/system/musicbox-update-check.timer" <<'UNIT'
[Unit]
Description=Music Box: check for new box software once a day

[Timer]
OnBootSec=15min
OnCalendar=*-*-* 03:40
RandomizedDelaySec=2h
Persistent=true

[Install]
WantedBy=timers.target
UNIT
# At each start-up: finishes an install the app started, otherwise makes sure
# unplug protection is on (unless maintenance mode was turned on on purpose).
cat > "$R/etc/systemd/system/musicbox-admin-resume.service" <<'UNIT'
[Unit]
Description=Music Box: finish an install the app started, or keep unplug protection on
Wants=network-online.target
After=network-online.target musicbox-web.service

[Service]
Type=simple
ExecStart=/usr/bin/python3 -I /usr/local/sbin/musicbox-admin _resume
TimeoutStopSec=30

[Install]
WantedBy=multi-user.target
UNIT
install -d -m 755 "$R/var/lib/musicbox-admin"

# Under unplug protection, ~/Music is the memory card's own folder (2.5.5), so
# music added in the app goes straight to the card instead of the box's memory.
# Takes effect at the next start-up.
cat > "$R/etc/systemd/system/musicbox-music-mount.service" <<'UNIT'
[Unit]
Description=Music Box: keep added music on the memory card (unplug protection)
After=local-fs.target
Before=musicbox-mpd.service musicbox-web.service musicbox-persist.service musicbox.service

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/usr/bin/python3 -I /usr/local/sbin/musicbox-admin _music_mount

[Install]
WantedBy=multi-user.target
UNIT

# The save keeper must be there before protection can be switched on (it saves
# tiles, settings, Wi-Fi and music while the system is read-only).
if [ ! -f "$R/etc/systemd/system/musicbox-persist.service" ] && [ -f "$H/musicbox/musicbox_persist.py" ]; then
  cat > "$R/etc/systemd/system/musicbox-persist.service" <<UNIT
[Unit]
Description=Music Box save keeper (unplug protection)
After=local-fs.target

[Service]
ExecStart=/usr/bin/python3 $H/musicbox/musicbox_persist.py $H
Restart=always
RestartSec=5
Environment=PYTHONUNBUFFERED=1
TimeoutStopSec=20

[Install]
WantedBy=multi-user.target
UNIT
  $SC daemon-reload
  $SC enable musicbox-persist > /dev/null 2>&1 || true
  $SC start musicbox-persist > /dev/null 2>&1 || true
fi

# A reminder for anyone who logs in with SSH: changes are lost while protection is on.
install -d -m 755 "$R/etc/profile.d"
cat > "$R/etc/profile.d/musicbox-protection.sh" <<'SH'
if awk '$2=="/" && $3=="overlay"{f=1} END{exit !f}' /proc/mounts 2>/dev/null; then
  echo "Music Box: unplug protection is ON, so changes made here are lost at the next restart."
  echo "  To change the system: sudo musicbox-admin maintenance-on   (restarts; stays writable)"
  echo "  When done:            sudo musicbox-admin protect-on"
elif [ -f /var/lib/musicbox-admin/hold.json ]; then
  echo "Music Box: maintenance mode is on (system writable). When done: sudo musicbox-admin protect-on"
fi
SH
chmod 644 "$R/etc/profile.d/musicbox-protection.sh"
$SC daemon-reload
$SC enable musicbox-admin-resume.service > /dev/null 2>&1 || true
$SC enable musicbox-music-mount.service > /dev/null 2>&1 || true
$SC enable musicbox-update-check.timer > /dev/null 2>&1 || true
$SC start musicbox-update-check.timer > /dev/null 2>&1 || true
echo "App helper installed: Spotify player install and software updates work from the app."
