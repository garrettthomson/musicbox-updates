"""
musicbox_common.py
Shared pieces used by both programs:
  musicbox.py      watches the NFC reader and plays albums
  musicbox_web.py  the phone app at http://<box name>.local

Keep all three files together in ~/musicbox/.
"""

import fcntl
import json
import os
import re
import subprocess
import urllib.error
import urllib.parse
import urllib.request

import spotipy
from spotipy.cache_handler import CacheFileHandler
from spotipy.oauth2 import SpotifyPKCE

# --------------------------------------------------------------------------
# Settings
# --------------------------------------------------------------------------
SPEAKER_NAME = "Music Box"   # must match LIBRESPOT_NAME in /etc/raspotify/conf

# Spotify app details. The Client ID is a name tag, not a password.
CLIENT_ID = "74d498a3c2a44309bd6ef88b986259ff"
REDIRECT_URI = "http://127.0.0.1:8888/callback"
SCOPES = "user-read-playback-state user-modify-playback-state"

HERE = os.path.dirname(os.path.abspath(__file__))
TOKEN_CACHE = os.path.join(HERE, ".spotify_token_cache")  # Spotify login pass
TOKENS_FILE = os.path.join(HERE, "tokens.json")           # coin ID -> album
SETTINGS_FILE = os.path.join(HERE, "settings.json")       # PIN, resume time
STATE_FILE = os.path.join(HERE, "state.json")             # what's on the reader
LOCK_FILE = os.path.join(HERE, ".spotify_lock")

DEFAULT_SETTINGS = {"resume_minutes": 10, "volume_min": 10, "volume_max": 100,
                    "startup_sound": True,
                    "product": "speaker",     # "pad" = no speakers, line out to a stereo
                    "line_out": "variable"}   # Pad only: "fixed" = always full volume, knob off


# --------------------------------------------------------------------------
# Small files
# --------------------------------------------------------------------------
def read_json(path, default):
    try:
        with open(path) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def write_json(path, data):
    """Write to a temp file, then swap it in, so a crash never leaves half a file."""
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, path)


def load_tokens():
    """Coin ID -> {"uri", "name", "image"}. Older files stored only the uri."""
    raw = read_json(TOKENS_FILE, {})
    tokens = {}
    for token_id, value in raw.items():
        if isinstance(value, str):
            value = {"uri": value, "name": "", "image": ""}
        value.setdefault("on_tile", False)
        tokens[token_id] = value
    return tokens


def save_tokens(tokens):
    write_json(TOKENS_FILE, tokens)


def token_uri(token_id):
    entry = load_tokens().get(token_id)
    return entry["uri"] if entry else None


def link_token(token_id, uri, name="", image="", on_tile=None):
    """Save (or change) what a tile plays. on_tile records whether the link is
    also written on the tile itself; None keeps whatever was known before
    (only if the music didn't change)."""
    tokens = load_tokens()
    old = tokens.get(token_id, {})
    if on_tile is None:
        on_tile = old.get("on_tile", False) if old.get("uri") == uri else False
    tokens[token_id] = {"uri": uri, "name": name or (old.get("name", "") if old.get("uri") == uri else ""),
                        "image": image or (old.get("image", "") if old.get("uri") == uri else ""),
                        "on_tile": on_tile}
    save_tokens(tokens)


def set_on_tile(token_id, value):
    tokens = load_tokens()
    if token_id in tokens:
        tokens[token_id]["on_tile"] = value
        save_tokens(tokens)


def spotify_link_for(uri):
    """spotify:album:ID -> https://open.spotify.com/album/ID"""
    parts = uri.split(":")
    return f"https://open.spotify.com/{parts[1]}/{parts[2]}" if len(parts) == 3 and parts[0] == "spotify" else None


# The phone app asks the tile program to write a link onto a tile through
# this little file (only the tile program can talk to the reader).
WRITE_REQUEST = os.path.join(HERE, "write_request.json")


def load_settings():
    settings = dict(DEFAULT_SETTINGS)
    settings.update(read_json(SETTINGS_FILE, {}))
    return settings


def save_settings(settings):
    write_json(SETTINGS_FILE, settings)


def spotify_uri_from_link(text):
    """Turn a Spotify share link into spotify:album:ID form. Works for albums,
    playlists, artists, songs, podcasts, podcast episodes and audiobooks."""
    match = re.search(r"(album|playlist|artist|track|show|episode|audiobook)[/:]([A-Za-z0-9]{22})",
                      text or "")
    return f"spotify:{match.group(1)}:{match.group(2)}" if match else None


# What each kind of Spotify link is called in the app.
KIND_NAMES = {"album": "Album", "playlist": "Playlist", "artist": "Artist", "track": "Song",
              "show": "Podcast", "episode": "Podcast episode", "audiobook": "Audiobook"}


def kind_of(uri):
    """spotify:album:ID -> "Album" (or "" if unknown)."""
    if (uri or "").startswith("local:"):
        return ""
    parts = (uri or "").split(":")
    return KIND_NAMES.get(parts[1], "") if len(parts) == 3 else ""


# Where a tile's music comes from. Add a line here when a new service is added.
SOURCES = (("spotify:", "Spotify"), ("local:", "Local"), ("apple:", "Apple Music"))


def source_name(uri):
    for prefix, name in SOURCES:
        if (uri or "").startswith(prefix):
            return name
    return ""


def tile_badge(tile):
    """'Playlist from Spotify', 'Audiobook from your music', 'Album from Apple Music'
    for the tile lists. Every tile says where its music comes from (Spotify asks that
    any preset tied to its content says so)."""
    uri = tile.get("uri", "")
    detail = tile.get("kind") or kind_of(uri)
    where = from_name(uri)
    if where:
        return f"{detail} from {where}" if detail else f"From {where}"
    return detail


# How the app finishes "Playing from ..." / "Album from ..." for each source.
FROM_NAMES = (("spotify:", "Spotify"), ("local:", "your music"), ("apple:", "Apple Music"))


def from_name(uri):
    for prefix, name in FROM_NAMES:
        if (uri or "").startswith(prefix):
            return name
    return ""


def spotify_link(uri):
    """spotify:album:ID -> https://open.spotify.com/album/ID (opens the Spotify app
    on phones that have it, the Spotify website otherwise). '' if it isn't one."""
    parts = (uri or "").split(":")
    if len(parts) >= 3 and parts[0] == "spotify" and re.fullmatch(r"[A-Za-z0-9]+", parts[-1]):
        kind = parts[-2]
        if kind in KIND_NAMES or kind == "collection":
            return f"https://open.spotify.com/{kind}/{parts[-1]}"
    return "https://open.spotify.com/" if parts[0] == "spotify" else ""


# --------------------------------------------------------------------------
# Spotify
# --------------------------------------------------------------------------
class NotSignedIn(Exception):
    pass


class LockedPKCE(SpotifyPKCE):
    """
    Both programs share one login file. The lock stops them from refreshing
    it at the same moment, and we refuse to ask for a login in a terminal
    nobody is watching (the phone app handles signing in instead).
    """

    def get_access_token(self, code=None, check_cache=True):
        with open(LOCK_FILE, "w") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            if code is None and not self.cache_handler.get_cached_token():
                raise NotSignedIn()
            try:
                return super().get_access_token(code=code, check_cache=check_cache)
            except EOFError:
                raise NotSignedIn()


def make_auth():
    return LockedPKCE(
        client_id=CLIENT_ID,
        redirect_uri=REDIRECT_URI,
        scope=SCOPES,
        cache_handler=CacheFileHandler(cache_path=TOKEN_CACHE),
        open_browser=False,
    )


def connect_spotify():
    return spotipy.Spotify(auth_manager=make_auth(), requests_timeout=10, retries=2)


def signed_in():
    return os.path.exists(TOKEN_CACHE)


def find_speaker(sp):
    for device in sp.devices().get("devices", []):
        if device.get("name") == SPEAKER_NAME:
            return device["id"]
    return None


def describe_public(uri):
    """Name and cover from Spotify's public link preview (no account needed)."""
    try:
        kind, item_id = uri.split(":")[1:3]
        link = f"https://open.spotify.com/{kind}/{item_id}"
        url = "https://open.spotify.com/oembed?url=" + urllib.parse.quote(link, safe="")
        with urllib.request.urlopen(url, timeout=8) as response:
            data = json.loads(response.read())
        return data.get("title", ""), data.get("thumbnail_url", "")
    except Exception:
        return "", ""


def describe(sp, uri):
    """Look up a name and cover picture for an album, playlist, or artist.
    Uses the optional Spotify developer sign-in if there is one, otherwise
    the public link preview."""
    if (uri or "").startswith("local:"):
        return os.path.basename(uri[len("local:"):].rstrip("/")), ""
    if (uri or "").startswith("apple:"):
        return uri, ""
    if sp is None or not signed_in():
        return describe_public(uri)
    try:
        kind = uri.split(":")[1]
        if kind == "album":
            item = sp.album(uri)
            artists = ", ".join(a["name"] for a in item.get("artists", []))
            name = f"{item['name']} · {artists}" if artists else item["name"]
        elif kind == "playlist":
            item = sp.playlist(uri, fields="name,images")
            name = item["name"]
        elif kind == "artist":
            item = sp.artist(uri)
            name = item["name"]
        else:
            return "", ""
        images = item.get("images") or []
        return name, (images[0]["url"] if images else "")
    except Exception:
        return describe_public(uri)


# --------------------------------------------------------------------------
# The speaker (go-librespot) has its own remote control inside the box.
# These calls never leave the box, so they're fast and have no rate limits.
# --------------------------------------------------------------------------
SPEAKER_API = "http://127.0.0.1:3678"
SPEAKER_STATE = os.path.expanduser("~/.config/go-librespot/state.json")


class SpeakerOffline(Exception):
    pass


def speaker_call(path, body=None, timeout=5):
    """POST when there's a body (or for player commands), GET otherwise.
    Returns parsed JSON, {} for an empty reply, or raises SpeakerOffline."""
    method = "POST" if body is not None or path.startswith("/player/") and path != "/player/volume" else "GET"
    data = json.dumps(body).encode() if body is not None else (b"" if method == "POST" else None)
    request = urllib.request.Request(SPEAKER_API + path, data=data, method=method,
                                     headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read()
            return json.loads(raw) if raw.strip() else {}
    except (urllib.error.URLError, ConnectionError, TimeoutError, OSError) as err:
        raise SpeakerOffline(str(err))


def speaker_status():
    """What the speaker is doing: {} when idle, raises SpeakerOffline if it's down."""
    return speaker_call("/status")


# --------------------------------------------------------------------------
# Startup chime
# --------------------------------------------------------------------------
CHIME_FILE = os.path.join(HERE, "chime.wav")


def play_chime():
    """Play the short chime through the speaker (mixes with any music).
    Returns True if it played."""
    if not os.path.exists(CHIME_FILE):
        return False
    try:
        return subprocess.run(["aplay", "-q", "-D", "default", CHIME_FILE],
                              timeout=10).returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False
