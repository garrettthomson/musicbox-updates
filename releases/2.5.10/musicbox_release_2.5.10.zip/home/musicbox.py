"""
musicbox.py
The tile program: set a tile on the box and its music plays on the "Music Box"
speaker. Lift it and the music pauses.

  Tile placed             -> play its music from the start, in order
  Tile lifted             -> pause after REMOVE_DELAY seconds
  Same tile back within   -> resume where it left off
    the resume window        (set in the phone app, 10 minutes to start)
  Same tile back later    -> start over
  Different tile          -> start the new one
  A "local:" tile         -> plays a folder from the USB stick or memory card
                             (see musicbox_local.py); long ones remember their place
  New (unlinked) tile     -> "teach mode" for 60 seconds: play any album,
                             playlist or podcast on Music Box from the Spotify
                             app and the tile learns it. Or link it in the app.

Tiles can carry their own link: the box writes the Spotify link onto the tile
(the same way phones write NFC tags), so a tile works on any music box. On
this box, its own list wins; tiles it has never seen play the link they carry.

Run it:           ~/musicbox/venv/bin/python ~/musicbox/musicbox.py
List tiles:       ~/musicbox/venv/bin/python ~/musicbox/musicbox.py list
Stop it:          Control + C

Needs musicbox_common.py in the same folder.
"""

import fcntl
import os
import sys
import threading
import time

import musicbox_apple as apple
import musicbox_local as local
from musicbox_common import (
    SPEAKER_NAME, STATE_FILE, WRITE_REQUEST, SpeakerOffline, describe,
    link_token, load_settings, load_tokens, play_chime, read_json, save_tokens, set_on_tile,
    speaker_call, speaker_status, spotify_link_for, spotify_uri_from_link,
    token_uri, write_json,
)

REMOVE_DELAY = 0.75   # seconds without the tile before pausing
TEACH_SECONDS = 60    # how long a new tile waits to learn something
TEACH_CHECK = 2       # seconds between checks while teaching
TEACHABLE = ("album", "playlist", "artist", "show")

# --------------------------------------------------------------------------
# NFC reader
# --------------------------------------------------------------------------
# Use the separate reader bus (pins 16 and 18) when it exists, which frees
# pin 5 for a power button. Otherwise use the standard bus (pins 3 and 5).
I2C_BUS = "/dev/i2c-3" if os.path.exists("/dev/i2c-3") else "/dev/i2c-1"
PN532_ADDRESS = 0x24
I2C_SLAVE = 0x0703
ACK = bytes([0x00, 0x00, 0xFF, 0x00, 0xFF, 0x00])

# Standard NFC "URI record" prefixes (the first byte of a link on a tag).
URI_PREFIXES = ["", "http://www.", "https://www.", "http://", "https://"]


class PN532:
    def __init__(self):
        self.dev = open(I2C_BUS, "r+b", buffering=0)
        fcntl.ioctl(self.dev, I2C_SLAVE, PN532_ADDRESS)

    def _write_frame(self, data):
        length = len(data)
        frame = [0x00, 0x00, 0xFF, length, (-length) & 0xFF]
        frame += data + [(-sum(data)) & 0xFF, 0x00]
        self.dev.write(bytes(frame))

    def _wait_ready(self, timeout):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            try:
                if self.dev.read(1)[0] & 0x01:
                    return True
            except OSError:
                pass
            time.sleep(0.01)
        return False

    def _read(self, count):
        return self.dev.read(count + 1)[1:]

    def command(self, cmd, params=(), response_length=32, timeout=1.0):
        """Send a command and return the reader's answer.
        Any missing or garbled answer is an error: the reader is told to drop
        what it was doing, so the next command starts clean instead of
        getting out of step (which used to look like "no tile" forever)."""
        self._write_frame([0xD4, cmd] + list(params))
        if not self._wait_ready(timeout) or self._read(6) != ACK:
            self.resync()
            raise RuntimeError("Reader did not acknowledge the command")
        if not self._wait_ready(timeout):
            self.resync()
            raise RuntimeError("Reader didn't answer in time")
        raw = self._read(response_length + 8)
        start = raw.find(b"\x00\xff")
        body, ok = b"", False
        if start >= 0 and start + 4 < len(raw):
            length, lcs = raw[start + 2], raw[start + 3]
            body = raw[start + 4 : start + 4 + length]
            dcs_at = start + 4 + length
            # The reader adds two check bytes to every answer. If either
            # doesn't add up, some bits got scrambled on the wires.
            ok = ((length + lcs) & 0xFF == 0 and len(body) == length
                  and dcs_at < len(raw) and (sum(body) + raw[dcs_at]) & 0xFF == 0)
        if not ok or len(body) < 2 or body[0] != 0xD5 or body[1] != cmd + 1:
            self.resync()
            raise RuntimeError("Reader's answer was garbled")
        return body[2:]

    def resync(self):
        """Un-stick a reader that was mid-command when the Pi restarted."""
        try:
            self.dev.write(ACK)
        except OSError:
            pass
        time.sleep(0.05)
        for _ in range(3):
            try:
                self.dev.read(32)
            except OSError:
                pass
            time.sleep(0.02)

    def setup(self):
        self.resync()
        self.command(0x14, [0x01, 0x14, 0x01])        # normal mode
        self.command(0x32, [0x05, 0xFF, 0x01, 0x02])  # look briefly, then report

    def read_token_id(self):
        """Look for a tile. Returns its ID, and leaves it selected so the
        next read or write goes to it."""
        reply = self.command(0x4A, [0x01, 0x00], response_length=20)
        if not reply or reply[0] == 0:
            return None
        id_length = reply[5]
        return ":".join(f"{b:02X}" for b in reply[6 : 6 + id_length])

    # --- reading and writing the tile's memory (NTAG215) -------------------
    def read_pages(self, page):
        """Read 4 pages (16 bytes) starting at page."""
        reply = self.command(0x40, [0x01, 0x30, page], response_length=24)
        if not reply or reply[0] != 0x00 or len(reply) < 17:
            raise RuntimeError("Couldn't read the tile")
        return bytes(reply[1:17])

    def write_page(self, page, four_bytes):
        reply = self.command(0x40, [0x01, 0xA2, page] + list(four_bytes), response_length=8)
        if not reply or reply[0] != 0x00:
            raise RuntimeError(f"Couldn't write page {page}")

    def read_tile_link(self):
        """The web link written on the tile (if any), as text."""
        data = bytearray(self.read_pages(4))
        i = 0

        def need(n):
            while len(data) < n:
                if len(data) >= 500:
                    raise RuntimeError("Tile data too long")
                data.extend(self.read_pages(4 + len(data) // 4))

        while True:
            need(i + 1)
            t = data[i]
            if t == 0x00:            # padding (a brand-new tile is often all zeros)
                i += 1
                if i >= 32:
                    return None
                continue
            if t == 0xFE:            # end of data
                return None
            need(i + 2)
            length = data[i + 1]
            head = 2
            if length == 0xFF:
                need(i + 4)
                length = (data[i + 2] << 8) | data[i + 3]
                head = 4
            need(i + head + length)
            if t != 0x03:            # not an NDEF message; skip it
                i += head + length
                continue
            msg = bytes(data[i + head : i + head + length])
            return parse_uri_record(msg)

    def write_tile_link(self, url):
        """Write url onto the selected tile as a standard NFC link."""
        cc = self.read_pages(3)[:4]
        if cc == b"\x00\x00\x00\x00":
            self.write_page(3, b"\xE1\x10\x3E\x00")   # mark it as an NFC data tag
        record = make_uri_record(url)
        tlv = bytes([0x03, len(record)]) + record + b"\xFE"
        tlv += b"\x00" * (-len(tlv) % 4)
        for n in range(len(tlv) // 4):
            self.write_page(4 + n, tlv[4 * n : 4 * n + 4])
        if self.read_tile_link() != url:
            raise RuntimeError("The tile didn't keep the link")


def make_uri_record(url):
    code, rest = 0, url
    for i, prefix in enumerate(URI_PREFIXES):
        if prefix and url.startswith(prefix) and len(prefix) > len(URI_PREFIXES[code]):
            code, rest = i, url[len(prefix):]
    payload = bytes([code]) + rest.encode()
    if len(payload) > 250:
        raise ValueError("Link too long for a tile")
    return bytes([0xD1, 0x01, len(payload), 0x55]) + payload   # one short "U" record


def parse_uri_record(msg):
    if len(msg) < 3:
        return None
    header = msg[0]
    tnf, short, has_id = header & 0x07, header & 0x10, header & 0x08
    type_len = msg[1]
    pos = 2
    if short:
        payload_len = msg[pos]
        pos += 1
    else:
        payload_len = int.from_bytes(msg[pos : pos + 4], "big")
        pos += 4
    id_len = 0
    if has_id:
        id_len = msg[pos]
        pos += 1
    rtype = msg[pos : pos + type_len]
    pos += type_len + id_len
    payload = msg[pos : pos + payload_len]
    if tnf != 0x01 or rtype != b"U" or not payload:
        return None
    prefix = URI_PREFIXES[payload[0]] if payload[0] < len(URI_PREFIXES) else ""
    return prefix + payload[1:].decode("utf-8", "replace")


# --------------------------------------------------------------------------
# What the phone app sees
# --------------------------------------------------------------------------
STATE = {"token": None, "known": False, "teaching": False, "reader_ok": True,
         "tile_link": None, "write": None}


def log(message):
    print(time.strftime("%H:%M:%S"), message, flush=True)


def report(**changes):
    STATE.update(changes)
    STATE["updated"] = time.time()
    try:
        write_json(STATE_FILE, STATE)
    except OSError:
        pass


def open_reader():
    """Connect to the reader. If it isn't answering, keep trying (a power
    cycle or a reseated wire brings it back)."""
    complained = False
    while True:
        reader = None
        try:
            reader = PN532()
            reader.setup()
            if complained:
                log("Reader is answering again")
            report(reader_ok=True)
            return reader
        except (OSError, RuntimeError) as err:
            if not complained:
                log(f"Reader isn't answering ({err}). Retrying every 5 seconds. "
                    "If this keeps up, unplug the box for 10 seconds.")
                complained = True
                report(reader_ok=False)
            if reader is not None:
                try:
                    reader.dev.close()
                except OSError:
                    pass
            time.sleep(5)


# --------------------------------------------------------------------------
# Talking to the speaker (go-librespot, inside the box)
# --------------------------------------------------------------------------
last_started = {"uri": None}


def speaker_ready(timeout=90):
    """Wait until the speaker program has started and signed in to Spotify."""
    deadline = time.monotonic() + timeout
    said = False
    while time.monotonic() < deadline:
        try:
            if speaker_call("/").get("playback_ready"):
                return True
        except SpeakerOffline:
            pass
        if not said:
            log("Waiting for the speaker to finish starting...")
            said = True
        time.sleep(2)
    return False


def spotify_is_playing():
    status = status_or_empty()
    return bool(status.get("track")) and not status.get("paused") and not status.get("stopped")


def pause_spotify():
    """Pause Spotify and wait (a moment) until it has really stopped."""
    if not spotify_is_playing():
        return
    try:
        speaker_call("/player/pause")
    except SpeakerOffline:
        return
    for _ in range(10):
        if not spotify_is_playing():
            return
        time.sleep(0.2)


def heal_local_tile(uri):
    """The folder a tile played is gone. If one album with the same name and artist
    exists somewhere else now (files were reorganized), point the tile at it.
    Returns the tile's new link, or None."""
    tokens = load_tokens()
    mine = [t for t in tokens.values() if t.get("uri") == uri and t.get("album")]
    if not mine:
        return None
    try:
        key = local.find_moved(mine[0]["album"], mine[0].get("artist", ""))
    except local.MPDError:
        return None
    if not key or local.make_uri(key.partition("|")[0], key.partition("|")[2] if "|" in key else None) == uri:
        return None
    new_uri = local.make_uri(key.partition("|")[0], key.partition("|")[2] if "|" in key else None)
    for t in tokens.values():
        if t.get("uri") == uri:
            t["uri"] = new_uri
    save_tokens(tokens)
    log(f"Tile's album moved: now {new_uri}")
    return new_uri


def pause_apple():
    """Stop Apple Music (if it is set up and playing) so two sources never overlap."""
    if apple.configured() and apple.is_playing():
        apple.pause()


def play_apple(uri):
    started = time.monotonic()
    if not apple.configured():
        log("Apple Music isn't set up on this box (Settings > Apple Music).")
        time.sleep(3)
        return False
    st = status_or_empty()                  # start at the volume the box is at now
    if st.get("volume") is not None:
        apple.set_volume(round(st["volume"] * 100 / (st.get("volume_steps") or 100)))
    pause_spotify()
    local.pause_and_save()
    try:
        apple.play(uri)
    except apple.AppleError as err:
        log(f"Apple Music problem ({err}); trying again.")
        time.sleep(3)
        return False
    last_started["uri"] = uri
    log(f"Playing {uri} through Apple Music ({time.monotonic() - started:.1f}s)")
    return True


def play_local(uri, healed=False):
    started = time.monotonic()
    if not local.ping():
        log("The local music player (MPD) isn't running yet; will keep trying while the tile is on.")
        return False
    st = status_or_empty()                  # start at the volume the box is at now
    if st.get("volume") is not None:
        local.set_volume(round(st["volume"] * 100 / (st.get("volume_steps") or 100)))
    pause_spotify()
    pause_apple()
    try:
        info = local.play_path(local.path_of(uri))
    except local.NoMusic as err:
        if not healed:
            moved = heal_local_tile(uri)
            if moved:
                return play_local(moved, healed=True)
        log(f"{err}. Is the USB stick plugged in? Trying again while the tile is on.")
        time.sleep(3)
        return False
    except local.MPDError as err:
        log(f"Local player problem ({err}); trying again.")
        return False
    last_started["uri"] = uri
    what = "audiobook" if info["book"] else "music"
    log(f"Playing {uri} ({info['tracks']} files, {what}"
        f"{', carrying on where it stopped' if info['resumed'] else ''}) "
        f"({time.monotonic() - started:.1f}s)")
    return True


def play_from_start(uri):
    if local.is_local_uri(uri):
        return play_local(uri)
    if apple.is_apple_uri(uri):
        return play_apple(uri)
    started = time.monotonic()
    if not speaker_ready():
        log("Speaker still isn't ready; will keep trying while the tile is on.")
        return False
    local.pause_and_save()
    pause_apple()
    try:
        speaker_call("/player/shuffle_context", {"shuffle_context": False})
        speaker_call("/player/play", {"uri": uri})
    except SpeakerOffline as err:
        log(f"Speaker didn't take the play command ({err}); trying again.")
        return False
    local.set_source("spotify")
    last_started["uri"] = uri
    log(f"Playing {uri} from the top ({time.monotonic() - started:.1f}s)")
    return True


def resume(uri=None):
    if apple.is_apple_uri(uri):
        pause_spotify()
        local.pause_and_save()
        ok = apple.resume()
        log("Resumed (Apple Music)" if ok else "Apple Music didn't take the resume command; trying again.")
        return ok
    if local.is_local_uri(uri):
        pause_spotify()
        pause_apple()
        ok = local.resume()
        log("Resumed" if ok else "Local player didn't take the resume command; trying again.")
        return ok
    started = time.monotonic()
    if not speaker_ready():
        return False
    try:
        speaker_call("/player/resume")
    except SpeakerOffline as err:
        log(f"Speaker didn't take the resume command ({err}); trying again.")
        return False
    pause_apple()
    local.set_source("spotify")
    log(f"Resumed ({time.monotonic() - started:.1f}s)")
    return True


def status_or_empty():
    try:
        return speaker_status()
    except SpeakerOffline:
        return {}


def still_playing(uri):
    """True if the speaker is actually playing right now (used to tell a quick
    lift-and-set-down hiccup from a tile set back on a silent box)."""
    if apple.is_apple_uri(uri) or local.is_local_uri(uri):
        return True    # keep the old behaviour for these sources
    status = status_or_empty()
    return bool(status.get("track")) and not status.get("paused") and not status.get("stopped")


def paused_on(uri):
    """True only if the speaker is paused partway through this tile's music."""
    if apple.is_apple_uri(uri):
        return apple.paused_on(uri)
    if local.is_local_uri(uri):
        return local.paused_on(local.path_of(uri))
    status = status_or_empty()
    if not status.get("track") or not status.get("paused") or status.get("stopped"):
        return False
    context = status.get("context_uri")
    return context == uri if context else last_started["uri"] == uri


def playing_context():
    """What album/playlist/podcast is playing right now (for teach mode)."""
    status = status_or_empty()
    if not status.get("track") or status.get("paused") or status.get("stopped"):
        return None
    uri = status.get("context_uri") or ""
    return uri if uri.split(":")[1:2] and uri.split(":")[1] in TEACHABLE else None


def pause_if_playing():
    if apple.configured() and apple.source() == "apple" and apple.is_playing():
        apple.pause()
        log("Paused (Apple Music)")
        return
    if local.pause_and_save():
        log("Paused")
        return
    status = status_or_empty()
    if status.get("track") and not status.get("paused") and not status.get("stopped"):
        try:
            speaker_call("/player/pause")
            log("Paused")
        except SpeakerOffline:
            pass


# --------------------------------------------------------------------------
# Writing links onto tiles (asked for by the phone app)
# --------------------------------------------------------------------------
def queue_write(token, uri, quiet=False):
    if local.is_local_uri(uri) or apple.is_apple_uri(uri):
        return           # folders on this box's own drive mean nothing on another box
    write_json(WRITE_REQUEST, {"token": token, "uri": uri, "id": f"{time.time():.3f}",
                               "quiet": quiet})


def handle_write_request(reader, current):
    request = read_json(WRITE_REQUEST, None)
    if not request or request.get("token") != current:
        return
    try:
        os.remove(WRITE_REQUEST)
    except OSError:
        pass
    url = spotify_link_for(request["uri"])
    if not url:
        return
    try:
        if reader.read_token_id() != current:
            raise RuntimeError("The tile moved")
        reader.write_tile_link(url)
        set_on_tile(current, True)
        log(f"Wrote {url} onto tile {current}")
        report(write={"id": request["id"], "ok": True, "message": "Saved on the tile."},
               tile_link=url)
    except (RuntimeError, OSError, ValueError) as err:
        log(f"Couldn't write tile {current}: {err}")
        if request.get("quiet"):
            return
        report(write={"id": request["id"], "ok": False,
                      "message": "Couldn't save onto the tile. Keep it still on the box "
                                 "and try again. It still works on this box."})


# --------------------------------------------------------------------------
# Main loop
# --------------------------------------------------------------------------
def flash_light():
    try:
        with open("/dev/shm/musicbox-flash", "w") as f:
            f.write(str(time.time()))
    except OSError:
        pass


CHIMED_FLAG = "/dev/shm/musicbox-chimed"   # cleared every time the box starts


def startup_chime():
    """Once per power-up: when the speaker is ready for tiles, play the chime."""
    if os.path.exists(CHIMED_FLAG):
        return                       # just a program restart, not a fresh start
    if not speaker_ready(timeout=240):
        return
    try:
        open(CHIMED_FLAG, "w").close()
    except OSError:
        pass
    if load_settings().get("startup_sound", True):
        log("Ready. Playing the startup chime.")
        play_chime()


def run():
    threading.Thread(target=startup_chime, daemon=True).start()
    threading.Thread(target=local.watch, args=(spotify_is_playing,), daemon=True).start()
    threading.Thread(target=apple.watch,
                     args=(lambda: spotify_is_playing() or local.status().get("state") == "play",),
                     daemon=True).start()
    reader = open_reader()
    report(token=None, known=False, teaching=False, tile_link=None)
    log(f"Music box ready. Watching for tiles on '{SPEAKER_NAME}'.")

    current = None          # tile on the reader right now
    last_seen = 0.0
    paused_token, paused_at = None, 0.0
    reader_errors = 0
    unlinked = False
    teach_until = 0.0
    teach_baseline = None
    next_check = 0.0
    last_loop = time.monotonic()

    while True:
        # If the last pass got stuck (the speaker or Wi-Fi was slow to answer),
        # we weren't looking at the reader, so don't count that time as a lift.
        loop_now = time.monotonic()
        if loop_now - last_loop > REMOVE_DELAY:
            last_seen = loop_now
        last_loop = loop_now
        try:
            token = reader.read_token_id()
            reader_errors = 0
        except (RuntimeError, OSError):
            token = None
            reader_errors += 1
            if reader_errors >= 5:
                log("Reader stopped answering; restarting it")
                report(reader_ok=False)
                reader = open_reader()
                reader_errors = 0

        if token and token != current:
            # A new tile: read it once more and only believe it if both reads
            # agree, so a scrambled read can't turn into a "new" tile.
            try:
                confirm = reader.read_token_id()
            except (RuntimeError, OSError):
                confirm = None
            if confirm != token:
                log(f"Ignored an unclear read of a tile ({token})")
                token = current

        now = time.monotonic()
        try:
            if token:
                last_seen = now
                if token != current:
                    # A tile was just set down.
                    current = token
                    flash_light()
                    tile_link, tile_read = None, False
                    try:
                        tile_link = reader.read_tile_link()
                        tile_read = True
                    except (RuntimeError, OSError):
                        pass
                    uri = token_uri(token)
                    tile_uri = spotify_uri_from_link(tile_link) if tile_link else None
                    log(f"Tile {token} set down" + (f" (carries {tile_link})" if tile_link else ""))
                    if not uri and tile_uri:
                        # A tile from another box: play what it carries, and remember it.
                        uri = tile_uri
                        name, image = describe(None, uri)
                        link_token(token, uri, name, image, on_tile=True)
                        log(f"Learned {token} from the tile itself: {name or uri}")
                    elif uri and tile_uri == uri:
                        set_on_tile(token, True)
                    elif uri and tile_read and not tile_link:
                        # A blank tile this box knows: save its music onto it,
                        # so it works on other boxes too.
                        queue_write(token, uri, quiet=True)

                    unlinked = not uri
                    report(token=token, known=bool(uri), tile_link=tile_link, write=None)
                    if not uri:
                        log(f"New tile {token}. Teach mode for {TEACH_SECONDS} seconds.")
                        teach_until = now + TEACH_SECONDS
                        teach_baseline = playing_context()
                        next_check = now + TEACH_CHECK
                        report(teaching=True)
                        paused_token = None
                    else:
                        resume_window = load_settings()["resume_minutes"] * 60
                        if token == paused_token and now - paused_at < 5 and not paused_on(uri) and still_playing(uri):
                            # Same tile back within seconds and nothing was paused:
                            # the "lift" was a hiccup, so let the music carry on.
                            log("Same tile back right away; carrying on")
                            ok = True
                        elif token == paused_token and now - paused_at < resume_window and paused_on(uri):
                            ok = resume(uri)
                        else:
                            ok = play_from_start(uri)
                        if not ok:
                            current = None        # tile still there: try again next loop
                        else:
                            paused_token = None   # keep it on a failed resume, so the retry resumes too

                elif now >= next_check:
                    next_check = now + (TEACH_CHECK if unlinked else 0.5)
                    handle_write_request(reader, current)
                    if unlinked:
                        uri = token_uri(current)
                        if uri:
                            # Linked from the phone app while it sat here: play it.
                            unlinked, teach_until = False, 0
                            report(known=True, teaching=False)
                            if not play_from_start(uri):
                                current = None
                        elif now < teach_until:
                            found = playing_context()
                            if found and found != teach_baseline:
                                name, image = describe(None, found)
                                link_token(current, found, name, image)
                                queue_write(current, found)   # save it on the tile too
                                log(f"Learned {current} -> {name or found}")
                                unlinked, teach_until = False, 0
                                report(known=True, teaching=False)
                        elif teach_until:
                            teach_until = 0
                            log("Teach mode timed out. Link it in the phone app.")
                            report(teaching=False)

            elif current and now - last_seen > REMOVE_DELAY:
                # The tile was lifted.
                if token_uri(current):
                    pause_if_playing()
                    paused_token, paused_at = current, now
                flash_light()
                log("Tile lifted")
                current = None
                unlinked, teach_until = False, 0
                report(token=None, known=False, teaching=False, tile_link=None)

        except Exception as err:  # never let one hiccup stop the box
            log(f"Problem: {err}")

        time.sleep(0.1)


def list_tokens():
    tokens = load_tokens()
    if not tokens:
        print("No tiles linked yet.")
    for token, entry in tokens.items():
        where = "on tile + box" if entry.get("on_tile") else "box only"
        print(f"{token}  ->  {entry['name'] or entry['uri']}  ({where})")


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "run"
    try:
        if mode == "list":
            list_tokens()
        else:
            run()
    except KeyboardInterrupt:
        print("\nStopped.")
