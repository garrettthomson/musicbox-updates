#!/bin/bash
# soloist_update.sh - fetches the newest Spotify Soloist build.
# Each build stops working 90 days after Spotify made it, so the box checks
# every day (soloist-update.timer) and swaps in a new one when there is one.
# Usage: soloist_update.sh /home/<user> [--force]
# Works with unplug protection on: the new copy is also saved to the card.
set -u
H="${1:-$HOME}"
FORCE="${2:-}"
DEST="$H/soloist"
# Pick the build from the system's own type (a 64-bit kernel can run a
# 32-bit system, and then uname says aarch64 but only the arm32 build runs).
ARCH=$(dpkg --print-architecture 2>/dev/null || uname -m)
case "$ARCH" in
  arm64|aarch64) F=arm64 ;;
  armhf|armv7l)  F=arm32 ;;
  amd64|x86_64)  F=x86_64 ;;
  *) echo "Soloist has no build for $ARCH"; exit 1 ;;
esac
URL="https://soloist-builds.spotifycdn.com/soloist_release_$F.tar.gz"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

echo "Downloading from Spotify: $URL"
curl -fsSL --retry 3 --max-time 300 -o "$TMP/s.tgz" "$URL" || { echo "Download failed (is the box online?): $URL"; exit 1; }
mkdir "$TMP/x" && tar -xzf "$TMP/s.tgz" -C "$TMP/x" || { echo "Couldn't unpack the download"; exit 1; }
NEW=$(find "$TMP/x" -type f -name soloist | head -1)
[ -n "$NEW" ] || { echo "No 'soloist' program in the download"; exit 1; }
chmod 755 "$NEW"
SRC=$(dirname "$NEW")
OUT=$("$NEW" --version 2>&1); RC=$?
NEWV=$(echo "$OUT" | head -1)
if [ $RC -ne 0 ]; then
  echo "The new build won't run here (exit $RC):"; echo "$OUT" | head -5
  if echo "$OUT" | grep -q GLIBC; then
    echo "This box's system is too old for Spotify's player (it needs Raspberry Pi OS Trixie; this is $(. /etc/os-release; echo "$PRETTY_NAME"))."
  fi
  exit 1
fi
OLDV=""
[ -x "$DEST/soloist" ] && OLDV=$("$DEST/soloist" --version 2>/dev/null | head -1)
if [ "$NEWV" = "$OLDV" ] && [ "$FORCE" != "--force" ]; then
  echo "Soloist is up to date ($NEWV)"; exit 0
fi

OWNER=$(stat -c %U "$H")
install_into() {   # $1 = folder to install into
  mkdir -p "$1"
  cp -a "$SRC/." "$1/.new.$$" 2>/dev/null || { mkdir -p "$1/.new.$$"; cp -a "$SRC/." "$1/.new.$$/"; }
  for f in "$1/.new.$$"/*; do mv -f "$f" "$1/"; done
  rm -rf "$1/.new.$$"
  chown -R "$OWNER:$OWNER" "$1" 2>/dev/null || true
}
install_into "$DEST"
echo "Installed Soloist: $NEWV (was: ${OLDV:-none})"

# Unplug protection on? Save the new copy to the real card too.
LOWER=$(awk '$2=="/" && $3=="overlay"{print $4}' /proc/mounts | sed -n 's/.*lowerdir=\([^,:]*\).*/\1/p')
if [ -n "$LOWER" ] && [ "$(id -u)" = 0 ]; then
  mount -o remount,rw "$LOWER" && { install_into "$LOWER$DEST"; sync; mount -o remount,ro "$LOWER"; echo "Saved to the card too"; }
fi

# Restart the player to use the new build (only when nothing is playing).
if [ "$(id -u)" = 0 ] && [ -n "$OLDV" ]; then
  PLAYING=$(curl -s --max-time 3 http://127.0.0.1:3678/status | python3 -c 'import json,sys
try:
    s = json.load(sys.stdin)
    print("yes" if s.get("track") and not s.get("paused") and not s.get("stopped") else "no")
except Exception:
    print("no")')
  if [ "$PLAYING" != "yes" ]; then
    systemctl restart go-librespot && echo "Player restarted on the new build"
  else
    echo "Music is playing; the new build starts next time the player restarts"
  fi
fi
exit 0
