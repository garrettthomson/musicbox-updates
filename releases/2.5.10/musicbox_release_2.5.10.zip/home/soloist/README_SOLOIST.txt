MUSIC BOX / PAD: SPOTIFY SOLOIST (updated 2026-11-21, app 2.5.0)

Why: Spotify now refuses newer accounts on go-librespot ("failed retrieving
aes key with code 1"). Soloist is Spotify's own player for headless devices
and is the standard Spotify method on every box and Pad.

What it changes:
- The player service (still named go-librespot.service) runs
  ~/musicbox/soloist_run.sh, which starts ~/soloist/soloist.
- soloist-bridge.service answers the box's old player API on 127.0.0.1:3678
  and passes commands to Soloist (WebSocket on 127.0.0.1:3679). Tiles,
  buttons, knob, app and light keep working unchanged.
- Sound: Soloist -> PulseAudio (user service, linger on) -> ALSA "default".
- soloist-update.timer fetches a new build daily (builds expire after 90
  days); with unplug protection on it also saves the new copy to the card.
- Each owner adds their own free player key in the app (Settings > Spotify),
  made at developer.spotify.com/dashboard/soloist with a Premium account.
  Then they pick the box in the Spotify app's speaker list once.

Rules we follow (Spotify's terms): Soloist is always downloaded on the box
from Spotify's servers. Never put ~/soloist or a soloist.key on a card image,
in a zip, a backup that leaves the house, or a release.

Install, no terminal (app 2.5.0 and newer):
  Settings > Unplug protection > Turn on maintenance mode, wait for the restart,
  then Settings > Spotify > Install Spotify's player. The app shows progress,
  then asks for the key and tells the owner to pick the box in Spotify.
  (Runs /usr/local/lib/musicbox/soloist/install_soloist.sh as root through
  /usr/local/sbin/musicbox-admin; log in /run/musicbox-admin/soloist.log.)

Install by hand (maintenance mode ON):
  bash ~/musicbox/soloist/install_soloist.sh
  bash ~/musicbox/soloist/check_soloist.sh
Undo: bash ~/musicbox/soloist/uninstall_soloist.sh
Debug: journalctl -u go-librespot -n 40 --no-pager   (Soloist's log)
       journalctl -u soloist-bridge -n 40 --no-pager
       python3 ~/musicbox/soloist_bridge.py --dump
