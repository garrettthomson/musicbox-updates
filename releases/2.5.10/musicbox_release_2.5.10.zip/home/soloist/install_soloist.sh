#!/bin/bash
# install_soloist.sh - sets a Music Box or Pad up to play Spotify through
# Spotify Soloist (Spotify's own player for headless devices).
# Safe to run more than once. Needs maintenance mode ON first.
#
# Two ways to run it:
#   - From the phone app: Settings > Spotify > "Install Spotify's player".
#     The app runs it as root through /usr/local/sbin/musicbox-admin, with
#     MB_USER set to the box's user and --from-app (no terminal needed).
#   - By hand (as the box's user):  bash ~/musicbox/soloist/install_soloist.sh
# Undo: bash ~/musicbox/soloist/uninstall_soloist.sh
#
# Soloist itself is always downloaded on the box from Spotify's servers. It is
# never copied onto a card or into a zip (Spotify's rules), and neither is the
# owner's key: the owner pastes their own key in the app afterwards.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
FROM_APP=0; [ "${1:-}" = "--from-app" ] && FROM_APP=1

if [ "$(id -u)" = 0 ]; then
  ME="${MB_USER:-${SUDO_USER:-}}"
  if [ -z "$ME" ] || [ "$ME" = root ] || ! id "$ME" > /dev/null 2>&1; then
    echo "STOPPED: run this as the box's user, or set MB_USER."; exit 1
  fi
  HOME="$(getent passwd "$ME" | cut -d: -f6)"; export HOME
  SUDO=""
  export PYTHONDONTWRITEBYTECODE=1
else
  ME="$(id -un)"; SUDO="sudo"
fi
MYID="$(id -u "$ME")"
GRP="$(id -gn "$ME")"
UXDG="/run/user/$MYID"
DIR="${MB_DIR:-$HOME/musicbox}"
STAMP=$(date +%Y%m%d-%H%M%S)
BK="$DIR/backup-soloist-$STAMP"
say() { echo; echo "== $*"; }
die() { echo; echo "STOPPED: $*"; fixown; exit 1; }
# Files made while running as root still belong to the box's user.
fixown() {
  [ -z "$SUDO" ] || return 0
  for p in "$HOME/.config/pulse" "$HOME/.local/share/soloist" "$HOME/.cache/soloist" "$HOME/soloist" "$BK" \
           "$DIR/soloist_bridge.py" "$DIR/soloist_run.sh" "$DIR/soloist_update.sh" "$DIR/soloist.enabled" \
           "$DIR/go-librespot.service.orig"; do
    [ -e "$p" ] && chown -R "$ME:$GRP" "$p" 2>/dev/null
  done
  for p in "$HOME/.config" "$HOME/.local" "$HOME/.local/share" "$HOME/.cache"; do
    [ -d "$p" ] && [ "$(stat -c %u "$p")" = 0 ] && chown "$ME:$GRP" "$p"
  done
  return 0
}
# Run something as the box's user, with its own session settings.
asme() {
  if [ -z "$SUDO" ]; then runuser -u "$ME" -- env HOME="$HOME" XDG_RUNTIME_DIR="$UXDG" "$@"
  else XDG_RUNTIME_DIR="$UXDG" "$@"; fi
}

[ -d "$DIR" ] || die "No ~/musicbox folder. This needs a card that already has the Music Box software."
if awk '$2=="/" && $3=="overlay"{f=1} END{exit !f}' /proc/mounts; then
  die "Unplug protection is on, so nothing would stick. Install from the app (Spotify page), or run: sudo musicbox-admin maintenance-on, wait for the restart, try again, then: sudo musicbox-admin protect-on"
fi
case "$(uname -m)" in aarch64|armv7l) ;; *) die "Spotify's player has no version for this kind of computer ($(uname -m))." ;; esac
if [ -n "$SUDO" ]; then sudo -v || die "Needs your password for sudo."; fi
echo "This box: $(. /etc/os-release; echo "$PRETTY_NAME"), $(dpkg --print-architecture), $(free -m | awk '/^Mem:/{print $2}') MB memory"
mkdir -p "$BK"; echo "Backups go in $BK"

say "1/7  Downloading Spotify's player from Spotify and checking it runs on this box..."
bash "$HERE/soloist_update.sh" "$HOME" --force || die "Spotify's player didn't download, or won't run on this box. Check the box is online and try again."
fixown
asme "$HOME/soloist/soloist" --version || die "Spotify's player downloaded but won't start on this box."

say "2/7  Installing the sound server Spotify's player plays through..."
export DEBIAN_FRONTEND=noninteractive
$SUDO apt-get install -y -qq --no-install-recommends pulseaudio > /dev/null \
  || { $SUDO apt-get update -qq > /dev/null; $SUDO apt-get install -y -qq --no-install-recommends pulseaudio > /dev/null; } \
  || die "Couldn't install the sound server. Is the box online?"
mkdir -p "$HOME/.config/pulse"
[ -f "$HOME/.config/pulse/default.pa" ] && cp -p "$HOME/.config/pulse/default.pa" "$BK/"
cat > "$HOME/.config/pulse/default.pa" <<'PA'
# Music Box: send everything to the box's shared output (ALSA "default"),
# which mixes with the chime and the always-on silence stream.
load-module module-native-protocol-unix
load-module module-alsa-sink device=default sink_name=box tsched=0
set-default-sink box
PA
cat > "$HOME/.config/pulse/daemon.conf" <<'PA'
exit-idle-time = -1
default-sample-rate = 44100
alternate-sample-rate = 44100
resample-method = speex-float-1
flat-volumes = no
PA
fixown
$SUDO loginctl enable-linger "$ME"
for _ in $(seq 1 15); do [ -S "$UXDG/bus" ] && break; sleep 1; done   # user session starting
asme systemctl --user daemon-reload 2>/dev/null
asme systemctl --user enable pulseaudio.socket pulseaudio.service > /dev/null 2>&1
asme systemctl --user restart pulseaudio.service 2>/dev/null || asme pulseaudio --start
sleep 2
[ -S "$UXDG/pulse/native" ] && echo "   Sound server is running" || echo "   Note: the sound server isn't answering yet (it usually is after a restart)"

say "3/7  Copying the bridge and helper scripts..."
for f in soloist_bridge.py soloist_run.sh soloist_update.sh; do
  [ "$HERE/$f" -ef "$DIR/$f" ] || cp "$HERE/$f" "$DIR/$f"
done
chmod +x "$DIR/soloist_run.sh" "$DIR/soloist_update.sh"
mkdir -p "$HOME/.local/share/soloist" "$HOME/.cache/soloist"
touch "$DIR/soloist.enabled"
fixown

say "4/7  Checking the app and box programs..."
# By hand from an update folder: bring the box programs that go with it.
for f in musicbox_web.py musicbox_persist.py musicbox.py musicbox_common.py buttons.py \
         musicbox_local.py musicbox_apple.py musicbox_about.py musicbox_naming.py musicbox_update.py; do
  if [ -f "$HERE/$f" ] && ! [ "$HERE/$f" -ef "$DIR/$f" ]; then
    [ -f "$DIR/$f" ] && cp -p "$DIR/$f" "$BK/"
    cp "$HERE/$f" "$DIR/$f"
    [ -z "$SUDO" ] && chown "$ME:$GRP" "$DIR/$f"
  fi
done
/usr/bin/python3 - "$DIR/musicbox_web.py" "$DIR/soloist_bridge.py" "$DIR/musicbox_persist.py" <<'PY' \
  || { cp -p "$BK"/*.py "$DIR/" 2>/dev/null; die "The app files didn't check out; the old ones are back."; }
import sys
for f in sys.argv[1:]:
    compile(open(f).read(), f, "exec")
PY
echo "   OK"

say "5/7  Switching the player service to Spotify's player..."
$SUDO cp -p /etc/systemd/system/go-librespot.service "$BK/" 2>/dev/null
if [ ! -f "$DIR/go-librespot.service.orig" ] && ! grep -qs soloist_run.sh /etc/systemd/system/go-librespot.service; then
  $SUDO cp -p /etc/systemd/system/go-librespot.service "$DIR/go-librespot.service.orig" 2>/dev/null
fi
$SUDO tee /etc/systemd/system/go-librespot.service > /dev/null <<UNIT
[Unit]
Description=Music Box Spotify player (Spotify Soloist; old service name kept)
Wants=network-online.target
After=network-online.target sound.target audio-keepalive.service user@$MYID.service

[Service]
User=$ME
Environment=HOME=$HOME
ExecStart=/bin/bash $DIR/soloist_run.sh
Restart=always
RestartSec=5
SuccessExitStatus=10

[Install]
WantedBy=multi-user.target
UNIT
$SUDO tee /etc/systemd/system/soloist-bridge.service > /dev/null <<UNIT
[Unit]
Description=Music Box bridge: box controls -> Spotify Soloist
After=go-librespot.service

[Service]
User=$ME
Environment=PYTHONUNBUFFERED=1
ExecStart=/usr/bin/python3 $DIR/soloist_bridge.py
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
UNIT
$SUDO tee /etc/systemd/system/soloist-update.service > /dev/null <<UNIT
[Unit]
Description=Fetch the newest Spotify Soloist build (they expire after 90 days)
Wants=network-online.target
After=network-online.target

[Service]
Type=oneshot
ExecStart=/bin/bash $DIR/soloist_update.sh $HOME
UNIT
$SUDO tee /etc/systemd/system/soloist-update.timer > /dev/null <<'UNIT'
[Unit]
Description=Check for a new Spotify Soloist build every day

[Timer]
OnBootSec=10min
OnCalendar=*-*-* 04:20
RandomizedDelaySec=30min
Persistent=true

[Install]
WantedBy=timers.target
UNIT
$SUDO systemctl daemon-reload
$SUDO systemctl enable go-librespot.service soloist-bridge.service soloist-update.timer > /dev/null 2>&1
fixown

say "6/7  Restarting the player and the box's programs..."
$SUDO systemctl restart go-librespot soloist-bridge
sleep 3
for svc in musicbox musicbox-web musicbox-buttons musicbox-persist; do
  # From the app, the app keeps running (it is showing this progress).
  [ "$FROM_APP" = 1 ] && [ "$svc" = musicbox-web ] && continue
  systemctl list-unit-files "$svc.service" 2>/dev/null | grep -q "$svc" && $SUDO systemctl restart "$svc"
done
$SUDO systemctl start soloist-update.timer

say "7/7  Checking the box can talk to Spotify's player..."
ok=""
for _ in $(seq 1 20); do
  R=$(curl -s --max-time 2 http://127.0.0.1:3678/auth/code 2>/dev/null)
  case "$R" in *soloist*|"{}") ok=1; break ;; esac
  sleep 1
done
[ -n "$ok" ] || die "Spotify's player was installed, but the box's bridge to it isn't answering. Try Restart music in Settings."
echo "   The bridge answers."
if [ -s "$DIR/soloist.key" ]; then
  echo "   A Spotify player key is already saved."
else
  echo "   No Spotify player key yet."
fi
fixown
echo
echo "DONE: Spotify's player is installed."
if [ "$FROM_APP" = 0 ]; then
  echo "Next:"
  echo "  1. In the app, Settings > Spotify: add the key (if asked), then pick this box in the Spotify app."
  echo "  2. Run:  bash $HERE/check_soloist.sh"
  echo "  3. sudo reboot, run check_soloist.sh once more, then: sudo musicbox-admin protect-on"
fi
exit 0
