#!/bin/bash
# uninstall_soloist.sh - goes back to go-librespot. Keeps Soloist's files.
set -u
DIR="$HOME/musicbox"
if awk '$2=="/" && $3=="overlay"{f=1} END{exit !f}' /proc/mounts; then
  echo "Turn on maintenance mode first."; exit 1
fi
[ -f "$DIR/go-librespot.service.orig" ] || { echo "No saved go-librespot service to go back to."; exit 1; }
sudo systemctl disable --now soloist-bridge.service soloist-update.timer > /dev/null 2>&1
sudo cp "$DIR/go-librespot.service.orig" /etc/systemd/system/go-librespot.service
sudo systemctl daemon-reload
rm -f "$DIR/soloist.enabled"
sudo systemctl restart go-librespot musicbox musicbox-web musicbox-buttons
echo "Back on go-librespot. (The old app version stays at 2.4.0; it works with both.)"
