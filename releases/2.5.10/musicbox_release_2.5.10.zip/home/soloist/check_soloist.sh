#!/bin/bash
# check_soloist.sh - checks the Soloist setup. Changes nothing.
DIR="$HOME/musicbox"; ok=0; bad=0
pass() { echo "PASS  $*"; ok=$((ok+1)); }
fail() { echo "FAIL  $*"; bad=$((bad+1)); }
export XDG_RUNTIME_DIR="/run/user/$(id -u)"
[ -x "$HOME/soloist/soloist" ] && pass "Soloist installed: $("$HOME/soloist/soloist" --version 2>&1 | head -1)" || fail "Soloist program missing (~/soloist/soloist)"
[ -f "$DIR/soloist.enabled" ] && pass "app is in Soloist mode" || fail "no ~/musicbox/soloist.enabled marker"
[ -s "$DIR/soloist.key" ] && pass "player key saved" || fail "no player key yet (app: Settings > Spotify)"
[ "$(stat -c %a "$DIR/soloist.key" 2>/dev/null)" = "600" ] && pass "key file is private" || { [ -f "$DIR/soloist.key" ] && fail "key file should be private (chmod 600 ~/musicbox/soloist.key)"; }
[ -S "$XDG_RUNTIME_DIR/pulse/native" ] && pass "PulseAudio running" || fail "PulseAudio not running (systemctl --user status pulseaudio)"
loginctl show-user "$(id -un)" 2>/dev/null | grep -q 'Linger=yes' && pass "sound server starts at boot (linger on)" || fail "linger is off: sudo loginctl enable-linger $(id -un)"
grep -q soloist_run.sh /etc/systemd/system/go-librespot.service && pass "player service runs Soloist" || fail "player service still runs go-librespot"
for s in go-librespot soloist-bridge musicbox musicbox-web musicbox-buttons; do
  systemctl is-active --quiet "$s" && pass "$s running" || fail "$s not running"
done
systemctl is-enabled --quiet soloist-update.timer && pass "daily Soloist update check on" || fail "soloist-update.timer not enabled"
R=$(curl -s --max-time 4 http://127.0.0.1:3678/ ); echo "$R" | grep -q '"playback_ready": true' && pass "Spotify connected and ready" || fail "Spotify not connected yet (pick this box in the Spotify app) [$R]"
V=$(sed -n 's/^APP_VERSION = "\([0-9.]*\)".*/\1/p' "$DIR/musicbox_web.py")
case "$V" in 2.4.*|2.[5-9]*|[3-9].*) pass "app version $V" ;; *) fail "app is $V (needs 2.4 or newer)" ;; esac
[ -x /usr/local/sbin/musicbox-admin ] && [ -f /etc/sudoers.d/musicbox-admin ] && pass "app can install Spotify's player and updates by itself" || fail "app helper missing (install the 2.5 update)"
pactl info > /dev/null 2>&1 && { pactl list short sinks | grep -q box && pass "PulseAudio plays to the box output" || fail "PulseAudio has no 'box' output"; }
free -m | awk '/^Mem:/{print "INFO  memory: " $3 " MB used of " $2 " MB"}'
echo; echo "$ok passed, $bad failed."
echo "Raw player state (for Claude):  python3 $DIR/soloist_bridge.py --dump"
