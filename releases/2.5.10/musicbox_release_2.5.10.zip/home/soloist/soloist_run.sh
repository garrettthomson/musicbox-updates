#!/bin/bash
# soloist_run.sh - starts Spotify Soloist for the Music Box.
# Run by go-librespot.service (the old name is kept on purpose, so the app's
# "Restart music" button and the box's helpers keep working unchanged).
DIR="$HOME/musicbox"
BIN="$HOME/soloist/soloist"
KEY_FILE="$DIR/soloist.key"
NAME_CONFIG="$HOME/.config/go-librespot/config.yml"
DATA="$HOME/.local/share/soloist"
CACHE="$HOME/.cache/soloist"

if [ ! -s "$KEY_FILE" ]; then
  echo "No Soloist key yet. Add it in the app: Settings > Spotify."
  sleep 30; exit 1
fi
if [ ! -x "$BIN" ]; then
  echo "Soloist isn't downloaded yet; fetching it."
  bash "$DIR/soloist_update.sh" "$HOME" || { sleep 30; exit 1; }
fi

NAME=$(python3 - "$NAME_CONFIG" <<'PY'
import json, sys
try:
    for line in open(sys.argv[1]):
        if line.startswith("device_name:"):
            v = line.split(":", 1)[1].strip()
            print(json.loads(v) if v.startswith('"') else (v or "Music Box")); break
    else:
        print("Music Box")
except Exception:
    print("Music Box")
PY
)

export XDG_RUNTIME_DIR="/run/user/$(id -u)"
export PULSE_SERVER="unix:$XDG_RUNTIME_DIR/pulse/native"
for _ in $(seq 1 30); do                      # wait for the sound server
  [ -S "$XDG_RUNTIME_DIR/pulse/native" ] && break
  sleep 1
done

mkdir -p "$DATA" "$CACHE"
"$BIN" -n "$NAME" -k "$(cat "$KEY_FILE")" -D "$DATA" -C "$CACHE" -z 100 -w 127.0.0.1:3679 &
PID=$!
trap 'kill -TERM $PID 2>/dev/null; wait $PID' TERM INT
wait $PID
RC=$?
if [ "$RC" = 10 ]; then
  echo "This Soloist build has expired (they last 90 days). Fetching a new one."
  bash "$DIR/soloist_update.sh" "$HOME"
fi
exit $RC
