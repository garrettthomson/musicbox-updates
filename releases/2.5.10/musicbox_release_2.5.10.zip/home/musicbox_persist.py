"""
musicbox_persist.py
The "save keeper" for unplug-proof mode.

In unplug-proof mode the Pi's system is read-only: everything it writes goes
to memory and disappears at the next restart, so pulling the plug can't
damage the memory card. A few things must survive a restart, though:

  - coins/tiles and settings (tokens.json, settings.json)
  - the Spotify pairing (go-librespot state) and optional developer sign-in
  - saved Wi-Fi networks
  - music added or removed in the app (~/Music, not the USB stick)

Every 15 seconds this checks those files. If one changed, it briefly unlocks
the memory card, saves the new copy safely (write, flush, swap in), and locks
it again: about a second of writing per change instead of all the time.

Music is compared by size and time only (no reading), so a big library costs
little; new or changed files are copied to the card, removed ones removed.

When unplug-proof mode is off (maintenance), it does nothing.
Runs as root:  /usr/bin/python3 musicbox_persist.py /home/<user>
"""

import os
import re
import shutil
import signal
import stat
import subprocess
import sys
import time

HOME = sys.argv[1] if len(sys.argv) > 1 else "/home/hotdog"
CHECK_EVERY = 15

TRACK_FILES = [
    f"{HOME}/musicbox/tokens.json",
    f"{HOME}/musicbox/settings.json",
    f"{HOME}/musicbox/local_places.json",   # audiobook bookmarks
    f"{HOME}/musicbox/apple_music.json",   # Apple Music (Music Assistant) address and token
    f"{HOME}/musicbox/album_overrides.json",   # album names fixed in the app
    f"{HOME}/musicbox/stats.json",       # listening stats (saved every 10 min)
    f"{HOME}/musicbox/.spotify_token_cache",
    f"{HOME}/.config/go-librespot/state.json",
    f"{HOME}/.config/go-librespot/config.yml",
    f"{HOME}/musicbox/soloist.key",       # the owner's Soloist player key (Spotify)
    "/etc/hostname",                # the speaker's web address (renamed in the app)
    "/etc/hosts",
    "/etc/camilladsp/musicbox.yml",      # the sound preset picked in the app
    "/etc/camilladsp/current_preset",
]
TRACK_DIRS = [
    "/etc/NetworkManager/system-connections",
    f"{HOME}/musicbox/album_art",         # covers chosen in the app
    f"{HOME}/musicbox/tile_art",          # pictures chosen for tiles
]

# Folders saved with everything inside them (sub-folders too).
TRACK_TREES = [
    f"{HOME}/.local/share/soloist",       # Soloist's saved Spotify sign-in
]
SKIP_NAMES = {"soloist.pid", "ws.addr", "ws.port",   # Soloist's running notes, not worth saving
              "es_counters.dat", "pe_counters.dat",  # play counters it rewrites all the time
              "LOCK", "LOG", "LOG.old"}              # database lock and debug notes
# Soloist's own caches: rewritten every few seconds while music plays (megabytes),
# and not part of the sign-in. Saving them wore the card and kept it from locking.
SKIP_DIRS = {"public.ldb", "Storage", "crashpad", "Crashpad", "Cache", "GPUCache"}
# Everything else in those folders is saved at most this often (and on shutdown),
# and written into the card's existing file rather than swapped for a new one.
TREE_SAVE_EVERY = 30 * 60
STATUS_DIR = "/run/musicbox-persist"
STATUS_FILE = STATUS_DIR + "/status.json"     # read by the app's notices

# Music added in the app. Compared by size and time, copied in chunks.
MUSIC_DIR = f"{HOME}/Music"
MUSIC_SKIP_TOP = {"USB", ".incoming"}   # a USB stick, and music still arriving: never copied
# From 2.5.5 ~/Music is the memory card's own folder (musicbox-music-mount), so
# music_changes finds nothing to copy. While the app adds music it unlocks the
# card and leaves this note; the keeper must not lock the card under it, and
# locks it once the note runs out.
MUSIC_LOCK = "/run/musicbox-admin/music_open.json"

stopping = False
music_wait_until = 0.0
last_tree_save = 0.0
lock_state = {"locked": True, "failing_since": None, "error": ""}


def log(message):
    print(time.strftime("%H:%M:%S"), message, flush=True)


def lower_root():
    """Where the real memory card is mounted when the system is read-only."""
    try:
        with open("/proc/mounts") as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 4 and parts[1] == "/" and parts[2] == "overlay":
                    match = re.search(r"lowerdir=([^,]+)", parts[3])
                    if match:
                        return match.group(1).split(":")[0]
    except OSError:
        pass
    return None


def read(path):
    try:
        with open(path, "rb") as f:
            return f.read()
    except (FileNotFoundError, IsADirectoryError, NotADirectoryError):
        return None


def tracked_paths(lower, trees=True):
    paths = list(TRACK_FILES)
    for d in TRACK_DIRS:
        names = set()
        for base in (d, lower + d):
            try:
                names.update(n for n in os.listdir(base)
                             if os.path.isfile(os.path.join(base, n)) and not n.endswith(".mbtmp"))
            except FileNotFoundError:
                pass
        paths += [os.path.join(d, n) for n in sorted(names)]
    for d in (TRACK_TREES if trees else ()):
        found = set()
        for base in (d, lower + d):
            for root, dirs, files in os.walk(base):
                dirs[:] = [x for x in dirs if x not in SKIP_DIRS]
                rel = os.path.relpath(root, base)
                for n in files:
                    if n in SKIP_NAMES or n.endswith(".mbtmp"):
                        continue
                    found.add(os.path.normpath(os.path.join(d, rel, n)))
        paths += sorted(found)
    return paths


def in_tree(path):
    return any(path.startswith(d.rstrip("/") + "/") for d in TRACK_TREES)


def tree_saved_before(lower):
    """True once the card holds any of Soloist's sign-in files."""
    for d in TRACK_TREES:
        for _root, _dirs, files in os.walk(lower + d):
            if files:
                return True
    return False


def find_changes(lower, final=False):
    """Changed files to save. Soloist's folders are only looked at every
    TREE_SAVE_EVERY seconds (right away the first time, and on shutdown)."""
    global last_tree_save
    trees = (final or time.time() - last_tree_save >= TREE_SAVE_EVERY
             or not tree_saved_before(lower))
    changes = []
    for path in tracked_paths(lower, trees=trees):
        current, saved = read(path), read(lower + path)
        if current != saved:
            changes.append((path, current))
    if trees:
        last_tree_save = time.time()
    return changes


def scan_music(root):
    """{relative path: ("d", None) or ("f", (size, whole seconds))} under root,
    without following links or crossing into other mounts (a USB stick)."""
    found = {}
    if not os.path.isdir(root) or os.path.islink(root):
        return found
    for here, dirs, files in os.walk(root):
        rel_here = os.path.relpath(here, root)
        keep_dirs = []
        for d in dirs:
            full = os.path.join(here, d)
            if rel_here == "." and d in MUSIC_SKIP_TOP:
                continue
            if os.path.islink(full) or os.path.ismount(full):
                continue
            keep_dirs.append(d)
            found[os.path.normpath(os.path.join(rel_here, d))] = ("d", None)
        dirs[:] = keep_dirs
        for n in files:
            if n.endswith(".mbtmp"):
                continue
            try:
                st = os.lstat(os.path.join(here, n))
            except OSError:
                continue
            if stat.S_ISREG(st.st_mode):
                found[os.path.normpath(os.path.join(rel_here, n))] = ("f", (st.st_size, int(st.st_mtime)))
    return found


def music_changes(lower):
    """(paths to copy to the card, paths to remove from it) for ~/Music."""
    if not os.path.isdir(MUSIC_DIR) or os.path.islink(MUSIC_DIR) or os.path.ismount(MUSIC_DIR):
        return [], []
    live, card = scan_music(MUSIC_DIR), scan_music(lower + MUSIC_DIR)
    copies = sorted(rel for rel, (kind, sig) in live.items()
                    if card.get(rel, (None, None))[0] != kind or (kind == "f" and card[rel][1] != sig))
    removals = sorted((rel for rel, (kind, _) in card.items()
                       if live.get(rel, (None, None))[0] != kind), key=lambda r: -r.count("/"))
    return copies, removals


def save_music(lower, copies, removals):
    card_root = lower + MUSIC_DIR
    for rel in removals:
        dest = os.path.join(card_root, rel)
        if os.path.isdir(dest) and not os.path.islink(dest):
            shutil.rmtree(dest, ignore_errors=True)
        elif os.path.lexists(dest):
            os.remove(dest)
        log(f"Removed music {rel}")
    if copies and not os.path.isdir(card_root):
        os.makedirs(card_root, exist_ok=True)
        st = os.stat(MUSIC_DIR)
        os.chown(card_root, st.st_uid, st.st_gid)
    saved = 0
    for rel in copies:          # sorted, so folders come before what's in them
        src, dest = os.path.join(MUSIC_DIR, rel), os.path.join(card_root, rel)
        try:
            st = os.lstat(src)
        except FileNotFoundError:
            continue            # removed meanwhile; the next check catches it
        if stat.S_ISDIR(st.st_mode):
            os.makedirs(dest, exist_ok=True)
            os.chmod(dest, st.st_mode & 0o7777)
            os.chown(dest, st.st_uid, st.st_gid)
            continue
        if not stat.S_ISREG(st.st_mode):
            continue
        tmp = dest + ".mbtmp"
        fd = os.open(src, os.O_RDONLY | os.O_NOFOLLOW)
        try:
            with os.fdopen(fd, "rb") as fin, open(tmp, "wb") as fout:
                shutil.copyfileobj(fin, fout, 1024 * 1024)
                fout.flush()
                os.fsync(fout.fileno())
        except BaseException:
            try:
                os.remove(tmp)
            except OSError:
                pass
            raise
        os.chmod(tmp, st.st_mode & 0o7777)
        os.chown(tmp, st.st_uid, st.st_gid)
        os.utime(tmp, ns=(st.st_atime_ns, st.st_mtime_ns))
        os.replace(tmp, dest)
        saved += 1
    if saved:
        log(f"Saved {saved} music file{'s' if saved != 1 else ''}")


def music_lock_active():
    try:
        with open(MUSIC_LOCK) as f:
            import json
            return float(json.load(f).get("until", 0)) > time.time()
    except (OSError, ValueError, AttributeError):
        return False


def card_is_rw(lower):
    try:
        with open("/proc/mounts") as f:
            for line in f:
                p = line.split()
                if len(p) >= 4 and p[1] == lower:
                    return "rw" in p[3].split(",")
    except OSError:
        pass
    return False


def write_status():
    try:
        os.makedirs(STATUS_DIR, exist_ok=True)
        os.chmod(STATUS_DIR, 0o755)
        import json
        tmp = STATUS_FILE + ".tmp"
        with open(tmp, "w") as f:
            json.dump(dict(lock_state, checked=time.time()), f)
        os.chmod(tmp, 0o644)
        os.replace(tmp, STATUS_FILE)
    except OSError:
        pass


def drop_name_cache():
    """Forget cached file names and file records (not file contents). A file this
    keeper replaced on the card stays "in use" while the system still remembers
    the old copy, and the card refuses to lock until it's forgotten."""
    try:
        with open("/proc/sys/vm/drop_caches", "w") as f:
            f.write("2\n")
    except OSError:
        pass


def lock_card(lower):
    """Make the memory card read-only again. Returns True if it is."""
    err = ""
    for attempt in range(3):
        os.sync()
        r = subprocess.run(["mount", "-o", "remount,ro", lower], capture_output=True, text=True)
        if r.returncode == 0:
            if not lock_state["locked"]:
                log("Memory card locked again")
            lock_state.update(locked=True, failing_since=None, error="")
            write_status()
            return True
        err = (r.stderr or r.stdout or f"exit {r.returncode}").strip()
        drop_name_cache()
        time.sleep(1 + attempt)
    if lock_state["locked"]:
        log(f"Couldn't lock the memory card ({err}); will keep trying")
        lock_state.update(locked=False, failing_since=time.time())
    lock_state["error"] = err
    write_status()
    return False


def remount(lower, mode):
    if mode == "ro":
        if music_lock_active():
            return        # the app is adding music; it (or the next check) locks the card
        lock_card(lower)
        return
    subprocess.run(["mount", "-o", f"remount,{mode}", lower], check=True)


def lock_card_if_done(lower):
    """The card is still writable (the app added music, or an earlier lock
    failed): lock it again."""
    if not music_lock_active() and card_is_rw(lower):
        if lock_card(lower):
            try:
                os.remove(MUSIC_LOCK)
            except OSError:
                pass
    elif not lock_state["locked"] and not card_is_rw(lower):
        lock_state.update(locked=True, failing_since=None, error="")
        write_status()


def save(lower, changes, music=((), ())):
    remount(lower, "rw")
    try:
        for path, data in changes:
            dest = lower + path
            if data is None:
                if os.path.exists(dest):
                    os.remove(dest)
                    log(f"Removed {path}")
                continue
            if not os.path.isdir(os.path.dirname(dest)):
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                try:   # new folders belong to the same user as the live ones
                    pst = os.stat(os.path.dirname(path))
                    os.chown(os.path.dirname(dest), pst.st_uid, pst.st_gid)
                except OSError:
                    pass
            if in_tree(path) and os.path.isfile(dest) and not os.path.islink(dest):
                # Soloist keeps these open: write into the card's existing file
                # (a swapped-in new file leaves the old one "in use" on the card).
                with open(dest, "r+b") as f:
                    f.write(data)
                    f.truncate()
                    f.flush()
                    os.fsync(f.fileno())
                log(f"Saved {path}")
                continue
            tmp = dest + ".mbtmp"
            with open(tmp, "wb") as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
            st = os.stat(path)
            os.chmod(tmp, st.st_mode & 0o7777)
            os.chown(tmp, st.st_uid, st.st_gid)
            os.replace(tmp, dest)
            fd = os.open(os.path.dirname(dest), os.O_RDONLY)
            os.fsync(fd)
            os.close(fd)
            log(f"Saved {path}")
        try:                       # music last, so a full card never holds up tiles or settings
            save_music(lower, *music)
        except Exception as err:
            global music_wait_until
            music_wait_until = time.time() + 600     # e.g. the card is full: don't keep hammering it
            log(f"Music save problem (trying again in 10 minutes): {err}")
        os.sync()
    finally:
        remount(lower, "ro")


def check_once(final=False):
    lower = lower_root()
    if not lower:
        return False          # not in unplug-proof mode: nothing to do
    changes = find_changes(lower, final=final)
    try:
        music = music_changes(lower) if time.time() >= music_wait_until else ([], [])
    except OSError as err:
        log(f"Music check problem: {err}")
        music = ([], [])
    if changes or music[0] or music[1]:
        save(lower, changes, music)
    lock_card_if_done(lower)
    return True


def stop(*_):
    global stopping
    stopping = True


def main():
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    protected = lower_root() is not None
    log("Unplug-proof mode is ON. Watching for changes to save." if protected
        else "Unplug-proof mode is OFF (maintenance). Nothing to do.")
    while not stopping:
        try:
            check_once()
        except Exception as err:
            log(f"Save problem: {err}")
        for _ in range(CHECK_EVERY):
            if stopping:
                break
            time.sleep(1)
    try:
        check_once(final=True)    # one last save on a clean shutdown
    except Exception as err:
        log(f"Final save problem: {err}")


if __name__ == "__main__":
    main()
