"""
buttons.py
Back and next buttons (and the volume knob, once it's wired) for the Music Box.

  Next button          -> next track
  Back button          -> restart the song; press again within 3 seconds
                          (or near the start of a song) for the previous track
  Knob (when wired)    -> volume up / down

Talks only to the speaker program inside the box, so it's instant.
Runs as the musicbox-buttons service with the Pi's own Python (it needs the
system's GPIO library, which isn't in the musicbox venv).
"""

import json
import os
import threading
import time
import urllib.error
import urllib.request
from signal import pause

from gpiozero import Button, RotaryEncoder

try:
    import musicbox_local as local     # music from the box's own drive (same folder)
except ImportError:
    local = None
try:
    import musicbox_apple as apple     # Apple Music through Music Assistant (experimental)
except ImportError:
    apple = None

# --------------------------------------------------------------------------
# Pins (GPIO numbers, not physical pin numbers)
# --------------------------------------------------------------------------
BACK_GPIO = 5        # physical pin 29 (other wire to pin 30, ground)
NEXT_GPIO = 6        # physical pin 31 (other wire to pin 34, ground)
KNOB_CLK_GPIO = 17   # physical pin 11
KNOB_DT_GPIO = 27    # physical pin 13

VOLUME_STEP = 4      # volume change per knob click (out of 100)
SETTINGS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "settings.json")
DEFAULT_MIN, DEFAULT_MAX = 10, 100   # changed in the phone app (Settings)
RESTART_IF_PAST = 3000   # ms into a song: Back restarts instead of going back
DOUBLE_PRESS = 3.0       # seconds: a second Back press in this time goes back

SPEAKER_API = "http://127.0.0.1:3678"


def log(message):
    print(time.strftime("%H:%M:%S"), message, flush=True)


def speaker(path, body=None, method=None):
    if method is None:
        method = "POST" if body is not None or path.startswith("/player/") else "GET"
    data = json.dumps(body).encode() if body is not None else (b"" if method == "POST" else None)
    request = urllib.request.Request(SPEAKER_API + path, data=data, method=method,
                                     headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=3) as response:
            raw = response.read()
            return json.loads(raw) if raw.strip() else {}
    except (urllib.error.URLError, OSError, ValueError) as err:
        log(f"Speaker didn't answer: {err}")
        return None


last_back = 0.0


def flash_light():
    try:
        with open("/dev/shm/musicbox-flash", "w") as f:
            f.write(str(time.time()))
    except OSError:
        pass


def local_active():
    return local is not None and local.source() == "local"


def apple_active():
    return apple is not None and apple.source() == "apple" and apple.configured()


def on_next():
    flash_light()
    log("Next")
    if apple_active():
        apple.next_track()
        return
    if local_active():
        local.next_track()
        return
    speaker("/player/next")


def on_back():
    global last_back
    flash_light()
    if apple_active():
        log("Back (Apple Music)")
        apple.back()
        return
    if local_active():
        log("Back (local music)")
        local.back()
        return
    now = time.monotonic()
    status = speaker("/status") or {}
    track = status.get("track") or {}
    position = track.get("position", 0)
    if position > RESTART_IF_PAST and now - last_back > DOUBLE_PRESS:
        log("Back: restart song")
        speaker("/player/seek", {"position": 0})
    else:
        log("Back: previous track")
        speaker("/player/prev")
    last_back = now


def volume_limits():
    """Lowest and highest volume allowed (0 to 100), from the app's settings."""
    try:
        with open(SETTINGS_FILE) as f:
            settings = json.load(f)
    except (OSError, ValueError):
        settings = {}
    if settings.get("product") == "pad" and settings.get("line_out") == "fixed":
        return 100, 100   # Pad on fixed line out: always full, the stereo's knob does the work
    low = int(settings.get("volume_min", DEFAULT_MIN))
    high = int(settings.get("volume_max", DEFAULT_MAX))
    low, high = max(0, min(low, 100)), max(0, min(high, 100))
    return (low, high) if low <= high else (high, high)


def current_volume():
    if apple_active():
        return apple.get_volume()
    if local_active():
        return local.get_volume()
    reply = speaker("/player/volume", method="GET") or {}
    value, top = reply.get("value"), reply.get("max") or 100
    if value is None:
        return None
    return round(value * 100 / top)


def set_volume(percent):
    if apple_active():
        apple.set_volume(percent)
        return
    if local_active():
        local.set_volume(percent)
        return
    speaker("/player/volume", {"volume": int(percent), "relative": False})


def on_knob(direction):
    now = current_volume()
    if now is None:
        return
    low, high = volume_limits()
    target = max(low, min(high, now + direction * VOLUME_STEP))
    if target != now:
        set_volume(target)


def keep_volume_in_range():
    """If the volume ends up outside the limits (say, from a phone's Spotify
    app, or a knob turned all the way down), nudge it back inside."""
    while True:
        time.sleep(3)
        now = current_volume()
        if now is None:
            continue
        low, high = volume_limits()
        if now > high:
            log(f"Volume {now} is above the limit; setting it to {high}")
            set_volume(high)
        elif now < low:
            log(f"Volume {now} is below the minimum; setting it to {low}")
            set_volume(low)


def main():
    back = Button(BACK_GPIO, pull_up=True, bounce_time=0.05)
    nxt = Button(NEXT_GPIO, pull_up=True, bounce_time=0.05)
    back.when_pressed = on_back
    nxt.when_pressed = on_next

    knob = RotaryEncoder(KNOB_CLK_GPIO, KNOB_DT_GPIO, max_steps=0)
    knob.when_rotated_clockwise = lambda: on_knob(+1)
    knob.when_rotated_counter_clockwise = lambda: on_knob(-1)

    threading.Thread(target=keep_volume_in_range, daemon=True).start()
    log("Buttons ready (back on GPIO 5, next on GPIO 6, knob on GPIO 17/27)")
    pause()


if __name__ == "__main__":
    main()
