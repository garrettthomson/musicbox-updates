"""
musicbox_naming.py
The speaker's name, and the web address that goes with it.

Every box has:
  - a NAME the owner picks, like "Ava's Room". It's what Spotify shows in its
    device list and what the phone app calls the box.
  - an ADDRESS made from the name, like http://avas-room.local
  - a permanent BOX ID: 4 letters/numbers from the Pi's serial, like 3F2A.
    It's printed on the bottom sticker, is in the setup network's name
    ("Music Box Setup 3F2A"), and http://musicbox-3f2a.local always works,
    whatever the box is called.

No more musicbox1, musicbox2, ... numbering: two boxes only clash if someone
picks the same name twice on one network, and then the second one gets its
box ID added (avas-room-3f2a.local).

Changing the computer name needs root, so the app calls a tiny helper
(/usr/local/sbin/musicbox-set-hostname) through sudo. Everything else here
runs as the normal user.
"""

import os
import re
import shutil
import socket
import subprocess
import threading
import time
import unicodedata

from musicbox_common import load_settings, save_settings

DEFAULT_NAME = "Music Box"
NAME_MAX = 32
SLUG_MAX = 30
LIBRESPOT_CONFIG = os.path.expanduser("~/.config/go-librespot/config.yml")
HOSTNAME_HELPER = "/usr/local/sbin/musicbox-set-hostname"
SERVICE_TYPE = "_musicbox._tcp"


# --------------------------------------------------------------------------
# Box ID
# --------------------------------------------------------------------------
def _serial():
    for path in ("/sys/firmware/devicetree/base/serial-number", "/proc/device-tree/serial-number"):
        try:
            with open(path) as f:
                value = f.read().strip("\x00 \n")
                if value:
                    return value
        except OSError:
            pass
    try:
        with open("/proc/cpuinfo") as f:
            for line in f:
                if line.lower().startswith("serial"):
                    return line.split(":", 1)[1].strip()
    except OSError:
        pass
    try:                                    # last resort: the Wi-Fi chip's address
        with open("/sys/class/net/wlan0/address") as f:
            return f.read().strip().replace(":", "")
    except OSError:
        return "0000"


def box_id():
    """4 characters, upper case, e.g. '3F2A'. Never changes for this Pi."""
    return re.sub(r"[^0-9a-fA-F]", "", _serial())[-4:].upper().rjust(4, "0")


def fallback_host():
    return f"musicbox-{box_id().lower()}"


# --------------------------------------------------------------------------
# Names
# --------------------------------------------------------------------------
def clean_name(text):
    """What the owner typed -> a tidy display name, or '' if nothing usable."""
    text = unicodedata.normalize("NFC", text or "")
    text = "".join(ch for ch in text if unicodedata.category(ch)[0] != "C")   # no control chars
    text = re.sub(r"\s+", " ", text).strip()
    return text[:NAME_MAX].strip()


def slugify(name):
    """"Ava's Room" -> "avas-room". Only a-z, 0-9 and dashes (what web addresses allow)."""
    ascii_text = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode()
    ascii_text = re.sub(r"['\u2019`]", "", ascii_text.lower())
    slug = re.sub(r"[^a-z0-9]+", "-", ascii_text).strip("-")
    slug = slug[:SLUG_MAX].rstrip("-")
    if not slug or slug in ("localhost", "local") or slug.isdigit():
        return fallback_host()
    return slug


def speaker_name():
    return load_settings().get("speaker_name") or DEFAULT_NAME


def is_named():
    return bool(load_settings().get("speaker_name"))


def current_host():
    return socket.gethostname()


def address():
    return f"{current_host()}.local"


def setup_ssid():
    return f"Music Box Setup {box_id()}"


# --------------------------------------------------------------------------
# Looking at the network (needs avahi-utils; quietly does nothing without it)
# --------------------------------------------------------------------------
def _run(args, timeout=8):
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout
    except (OSError, subprocess.TimeoutExpired):
        return 1, ""


def my_ips():
    code, out = _run(["hostname", "-I"], timeout=3)
    return set(out.split())


def _unescape(text):
    """avahi-browse -p writes spaces as \\032 and so on."""
    return re.sub(r"\\(\d{3})", lambda m: chr(int(m.group(1))), text)


def other_boxes():
    """[{"name", "host", "id"}] for other Music Boxes on this Wi-Fi."""
    if not shutil.which("avahi-browse"):
        return []
    code, out = _run(["avahi-browse", "-rpt", SERVICE_TYPE], timeout=6)
    me, found = box_id(), {}
    for line in out.splitlines():
        parts = line.split(";")
        if len(parts) < 10 or parts[0] != "=":
            continue
        txt = dict(re.findall(r'"(\w+)=([^"]*)"', parts[9]))
        if txt.get("id", "").upper() == me:
            continue
        name = _unescape(parts[3])
        found[(name, parts[6])] = {"name": name, "host": parts[6].removesuffix(".local"),
                                   "id": txt.get("id", "")}
    return list(found.values())


def host_taken(host):
    """True if some OTHER device on this Wi-Fi already answers to host.local."""
    if not shutil.which("avahi-resolve-host-name"):
        return False
    code, out = _run(["avahi-resolve-host-name", "-4", f"{host}.local"], timeout=5)
    if code != 0 or not out.strip():
        return False
    ip = out.split()[-1]
    return ip not in my_ips()


def check_name(name):
    """Before renaming: (ok, message). Only knows about boxes it can see."""
    others = other_boxes()
    if any(o["name"].casefold() == name.casefold() for o in others):
        return False, f"Another speaker here is already called \u201c{name}\u201d. Try something like \u201c{name} 2\u201d."
    return True, ""


def pick_host(name, online=True):
    """The address to use for a name: the plain slug if it's free, otherwise
    slug + box ID, which no other box can have."""
    slug = slugify(name)
    if slug == fallback_host() or slug == current_host():
        return slug
    if online and host_taken(slug):
        return f"{slug[:SLUG_MAX - 5].rstrip('-')}-{box_id().lower()}"
    return slug


# --------------------------------------------------------------------------
# Applying a name
# --------------------------------------------------------------------------
def _yaml_string(text):
    # A JSON string with ASCII escapes is also a valid YAML double-quoted string.
    import json
    return json.dumps(text, ensure_ascii=True)


def set_spotify_name(name):
    """Change device_name in go-librespot's config. True if the file changed."""
    try:
        with open(LIBRESPOT_CONFIG) as f:
            lines = f.read().splitlines()
    except FileNotFoundError:
        return False
    new_line = f"device_name: {_yaml_string(name)}"
    out, done = [], False
    for line in lines:
        if re.match(r"^device_name\s*:", line):
            if not done:
                out.append(new_line)
                done = True
            continue
        out.append(line)
    if not done:
        out.insert(0, new_line)
    if out == lines:
        return False
    tmp = LIBRESPOT_CONFIG + ".tmp"
    with open(tmp, "w") as f:
        f.write("\n".join(out) + "\n")
    os.replace(tmp, LIBRESPOT_CONFIG)
    return True


def set_hostname(host):
    """Ask the root helper to rename the computer. Returns '' or an error."""
    if host == current_host():
        return ""
    if not os.path.exists(HOSTNAME_HELPER):
        return "The renaming helper isn't installed yet (run the update script)."
    try:
        r = subprocess.run(["sudo", "-n", HOSTNAME_HELPER, host],
                           capture_output=True, text=True, timeout=40)
    except subprocess.TimeoutExpired:
        return "Renaming took too long."
    return "" if r.returncode == 0 else (r.stderr.strip() or "Couldn't change the address.")


def apply_name(name, online=True, restart_speaker=None):
    """Save the name and push it everywhere. Returns (host, error)."""
    name = clean_name(name)
    if not name:
        return current_host(), "Type a name first."
    host = pick_host(name, online=online)
    settings = load_settings()
    settings.update(speaker_name=name, host_checked=bool(online))
    save_settings(settings)
    error = set_hostname(host)
    if set_spotify_name(name) and restart_speaker:
        restart_speaker()
    publisher.refresh()
    return (current_host() if error else host), error


def check_after_joining():
    """Named in setup mode (where we can't see other boxes)? Once on the home
    Wi-Fi, make sure nobody else already had the address; if they did, add
    the box ID. Returns the new host if it changed, else ''."""
    settings = load_settings()
    if settings.get("host_checked") or not settings.get("speaker_name"):
        return ""
    time.sleep(8)                     # give mDNS a moment after joining
    host = current_host()
    new_host = ""
    if host != fallback_host() and host_taken(host):
        candidate = f"{host[:SLUG_MAX - 5].rstrip('-')}-{box_id().lower()}"
        if not set_hostname(candidate):
            new_host = candidate
            print(f"Address {host}.local was taken; now {candidate}.local", flush=True)
    settings = load_settings()
    settings["host_checked"] = True
    save_settings(settings)
    publisher.refresh()
    return new_host


# --------------------------------------------------------------------------
# Announcing ourselves: the always-works musicbox-XXXX.local address, and a
# "_musicbox._tcp" record so other boxes (and a future app) can see our name.
# --------------------------------------------------------------------------
class Publisher:
    def __init__(self):
        self.lock = threading.Lock()
        self.procs = {}
        self.key = None

    def _stop(self):
        for p in self.procs.values():
            try:
                p.terminate()
            except OSError:
                pass
        self.procs = {}

    def _wanted(self):
        ips = sorted(ip for ip in my_ips() if "." in ip and not ip.startswith("127."))
        return (speaker_name(), current_host(), ips[0] if ips else "")

    def refresh(self, force=False):
        if not shutil.which("avahi-publish"):
            return
        with self.lock:
            key = self._wanted()
            alive = all(p.poll() is None for p in self.procs.values())
            if key == self.key and alive and not force:
                return
            self._stop()
            name, host, ip = key
            self.key = key
            try:
                self.procs["service"] = subprocess.Popen(
                    ["avahi-publish", "-s", name, SERVICE_TYPE, "80",
                     f"id={box_id()}", f"host={host}"],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                if ip and host != fallback_host():
                    self.procs["alias"] = subprocess.Popen(
                        ["avahi-publish", "-a", "-R", f"{fallback_host()}.local", ip],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except OSError as err:
                print(f"Couldn't announce the box: {err}", flush=True)

    def loop(self):
        while True:
            try:
                self.refresh()
            except Exception as err:
                print(f"Announcer hiccup: {err}", flush=True)
            time.sleep(30)


publisher = Publisher()
