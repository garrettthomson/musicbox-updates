#!/bin/bash
# install_player.sh - puts the music player for your own music (MPD) on a Music Box
# or Pad, so the Library tab, USB sticks and "your music" tiles work. (2.5.7)
#
# It only sets up the player. It never replaces the box's programs (updates do that),
# so it is safe on any box from 2.5.4 on, and safe to run more than once.
# Needs the system writable (maintenance mode), and the internet the first time.
#
#   - From the phone app: Library > "Set up the music player" (the app runs it as
#     root through /usr/local/sbin/musicbox-admin; the box restarts by itself).
#   - Updates from 2.5.7 on run it by themselves if the player is missing.
#   - By hand:  sudo MB_USER=$(whoami) bash ~/musicbox/install_player.sh
set -u

if [ "$(id -u)" != 0 ]; then
  echo "STOPPED: run it with sudo:  sudo MB_USER=\$(whoami) bash $0"; exit 1
fi
ME="${MB_USER:-${SUDO_USER:-}}"
if [ -z "$ME" ] || [ "$ME" = root ] || ! id "$ME" > /dev/null 2>&1; then
  echo "STOPPED: set MB_USER to the box's user."; exit 1
fi
H="$(getent passwd "$ME" | cut -d: -f6)"
GRP="$(id -gn "$ME")"
DIR="$H/musicbox"
export PYTHONDONTWRITEBYTECODE=1 DEBIAN_FRONTEND=noninteractive
say() { echo; echo "== $*"; }
die() { echo; echo "STOPPED: $*"; exit 1; }
asme() { runuser -u "$ME" -- env HOME="$H" "$@"; }

[ -d "$DIR" ] || die "No musicbox folder for $ME. This needs a box that already has the Music Box software."
if awk '$2=="/" && $3=="overlay"{f=1} END{exit !f}' /proc/mounts; then
  die "Unplug protection is on, so nothing would stick. Set it up from the app (Library page), or run: sudo musicbox-admin maintenance-on, wait for the restart, run this again, then: sudo musicbox-admin protect-on"
fi

mpd_answers() {   # the player says "OK MPD ..." when it is ready
  python3 -I -c '
import socket, sys
try:
    s = socket.create_connection(("127.0.0.1", int(sys.argv[1])), timeout=3)
    ok = s.recv(64).startswith(b"OK MPD")
    s.close()
except OSError:
    ok = False
sys.exit(0 if ok else 1)' "${MB_MPD_PORT:-6600}"
}

say "1/4  Getting the music player..."
if command -v mpd > /dev/null; then
  echo "   Already on the box ($(mpd --version 2>/dev/null | head -1))"
else
  timeout 300 apt-get update -qq || echo "   (couldn't refresh the package list; trying anyway)"
  timeout 600 apt-get install -y -qq --no-install-recommends mpd > /tmp/musicbox-mpd-apt.log 2>&1 || {
    tail -15 /tmp/musicbox-mpd-apt.log
    die "Couldn't download the music player. Check the box is online and try again."
  }
  command -v mpd > /dev/null || die "The music player didn't install. Try again in a few minutes."
  echo "   Installed $(mpd --version 2>/dev/null | head -1)"
fi
# The box runs its own copy; switch off the one the package starts by itself.
systemctl disable --now mpd.service mpd.socket > /dev/null 2>&1 || true
# Tags (filing uploads under Artist/Album) and small covers. Optional, so failures are fine.
if [ -x "$DIR/venv/bin/pip" ]; then
  timeout 300 runuser -u "$ME" -- "$DIR/venv/bin/pip" install -q mutagen pillow > /dev/null 2>&1 \
    && echo "   Tag reader ready" || echo "   (tag reader not added; uploads still work)"
fi

say "2/4  Folders..."
asme mkdir -p "$H/Music" "$DIR/mpd/playlists"
# ~/Music/USB is where a USB stick appears (it may be mounted right now: leave it).
[ -d "$H/Music/USB" ] || asme mkdir -p "$H/Music/USB" 2>/dev/null || true
chown "$ME:$GRP" "$DIR/mpd" "$DIR/mpd/playlists"
echo "   Music lives in $H/Music"

say "3/4  Setting up the player to play through the box's speaker..."
write_conf() {   # $1 = resampler line (may be empty)
  cat > /etc/musicbox-mpd.conf <<CONF
# The music box's own MPD. It plays into ALSA "default", the same place Spotify
# plays, so the EQ and the amp are shared.
music_directory     "$H/Music"
playlist_directory  "$DIR/mpd/playlists"
db_file             "$DIR/mpd/database"
bind_to_address     "127.0.0.1"
port                "6600"
auto_update         "yes"
follow_inside_symlinks  "yes"
filesystem_charset  "UTF-8"
audio_output_format "44100:16:2"
$1
audio_output {
    type        "alsa"
    name        "Music Box"
    device      "default"
    mixer_type  "software"
}
CONF
  chmod 644 /etc/musicbox-mpd.conf
}
cat > /etc/systemd/system/musicbox-mpd.service <<UNIT
[Unit]
Description=Music Box local music player (MPD)
After=sound.target camilladsp.service musicbox-music-mount.service

[Service]
User=$ME
SupplementaryGroups=audio
ExecStart=/usr/bin/mpd --no-daemon /etc/musicbox-mpd.conf
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable musicbox-mpd > /dev/null 2>&1
STARTED=""
for CONV in 'samplerate_converter "soxr medium"' 'samplerate_converter "Medium Sinc Interpolator"' ''; do
  write_conf "$CONV"
  systemctl restart musicbox-mpd
  for _ in 1 2 3 4 5 6; do
    sleep 2
    if systemctl is-active --quiet musicbox-mpd && mpd_answers; then STARTED=1; break; fi
  done
  if [ -n "$STARTED" ]; then echo "   Player running (${CONV:-standard resampler})"; break; fi
done
if [ -z "$STARTED" ]; then
  journalctl -u musicbox-mpd -n 15 --no-pager 2>/dev/null | sed 's/^/   /'
  die "The music player didn't start. Open Details and send this to whoever set up the box."
fi

say "4/4  USB sticks..."
mkdir -p /etc/udev/rules.d
cat > /etc/udev/rules.d/99-musicbox-usb.rules <<RULES
# Mount a USB stick read-only inside the music folder.
ACTION=="add", SUBSYSTEM=="block", ENV{ID_BUS}=="usb", ENV{ID_FS_USAGE}=="filesystem", ENV{ID_FS_TYPE}=="vfat|exfat|ntfs", RUN+="/usr/bin/systemd-mount --no-block --collect -o ro,umask=022 \$devnode $H/Music/USB"
ACTION=="add", SUBSYSTEM=="block", ENV{ID_BUS}=="usb", ENV{ID_FS_USAGE}=="filesystem", ENV{ID_FS_TYPE}=="ext2|ext3|ext4", RUN+="/usr/bin/systemd-mount --no-block --collect -o ro \$devnode $H/Music/USB"
RULES
udevadm control --reload > /dev/null 2>&1 || true
echo "   A USB stick with music shows up in the Library when plugged in"

echo
echo "DONE: The music player is set up. Your music shows in the Library."
exit 0
