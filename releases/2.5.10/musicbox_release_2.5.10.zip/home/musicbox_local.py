"""
musicbox_local.py
Music from the box itself: files on a USB stick or on the memory card, played
by MPD (a small music player that runs inside the box) through the same
speaker output as Spotify, so the EQ and the amp are shared.

  A tile's link looks like   local:Audiobooks/The Hobbit
  (a folder inside the music library; a single file works too).

Folders that are long (90+ minutes in total, or any single file of 20+ minutes)
are treated as audiobooks: the box remembers the place and carries on from it
whenever the tile comes back, however long it was away. Everything else starts
from the top, like an album.

Uses only Python's standard library, so the button program (which runs with
the Pi's own Python) can import it too.

Command line (for checking on the box):
  python3 musicbox_local.py status | update | play "<folder>" | list
"""

import hashlib
import json
import os
import re
import shutil
import socket
import sys
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
MUSIC_DIR = os.path.join(os.path.dirname(HERE), "Music")      # ~/Music
USB_DIR = os.path.join(MUSIC_DIR, "USB")                       # a USB stick shows up here
PLACES_FILE = os.path.join(HERE, "local_places.json")          # audiobook bookmarks
OVERRIDES_FILE = os.path.join(HERE, "album_overrides.json")      # names fixed in the app
ART_DIR = os.path.join(HERE, "album_art")                      # covers chosen in the app
ART_CACHE = os.path.join(HERE, "art_cache")                    # covers read out of the files
SOURCE_FILE = "/dev/shm/musicbox-source"                       # "local" or "spotify"
LOADED_FILE = "/dev/shm/musicbox-local-loaded"                 # which folder is loaded now

MPD_HOST, MPD_PORT = "127.0.0.1", 6600
PREFIX = "local:"

AUDIO_EXTENSIONS = (".mp3", ".m4a", ".m4b", ".aac", ".flac", ".ogg", ".oga", ".opus",
                    ".wav", ".wma", ".aiff", ".aif")
BOOK_TOTAL_SECONDS = 90 * 60     # a folder this long (or longer) is an audiobook
BOOK_FILE_SECONDS = 20 * 60      # ...or one with a file this long
SAVE_EVERY = 30                  # seconds between saves of the place while playing


class MPDError(Exception):
    pass


class NoMusic(Exception):
    pass


# --------------------------------------------------------------------------
# Talking to MPD
# --------------------------------------------------------------------------
def quote(text):
    return '"' + str(text).replace("\\", "\\\\").replace('"', '\\"') + '"'


def _read_reply(f):
    """Read lines up to OK. Returns a list of (key, value) pairs."""
    pairs = []
    while True:
        line = f.readline()
        if not line:
            raise MPDError("MPD closed the connection")
        line = line.decode("utf-8", "replace").rstrip("\n")
        if line == "OK":
            return pairs
        if line.startswith("ACK"):
            raise MPDError(line)
        key, _, value = line.partition(": ")
        pairs.append((key, value))


def mpd(*commands, timeout=5):
    """Send one command (a string) or several (run together as a list).
    Returns the (key, value) pairs of the reply."""
    try:
        with socket.create_connection((MPD_HOST, MPD_PORT), timeout=timeout) as sock:
            f = sock.makefile("rwb")
            greeting = f.readline()
            if not greeting.startswith(b"OK MPD"):
                raise MPDError("That isn't MPD")
            if len(commands) == 1:
                f.write(commands[0].encode("utf-8") + b"\n")
            else:
                f.write(b"command_list_begin\n" + b"".join(c.encode("utf-8") + b"\n" for c in commands)
                        + b"command_list_end\n")
            f.flush()
            return _read_reply(f)
    except (OSError, socket.timeout) as err:
        raise MPDError(f"MPD isn't answering ({err})")


def as_dict(pairs):
    out = {}
    for key, value in pairs:
        out.setdefault(key, value)
    return out


def ping():
    try:
        mpd("ping")
        return True
    except MPDError:
        return False


def status():
    """MPD's own status as a dict ({} if it isn't running)."""
    try:
        return as_dict(mpd("status"))
    except MPDError:
        return {}


def current_song():
    try:
        return as_dict(mpd("currentsong"))
    except MPDError:
        return {}


def split_songs(pairs):
    """listallinfo / lsinfo output -> a list of dicts, one per file."""
    songs, cur = [], None
    for key, value in pairs:
        if key == "file":
            cur = {"file": value}
            songs.append(cur)
        elif key in ("directory", "playlist"):
            cur = None
        elif cur is not None:
            cur.setdefault(key, value)
    return songs


def seconds_of(song):
    for key in ("duration", "Time"):
        try:
            return float(song.get(key, ""))
        except ValueError:
            pass
    return 0.0


def number_of(text):
    """'3/12' -> 3; '' -> None."""
    match = re.match(r"\s*(\d+)", text or "")
    return int(match.group(1)) if match else None


def natural_key(text):
    return [int(p) if p.isdigit() else p.lower() for p in re.split(r"(\d+)", text)]


def order_songs(songs):
    """Play folders in name order; inside a folder use track numbers when every
    file has one, otherwise the file names (Chapter 2 before Chapter 10)."""
    by_dir = {}
    for song in songs:
        by_dir.setdefault(os.path.dirname(song["file"]), []).append(song)
    ordered = []
    for folder in sorted(by_dir, key=natural_key):
        group = by_dir[folder]
        if all(number_of(s.get("Track")) is not None for s in group):
            group.sort(key=lambda s: (number_of(s.get("Disc")) or 1, number_of(s["Track"]),
                                      natural_key(s["file"])))
        else:
            group.sort(key=lambda s: natural_key(os.path.basename(s["file"])))
        ordered.extend(group)
    return ordered


def is_book(songs):
    total = sum(seconds_of(s) for s in songs)
    longest = max((seconds_of(s) for s in songs), default=0)
    return total >= BOOK_TOTAL_SECONDS or longest >= BOOK_FILE_SECONDS


# --------------------------------------------------------------------------
# Which source is playing
# --------------------------------------------------------------------------
def set_source(name):
    try:
        with open(SOURCE_FILE, "w") as f:
            f.write(name)
    except OSError:
        pass


def source():
    try:
        with open(SOURCE_FILE) as f:
            return f.read().strip() or "spotify"
    except OSError:
        return "spotify"


def is_local_uri(uri):
    return bool(uri) and uri.startswith(PREFIX)


def path_of(uri):
    return uri[len(PREFIX):].strip("/")


def make_uri(rel, album=None):
    return PREFIX + rel.strip("/") + ("|" + album if album is not None else "")


def loaded_path():
    try:
        with open(LOADED_FILE) as f:
            return json.load(f).get("path")
    except (OSError, ValueError):
        return None


# --------------------------------------------------------------------------
# Remembered places (audiobooks)
# --------------------------------------------------------------------------
_places_lock = threading.Lock()


def load_places():
    try:
        with open(PLACES_FILE) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save_places(places):
    tmp = PLACES_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(places, f, indent=2)
    os.replace(tmp, PLACES_FILE)


def forget_place(rel):
    with _places_lock:
        places = load_places()
        if places.pop(rel, None) is not None:
            save_places(places)


def save_place():
    """Remember where we are in the loaded folder, if it is an audiobook.
    Called when the tile is lifted and every half minute while playing."""
    rel = loaded_path()
    if rel is None:
        return
    st = status()
    song = current_song()
    if not song or st.get("state") not in ("play", "pause"):
        return
    with _places_lock:
        places = load_places()
        entry = places.get(rel)
        if entry is None and not _loaded_is_book():
            return
        try:
            elapsed = float(st.get("elapsed", 0))
        except ValueError:
            elapsed = 0.0
        places[rel] = {"file": song.get("file", ""), "elapsed": round(elapsed, 1),
                       "saved": int(time.time())}
        save_places(places)


def _loaded_is_book():
    try:
        with open(LOADED_FILE) as f:
            return bool(json.load(f).get("book"))
    except (OSError, ValueError):
        return False


# --------------------------------------------------------------------------
# Finding and playing music
# --------------------------------------------------------------------------
def wait_for_update(timeout=60):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if "updating_db" not in status():
            return True
        time.sleep(0.5)
    return False


def update(path=None, wait=False):
    """Ask MPD to look for new or removed files."""
    forget_album_cache()
    try:
        mpd("update " + quote(path) if path else "update")
    except MPDError:
        return False
    return wait_for_update() if wait else True


def update_in_background(path=None):
    threading.Thread(target=update, args=(path, False), daemon=True).start()


def songs_in(key):
    """The songs behind a tile's key, in play order. A key is a folder (or one
    file); "Folder|Album" picks just that album out of a folder that holds several."""
    rel, sep, album = key.strip("/").partition("|")
    rel = rel.strip("/")
    pairs = mpd("lsinfo " + quote(rel)) if rel else []
    songs = split_songs(pairs)
    if len(songs) == 1 and songs[0]["file"] == rel:      # it's a single file
        return songs
    songs = split_songs(mpd("listallinfo " + quote(rel)))
    if sep:
        songs = [x for x in songs if x.get("Album", "") == album]
    return order_songs(songs)


_last_scan = [0.0]


def find_songs(rel):
    """Like songs_in, but if MPD hasn't seen the folder yet (just uploaded, or a
    stick just plugged in) ask it to look once."""
    try:
        songs = songs_in(rel)
    except MPDError:
        songs = []
    if not songs and time.monotonic() - _last_scan[0] > 30:     # not on every retry
        _last_scan[0] = time.monotonic()
        update(rel.partition("|")[0] or None, wait=True)
        try:
            songs = songs_in(rel)
        except MPDError:
            songs = []
    return songs


def play_path(rel, restore=True, start_at=None):
    """Load a folder/file and start it. Remembered audiobooks carry on where
    they stopped. start_at (a track number counted from 0) starts from that
    track instead. Raises NoMusic if there is nothing to play."""
    rel = rel.strip("/")             # the tile's key: "Folder" or "Folder|Album"
    if not rel.partition("|")[0]:
        raise NoMusic("No folder chosen")
    songs = find_songs(rel)
    if not songs:
        raise NoMusic(f"Nothing to play in '{rel}'")
    book = is_book(songs)
    start, elapsed = 0, 0.0
    if start_at is not None and 0 <= start_at < len(songs):
        start = start_at
    elif book and restore:
        place = load_places().get(rel)
        if place:
            for i, s in enumerate(songs):
                if s["file"] == place.get("file"):
                    start, elapsed = i, float(place.get("elapsed", 0))
                    break
    cmds = ["clear", "repeat 0", "random 0", "single 0", "consume 0"]
    cmds += ["add " + quote(s["file"]) for s in songs]
    mpd(*cmds)
    mpd(f"play {start}")
    if elapsed > 3:
        try:
            mpd(f"seekcur {max(0, elapsed - 2):.1f}")      # back up two seconds to catch the thread
        except MPDError:
            pass
    try:
        with open(LOADED_FILE, "w") as f:
            json.dump({"path": rel, "book": book}, f)
    except OSError:
        pass
    if not book or start_at is not None:
        forget_place(rel)                # a book started from a chosen chapter saves from there
    set_source("local")
    return {"tracks": len(songs), "book": book, "resumed": elapsed > 3}


# --------------------------------------------------------------------------
# Controls (the buttons, the knob and the phone app use these)
# --------------------------------------------------------------------------
def is_playing():
    return status().get("state") == "play"


def paused_on(rel):
    """True if this folder is loaded and paused partway through."""
    st = status()
    return st.get("state") == "pause" and loaded_path() == rel.strip("/") and "song" in st


def pause():
    try:
        mpd("pause 1")
        return True
    except MPDError:
        return False


def pause_and_save():
    if is_playing():
        save_place()
        pause()
        return True
    if status().get("state") == "pause":
        save_place()
    return False


def resume():
    try:
        mpd("pause 0")
        set_source("local")
        return True
    except MPDError:
        return False


def next_track():
    try:
        mpd("next")
    except MPDError:
        pass


def back():
    """Restart the file; press again near the start for the one before."""
    st = status()
    try:
        elapsed = float(st.get("elapsed", 0))
    except ValueError:
        elapsed = 0.0
    try:
        if elapsed > 3:
            mpd("seekcur 0")
        else:
            mpd("previous")
    except MPDError:
        pass


def get_volume():
    v = status().get("volume")
    return int(v) if v not in (None, "-1") else None


def set_volume(percent):
    try:
        mpd(f"setvol {max(0, min(100, int(percent)))}")
    except MPDError:
        pass


def now_playing():
    """What the phone app shows while local music plays, or None."""
    st = status()
    if st.get("state") not in ("play", "pause"):
        return None
    song = current_song()
    if not song:
        return None
    rel = loaded_path() or ""
    title = song.get("Title") or os.path.splitext(os.path.basename(song.get("file", "")))[0]
    folder = os.path.basename(rel.partition("|")[0]) or os.path.basename(os.path.dirname(song.get("file", "")))
    return {
        "playing": st.get("state") == "play",
        "track": title,
        "artist": song.get("Artist", "") or song.get("AlbumArtist", ""),
        "album_artist": song.get("AlbumArtist", "") or song.get("Artist", ""),   # for About this album
        "album": song.get("Album", "") or folder,
        "book": _loaded_is_book(),
        "volume": get_volume(),
    }


# --------------------------------------------------------------------------
# The library (for the phone app)
# --------------------------------------------------------------------------
def library():
    """Folders that directly hold music: [{path, name, tracks, seconds, book, usb}]."""
    songs = split_songs(mpd("listallinfo"))
    by_dir = {}
    for s in songs:
        by_dir.setdefault(os.path.dirname(s["file"]), []).append(s)
    folders = []
    for folder in sorted(by_dir, key=natural_key):
        group = by_dir[folder]
        if not folder:            # loose files at the top: not offered as a tile
            continue
        folders.append({
            "path": folder,
            "name": folder,
            "tracks": len(group),
            "seconds": int(sum(seconds_of(s) for s in group)),
            "book": is_book(group),
            "usb": folder == "USB" or folder.startswith("USB/"),
        })
    return folders


def tag_year(song):
    match = re.search(r"(\d{4})", song.get("OriginalDate") or song.get("Date") or "")
    return int(match.group(1)) if match else 0


def artist_sort_key(name):
    name = (name or "").lower().strip()
    for article in ("the ", "a "):
        if name.startswith(article):
            name = name[len(article):]
    return natural_key(name)


def album_artist(group):
    for s in group:
        if s.get("AlbumArtist"):
            return s["AlbumArtist"]
    artists = [s.get("Artist", "") for s in group if s.get("Artist")]
    if not artists:
        return ""
    if len(set(artists)) > 3:
        return "Various Artists"
    return max(set(artists), key=artists.count)


def albums(songs=None):
    """Every album on the box, ready to show: artist A to Z (ignoring The), then
    each artist's albums oldest first. One album per folder, unless a folder holds
    several albums, then each gets its own entry."""
    if songs is None:
        songs = split_songs(mpd("listallinfo"))
    groups = {}
    for s in songs:
        folder = os.path.dirname(s["file"])
        if folder:               # loose files at the top aren't offered
            groups.setdefault((folder, s.get("Album", "")), []).append(s)
    per_folder = {}
    for folder, album in groups:
        per_folder[folder] = per_folder.get(folder, 0) + 1
    out = []
    overrides = load_overrides()
    for (folder, album), group in groups.items():
        ordered = order_songs(group)
        key = folder + ("|" + album if per_folder[folder] > 1 else "")
        fix = overrides.get(key, {})
        artist = fix.get("artist") or album_artist(group)
        sort_name = artist if fix.get("artist") else next(
            (s.get("AlbumArtistSort") or s.get("ArtistSort") for s in group
             if s.get("AlbumArtistSort") or s.get("ArtistSort")), artist)
        year = int(fix["year"]) if str(fix.get("year", "")).isdigit() else \
            min((y for y in map(tag_year, group) if y), default=0)
        out.append({
            "key": key,
            "folder": folder,
            "album": fix.get("album") or album or os.path.basename(folder),
            "artist": artist,
            "year": year,
            "tracks": len(group),
            "seconds": int(sum(seconds_of(s) for s in group)),
            "book": is_book(group),
            "usb": folder == "USB" or folder.startswith("USB/"),
            "first": ordered[0],
            "multi": per_folder[folder] > 1,
            # for the Library's search box: every track title
            "titles": "\n".join(sorted({s.get("Title") or os.path.splitext(os.path.basename(s["file"]))[0]
                                        for s in group})),
            # audiobooks: (file, seconds) in play order, to show how far along you are
            "parts": [(s["file"], seconds_of(s)) for s in ordered] if is_book(group) else [],
            "sort": (0 if artist else 1, artist_sort_key(sort_name or artist),
                     year or 9999, natural_key(fix.get("album") or album or folder)),
        })
    out.sort(key=lambda a: a["sort"])
    for a in out:
        del a["sort"]
    return out


def book_progress(album, places=None):
    """How far along a remembered audiobook is, or None if it hasn't been started
    (or the bookmark no longer matches its files)."""
    if not album or not album.get("book"):
        return None
    place = (load_places() if places is None else places).get(album["key"])
    if not place:
        return None
    parts = album.get("parts") or []
    before = 0.0
    for i, (name, secs) in enumerate(parts):
        if name == place.get("file"):
            total = sum(p[1] for p in parts) or album.get("seconds") or 0
            at = min(before + float(place.get("elapsed", 0) or 0), total)
            return {"at": int(at), "total": int(total), "left": int(max(0, total - at)),
                    "percent": round(100 * at / total) if total else 0,
                    "chapter": i + 1, "chapters": len(parts),
                    "saved": int(place.get("saved", 0) or 0)}
        before += secs
    return None


_album_cache = [0.0, []]


def get_albums(max_age=20):
    """albums(), reused for a few seconds so the app can ask often."""
    if time.monotonic() - _album_cache[0] > max_age:
        _album_cache[1] = albums()
        _album_cache[0] = time.monotonic()
    return _album_cache[1]


def forget_album_cache():
    _album_cache[0] = 0.0


def album_by_key(key):
    for a in get_albums():
        if a["key"] == key:
            return a
    return None


def _read_picture(command, song):
    """Ask MPD for a picture (readpicture = inside the file, albumart = a
    cover.jpg next to it). Returns bytes or None."""
    data, size = b"", None
    try:
        with socket.create_connection((MPD_HOST, MPD_PORT), timeout=8) as sock:
            f = sock.makefile("rwb")
            f.readline()
            f.write(b"binarylimit 1048576\n")
            f.flush()
            f.readline()                                  # OK, or ACK on older MPD
            while True:
                f.write(f"{command} {quote(song['file'])} {len(data)}\n".encode("utf-8"))
                f.flush()
                headers, chunk = {}, b""
                while True:
                    line = f.readline()
                    if not line:
                        return None
                    text = line.decode("utf-8", "replace").rstrip("\n")
                    if text.startswith("ACK"):
                        return None
                    if text == "OK":
                        break
                    key, _, value = text.partition(": ")
                    headers[key] = value
                    if key == "binary":
                        chunk = f.read(int(value))
                        f.readline()
                if "binary" not in headers:
                    return None                           # no picture there
                size = int(headers.get("size", "0"))
                data += chunk
                if len(data) >= size or not chunk or len(data) > 12 * 1024 * 1024:
                    return data
    except (OSError, ValueError, socket.timeout):
        return None


def embedded_cover(song):
    """Path of a cached cover picture taken from the song file (or None)."""
    name = hashlib.sha1((song["file"] + song.get("Last-Modified", "")).encode("utf-8")).hexdigest()
    cached = os.path.join(ART_CACHE, name + ".jpg")
    missing = os.path.join(ART_CACHE, name + ".none")
    if os.path.exists(cached):
        return cached
    if os.path.exists(missing):
        return None
    data = _read_picture("readpicture", song) or _read_picture("albumart", song)
    os.makedirs(ART_CACHE, exist_ok=True)
    if not data:
        open(missing, "w").close()
        return None
    try:                                                  # small thumbnails if Pillow is there
        import io
        from PIL import Image
        img = Image.open(io.BytesIO(data)).convert("RGB")
        img.thumbnail((600, 600))
        img.save(cached, "JPEG", quality=85)
    except Exception:
        with open(cached, "wb") as out:
            out.write(data)
    return cached


def custom_cover(key):
    """The cover picture chosen in the app for this album, or None."""
    name = hashlib.sha1(key.encode("utf-8")).hexdigest()[:20]
    for ext in IMAGE_EXTENSIONS:
        path = os.path.join(ART_DIR, name + ext)
        if os.path.exists(path):
            return path
    return None


def custom_cover_base(key):
    return os.path.join(ART_DIR, hashlib.sha1(key.encode("utf-8")).hexdigest()[:20])


def cover_for(album):
    """A picture file for an album card: the one chosen in the app, then a picture
    in its folder (for a single-album folder), then one inside the files."""
    chosen = custom_cover(album["key"])
    if chosen:
        return chosen
    if not album["multi"]:
        path = find_cover(album["folder"])
        if path:
            return path
    return embedded_cover(album["first"])



# --------------------------------------------------------------------------
# Names fixed in the app (the files themselves are never changed)
# --------------------------------------------------------------------------
def load_overrides():
    try:
        with open(OVERRIDES_FILE) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def set_override(key, album="", artist="", year=""):
    """Show this album under a different name/artist/year. All empty = back to the tags."""
    fix = {k: v.strip() for k, v in (("album", album), ("artist", artist), ("year", str(year))) if v and v.strip()}
    with _places_lock:
        data = load_overrides()
        if fix:
            data[key] = fix
        else:
            data.pop(key, None)
        tmp = OVERRIDES_FILE + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f, indent=2)
        os.replace(tmp, OVERRIDES_FILE)
    forget_album_cache()


def find_moved(album, artist):
    """A tile's album, if its files moved: the one album with this name and artist now."""
    forget_album_cache()
    want = ((album or "").lower(), (artist or "").lower())
    hits = [a for a in get_albums() if (a["album"].lower(), (a["artist"] or "").lower()) == want]
    return hits[0]["key"] if len(hits) == 1 else None


# --------------------------------------------------------------------------
# Filing new music by its tags: Music/<Artist>/<Album>/
# --------------------------------------------------------------------------
def clean_part(text, limit=80):
    text = re.sub(r'[\x00-\x1f<>:"|?*\\/]', "_", text or "").strip(". ")
    return text[:limit]


def read_tags(path):
    """(artist, album, year) from a music file's tags, or ('', '', '') if none/unreadable.
    Needs the optional 'mutagen' library."""
    try:
        import mutagen
        f = mutagen.File(path, easy=True)
        tags = getattr(f, "tags", None)
        if not tags:
            return "", "", ""

        def first(*names):
            for n in names:
                try:
                    v = tags[n]
                except (KeyError, ValueError):
                    continue
                v = v[0] if isinstance(v, (list, tuple)) else v
                text = getattr(v, "text", [v])[0] if hasattr(v, "text") else v
                if str(text).strip():
                    return str(text).strip()
            return ""
        artist = first("albumartist", "TPE2") or first("artist", "TPE1")
        album = first("album", "TALB")
        year = first("originaldate", "date", "TDRC", "TYER")
        match = re.search(r"\d{4}", year)
        return artist, album, match.group(0) if match else ""
    except Exception:
        return "", "", ""


def unique_name(folder, name):
    base, ext = os.path.splitext(name)
    candidate, n = name, 2
    while os.path.exists(os.path.join(folder, candidate)):
        candidate = f"{base} ({n}){ext}"
        n += 1
    return candidate


def place_file(src, name, fallback_folder="Uploads", root=None):
    """Move one just-arrived music file into the music folder under Artist/Album
    (from its tags), or fallback_folder when it has no album tag.
    Returns (folder relative to the music folder, (artist, album))."""
    root = root or MUSIC_DIR
    artist, album, _year = read_tags(src)
    if album:
        folder = os.path.join(clean_part(artist) or "Unknown Artist", clean_part(album) or "Unknown Album")
        label = (artist, album)
    else:
        folder = fallback_folder
        label = ("", os.path.basename(fallback_folder))
    dest = os.path.join(root, folder)
    os.makedirs(dest, exist_ok=True)
    shutil.move(src, os.path.join(dest, unique_name(dest, name)))
    return folder, label


# Files the box can't play, and why (plain words for owners).
PROTECTED_EXTENSIONS = (".m4p",)
VIDEO_EXTENSIONS = (".m4v", ".mp4", ".mov", ".mkv", ".avi")
MP4_CONTAINERS = {b"moov", b"trak", b"mdia", b"minf", b"stbl"}


def mp4_sample_type(path):
    """The first sample entry type in an MP4/M4A file (b'mp4a', b'alac', or
    b'drms'/b'enca' for files locked by FairPlay), or None. Reads only box headers."""
    try:
        with open(path, "rb") as f:
            f.seek(0, 2)
            end = f.tell()

            def walk(start, stop, depth):
                pos = start
                while pos + 8 <= stop and depth < 8:
                    f.seek(pos)
                    head = f.read(16)
                    if len(head) < 8:
                        return None
                    size, kind = int.from_bytes(head[:4], "big"), head[4:8]
                    hdr = 8
                    if size == 1:
                        size, hdr = int.from_bytes(head[8:16], "big"), 16
                    elif size == 0:
                        size = stop - pos
                    if size < hdr:
                        return None
                    if kind in MP4_CONTAINERS:
                        found = walk(pos + hdr, min(pos + size, stop), depth + 1)
                        if found:
                            return found
                    elif kind == b"stsd":
                        f.seek(pos + hdr + 8)       # version/flags + entry count
                        entry = f.read(8)
                        return entry[4:8] if len(entry) == 8 else None
                    pos += size
                return None
            return walk(0, end, 0)
    except OSError:
        return None


def why_unplayable(path, name=None):
    """None if the box can play the file, otherwise a short reason key:
    'protected', 'video' or 'not-music'."""
    lower = (name or path).lower()
    if lower.endswith(PROTECTED_EXTENSIONS):
        return "protected"
    if lower.endswith(VIDEO_EXTENSIONS):
        return "video"
    if not lower.endswith(AUDIO_EXTENSIONS):
        return "not-music"
    if lower.endswith((".m4a", ".m4b", ".aac")) and mp4_sample_type(path) in (b"drms", b"enca", b"drmi"):
        return "protected"
    return None


def library_index(root=None):
    """{(lower-case file name, size)} for music already on the box (not the USB
    stick), to spot songs that are being added a second time."""
    root = root or MUSIC_DIR
    have = set()
    for here, dirs, files in os.walk(root):
        if here == root:
            dirs[:] = [d for d in dirs if d not in ("USB", ".incoming")]
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for n in files:
            if n.lower().endswith(AUDIO_EXTENSIONS):
                try:
                    have.add((n.lower(), os.path.getsize(os.path.join(here, n))))
                except OSError:
                    pass
    return have


def file_batch(incoming, fallback_folder="Uploads", root=None):
    """Move just-uploaded files from `incoming` into the music folder, each album
    under Artist/Album using its tags. Files without an album tag go to
    fallback_folder. Returns {"added", "albums": [(artist, album)], "skipped"}."""
    root = root or MUSIC_DIR
    added, skipped, seen, pictures, placed_dirs = 0, 0, [], [], []
    for name in sorted(os.listdir(incoming), key=natural_key):
        src = os.path.join(incoming, name)
        lower = name.lower()
        if lower.endswith(IMAGE_EXTENSIONS):
            pictures.append(src)
            continue
        if not lower.endswith(AUDIO_EXTENSIONS):
            skipped += 1
            continue
        folder, label = place_file(src, name, fallback_folder, root)
        dest = os.path.join(root, folder)
        added += 1
        if label not in seen:
            seen.append(label)
        if dest not in placed_dirs:
            placed_dirs.append(dest)
    if len(placed_dirs) == 1:                      # one album: its picture goes with it
        for pic in pictures:
            shutil.move(pic, os.path.join(placed_dirs[0], unique_name(placed_dirs[0], os.path.basename(pic))))
    else:
        skipped += len(pictures)
    return {"added": added, "albums": seen, "skipped": skipped}



def usb_present():
    return os.path.ismount(USB_DIR)


def duration_text(seconds):
    minutes = int(seconds // 60)
    if minutes >= 60:
        return f"{minutes // 60} h {minutes % 60:02d} min"
    return f"{max(minutes, 1)} min" if seconds else ""


def safe_join(rel):
    """A path inside the music folder, or None if it tries to leave it."""
    full = os.path.realpath(os.path.join(MUSIC_DIR, rel.strip("/")))
    root = os.path.realpath(MUSIC_DIR)
    return full if full == root or full.startswith(root + os.sep) else None



COVER_NAMES = ("cover", "folder", "front", "album", "albumart", "artwork", "art")
IMAGE_EXTENSIONS = (".jpg", ".jpeg", ".png", ".webp", ".gif")


def find_cover(rel):
    """A picture inside the folder to use as its artwork (cover.jpg and friends
    first, otherwise the first picture), or None."""
    full = safe_join(rel)
    if not full or not os.path.isdir(full):
        return None
    try:
        names = sorted(os.listdir(full), key=natural_key)
    except OSError:
        return None
    pictures = [n for n in names if n.lower().endswith(IMAGE_EXTENSIONS) and not n.startswith(".")]
    for want in COVER_NAMES:
        for n in pictures:
            if os.path.splitext(n)[0].lower() == want:
                return os.path.join(full, n)
    return os.path.join(full, pictures[0]) if pictures else None


# --------------------------------------------------------------------------
# Watcher (runs inside the tile program)
# --------------------------------------------------------------------------
def watch(spotify_playing, stop=lambda: False):
    """Every couple of seconds: notice a USB stick coming or going, hand over
    to Spotify if a phone starts it, and keep the audiobook place saved."""
    last_usb, last_save, spotify_votes = None, 0.0, 0
    scanned = False
    while not stop():
        time.sleep(2)
        try:
            if not scanned:
                # Once at start: music added while unplug protection was on is saved to
                # the card but not in the player's list after a restart until it looks.
                scanned = update()
            usb = usb_present()
            if last_usb is not None and usb != last_usb:
                update_in_background()
            last_usb = usb
            playing_here = is_playing()
            spotify_on = spotify_playing()
            if spotify_on:
                spotify_votes += 1
                if spotify_votes >= 2:           # two looks in a row: Spotify really is playing
                    if playing_here:
                        save_place()
                        pause()
                    if source() != "spotify":
                        set_source("spotify")
                continue
            spotify_votes = 0
            if playing_here:
                if source() != "local":
                    set_source("local")
                if time.monotonic() - last_save > SAVE_EVERY:
                    save_place()
                    last_save = time.monotonic()
        except Exception:
            pass


def stop_all():
    """Stop and empty the queue (used after the install test)."""
    try:
        mpd("stop", "clear")
    except MPDError:
        pass
    set_source("spotify")


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "status"
    if cmd == "status":
        print(json.dumps({"mpd": ping(), "status": status(), "song": current_song(),
                          "usb": usb_present(), "source": source()}, indent=2))
    elif cmd == "stop":
        stop_all()
    elif cmd == "update":
        print("ok" if update(wait=True) else "MPD isn't running")
    elif cmd == "list":
        for f in library():
            print(f"{'BOOK ' if f['book'] else '     '}{f['tracks']:4d} files  {duration_text(f['seconds']):>10}  {f['path']}")
    elif cmd == "play" and len(sys.argv) > 2:
        print(play_path(sys.argv[2]))
    else:
        print(__doc__)
