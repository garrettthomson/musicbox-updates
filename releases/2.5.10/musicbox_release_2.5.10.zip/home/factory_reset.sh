#!/bin/bash
# factory_reset.sh - the app's "Erase this box" (factory reset), app 2.5.9.
# Same clean-up as reset_for_new_owner.sh, without the questions: the app has
# already asked for the PIN, the word RESET and a final yes.
#
# Run by musicbox-admin as root (never by hand), with:
#   MB_USER   the box's user
#   MB_RESET  options, comma separated: keep-tiles|erase-tiles, keep-music|erase-music,
#             shut-down|restart
# The system must be writable (musicbox-admin switches maintenance mode on first).
#
# Clears: speaker name, PIN and signed-in phones, setup, Spotify pairing and the
# Soloist key and sign-in, Apple Music link, listening stats and sharing choice,
# album info cache, all saved Wi-Fi; tiles' music links and pictures (if asked);
# the owner's music and audiobooks (if asked). Keeps: sound, volume limits,
# software. The address goes back to musicbox-XXXX.local. Unplug protection comes
# back on by itself after the next owner's setup.
set -u
say() { echo; echo "== $*"; }
die() { echo; echo "STOPPED: $*"; exit 1; }
TEST="${MB_RESET_TEST:-}"       # tests only: don't touch services, Wi-Fi or power
R="${MB_SYSROOT:-}"
run() { if [ -n "$TEST" ]; then echo "(test) $*"; else "$@"; fi; }

ME="${MB_USER:-}"
[ -n "$ME" ] || die "set MB_USER to the box's user."
[ "$(id -u)" = 0 ] || [ -n "$TEST" ] || die "this runs as root through the app's helper."
H="${MB_HOME:-$(getent passwd "$ME" | cut -d: -f6)}"
DIR="$H/musicbox"
[ -d "$DIR" ] || die "can't find the box's software in $DIR."
if [ -z "$TEST" ] && awk '$2=="/" && $3=="overlay"{f=1} END{exit !f}' /proc/mounts; then
  die "unplug protection is still on, so nothing was erased."
fi

TILES=keep; MUSIC=keep; AFTER=shut-down
IFS=, read -r -a OPTS <<< "${MB_RESET:-}"
for o in "${OPTS[@]}"; do
  case "$o" in
    keep-tiles) TILES=keep ;; erase-tiles) TILES=erase ;;
    keep-music) MUSIC=keep ;; erase-music) MUSIC=erase ;;
    shut-down|restart) AFTER="$o" ;;
    "") ;;
    *) die "unknown option $o, so nothing was erased." ;;
  esac
done
as_user() { if [ -n "$TEST" ]; then "$@"; else runuser -u "$ME" -- "$@"; fi; }
PY="$DIR/venv/bin/python"; [ -x "$PY" ] || PY=/usr/bin/python3

sleep "${MB_RESET_DELAY:-3}"     # let the app finish answering the phone first

say "1/5 Stopping the music"
for s in musicbox-web musicbox musicbox-buttons go-librespot soloist-bridge musicbox-mpd musicbox-persist; do
  run systemctl stop "$s" > /dev/null 2>&1 || true
done

say "2/5 Erasing the name, PIN and setup"
ID=$(cd "$DIR" && as_user "$PY" -I -c 'import sys; sys.path.insert(0, "."); import musicbox_naming as n; print(n.box_id())' 2>/dev/null) || ID=""
[ -n "$ID" ] || die "couldn't read the box ID. Nothing was erased."
LOWER=$(echo "$ID" | tr 'A-Z' 'a-z')
( cd "$DIR" && as_user "$PY" -I - <<'PY'
import sys
sys.path.insert(0, ".")
from musicbox_common import read_json, SETTINGS_FILE, write_json
s = read_json(SETTINGS_FILE, {})
for k in ("speaker_name", "host_checked", "pin_hash", "pin_salt", "setup_done", "secret", "share_stats"):
    s.pop(k, None)
write_json(SETTINGS_FILE, s)
import musicbox_naming as n
n.set_spotify_name(n.DEFAULT_NAME)
print("Name, PIN and setup cleared. Every phone is signed out.")
PY
) || die "couldn't clear the settings. The box may be partly erased: try again."

say "3/5 Signing out of Spotify and Apple Music"
rm -f "$H/.config/go-librespot/state.json" "$DIR/.spotify_token_cache" "$DIR/soloist.key" \
      "$DIR/apple_music.json" "$DIR/stats.json" "$DIR/stats_queue.json" "$DIR/stats_current.json" \
      "$DIR/about_cache.json" "$DIR/state.json"
if [ -d "$H/.local/share/soloist" ]; then
  rm -rf "$H/.local/share/soloist"; install -d -o "$ME" -g "$(id -gn "$ME")" "$H/.local/share/soloist" 2>/dev/null \
    || mkdir -p "$H/.local/share/soloist"
fi
rm -rf "$H/.cache/soloist"
echo "Signed out."

say "4/5 Tiles and music"
if [ "$TILES" = erase ]; then
  echo '{}' > "$DIR/tokens.json"; chown "$ME": "$DIR/tokens.json" 2>/dev/null || true
  rm -rf "$DIR/tile_art"
  echo "Tile links and pictures erased. The tiles themselves are blank and can be set up again."
else
  echo "Tiles kept: they still play the same albums."
fi
if [ "$MUSIC" = erase ]; then
  M="$H/Music"
  if [ -d "$M" ]; then
    # Never reach into a plugged-in USB stick or anything else mounted under Music.
    find "$M" -xdev -mindepth 1 -depth ! -path "$M/USB" -delete 2>/dev/null || true
    install -d -o "$ME" -g "$(id -gn "$ME")" "$M/USB" 2>/dev/null || mkdir -p "$M/USB"
  fi
  rm -f "$DIR/local_places.json" "$DIR/album_overrides.json" "$DIR/mpd/database"
  echo "Music and audiobooks added to the box erased (a plugged-in USB stick is untouched)."
else
  echo "Music and audiobooks kept."
fi

say "5/5 Forgetting Wi-Fi"
# Maintenance mode was switched on for this. Drop it, so unplug protection comes
# back on by itself once the next owner has set the box up.
rm -f "$R/var/lib/musicbox-admin/hold.json" "$R/var/lib/musicbox-admin/protect.json" \
      "$R/var/lib/musicbox-admin/auto.json" "$R/var/lib/musicbox-admin/pending.json"
if [ -x "$R/usr/local/sbin/musicbox-set-hostname" ]; then
  run /usr/local/sbin/musicbox-set-hostname "musicbox-$LOWER" > /dev/null 2>&1 || true
fi
if [ -z "$TEST" ]; then
  nmcli -t -f UUID,TYPE connection show 2>/dev/null | while IFS=: read -r uuid type; do
    [ "$type" = "802-11-wireless" ] && nmcli connection delete uuid "$uuid" > /dev/null 2>&1
  done
  rm -f /etc/netplan/*.yaml
  sync
fi
echo "Saved Wi-Fi removed. Address is now musicbox-$LOWER.local"

if [ "$AFTER" = restart ]; then
  run systemd-run --on-active=4 --quiet /usr/sbin/shutdown -r now
  echo "DONE: Erased. The box restarts into setup: join 'Music Box Setup $ID' (password musicbox)."
else
  run systemd-run --on-active=4 --quiet /usr/sbin/shutdown -h now
  echo "DONE: Erased. The box is shutting down. Next owner: plug in, wait 2 minutes, join 'Music Box Setup $ID' (password musicbox)."
fi
exit 0
