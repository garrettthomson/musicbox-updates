"""
tile_factory.py
Turns blank NFC tiles into genuine Music Boxx tiles. Runs on any Music Boxx
(it uses the box's own tile reader), one tile after another.

  Make tiles:   ~/musicbox/venv/bin/python ~/musicbox/tile_factory.py make /media/usb/PRIVATE_tile_signing_key.pem
  Check tiles:  ~/musicbox/venv/bin/python ~/musicbox/tile_factory.py check

"make" stops the tile program while it runs (so only one program talks to
the reader) and starts it again when you press Control + C.

Each tile: set it on the box, wait for "Done", lift it, set down the next.
The tool signs the chip's serial number with the PRIVATE tile key, writes
the signature to pages 112-127 and locks those pages for good. Owners can
still give the tile any music they like; that part is never locked.

Keep the private key off the box: bring it on a USB stick, take it away
after. Anyone with that file can make genuine tiles.

Blanks must be NTAG215 (the chip in every Music Boxx tile so far).
Options:  --no-lock   sign but don't lock (for a first test tile)
"""

import csv
import os
import subprocess
import sys
import time

import musicbox_genuine as genuine
from musicbox import open_reader

LOG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tile_factory_log.csv")
NTAG215_STORAGE = 0x11


def say(text):
    print(time.strftime("%H:%M:%S"), text, flush=True)


def chip_kind(reader):
    """'NTAG215', another name, or '' if the chip didn't say."""
    for cmd in (0x42, 0x40):          # InCommunicateThru, then InDataExchange
        try:
            reader.read_token_id()        # (re)select the tile first
            params = [0x60] if cmd == 0x42 else [0x01, 0x60]
            reply = reader.command(cmd, params, response_length=16)
        except (RuntimeError, OSError):
            continue
        if reply and reply[0] == 0x00 and len(reply) >= 9:
            version = reply[1:9]
            if version[1] == 0x04 and version[2] == 0x04:     # NXP NTAG
                return {0x0F: "NTAG213", 0x11: "NTAG215", 0x13: "NTAG216"}.get(version[6], "NTAG?")
            return "not an NTAG"
    # Fallback: NTAG215 has pages 0-134, so page 130 reads and page 135 doesn't.
    try:
        reader.read_pages(130)
    except (RuntimeError, OSError):
        return "smaller than NTAG215"
    try:
        reader.read_pages(135)
        return "bigger than NTAG215"
    except (RuntimeError, OSError):
        reader.read_token_id()      # the failed read drops the tile; select it again
        return "NTAG215"


def signature_locked(reader):
    return bool(reader.read_pages(genuine.LOCK_PAGE)[0] & genuine.LOCK_BITS[0])


def same_tile(reader, uid):
    if reader.read_token_id() != uid:
        raise RuntimeError("The tile moved. Set it down again.")


def make_one(reader, uid, key, lock=True):
    """Sign one tile. Returns a short result for the log."""
    try:
        if genuine.verify(uid, reader.read_signature()):
            return "already genuine"
    except (RuntimeError, OSError):
        pass                          # a smaller chip; chip_kind says so below
    kind = chip_kind(reader)
    if kind != "NTAG215":
        raise RuntimeError(f"This chip is {kind or 'unknown'}, not NTAG215. Use a different blank.")
    same_tile(reader, uid)
    if signature_locked(reader):
        raise RuntimeError("The signature pages on this chip are already locked. It can't be used.")
    sig = genuine.sign_bytes(uid, key)
    if reader.read_pages(3)[:4] == b"\x00\x00\x00\x00":
        reader.write_page(3, b"\xE1\x10\x3E\x00")      # mark it as an NFC data tag
    for n in range(genuine.SIG_PAGES):
        reader.write_page(genuine.SIG_FIRST_PAGE + n, sig[4 * n: 4 * n + 4])
    if reader.read_signature() != sig or not genuine.verify(uid, reader.read_signature()):
        raise RuntimeError("The signature didn't read back right. Try this tile again.")
    if lock:
        reader.write_page(genuine.LOCK_PAGE, genuine.LOCK_BITS)
        same_tile(reader, uid)
        if not signature_locked(reader):
            raise RuntimeError("Signed, but the lock didn't take. Try this tile again.")
    return "signed and locked" if lock else "signed (not locked)"


def log_row(uid, result):
    new = not os.path.exists(LOG_FILE)
    with open(LOG_FILE, "a", newline="") as f:
        w = csv.writer(f)
        if new:
            w.writerow(["time", "tile serial", "result"])
        w.writerow([time.strftime("%Y-%m-%d %H:%M:%S"), uid, result])


def wait_for_tile(reader, last):
    while True:
        try:
            uid = reader.read_token_id()
            if uid and uid != last and reader.read_token_id() == uid:
                return uid
            if not uid:
                last = None
        except (RuntimeError, OSError):
            pass
        time.sleep(0.15)


def wait_for_lift(reader):
    gone = 0
    while gone < 4:
        try:
            gone = 0 if reader.read_token_id() else gone + 1
        except (RuntimeError, OSError):
            gone += 1
        time.sleep(0.15)


def tile_service(action):
    subprocess.run(["sudo", "-n", "systemctl", action, "musicbox"], capture_output=True)


def make(key, lock=True):
    if not os.path.isfile(key):
        sys.exit(f"Can't find the private tile key at {key}")
    genuine.sign_bytes("04:00:00:00:00:00:00", key)     # fails now if the key is wrong
    tile_service("stop")
    made = 0
    try:
        reader = open_reader()
        say("Ready. Set a blank tile on the box." + ("" if lock else " (Test mode: not locking.)"))
        while True:
            uid = wait_for_tile(reader, None)
            try:
                result = make_one(reader, uid, key, lock)
                made += result.startswith("signed")
                say(f"Done: {uid} {result}. Lift it.  ({made} made)")
            except (RuntimeError, OSError) as err:
                result = f"failed: {err}"
                say(f"Problem with {uid}: {err}")
            log_row(uid, result)
            wait_for_lift(reader)
            say("Next tile.")
    except KeyboardInterrupt:
        print()
    finally:
        tile_service("start")
        say(f"Made {made} tile(s). Log: {LOG_FILE}")


def check():
    tile_service("stop")
    try:
        reader = open_reader()
        say("Set a tile on the box to check it. Control + C to stop.")
        while True:
            uid = wait_for_tile(reader, None)
            try:
                ok = genuine.verify(uid, reader.read_signature())
                locked = signature_locked(reader)
            except (RuntimeError, OSError):
                ok, locked = False, False
            say(f"{uid}: " + ("GENUINE Music Boxx tile" + ("" if locked else " (signature not locked)")
                              if ok else "not a Music Boxx tile"))
            wait_for_lift(reader)
    except KeyboardInterrupt:
        print()
    finally:
        tile_service("start")


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if args[:1] == ["make"] and len(args) == 2:
        make(args[1], lock="--no-lock" not in sys.argv)
    elif args[:1] == ["check"]:
        check()
    else:
        print(__doc__)
