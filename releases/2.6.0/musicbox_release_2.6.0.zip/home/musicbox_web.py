"""
musicbox_web.py
The Music Box phone app. Open http://<speaker name>.local (for example
http://avas-room.local) on any phone or computer on the same Wi-Fi.
http://musicbox-XXXX.local (XXXX = the box ID on the bottom sticker) always
works too, whatever the box is called.

  Now       what's playing, play/pause, back, next, and plain-English fixes
            when something needs attention                       (no PIN)
  Tiles     add tiles, change their music, rename, remove        (PIN)
  Settings  Wi-Fi, Spotify, volume limits, resume time, PIN,
            restart and shut down (unplug protection runs by itself;
            troubleshooting switch on the hidden /advanced page),
            Erase this box (factory reset: PIN again, type RESET,
            final yes)                                            (PIN)

First time: the app walks you through a short setup (PIN, naming the speaker,
Wi-Fi if needed, pairing the speaker with Spotify, and your first tile).

Setup mode: if the box can't find a Wi-Fi network it knows for about 90
seconds, it makes its own network called "Music Box Setup XXXX" (password:
musicbox). Join it from your phone and the setup page pops up (or open
http://10.42.0.1). Setup mode never runs forever: if nobody joins it for 20
minutes it switches off and the box just keeps trying its saved Wi-Fi.
Unplug and replug the box to get setup mode back.

Needs musicbox_common.py in the same folder. Runs as the musicbox-web service.
"""

import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import shutil
import socket
import subprocess
import tempfile
import threading
import urllib.parse
import time
from datetime import timedelta
from urllib.parse import parse_qs, urlparse

from flask import (Flask, Response, abort, jsonify, redirect, render_template,
                   request, send_file, session, url_for)
from jinja2 import DictLoader

from musicbox_common import (
    CLIENT_ID, SPEAKER_STATE, STATE_FILE, WRITE_REQUEST, NotSignedIn, SpeakerOffline,
    connect_spotify, describe, kind_of, link_token, tile_badge, spotify_link, play_chime, load_settings, load_tokens,
    make_auth, read_json, save_settings, save_tokens, signed_in, speaker_call,
    speaker_status, spotify_uri_from_link, write_json,
)
import musicbox_apple as apple
import musicbox_update as updates
import musicbox_local as local
import musicbox_genuine as genuine
from musicbox_about import about as album_about
from musicbox_naming import (
    NAME_MAX, address, apply_name, box_id, check_after_joining, check_name, clean_name,
    current_host, fallback_host, is_named, publisher, setup_ssid, slugify, speaker_name,
)

APP_VERSION = "2.6.0"        # open phones reload themselves when this changes
SPEAKER_SERVICE = "go-librespot"


def systemctl(action, service):
    subprocess.run(["sudo", "-n", "/usr/bin/systemctl", action, service])


# Spotify Soloist (Spotify's official player). The installer leaves this marker.
SOLOIST_MARK = os.path.expanduser("~/musicbox/soloist.enabled")
SOLOIST_KEY = os.path.expanduser("~/musicbox/soloist.key")
SOLOIST_DATA = os.path.expanduser("~/.local/share/soloist")


def soloist_mode():
    return os.path.exists(SOLOIST_MARK)


SOLOIST_BIN = os.path.expanduser("~/soloist/soloist")
SOLOIST_MACHINES = ("aarch64", "armv7l")      # Spotify's player has ARM builds for boxes


def soloist_installed():
    """Spotify's player has been downloaded and the box is set up to use it."""
    return soloist_mode() and os.path.exists(SOLOIST_BIN)


# --------------------------------------------------------------------------
# Jobs the app starts as root through /usr/local/sbin/musicbox-admin (installing
# Spotify's player, software updates). They run in the background, so the
# owner never needs a terminal, and survive the app restarting.
# --------------------------------------------------------------------------
ADMIN = "/usr/local/sbin/musicbox-admin"
JOB_DIR = "/run/musicbox-admin"
JOBS = ("soloist", "update", "player", "reset")


AUTO_STATE = "/var/lib/musicbox-admin/auto.json"
HOLD_STATE = "/var/lib/musicbox-admin/hold.json"        # maintenance mode on purpose (troubleshooting)
PROTECT_STATE = "/var/lib/musicbox-admin/protect.json"  # the helper couldn't switch protection on
RESUME_UNIT = "/etc/systemd/system/musicbox-admin-resume.service"


def held():
    """Maintenance mode was turned on on purpose (hidden Advanced page or SSH):
    the box stays writable and doesn't switch unplug protection on by itself."""
    return bool(read_json(HOLD_STATE, None))


def protect_failed():
    return bool((read_json(PROTECT_STATE, {}) or {}).get("failed")) and not unplug_proof_on()


def helper_knows(command):
    try:
        with open(ADMIN, errors="replace") as f:
            return command in f.read()
    except OSError:
        return False


def admin_ready():
    return os.path.exists(ADMIN) and os.path.exists("/etc/sudoers.d/musicbox-admin")


def auto_ready():
    """The helper can switch maintenance mode on and off by itself around a job (2.5.1+)."""
    try:
        with open(ADMIN, errors="replace") as f:
            knows = "auto-update-apply" in f.read()
    except OSError:
        return False
    return knows and admin_ready() and os.path.exists(RESUME_UNIT)


def start_install(command, *args):
    """Start an install job. With unplug protection on, the helper switches
    maintenance mode on by itself first and protection back on afterwards."""
    if auto_ready():
        return start_job("auto-" + command, *args)   # the helper only switches modes when needed
    if unplug_proof_on():
        return False, ("This box's helper is out of date, so it can't install from the app. "
                       "Ask whoever set up the box to update it by hand once.")
    return start_job(command, *args)


def start_job(command, *args):
    try:
        r = subprocess.run(["sudo", "-n", ADMIN, command, *args], capture_output=True, text=True,
                           timeout=30)
    except (OSError, subprocess.TimeoutExpired) as err:
        return False, str(err)
    return r.returncode == 0, (r.stderr or r.stdout).strip()[:300]


def job_state(job):
    """What a background job is doing, in plain words, for the progress screens."""
    state = read_json(f"{JOB_DIR}/{job}.json", {}) or {}
    try:
        with open(f"{JOB_DIR}/{job}.log", errors="replace") as f:
            lines = f.read()[-60000:].splitlines()
    except OSError:
        lines = []
    steps = [l[3:].strip() for l in lines if l.startswith("== ")]
    errors = [l[len("STOPPED:"):].strip() for l in lines if l.startswith("STOPPED:")]
    done = [l[len("DONE:"):].strip() for l in lines if l.startswith("DONE:")]
    running = bool(state.get("running"))
    if running and time.time() - state.get("started", 0) > 15:
        # Make sure the job is really still going (a restart clears /run anyway).
        r = subprocess.run(["systemctl", "is-active", f"musicbox-job-{job}"], capture_output=True, text=True)
        running = r.stdout.strip() in ("active", "activating")
    num = total = 0
    m = re.match(r"(\d+)/(\d+)\s+(.*)", steps[-1]) if steps else None
    if m:
        num, total = int(m.group(1)), int(m.group(2))
    rc = state.get("rc")
    return {"exists": bool(state), "running": running, "command": state.get("command", ""),
            "ok": bool(state) and not running and rc == 0,
            "failed": bool(state) and not running and rc != 0,
            "step": re.sub(r"^\d+/\d+\s+", "", steps[-1]) if steps else "Starting...",
            "num": num, "total": total, "error": errors[-1] if errors else "",
            "done": done[-1] if done else "", "started": state.get("started", 0),
            "ended": state.get("ended", 0), "log": "\n".join(lines[-40:])}


AUTO_STEPS = {
    "pausing": "Getting the box ready to update...",
    "working": "Getting ready...",
    "restoring": "Finishing up...",
}
AUTO_NOTES = {
    "pausing": ("The box is restarting to get ready (2 to 5 minutes). "
                "This page follows along by itself. Please don't unplug the box."),
    "working": ("The box restarts once more when this is done. "
                "Please don't unplug the box."),
    "restoring": ("The box restarts once more to finish (up to 5 minutes). This page follows "
                  "along by itself. Please don't unplug the box."),
}


def auto_phase(job, run_state):
    """Where an install the helper started with maintenance mode switching is up to:
    pausing, working, restoring (still going), done or attention (finished), or None."""
    a = read_json(AUTO_STATE, {}) or {}
    if a.get("job") != job:
        return None, a
    stage = a.get("stage")
    if stage in ("pausing", "working"):
        if stage == "working" and not run_state["running"]:
            r = subprocess.run(["systemctl", "is-active", "musicbox-admin-resume"],
                               capture_output=True, text=True)
            if r.stdout.strip() not in ("active", "activating"):
                a["message"] = ("The box restarted before the install finished. Nothing is "
                                "lost: try again.") if job != "reset" else (
                               "The box restarted before the reset finished. Try again.")
                return "attention", a
        if time.time() - a.get("updated", 0) > 3 * 3600:
            return None, a                     # long stale: don't block the page
        return stage, a
    if stage not in ("restoring", "attention"):
        return None, a
    if run_state["exists"] and run_state["started"] > a.get("ended", 0) + 5:
        return None, a                         # a newer job ran by hand since
    if time.time() - a.get("ended", 0) > 12 * 3600:
        return None, a
    if stage == "restoring":
        if a.get("boot") and a["boot"] == boot_id():
            return "restoring", a              # the restart that turns protection on is coming
        # (2.5.1's helper added this sentence; owners don't need to hear about it)
        a["message"] = a.get("message", "").replace(" Unplug protection is back on.", "")
        return "done", a
    return "attention", a


def boot_id():
    sim = os.environ.get("MB_SYSROOT")         # simulation tests only
    try:
        with open(os.path.join(sim, "boot_id") if sim else "/proc/sys/kernel/random/boot_id") as f:
            return f.read().strip()
    except OSError:
        return ""


def job_view(job):
    """job_state, plus the maintenance mode steps around it when the box switches
    maintenance mode on and off by itself."""
    s = job_state(job)
    phase, a = auto_phase(job, s)
    s["auto"] = phase
    s["note"] = ""
    if not phase:
        return s
    s["command"] = a.get("command") or s["command"]
    if phase in AUTO_STEPS:
        s.update(exists=True, ok=False, failed=False, note=AUTO_NOTES[phase])
        if phase != "working" or not s["exists"]:
            step = AUTO_STEPS[phase]
            if phase == "pausing" and job == "soloist":
                step = "Getting the box ready to install Spotify's player..."
            elif phase == "pausing" and job == "player":
                step = "Getting the box ready to set up the music player..."
            elif phase == "pausing" and job == "reset":
                step = "Getting the box ready to erase..."
            if job == "reset":
                s["note"] = RESET_NOTES.get(phase, s["note"])
            s.update(step=step, num=0 if phase == "pausing" else s["num"],
                     total=0 if phase == "pausing" else s["total"])
        if phase == "restoring":
            s.update(num=1, total=1, log=a.get("log") or s["log"])
        s["running"] = True
        return s
    ok = phase == "done" and bool(a.get("ok"))
    message = a.get("message", "")
    s.update(exists=True, running=False, ok=ok, failed=not ok, auto_message=message,
             error="" if ok else message, done=message if ok else s["done"],
             log=s["log"] if s["log"] and phase == "attention" else (a.get("log") or s["log"]))
    return s


RESET_NOTES = {
    "pausing": ("The box is restarting to get ready (2 to 5 minutes). Nothing is erased yet. "
                "Please don't unplug the box."),
    "working": "Erasing. Please don't unplug the box.",
}


def apple_supported():
    """Apple Music runs through Music Assistant, which is too big for the small
    boards (Pi Zero 2 W, Pi 3). Offer it on a 64-bit Pi 4 or Pi 5 (any memory
    size), or any other 64-bit board with 2 GB or more."""
    if os.uname().machine != "aarch64":
        return False
    try:
        with open("/proc/device-tree/model") as f:
            model = f.read().strip("\x00\n ")
    except OSError:
        model = ""
    if model.startswith(("Raspberry Pi 4", "Raspberry Pi 5", "Raspberry Pi Compute Module 4",
                         "Raspberry Pi Compute Module 5", "Raspberry Pi 500", "Raspberry Pi 400")):
        return True
    if model.startswith("Raspberry Pi"):
        return False
    try:
        with open("/proc/meminfo") as f:
            kb = next(int(l.split()[1]) for l in f if l.startswith("MemTotal:"))
    except (OSError, StopIteration, ValueError):
        return False
    return kb // 1024 >= 1800


PORT = 80
HOTSPOT_NAME = "MusicBoxSetup"          # NetworkManager profile name
HOTSPOT_SSID_PREFIX = "Music Box Setup"  # phones see "Music Box Setup 3F2A"
HOTSPOT_PASSWORD = "musicbox"           # at least 8 characters
HOTSPOT_ADDRESS = "10.42.0.1"           # the box's address in setup mode
OFFLINE_BEFORE_SETUP = 90               # seconds without Wi-Fi before setup mode
SETUP_RETRY = 3 * 60                    # in setup mode, retry known Wi-Fi this often
SETUP_IDLE_LIMIT = 20 * 60              # nobody joined setup mode this long -> switch it off

app = Flask(__name__)
sp = connect_spotify()   # only used if the optional developer sign-in exists (search)


# --------------------------------------------------------------------------
# PIN
# --------------------------------------------------------------------------
def _settings_with_secret():
    settings = load_settings()
    if "secret" not in settings:
        settings["secret"] = secrets.token_hex(32)
        save_settings(settings)
    return settings


app.secret_key = _settings_with_secret()["secret"]
app.config.update(
    SESSION_COOKIE_SAMESITE="Strict",
    PERMANENT_SESSION_LIFETIME=timedelta(days=30),
)

failed_pins = {"count": 0, "until": 0.0}


def hash_pin(pin, salt):
    return hashlib.pbkdf2_hmac("sha256", pin.encode(), bytes.fromhex(salt), 100_000).hex()


def pin_is_set():
    return "pin_hash" in load_settings()


def check_pin(pin):
    settings = load_settings()
    if "pin_hash" not in settings:
        return False
    return hmac.compare_digest(hash_pin(pin, settings["pin_salt"]), settings["pin_hash"])


def set_pin(pin):
    settings = load_settings()
    settings["pin_salt"] = secrets.token_hex(16)
    settings["pin_hash"] = hash_pin(pin, settings["pin_salt"])
    save_settings(settings)


def needs_pin(view):
    """Decorator: send people to the PIN page first."""
    def wrapper(*args, **kwargs):
        if not pin_is_set():
            return redirect(url_for("pin_page", next=request.path))
        if not session.get("ok"):
            return redirect(url_for("pin_page", next=request.path))
        return view(*args, **kwargs)
    wrapper.__name__ = view.__name__
    return wrapper


@app.route("/pin", methods=["GET", "POST"])
def pin_page():
    next_page = request.values.get("next") or "/"
    if not next_page.startswith("/"):
        next_page = "/"
    first_time = not pin_is_set()
    error = ""
    if request.method == "POST":
        pin = request.form.get("pin", "").strip()
        if first_time:
            if not (pin.isdigit() and 4 <= len(pin) <= 8):
                error = "Use 4 to 8 numbers."
            elif pin != request.form.get("pin2", "").strip():
                error = "Those two didn't match."
            else:
                set_pin(pin)
                session.permanent = True
                session["ok"] = True
                return redirect(next_page)
        elif time.time() < failed_pins["until"]:
            error = "Too many tries. Wait a minute and try again."
        elif check_pin(pin):
            failed_pins["count"] = 0
            session.permanent = True
            session["ok"] = True
            return redirect(next_page)
        else:
            failed_pins["count"] += 1
            if failed_pins["count"] >= 5:
                failed_pins.update(count=0, until=time.time() + 60)
            error = "Wrong PIN."
    return render_template("pin.html", first_time=first_time, error=error, next=next_page)


@app.route("/lock", methods=["POST"])
def lock():
    session.clear()
    return redirect("/")


# --------------------------------------------------------------------------
# First-time setup
# --------------------------------------------------------------------------
def setup_done():
    settings = load_settings()
    if settings.get("setup_done"):
        return True
    # Boxes that were set up before the guide existed count as done.
    return "pin_hash" in settings and bool(load_tokens())


def mark_setup_done():
    settings = load_settings()
    settings["setup_done"] = True
    save_settings(settings)


SETUP_STEPS = ["name", "wifi", "spotify", "tile"]


def setup_step():
    """Which step of the first-time guide we're on."""
    if not is_named():
        return "name"
    if setup.hotspot_on:
        return "wifi"
    if not soloist_installed():
        return "spotify"                 # Spotify's player isn't on the box yet
    online, _ = speaker_account()
    if online and pairing_code():
        return "spotify"
    if not online:
        return "speaker"
    return "tile"


@app.route("/setup")
@needs_pin
def setup_page():
    if request.args.get("finish"):
        mark_setup_done()
        return redirect("/")
    if setup_done() and setup.hotspot_on:
        return redirect(url_for("wifi_page"))       # a set-up box that moved house
    step = setup_step()
    if step == "wifi":
        return redirect(url_for("wifi_page"))
    state = reader_state()
    tile = state.get("token")
    if step == "tile" and tile and state.get("known"):
        mark_setup_done()
        return redirect(url_for("tiles_page", saved=tile))
    if step == "name":
        return redirect(url_for("name_page", setup=1))
    return render_template("setup.html", tab="", step=step, pairing=pairing_code(),
                           keyerror=request.args.get("keyerror"),
                           need_install=not soloist_installed(), install=soloist_install_info(),
                           tile=tile, wifi=current_wifi(),
                           step_num=SETUP_STEPS.index("spotify" if step == "speaker" else step) + 1,
                           step_count=len(SETUP_STEPS))


@app.route("/setup/again", methods=["POST"])
@needs_pin
def setup_again():
    settings = load_settings()
    settings["setup_done"] = False
    save_settings(settings)
    return redirect(url_for("name_page", setup=1))


# --------------------------------------------------------------------------
# Speaker name
# --------------------------------------------------------------------------
NAME_IDEAS = ["Living Room", "Kitchen", "Playroom", "Bedroom", "Nursery", "Office"]


@app.route("/name", methods=["GET", "POST"])
@needs_pin
def name_page():
    in_setup = bool(request.values.get("setup")) and not setup_done()
    error, typed = "", ""
    if request.method == "POST":
        typed = request.form.get("name", "")
        name = clean_name(typed)
        online = not setup.hotspot_on and wifi_connected()
        if not name:
            error = "Type a name first."
        elif online and name != speaker_name():
            ok, error = check_name(name)
        if name and not error:
            old_host = current_host()
            if name == speaker_name() and is_named():
                new_host = old_host
            else:
                # Rename after this page has loaded: the old address stops working.
                from musicbox_naming import pick_host
                new_host = pick_host(name, online=online)

                def worker():
                    time.sleep(2)
                    _, err = apply_name(name, online=online,
                                        restart_speaker=lambda: systemctl("restart", SPEAKER_SERVICE))
                    if err:
                        print(f"Rename problem: {err}", flush=True)
                settings = load_settings()
                settings["speaker_name"] = name   # so the next page already shows it
                save_settings(settings)
                threading.Thread(target=worker, daemon=True).start()
            if in_setup:
                if setup.hotspot_on or new_host == old_host:
                    return redirect(url_for("setup_page"))
            if new_host == old_host:
                return redirect(url_for("settings_page", message="Name saved."))
            return render_template("renamed.html", tab="", name=name, host=new_host,
                                   fallback=fallback_host(), in_setup=in_setup)
    return render_template("name.html", tab="" if in_setup else "settings", in_setup=in_setup,
                           name=typed or (speaker_name() if is_named() else ""),
                           ideas=NAME_IDEAS, error=error, max_len=NAME_MAX,
                           host=current_host(), fallback=fallback_host(), box=box_id(),
                           setup_mode=setup.hotspot_on, step_count=len(SETUP_STEPS))


@app.route("/api/name-preview")
def api_name_preview():
    return jsonify(host=slugify(clean_name(request.args.get("name", "")) or "x"))


# --------------------------------------------------------------------------
# Now playing (no PIN)
# --------------------------------------------------------------------------
def reader_state():
    state = read_json(STATE_FILE, {})
    if time.time() - state.get("updated", 0) > 6 * 3600 and not state.get("token"):
        return {"reader_ok": state.get("reader_ok", True)}
    return state


def refused_on_reader(state=None):
    """The tile on the box isn't a genuine Music Boxx tile (and this box didn't know it)."""
    state = state or reader_state()
    return bool(state.get("token")) and state.get("allowed", True) is False


def tile_refused(token_id):
    """True if this tile may not be given music here (not a genuine tile)."""
    return not genuine.may_take_music(token_id) and not (
        reader_state().get("token") == token_id and reader_state().get("allowed", True))


NOT_GENUINE = ("That isn't a Music Boxx tile, so it can't be given music. "
               "Tiles from Music Boxx work, and so do tiles this box already played.")


def protection_installed():
    return os.path.exists("/etc/sudoers.d/musicbox") and os.path.exists("/usr/sbin/overlayroot-chroot")


@app.route("/")
def now_page():
    if not setup_done():
        return redirect(url_for("setup_page"))
    return render_template("now.html", tab="now", version=APP_VERSION)


now_cache = {"when": 0.0, "data": None}
now_lock = threading.Lock()


@app.route("/api/now")
def api_now():
    # Several open phones share one answer.
    with now_lock:
        if now_cache["data"] and time.time() - now_cache["when"] < 3:
            data = now_cache["data"]
        else:
            data = build_now()
            now_cache.update(when=time.time(), data=data)
    # The reader part changes fast and costs nothing, so it's always fresh.
    state = reader_state()
    tile = state.get("token")
    refused = refused_on_reader(state)
    return jsonify(dict(data, tile=None if refused else tile,
                        new_tile=bool(tile and not state.get("known") and not refused),
                        fake_tile=refused,
                        teaching=bool(state.get("teaching")),
                        reader_ok=state.get("reader_ok", True) is not False))


@app.route("/api/about")
def api_about():
    """About the album that's playing right now (no PIN, like /api/now)."""
    with now_lock:
        data = now_cache["data"] if now_cache["data"] and time.time() - now_cache["when"] < 10 else None
    if data is None:
        data = build_now()
    # Spotify, Apple Music and your own albums all get the card (only the
    # artist and album names are looked up). Audiobooks don't: MusicBrainz and
    # Wikipedia would mostly find the wrong thing.
    if not data.get("on_box") or setup.hotspot_on or data.get("kind") == "Audiobook":
        return jsonify(status="none")
    return jsonify(album_about(data.get("album_artist") or data.get("artist", ""),
                               data.get("album", ""), data.get("track", "")))


# --------------------------------------------------------------------------
# Notices: problems the box noticed by itself, said in plain words (Now screen,
# top of Settings, and a dot on the Settings tab). Each clears itself once fixed.
# --------------------------------------------------------------------------
SKIPS_FILE = "/dev/shm/musicbox-skips.json"        # written by soloist_bridge.py
SKIPS_SEEN = "/dev/shm/musicbox-skips-seen.json"   # when the owner tapped OK
PERSIST_STATUS = "/run/musicbox-persist/status.json"   # written by musicbox_persist.py
SKIP_SHOW_HOURS = 24
LOCK_GRACE = 120          # seconds the card may stay unlocked before it's worth a word


def uptime_seconds():
    try:
        with open("/proc/uptime") as f:
            return float(f.read().split()[0])
    except (OSError, ValueError, IndexError):
        return 1e9


def new_skips():
    """Songs Spotify passed over by itself that the owner hasn't seen yet."""
    skips = (read_json(SKIPS_FILE, {}) or {}).get("skips") or []
    seen = float((read_json(SKIPS_SEEN, {}) or {}).get("at", 0) or 0)
    cutoff = max(seen, time.time() - SKIP_SHOW_HOURS * 3600)
    return [s for s in skips if isinstance(s, dict) and float(s.get("at", 0) or 0) > cutoff]


def card_lock_failing():
    st = read_json(PERSIST_STATUS, {}) or {}
    since = st.get("failing_since")
    return bool(st.get("locked") is False and since and time.time() - float(since) > LOCK_GRACE
                and unplug_proof_on())


def song_list(skips, most=3):
    names = []
    for s in skips[-most:]:
        name = s.get("name") or "a song"
        names.append(f"“{name}”" + (f" by {s['artist']}" if s.get("artist") else ""))
    more = len(skips) - len(names)
    text = ", ".join(names)
    return text + (f" and {more} more" if more > 0 else "")


def notices():
    """[{id, kind, icon, title, body, action: {href|post, label}}] for problems
    the Now screen doesn't already show on its own."""
    out = []
    skips = new_skips()
    if skips:
        reasons = {s.get("reason") for s in skips}
        why = ("Spotify's explicit-content filter is on for this account."
               if reasons == {"explicit"} else
               "Spotify won't play them on this account: usually they aren't available here, "
               "or an explicit-content filter blocks them.")
        n = len(skips)
        out.append({"id": "skips", "kind": "calm", "icon": "music",
                    "title": f"Spotify skipped {n} song{'s' if n != 1 else ''}",
                    "body": f"{song_list(skips)}. {why} They look greyed out in the Spotify app. "
                            "Swap in versions that play. Nothing is wrong with the box.",
                    "action": {"post": "/api/notices/skips/seen", "label": "OK"}})
    if card_lock_failing():
        out.append({"id": "card", "kind": "", "icon": "shield",
                    "title": "Use Shut down before unplugging",
                    "body": "The box couldn't lock its memory card after saving, so pulling the plug "
                            "right now could lose recent changes. Restarting the box usually fixes it.",
                    "action": {"href": "/settings#power", "label": "Restart the box"}})
    if os.path.exists(MPD_UNIT) and uptime_seconds() > 180 and not local.ping():
        out.append({"id": "player", "kind": "", "icon": "music",
                    "title": "The music player for your own music has stopped",
                    "body": "Your music and audiobooks are still on the box. Start the player again "
                            "to play them.",
                    "action": {"href": "/library", "label": "Start it"}})
    return out


def needs_attention():
    """Anything worth a dot on the Settings tab."""
    state = reader_state()
    try:
        return bool(notices()) or state.get("reader_ok", True) is False or protect_failed()
    except Exception:
        return False


@app.route("/api/notices/skips/seen", methods=["POST"])
def api_skips_seen():
    try:
        with open(SKIPS_SEEN, "w") as f:
            json.dump({"at": time.time()}, f)
    except OSError:
        pass
    now_cache["when"] = 0.0
    if request.args.get("back") == "settings":
        return redirect(url_for("settings_page"))
    return jsonify(ok=True)


def build_now():
    info = {"version": APP_VERSION, "signed_in": True, "speaker": False,
            "playing": False, "wifi": current_wifi(), "setup_mode": setup.hotspot_on,
            "maintenance": held() and not unplug_proof_on(), "protect_failed": protect_failed()}
    try:
        info["notices"] = notices()
    except Exception:
        info["notices"] = []
    upd = update_status()
    info["update"] = upd.get("latest", "") if upd["available"] else ""
    if setup.hotspot_on:
        return info
    if local.source() == "local":
        mine = local.now_playing()          # music from this box's own drive
        if mine:
            info.update(speaker=True, on_box=True, local=True, playing=mine["playing"],
                        track=mine["track"], artist=mine["artist"], album=mine["album"],
                        album_artist=mine.get("album_artist", ""),
                        image=album_art_url(local.loaded_path()),
                        kind="Audiobook" if mine["book"] else "", source="your music")
            if mine["volume"] is not None:
                info["volume"] = mine["volume"]
            return info
    if apple.source() == "apple" and apple.configured():
        mine = apple.now_playing()         # Apple Music through Music Assistant
        if mine:
            info.update(speaker=True, on_box=True, apple=True, playing=mine["playing"],
                        track=mine["track"], artist=mine["artist"], album=mine["album"],
                        image=mine["image"], kind="", source="Apple Music")
            if mine["volume"] is not None:
                info["volume"] = mine["volume"]
            return info
    try:
        status = speaker_status()          # asked inside the box, always current
    except SpeakerOffline:
        return info
    info["speaker"] = True
    if not status.get("username"):
        code = pairing_code()
        if code:
            info.update(signed_in=False, pairing=code)
            return info
    steps = status.get("volume_steps") or 100
    if status.get("volume") is not None:
        info["volume"] = round(status["volume"] * 100 / steps)
    track = status.get("track")
    if track and not status.get("stopped"):
        info.update(
            on_box=True,
            playing=not status.get("paused"),
            track=track.get("name", ""),
            artist=", ".join(track.get("artist_names") or []),
            album=track.get("album_name", ""),
            image=track.get("album_cover_url") or "",
            kind=kind_of(status.get("context_uri")),
            spotify=True, source="Spotify",   # the Now page says where it's playing from
            link=spotify_link(status.get("context_uri") or track.get("uri")),
        )
    return info


@app.after_request
def no_caching(response):
    # Always fetch fresh pages and status, never an old saved copy.
    if request.path not in ("/icon.png", "/manifest.json", "/brand-font.woff2"):
        response.headers["Cache-Control"] = "no-store"
    return response


@app.route("/api/control/<action>", methods=["POST"])
def api_control(action):
    paths = {"play": "/player/resume", "pause": "/player/pause",
             "next": "/player/next", "back": "/player/prev"}
    if action not in paths:
        abort(404)
    if apple.source() == "apple" and apple.configured() and apple.state() in ("playing", "paused"):
        {"play": apple.resume, "pause": apple.pause, "next": apple.next_track,
         "back": apple.back}[action]()
        now_cache["when"] = 0.0
        return jsonify(ok=True)
    if local.source() == "local" and local.status().get("state") in ("play", "pause"):
        if action == "play":
            local.resume()
        elif action == "pause":
            local.pause_and_save()
        elif action == "next":
            local.next_track()
        else:
            local.back()
        now_cache["when"] = 0.0
        return jsonify(ok=True)
    try:
        speaker_call(paths[action])
    except SpeakerOffline:
        return jsonify(ok=False, message="Speaker is offline")
    now_cache["when"] = 0.0   # show the change on the next refresh
    return jsonify(ok=True)


last_fix = {"when": 0.0}


@app.route("/api/fix/restart-music", methods=["POST"])
def api_fix_music():
    """One-tap fix on the Now page. No PIN: it only restarts the music, and
    only once a minute, so it can't be used to bother the box."""
    if time.time() - last_fix["when"] > 60:
        last_fix["when"] = time.time()

        def worker():
            systemctl("restart", SPEAKER_SERVICE)
            systemctl("restart", "musicbox")
        threading.Thread(target=worker, daemon=True).start()
    now_cache["when"] = 0.0
    return jsonify(ok=True)


# --------------------------------------------------------------------------
# Home-screen icon
# --------------------------------------------------------------------------
# Music Boxx mark C "Stack" in cream on walnut (brand pick 2026-11-22).
ICON_PNG = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAIAAADdvvtQAAAQAElEQVR4AeydB1RURxfHASkC0lREbKhREYyeLwVbLElMjD2WT8FoRFQsgBoBxbpAooBK0xUIYgRiRCRRUSP2+Jmix2A/ihFRJFYsVAXp30VzPAFhtr23U954hnX3zZ079/7vb1/dfas34v1uvHEF1FZAT4f/4wpooAAHSAPx+FAdHQ4Qp0AjBThAGsnHB3OAOAMaKcAB0kg+PlhtgLh0XIFaBThAtSrwP7UV4ACpLR0fWKsAB6hWBf6ntgIcILWl4wNrFeAA1arA/9RWgAOktnR8YK0C2geodlb+x4wCHCBmSoknEQ4QHt2ZmZUDxEwp8STCAcKjOzOzcoCYKSWeRDhAeHRnZlaKAGJGc6YS4QAxVU7tJ8MB0r7mTM3IAWKqnNpPhgOkfc2ZmpEDxFQ5tZ8MB0j7mjM1oxQAYqpgpCXDASKtIpTFwwGirGCkhcsBIq0ilMXDAaKsYKSFywEirSKUxcMBoqxgpIXLAUJUhHcpVoADpFgjboFQgAOEEId3KVaAA6RYI26BUEC6AFnb2HRzcOjdv9/QUaMmTpkycepU7bdho0f3HTDAvoejjW1rA0MDRJ2I7ZIWQADNqPHjvw4NTT5wICohYXV4uO8q2SxPz1p0gCGttxkeHt4rVnwTGibfGr99776QjRvGOTu3a9+eWFzeDEwSABmbGE9wcQmNjgZoprm7d+/RQ0+PxMQ7d+02efr08M2bN2zZ4uLqam5u8WbBSFtCoo4CamRkZATv6aiERGdX1w6dOgnoGelK007btm3Hu7hsSoif7Drd1NRUU3dijmcWIH0DfdhabUpIgPd0MzMzMTUUy3dTY+NxLs5R3yfCLhqsRMWaRjO/bALUwtp6nXwTbK0sLC010wf/aBMTU9hFi4jd3LZDB/zRvBEBgwB16tJlrVzezs7ujWQpXtC8ZcvgyMgevXqRlgNrAL3bu/c3YWHmFhTsfqqKAmzRVgUFDRoyRNWBotozBZBDz55L/P0NDQ1FlQyjc70mTbx8fQd+9BHGGOpNzQ5Ardu08fP3J/P4vJ7oGr6c5+1t7+iooROhhjMCULNmzVasXm2iyhHv1UsXkxMT4+Qbw1Z/E+jnF4Cjrf/669jIDUnx8efT019WVKkHfX39xTKZdatWSlmLbMQIQL4ymY2trTJa5ec9TYiNneXsErh02e7k5KNpB8/8cerq5csZOFr66dPHDx9KTUkJkcmmT5gQu2Fj7oMHymQBO3lLAwObNjVWxlhUGxYAGvPfCY49eyqUqaTk+Y74BC83t7TU1KKiQoX2WjYoKSk5fujgQnf3LVFRhQUFCmdv37HjpGlTFZqJbUA9QMYmJuNdJiuU6U5OjvecuXtSdlaUVyg0xmhQXVV15OefF82efT0jQ2EYw0aPgcN7hWaiGlAP0ITJkxXu+pw7c2bpggV5T56IKqWAzp8VF/svXnziyBG0T9gZmuLmhrYRu5dugKxatBgxdixaI6BnbUBARXk52oy03urq6piIiIN796IDG/jxx7AtQ9uI2ks3QENHjoB3IUKgnOzs8KAghAHhXbC/f+XSJXSQI8Z+jjYQtZdugHr3649Qp7KyEo6TqVv3/DujmpqaiODg0pKSfy+s9/ylCPWWae8lxQDBFVP02huOth49fKg9LcWZqbiw8Mft2xG+zczNuzv2QBiI2kUxQP0GDkRIU1RY+FNSEsKAoi7YE3p4/z4iYKf+/RC9onZRDJATcvt15MCBF6WlomqnNedVVVUH9qYipuszYACiV9QuigHq5tAdIU36qdOIXuq6zvz2OyLmVjY2uD64SCtAoFeTJk0a07QgLy/7ZlZjvTQuL8jPv3UjExG5VfPmiF7xumgFyNIKpdf1a3+JJxkuz1mZNxBTW1hZIXrF66IVIIvmKL3giql4kuHynP/0KWJqSzUBQrhUqotWgKyQehXm5SmVPVVG+U9RSVk1b4ElG1oBQl//elbyHIuaok6K/gSBqXkzUWdvzDmVAFlYWcJxR2MpwfJ3nJwmavGryuMmOQ8aMsSxVy8b29Ywu0hNV0cX4VlPB08p8cyKEKKxLqOmTft80N9jkXfcjh1xSTs+nzSpMUtY/u77ThO1+D3lyW7TvXx9A9aulW+NT9q/b1VQ8PAxYwj5xCCoIWqjAKC2HTos9pdt27PHZ+WqD4d+SvhXvfT1DXq+8x+3efOiEhPXyTd9MHiwqPXD7pxogFpaW3v5+oTFxDj1xXaqXpMKdezy1sKlS0Ojo9/r3VsTPySPJRegDz/9JCIubtCQT2j/okWHTp38AgMXLV9uaMTS943+oZpEgEBo2Nfx8PYxMjL6J0z6/4NLv0ERkbZt2tCfSp0MiAMIJAahYV+nTphMvIBVUYhc3hffhU8xVCQLoBbWLVeFBIPQYqRKgk9jExPvFSv6DRpEQjCCxEAQQLDl8pMFtLQm4vtygojbmBMPb++Ob73VWC9dywkCyMPbBw5b6JJPvWhh326Jv8zMwly94USNIgWg/oMH9Wdoxa6wxrCinTnPQ6EZ+QZEAKRvoD/FbQb5YgkbYf/Bg+0dHYT1qX1vqgMkQoxDR46ytrERwTHpLqfOmEl6iIriww+QsYnxOGdnRXGy2W/fo4dTPypPsr+uB36Axjm7WFhavg5Iak9cpk2j+lQ7foAIvO+fNiFuZ2dnYYn6dKU2g1FjLswAWVo172Jvr0bczAzR1dV9v28fetPBDJBTv76gIL3yCRK5E827QZgBatuept+FEASXN510daD4YF6LAL2pnI6OtQ37Fy4ayrvOMlNTUwNDKn+qB9LADVArET9EDOnR0mBfkJZQ68WJG6DWUjx/WK8G8NKa2vOoOAGCVTc0kI+3VtRuynECpEvkj3ZhodnAgNZPu+IECEup+KTCKiA5gMrLyy9fuLBtyxaZr+/8GTOmTRj/xejRc7+c6ufltXHdupPHjhcVEncLaWFLLqw3GgASKOPq6uqjaQeBldXLl+/fteuvq1dzHzx4UVJaWVmZ9+Rp9s2bv584ERUW6j558nfR0cVFRQJNy7gbqQB0Kytr2YIFcfKNz4qK0SWtqak5vH//QvdZxw8fgudoY94rCYBuZmauWbEC1jHK1xs4i43ckJaaqvwQaVqyD9CFs+kBi5eot0lK3Lw5ITaWr4cQ7w3GAXpw715EcHBZeRlCAnQXrISOpqWhbaTcyzJAsNYJlslgN1nDAsfHxMBqTEMnrA5nGaDkxAT07ZWVLGpVVVVMeKQmqzElJ6LRjFmAch8+PH7osFAlKcjPO3aAb8gakJNZgI6lpcGJnwYyVnfREb4n1JB0zAL052mBbzT+4O7de3fuNKShpJexCVBhfj7UW/DC/nnqlOA+aXfIJkC5j3LFKEzWXwzev1xDodgE6MVz1A9sqS1ZQX6+2mM1H6iLrFVVdZXmU6jhARmUGv7IGFJdUyNGIHgBMrewQCRVVFCA6BWvi02AzM01u3NKI3rrG+L82Bf6c9MF+RygRsqmxuJm5mZqjFI4BNfvUbwKzAL96w75ea/MtPzI5hoI/WZVW2K8AHW174aIHNfmlU2ADA0Nu4nwbb2OnTsjSihqF6x+OndFA8Q3YYJWYNjo0YL6q3WG8Qar6DveP3n0qLRUlAPP2rSRf2yugSDlPgMHmDYT8gdsnPr2tW3bFjxrvzVp0mTUuHGIef84eRLRK2oXswAZ6Bu6zpkjoHYTv/xSQG8quRo1fnzLVqjvgGM8Rc4sQDo6NYM/GWLv6KhSqRozhtWPUjtAjY3XYLmNre3EqVMRDp4VF9/Ad4qcYYB0dHV0lwYEmGl8Tgg8uHnguaOqgYGBn78/HBMgADqwZw+iV+wulgEC7ZqZmS0JCIAnajfY/1jiL2tpba22B00GzvTybGdnh/AAq5+fd+9GGIjdxThAcEWju4ODX2AgvJXVk9Jt3jx7xx7qjdVklJ6e3sx5Hh8P/QztZHdyclmZ+p/4RjtXppdxgEACYOi9Pr1DY2LQ15LAsl4zNjEJWLd26MiR9ZZr4SVMLQsO/myMgjMRcPLw8P79WogHMQX7ANUmX6Nj265tdGLiOBcXfX3Ft3LS1dXtP3jQWrncsWev2uFa/IMVz6cjhm+Ii3PspXjqH3/4oaKiQovRNTCVNACCxGt0DI2MvnB1/W5nMhzeW1g0fGNh61at4H0fFvPtV0uXtdbub3uZmJgMGTY8fPNm9/kLLJs3h5DR7eLZsyR830gyAL2sBmzOYOswcuzYLck74lNS1kdHrw4PD1y/PkQuj4yL25qSEpWYCHse7ew6vDTX3sOwMaMTdu2as3BBG+XOVf6dnR22Zo324mt8JmkB9FoHIMnUzMyuUye4ZObw9tudu3Rp064dHLK9NtDyk/Z2HZWfsaiwMEgmK3vxQvkh4llKFCDxBBXb84vS0qCVK/OePBF7IiX9c4CUFIoIsyePH69YtOhWVhYR0bwMggP0UgYaHq5nZCzx9LyTk0NUsBwgosrRaDC//fKL/+LFcN65UQtMHRwgTMIrPe2d27dDZDL5+vXV1dVKD9KeIQdIe1qrOtPTx4+jw8N9PTzOp6c3OhZ3B06AysqIOBDFXYL68xfk5cEZwjUrV3q6uf3v6FHCb2+FE6CK8ornz5/X10+Sr8vLy29mZsJ19VU+3rOnTImTyy+dO1ddhee7gipVACdAEGgBpi+jwNRENT9Pr2ULF34fF3c94xpRgSkMBjtA+QpDlIIBvW8kzADduMZvV6DzODeX3k05ZoAunjsnhRUMOkeqRcAMUOa1DHrffGgslO9NPy3wvbCUmlogI8wAVVZUZly+JFAuVLqprKi4cpFiBTADBDW/eFbSW7Erly5VVmL+VCFUQe2GH6Djhw79nZ2tdgK0D9z23RaqU8APEFzi2bltG9Uiqh38qZMn79wm6+q6qrngBwgihr3Ia1euwhNJtfKy8u3x8bSnTARAIGJsZERJibQuayQlxMMZIMid6kYKQPfv3YsICobNGdVqKh88XC5NS01V3p4gy7qhkAIQRAWXD+FiEDxhvl0+f35rdAwbaRIEEAgKb0p4a8IThhusa8PWrK6qqmQjR7IAAk3j5HJocHoNnrPX4LBriadHaUkpM6kRBxAoCyuhwKV+RUWF8JyZVlNTk7JtW2RICBx8MZMUJEIiQBDW9YxrvnPnnTh8BHSHl7S3Ozk5Ml+fn5KSaE/kzfgJBQgCLcjPj4mMAN1BfXhJaSspeR7/7beLPT3hLUFpCuiwyQXoVdygu8/cufExMdczMl4toeXx8aNHcEzw1Sz3g3v3UvHhVPWEVQEg9SYQZNTBfftW+fjMcnbZFBp26tdfb2Zm3r97tyAvn5z9ieKiotwHD29n3bx84cLOxERY5Xi6uibExsJ6VBAFiHVCB0Cv5CsqKvz1+LHI4OBlCxd+5e4+e8oXU8d+Pmn4cBLaTGfn+TPclsz3Wr18+a7k5Jxbt17FzPwjTQAxXwwaE+QA0Vg1gmLmABFUDBpD4QDRWDWCoAy2UQAAASRJREFUYuYAEVQMGkPRBkA06sJjVlIBDpCSQnGzhhXgADWsC1+qpAIcICWF4mYNK8ABalgXvlRJBThASgrFzRpWgAPUsC58qZIKEA2QkjlwM4wKcIAwis/C1BwgFqqIMQcOEEbxWZiaA8RCFTHmwAHCKD4LU3OAWKgixhzYBAijoFKbmgMktYoLnC8HSGBBpeaOAyS1igucLwdIYEGl5o4DJLWKC5wvB0hgQaXmjgNUp+L8haoKcIBUVYzb11GAA1RHDv5CVQU4QKoqxu3rKMABqiMHf6GqAhwgVRXj9nUU4ADVkYO/UFUBDpCqijVsL9mlHCDJll6YxDlAwugoWS8cIMmWXpjEOUDC6ChZLxwgyZZemMQ5QMLoKFkvHCDMpad9+v8DAAD//9uVZ4sAAAAGSURBVAMAolcj25db/ugAAAAASUVORK5CYII=")

# Fraunces (soft, bold), SIL Open Font License, Latin letters only. Served by the box so
# headings look right even in setup mode with no internet.
BRAND_FONT = base64.b64decode("d09GMgABAAAAAJJsABMAAAABEAgAAJH9AAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGm0btxIcgSg/SFZBUoQtBmA/U1RBVIIYJyYAhE4vJBEICoHZQIGyXwuDbAAwgeMCATYCJAOHUgQgBYdsB4ZlG2n5FdPNHSK3DQCgyKz3v4IzEYHzgGTyi79l0UgNNg5ACO/DFf+fkpyM4bAHzMxV+R8ogUEoOzKzHx3GqUnMujKcMWdCZsxSRnYKbiqsE5gE+fZTDivkeIAx3ppRjOzpmJDEskzNWJeusf27p9UTatMRb4ttci8dFrd9+as/OtgyjqMlfqYXkkA2BptFs/GTGu+ykWRSSBj3GhcsA2OXQYloMbZPvAd0abO7tyclucDX5BTUkarQFZICCEqlUEiVvrT9D26AbRZgNKKkiQKCiJXTGZv2Mu+jI3cdOEDb7Fy4GYmotBKlhKAIKEoJIiBpY4CF3bNja1eunCvXbr90Ff7ahb+sXyUPkX8f36nq6vsG+iQyLMy5CyLaCGAmevpqTfdUyHXywBfYewqCy1RIJFmhMq9cCVl26uz/TPf2WOFktS/qdQPyK6qsWzcxS3LnFXtcy5/AZo8oKZPDdb1XAHSKFaAwZ2SVr64w/QTjw+vm/6FPlJojFaXiiCU3CQmWYCkqbSlPzMflT38Tn0ycezTv7qEhxaWitA5p6Nv0/2exRTRASALVNKnLMdL2mviXP033mOaYp/XUJGlDY4LHwBcWCAuLrCG6Fs5hUuCk7UhNmAmDdsISQMy9/d+MIqEIhQMcwNP+0+noDzP1dHiSmwJI0jarUsDr1nVC5/MO0Hief7v+6x5JKwcRTpBMkNcdAHggf+3DP9AatNkzk2ZVFBFtYpW2c3Rap2aS/kcArkWGlm+P4L+IRlS7pEKLzIBe1Z6oWXKIJIPAeFBV8UUFVlDt7uN/yM5SlxTlvfovSnZy0JRP19fG2Nms4wVDDE4YXs8eZvNhjg/FQc7SrM1+LMxPBj/p9F3vEvvH5Q88oYuwB8o8dpmkdzqdTmCQA4aAIZ+cD/4IkozyB6ACsIs4bO004Eg8TLSM6daxY4ex8FBnvu7O68FvSgWr7hSkpgVMSulabSdAve5/elTDn/D//6qW3+KS4i444ZicsdfgVODIAbt04AwdWpGO8fSpaYaPhEgAlEeitB5BEH2odAySS/uRIG2ImNkQNeMQQxXTAyHZECHaELmypZWDZuWYfsihi0X529z933W//KVT58rlL39RtSG237efzv7yWLstmq8wFoSL02HMXLBjDGNrOZzB4lEoh7830/iArKyvUhUFI0zS2Y9zqt/tg+7V9xFrjSQryRjpnoxxvg398cA12uNqxMiPmE9XHGP+P+Z6XnhzuUG28GVFSIEyENe0HQIIdoju7j/6/2PZ632Ev2zt6569kSGMEiWISJAYz8D/b+4RkTc4KPQdgrYgIlqWc690J0BgykgukObxO4jO8hODgMx3RgqlianZeavd4XQvLa94fYFgKIxi8cRqMkVksnmSohm2UCzVGk0e1pdXVtfWN7b2kpQ41gGEfEIlAEAAUOmIgy6/MojB/gF3PWewRwAAf0az3f+e+wzz3ySPIUDBj3ufvwEVuscWVAFKa67Xg8wjt6leiMpTK9b0EHlXAlD5UbetmPLpto1p0Kk+aukqJQ4u6wqFVdePgyK8c8G//hKlL9KQVtntT4nQOGdHSWHJFPUnjvkYHL7jb1r+NbxDs1/2tPUELMvdRDbYOgRb0I+wUd7+G5fvtrrt2YTO3ihvK6VkU2ESrqcCKnJK+7daT4hz+eMB//1QIi3LC4QkCeu3Bn6snVABVPNMmvXn/0xhdr+olmoLNddLQvmwECxNwZamw9fst2GwvDMdaMbXrV0WUW6OBOJn8GAqdPgPjcWE8+HxkwY9djCJgS5fpG20WYp96DgFLrGNzARi93v1rUdAEXxt3FpbOgiYqOgFpuhnODhdJxUUcC3R+Qj/VBvpKuIgfLN/lS3fekEZtvlYXzwVPLdhE/pN2ai/hv5zaV2vU8DeBQTbKOlMAtbArnEa8JeOxhFpfv6Y/RwUztCnDx8nbdkDR5Um9/A/DdDIRNrURoPL0Ne8jrd884k0+j0c6r7d71v5xBjP7i7p91aiZhauaCuPk2tflvQ7iOBhCwG5ymA8eQWGvR4AtDkPdXfE2/qhVHTsqDZMUGfS0IWNY1VKZJa0Qir6Fjas6+kH36oYGByQTdjhl5gfmwJfaa65ri2sOkw+mNrhCsj07eCMcqwhB4C/trxFCnRhhStCkzRUBkDCxetbiMGFDIBGjJJktroK4C7W5X5yGErEJRRjXdKCliNgDWgYFACwzLaCIjHfEeuai3Ud2bWDoRSOAhPrg/8B8AOi339c0i8AChzhJQdu5yeP/6hrHi4WiAnKA2BIKA7nmi9f9cTnj9+LbFmpSijkf+Cwif7Z6DNRdOtHGAiOObP8Rsfh4hYwtirRJFotfd5C/PqiEBVKn4oweH+O6QcOnUF0GYVY+CONBWKDbQy3SOhR8ffFN1t9XawlVIZ4JZ2n64r4S9AvdMERw6OkLtgH7Zxdc1VK0lWtukgAPqp9QZVOA/1DeAAqPr5Lf1EhzDHU/THK713+jj5nKnsMbbzehCeNHyv4U6cgHmKdSxKGDs4zRgaFXRZCOCxBjSowB4aDshkcg5XIUT7902AwlgINDUOS44t4ddYHHJDTPyjgAM9zLLvgLITYLYQvyJh+uWOO/j/IQturv9xahtS/yw3pBwBQwXbiA/Cyvm2U3b9Mu7yhY9/E3M8eR2t2YKAvlyQ8oBfTP4140S2I8m7ErrX5QWHX1/nGy0v6HZXs0Gufna8eQelD+PaX9W+GY3sXdjjwD0GxZuZkAM2UNpcHhp/QIYAiwlgsZEuGq4M/tEiBQiG26bLKVVI7AYBs/xxO2m5Z1nxiCBdtyCzGAjNMMMcIETwoLIUIiioE2CxgIcYoQgOYDxMdlOCgjBoYGggQI0EdnEVooRdZW5Sj2V0iggi8lhqyIQVFKlpD560SEzYaDlTgCpJTQV6QgkY8EeS8lhIblD06NFET41JFI9XR5AXha8WmMB0+OgKVhFuCn2grEWoMIWS+blEhC1OlRRL0lmi2NNUwkmFgIi2ngZm4vA6F1KkihJO6EA3dNIVo6aadEVuFU3FzKSRJlygjxWTKgsjeYnIUuhYpsli1NRquG7Uga4UMbeLaRXWkFJ26oLrl+mpL0GvQKD8YjzvhdXnjo5RPvqHvu19IfpOiWV03E9EuDKQujiyfrjBQEbAKaoCPXGZsKzObQEEWSez4sGBDE6CKVdLSQFslvjRWDCdMVyOBIKFmIl1EDSTC9DTSF2Zwb2QoAjIaPzg6CED0iOhxwCPgjgdwPDLcYtw/wz0qAy6TuzqGRsbyMrhy1ZGzb0fQYWJtX0AqUdM3IvqlGRAxmGm2QoqE7XuID5DpY5duMchHKoSOKoB743YBt9MHwyq5P1WsCJc4ErLg3wRkLFyEbX15BQfJlc9C+/gfAHIwtaCRhIkDBoNFDhq9uGL3YKHvsMFA4HAAsjcAdLcBAPMcS4J+LfVteEEGYEpNVABj+RkeiDmZLP6OAEDfBhjTMQZ5GzwbWwAMctv3o18oKgR0M0oC00HgRFT5jjMCwDb+AQ4f+ZTnFm9NROpaZ/WudCCIWoFaMQz4yCFsBCpbIQ+SQM/LPTACZU+2gz7gvk0GLg87vzMQLSExqqKgQ00pZAiBwvvXERAUl/c/Akcy2l0PTsCNYmXUDyX2DQcFvg7zfQ9TRN9B4kUFPocBAFl7uLzmmyGRdM8mYaXRdK7Wxx+cuW4XG/reX8v8YMtQ2nfggmoO5382sxomPp2YsqHog4WJyVl7btlzqdc+MMR/IDH5sHRHDx8fsdhwB5PDi4RCWa7ReDabSo8/qK/wIN9WJ8urDn/tZd0W58t37kxFw6bizajZm+UHBOMigwyWzq1GTInmT1d9BIx+OfjkSlT/vjgwlvFjM5LLlJL5wMj8oHYxKl6LZTxpmXztiO2upl95F/xN3XB2z1omoA64yvo7YbXqACISQowR518lAD0wa8+BXVwaEEYZAJ4f36dLwN8m5X96/5JrZuvDdr1RT9bBmq7TlDcNcre8VX5UPsmev0BbHHbMaWeFExJR0EKZ4VwiYvq5LVjhFYBJos2Zt2KNmsDSD6M4t7WzKwSGQKI8PLE4AtmLQqUxmL7+AYHBAiKIASUUjsbiqUw2ly9Wa1vbO/XdxvEzl69en/j/DwQACDj3VDZHIJQYTRar3ROOxuKJdG4mBIRnPtm8NqGe1prgAN+9dgCI6Lxu9CMWpVCTPQcIytxc79nnshiASlqHcoF1OwlAOTyNAOSlLoR9ppdXtSggsxnNSdC3swA9+CHHjwDAfzHKIpyRR9+7PdECestNkY+zYR/FuE10o9QoV6RrjkmhFsgPAyFAL4o8MH52nP0ErJy2p+KkA2hgoz2Nxg5GHR6BtfyIH33OuQcHVvLWPPK3JI8wGkvxIulOGGYHpjg+D43IhGDZIm0BAiDePSQnIAAUdtG8USjsAiAoFkmTseFOrZ/3gqHX4ODdvUj4fRoAABt8AgIGQV4kZD2ozHO/Oi14KKmJyCmLlcSs1l8kFrr8J0/l7bzbLFq1pYN3pzLVaZwyWqQN2mnc0sOPd8Q5nwPQEtWjIo5RhtXvOFcbBLA2uBsVqXr/CrReMgbIqgeqNClUtNPsCxpfa0w2RgDMvqnx+ohhPnmTF72gXgQR3osaHUJPhLeFdwILFgDwB8AmAOwwBJCbNRci13akK9evwH/+EdaOVC/MJeaOoKGVpoxQHIEoImI1qtXi2ZNONL0SiZYSEPiJF7roxoMxKiYuKXUz4as1K6fHpBiRSs1io9UFocIF6vLMZh1c1DFIscJlx/W746EbrttglVuucrVQhAesPC1HnnwFBOlCySaUAiq+XVSqkqVarRp16jU4aacmjZq1aJWp27AhI0aNGddmwkuTXnntrTfeea/TB5998sVX35zwrx++++mX3zpIZWgXJZI9GTkJKQULAGwQhDwAqOe+cUg5h6SiJMZCLw9i04o0lZB+Y2AnQPu+APQ/CwCeANtaH0HjIApJrSOrZnwOoREyZGqNz/CiIwQBLwrYUrQFBIWMT/PGB6OU5jxJXaYUM0heYUgi3QFk+BIE6QD8OBLxbSY70x0uzkdS3bXM4UL+wUxFw4IIj3s0mVIp5uVRIkEGVfzEHk2SeYmU/ms2UPbTU/v4+5BKu81EOUGMKi2qkbCTYnp6AMNy9f25C0Qn3+oVi0GCihJ5yW53Syx9qIEQisA8x/F+Y9zIk6SfZzgnahJBAm6uTYjNpqhjmRSTpMKhWqHskJWMU2QAwajD6cAZfXbnkJ8hCHiKfRSzJi7TknhmFMGH8nv5PpptpUO9KdhMMrDJ5MJOmusgyEfcY7FECaNWGzcaBUGn5STE6LcjSDIJBy0Ot8nEu70Fl8dut1hIN2yEwswR3LlSW4lmUgbMHoDdZhjTGiUECQhuD2LC8ZfZzd9LRABZfXyx0tmVUtkhLHDBK0S8e6bM9w7pUg2jRGhNSlkCBEufiQ2wyBkR4egf5kQ5Vdi9dkyd2asLAOtJ4Yfq8Jd7cSaBJzFx7PRsMac/lwHwGffIO0+V6VyIiggrOIuACCW+Qozl8MUvRIcnTuLC4FNuamgxkcKM+LGPa4KIQQWSWH64UmpsNbC9BV/hJ2DvBVteTW9Ql6TNdUYMQ2W84i28Io1Q0o9cVvkdF8tL5yRXRBCDK+4b8uJbFheTXCQaQAbwoIxcNytnUBCoW1CaWRZfBVh9VbNqueslI0aRHe4ySZbvrz+rgxUjWFFIo/emrIwWbu7MEE00I14AFFRjsq+USfYVKHA1VJmUxVNTdtgGo6d7goGjyefHTtThTOIYkTmToGCp5pgjjPwjPa+DUlvniXpAbYnxtRg/zU7TE+rMl7io1FOXv5l1ydSMpY3wm5kZlbI4lD9L8D0VQYtI5imMfUZtInTEMPdPQPKEGBcQyhMw2o6CxVPFNlxtZnv1XbxNjvM5KmftWAM70EmfeFeDVHHstCwRchtBbGkM9+tSJCTJQVZO8PQwuwNYiRC4kygJ96Gg1/vIkcQu6CtxrU1cANYWIAF55bm08QVo1NU3BhLiMHFVSKf1Yo4jnZuJCKqwo4qzztw9WhIPLY3/hpoXw5xtQEIEbjATB2+lH2w7bUOW4UzGyEhbAMRNcRVovpkxkUOr617QxXizMRyXF2R3Sq29XJhtk1jpxEMoyJAgcVvh9lZBoeQcSybSwFL/bArAklkhoSkofIBPA43RPqbWbkEg92LUPYgFsRlTeI2hLMRKjhEN22SLmZG+mqCJNO+gN8LLNL1ExVU2Vi/HKlevMVWoFnlLgmL/vn6tjzID224BFCa4YJ3ICpK8q+QcYoSnFmP1FWBwB5Cq3O7pSroHt+UQDHWRJ1VWcib9YWOhhQu2Swd6JVbPkZeGGgwu6DnYLYxYkEk6aVuaQ5vWtg0f5TiskawrJNIiNGWLH5XB/VYbMBN6ky7DcXuEqwewq8tqGE3b+slPDs96z8A2c91XqCvM5EVgzpVq9Oq5+E+xLkAd5tbLVShCKVF3OPqGh97fO/Jj39jJ35H4SVjG8N5zUYCxoK3fRolmLpzObg9Jz4Rb8EzyXqQd6CGaDAv7YeasDy2aEpG0AmNDRpqAZUIRYJMSO+DLlKuTlGjW8M8EGZfA38dErBWElUCOuCJDAEhdrKxqNgKTFDdPga0cuQDzGKB3OE2QKPRCgqRisSrE9e02wsCJxUwd4gOKSatzKV4sNRfP0eDvx8KABkB6jK+eKLk+0RVCtstiRiTv1aQ/zwJUDqLUUAHWw8MBqH5f1dCUbOMPb0pnWGjhC3YgutAphXelhdPcmqeXilmyC/ocIu29qz0NsmxPJyiZ3lKd+4wYCyP6lcK1ZE8oQmsHEl33Ezx9td8K/YF+OkQatUFQ4bcyybhYa9+6Bo65iVcPHkYTn1ZFoGmKvDejSIa9QQy0NkGeKGcAzkuROleKn0ir56soOCqgXVXCUxA4Tw4vmP4HfKFUfE6MiT6TSf2D2vGpiUOAFp5z40JjJZVBfzCTpcA3oJL/KZjXMV1i/7q6C4bqHxQLMXhRm9LzXjBnkssxh42vmkjSy9xa9DCyHVBkeYXpPG4jDpNVz3unstnlWrpoXQ0gEVxmwzHk6FO9zDcg+otk/mC4LwcsPguw19j3xcYpdpI2kt3XFc4ZlIvBV9kxtbzrz+HHuSRWvM1k9quMlULZFB91Gdd1lJFkUTYji4lDwFUZEL7Em0MKiOOJnxooDuW+y6HFG/hmiAY1iX9KN4+hOTmllCx2BeNLCPLaycrDDcYHEKZzPNuEvZ1s6BaXXdkzQDxxGKd6uPvG7jPeu4988jpbaPCI4xuSab2RVq26Qnrsk/iwi+gV4dGyQle/G85tynUtNvN/1+gQFMbwZ08IpQhpzHiyV001lAYVzMD84xCkM06BCMqMX51v2tZqwRQ8FeAANlzVWUgX7k8Uk9FpX6fOjHx87kS0LhDtR9j132lg/snDkC4Jd52yw/Tn7itk8tsYS3zYRnCVMZt0ulik8Eixc4/AOXPgTaMLtuiFlHEZK6pCuWriYnS66s5BG1288GLiwBaUDHz5ZQyz+3ds05e/ER1w7gKfnP0A5Ket6+s2YZ6zHFgCfJBbJXR3RyC/Y1hii8vtcACQAqLOjZ40l81n2V6XH4XZjzwJXB2V3ajujLN6/IkEIkbWuXrFKDuT/1ZM/m3muh3ZTtaB0i74sUxCnFqnY1VCrowXANGuDyYXrbnuZ1Mi8/CFeMW8sVbk4gMRQBz9UyVZpte+/QE78cnhQGLwRb70qxeYV6bBozFuqxOr9HYy/UC+3zfTKZ0KCc1YmCg7t/o6St+RVqHWvjzvA0CkHFHmyIrq+4KzRvO7euRRVtGe1ry7y7c5lwNr/ojPnBEiBb/Vtkg61ndaMqI7FMr+xemDh1nL3HNFce36JO6mDlWJ9x4K1qXWD8C+zCyiyPAt8UsUXcomNmAC3HRUpCJrPlfG6pR0G7oAy7EyVDQ1ELe3Lp1Hbfs6YZZ9n5ET6ljAmUj8qxt+5nrcsPobDgs0g8M+ovhrX9VXFLCPW7+b2h0SUFc2BRSgACc3NDmWp9b/TW3nZJdpD7CHE9XvqnzikF5vrFIV6PI4dFyZnzCHMJbCPDkrR81gOkhku9EJeq4D8+DN0UClyis/2aUUI04LzPwpbYXdsnOHn2Iitkl6dKGKAmizbJu+VD1HUCHbKb9Kh1fqO5KE5MOfV06Toe7GxadcPDmrQYVa8o98SXPJlv3yGhd4S1+GBAk/vEFjs9/C3dJv06IC0uoRTLzN6SHI1QejZnz5TbrZGA4Tn2J8A33s0DeA4WFwktZq8U6IJ/dfZ0xkaYSsRy9nvPZm3T5ANF+Kxkm41Ww9BuStitHWY53zkR6ugiGroYnlrgKUJDqcmyMP4n5mcjw84499B4BrBpFDPvc5SVyRHMd41e3FW8kScMgopmnD40LlnJ8nVQHU4slbJhRhD6glz7H0Hcsb6GVpuNiZD/Pvl1kreC8LKz887aUkfV4DpGZxGy0fVCEBD4oGXEUtw+3r+JCRIzG5uJP48oyvMNw5jHCARoeuEArg2tqyRRPcU/0uAwO/Fo0WqjLniajqrunL9xP6Zwttsnu01OYJQ88K6sWmYBlPNG0Jh+k1S3TkbU7YuEVVXVwNNWHs0ObIiCboYX6cHP8m6Ny2f8yhhOKo+uoBRl3DtqRAsjJBaa5dJj1CYoZCR4lYPwpzyrRJQYNIZ1bjvP53qbWXS0i7Yg88vsFUXoiqezSIX8bMAMV3j6oC8cB1oakGfEabtAD6kVJbKZQPizTeF3w3wIYfxyIw0HWbLJ4y5LfEj6VJOKKHElKc1F5mE7KVTszNnUKF6km3RMwSSYTLSwuZhSiZ+0XpGAmJiS1EhW6UjBApqeLO5EQjn4yEaY2HQ3Ku980ZGIWAhUvpmOJjaOf8WymSTaDMehxOx7FrM0kKeLaRgONZw+8Ena3W0MaLcrNugtyMtYnC1bh0T0tRv81u8WU5/DyThuFByVAR+dc0ngVEdZTZTncvEaenWvkkEqzZqVeDx4v5Z4jmHDWt44TwAJ17fOlqtK4m06wdh9kEKcBoMI6y8CE3iVeTMAPm46fISgrn0AESqI/eOFv/ZgWYZXtJ2wRL0ABEmkRnyf9fiCpSejFLf2bT1ANxaEfDs86q2C7VFWYPmZo+NhTZaeIjdc4/h6vit7j0Lz925jB9Bf9Uw2ulWJCb/CobgFzY2aCtu3rxwC5+JyLWGsnyjY70R2SrassCe6obbBOnSWmY54kT80KkZGkHNIgzqK6X7KYME8MylsdR+Tpw0AAtUnU9Rctr6gYhsQX618UzaPOsFNkWpOswmetWiEoa3HvBHVC3T3qCjfXulb7RkX1boUTwDSIrDZfOcnenN9O45qtWlEyu56zD8CNfb5nWxaiyBCseffjUU5vC+UNDr0pidHH/1cRbRb4B1EDAuDNYpcClnfibkEH8qw7TNLRNFZIvzWZ4qoivDNZ1Q+2lWU73NLx7yehGSj9lwovy03gZUoNjgUB7ZWxuTol1DFKhTTXS2ukAeIhEn36Iuo1sJ7h/PSJGwkG1pJ+oOOA1gjYkWNrQhl9FnaoYxwoqoKjPGtNUBLBQnzgtzbFc20GsSsApsCoX9LOPwTK+0hTRaJeBj6tMC6s1kkoL2FZOLLMxhCgnKIKcwffgRpoMPzpJTOZI1MnnWdI+elyqSdpbjjGXzUIVty5U9xNRs3n/3ObucSm2JZvKRRXHedb6X1iyOU/LSLwpY5FBDSnQ91zWvELCs+yBHRsyTVqf/WKiZOp+17XlMyipzxfPAHvWtuw2SRl+vI3hin2T+Ao93HCCN1y+ndXQSWiwXDqUf+xoLIw2cD+pg0jvLe3t1yTi00XOUK/Icvq2fkphfsC3Zg72+b1nIyiFnAm/+m4v2z1u5Lu50P2oaKxi43N4oOTwDTkFRS0ATnf8c77cDeHsaKnsztVUlUcZ1sP47tcZTO89i8t4ebrGvKVGFWTVjrBk5s5HPcBkuVQWFIZ89PlMp42cpw6t/raX+ouecTwKYJ8C2g3MkGqVqRRMkPEUawDGNTZ8o/lbpO/yv0va+k5L0to2d66iGfNXFeBcotLtC6Fu33yhpnaT8ftczb+C0cZKbhtIgdP7GJbXFtYdSNcQna8L7OS31RDwtZ3KpO0R3khHNI9ozY8Ku+FRuYc7zq72H3Mg/aRzxp7LPycMY9bvMvWv7ShtrsXaksezrJe7jTlFUh/U4HfcRENSFDb41/unD0WBXFlrtSXzA9TABePs06ig2AbvyEmF++CORgiKS3duLmpVIRyZWV1GzpWZyO3sOZo3F0i3pcuv2q9fArqmn9uIn28MHGWyAR3RgOXn/4tprDFcNuwOo4ZwQZwIKmrslJpaBhI+fCJNsPjvmC6tmL2Ik0LDP3hwnT91ORpuwGg/pk/hKZGcu9wQKvb3+4pfBUMddeWzHV6HPLizwvnd/Rkg9ph68af9TbOMi2my/+8PF2FtsUXD9/+X0Yr9o/fbpN0+uMBUsPxO9Gr6hndRC4YHcnE7HstTmAyzWsnNKuZEoxKUKqUMzZTh8DJWXGE6oHdqESv7F9ZOq7qvcye2yqaXma32n/yU22XIRAiRCHi8Aoq1+u7PG7102leETKBmmopzqQJZVoh0AWZH5kjif2PFBfpBjVghZZhD8IAgmbd/I5LsxudcPXPAecPBbVjexlsj/sVPF6obk5TnVlQwThp7OuUxvFBtiFQEwD56COmc36emNKTOSt68nffkP54mKILktPDqXbRi/41+Eqdj6OBAkYsicPrgnSVRIVBNGVWo4VuT9wVpVRqZjzgWJlAjlSgBav80QfaEc91FxpPwPcelTr6XlPYXGcDcU+4ncRr35PPELnLh+01rN4IFUA1aKwhXuwUsKyU0bd4InyHSUtgYdX9bwXbxfNnAyKRHqKOCN2/noeofNxJ51Fh6OBDhqPBnslD3IpSubne1+Bx46KofqVuPxNpuXJ5tNXkKzY1IrkIokShYTTYE9+tpNO/Awf1lQkQuI6OkpI4mSukvDL+5ZKvp01ooEUISrQStRrZ2vuXfxVO0nNtckRfm17v5nP8wgPsjC02PZu5XncZuvl5bCnsuO4XXzMDr6G7E+olsp1+RVJdqXhjA4FLCP5KA4DXQLuvNb+5O78OTcytj9Jk5aQbOHW+v1V7eWAU9DlMVuw9/5TWB+p5IS2VjOam0UD76fs0gtlPlnumhcdcA3+rz3jn4PQ+7//97ATWCM8iJoBL0hHmPAqD0MwNd9FDHQ2NBXLnzWeLKHxh/cwIVfzHfBuG+iQEQcCvDLK7iaCnszyJNUfWjf+zdGWeJob5yaHUh2aDhI0dHrV9HTySWoDBeCA9zTOrk20fqqxUQrSk8NBek0+MzDQpdNDeCiv94/376WtxsERUvqJ7aMkWgxXI+cCKo2GsW94fz8XOSr62wcPs0C5cq4bHwJ1gyRLgb83yn3ZzFWfiFj69ZVHvSo7hzUl8tXmpMnHwAP/uqLabgvynkASElT681aHCpgF8yNYID5qRSQ2UE+bYUcndgwAqx8vAMhpjkTfL9QsPP5lBuQMi6I3IZSXIg4MqJ+A/moYS4y0KvZpajzseq/RmUkuodqpe7jC71+5PcauulOSoPJQD0uYtHHTIqjqTNWzmS4njwxPzs2DEHc/nxFMeNS5PnHpycn6s6+5QZfY0/GbEkPYbNCuMTahMysDf4x6IWp0T7M+WBpFog+mNWe/MFYO/+3EMMOQm0vVTgKQMxZEVBoipDbFhba3icUznegd7q578Vtq17zdNfaufA10LlC1tAXzwL9KtSU4upAvT30Z3QBBSofgNKUCj2VhpGdQMbC34Asck9kYrF3eZ4xxcxHkZImG+SowZ6cfbYg518S1xVfXVlhKypQR6Na8A3LOi9UoBJyYNXZ/QbQe3I3cb7Y8w94Y4WjkeOWe93q/GsFHeQ/bm2gIVAt5Iw0SGECYFk2lvLe9/fxATKyJ3L+fAHXpLkiHycQBkrYuPDUpkm+EHfq30R+woWlJ29f2CZKgcaDkXDETxPstxdrZn7cZ7E9uCDGq/I6vxOllgSLmGRZoq5Gegx32Pdqu3pVXWn3x0G4CfLrX2lTms8BcEiJwXn/+sk2Zm2t2q0mhPF96Sxsl15LCVPx+mhLqFms6h8zwiGUfNnNu3P4Cc5/zsrgkX61TAucQKkxwsxl0n6lud33xlQ0xkZjCgq5dPFFyr/BxAPiGYnGzW0XHApuTlhkRV+aQg6W41HC6DrXEtlzwzuMdQoRkz9aqE+vqDcku4KncDOitbsaWuojS5lB2TIBHO0EAR2oUZwCNwQKvrOrL8v3ETHZEu5CwrnRcPGYd/RcCDP5U4f1X++vzwSKF0HVxeYN+/fddnzRQ6TFlWXQI9Grx8zt3pZAgiwiim446THLRu+Gpn2l93A/I1MOixa5dQY+/Yl8vZ6dIHvq/G7ScN2YgOHRpvtjXx9m9fNlhtB9bzr/O6/eTQHkOOZF7DRU/YdHIti5xWeyule6klNZd9h43P52iLslDXfwH6XzZpGZ9C26Y3/1eQcBNQ+vPVPTuwCxDhqBAfNjaCS0Oj76F+55N+WdRe+Sy/gqRHc+d7i7G/b9vyIy5kDhyZD0F3csUCr8ct4Ks4fyDNiTv0JfOwnbfU7poCX7+bd2ntsM5aCZ/0+etbRDqOPkr37Af8HfeG+ldP1S7cdWTnoSY3gAJwIquzBjQF8//uXJzf5ZPsnWGTvOoq/Cj/9Xym6a+DWy4gPuxetj82oRx8J1tu/L4YBYS5t3uJg3/piwr33pQSyIenPJich7JrE0kXOE1vBWfQb84mkQaHizd6PFfSePIbExSmg2ChEtO5v7/SacZDbiQOw/4Y6MVcwlv/nxT0EyFwL08GxZA83Vxd/XWZUSow+TCgsqX6t3nV011DDsP0zkM1JnXD3fPchqA8vIZ+nyugxBzd0vF85wNTYdBCKoFZgwhNv6hwv+MhytwIyf6skuWlJM4Ba2AvMlTzzN+ldMJ5itJBMs96bUwBDcvtOKDFTHrgFc5K3iRSqljPLmvK2FBovta+pfHnzTGf+RhMvOXuBhzCMQfYSBGJKIw3EEok/harkAjzGYk12cmxMVJIcSZjAo9vQOn5qaGu1UMGPge44dY9Jr0FH5Sw8Gdvc86i48Upff+3Tl+dXLzigSmkGLrTx15Bp0A2MuEThF+CrGCcmJtQtCMIv0mWROYm/zunMeXHrbEfh+iNSsuo8RaF0r0FsSZSBdJIiACESK1XNvP9ffdNFwOphjC4+Rm+/4F2wQMkRYpFYhEY8MrCiip2PPbHu7yjnIDoyZ9FZQ8eyJ6W1N3v6yx69DBvrOGE0rwVUIGrdzsj5yeqYiBge6ScB+x3uWvYPtcA9kxY6qfFE3yZMmAnezrg9aCWn+t+NJ2s2h0VWStXRWok6Pl5NxC9EE7g4TJBXQBAmjCf5n3gC4xcTYsYBd2+k25iZHnZW47du94xwxfF+vhzdcMCAfRmtHmzt6vQy2i7qnonh5XKiM3V0Vm+8npesvUreJOD+szpKVbBLdHg627YuD+Fu8+EzPlAcK9fG6WXGNTXMVk1UYvaaG8bVG17FV20pSy5d/jR6dOEdQ8VGpJgpabCrYhq04nd+SMcXWUU9nK+iA54lvVX+bbfv6FH0qlbSLwKiLPHsxAlGgkX0PAtjlOo31y84aNZX1CyzbcB3CpomJjTNxumpS6Wnku/cfrcMBs4+RIPqzwLS/TmtjSdS9bWDG7tLNnJPUmm29UakeN0599DfOSCIjrqmz4TFSC4cAc+idB3jxMTZxDIE4TW5/S2b9xTfzfAjO0L2gYWiuKsn7e6j8PnXq7IqM+JiK81ZmcNobJzxeQDs55l4mr3TPdP9ei9sH69cExpeKtInRIerY1M0GAwYDr/qSaAqJeqQaGoSeznZwwpvhoV5/I01mS/7M7Me73aWj+Ml61S0W+tk6w7/9eeXIhFOllvSLkzwrcHPXR/Xx6+inf1ShXz5G477TlqBvkBwnXk96v5MM/DINEhze/LKnoB27VC6d95/ybk75hS9uvk+d2y6HYwt1S+rbziSpq3s3dhdkkzzKTWZxXO7Z3sKYuH+ILhEv7mubl+GtqRimW2duEdQbOyU6mfUeu9A/PPlhQAbhr0glvtYCIjhUmHBsqKr6APPsKWNNasBr/jxyCoQff8rvce79fXZPNkS8AZsGggZqVBDcaGfNRyiQ8WI9BVZ5Zn9YHGML8fO76mT+3dep/Hw6tc1DTMDba13PtVbVr2pbvhvqKX19seG9YO2p5HyOa0QIySVV/73x3yUbE4LJLU7BZbxaQDqanqky2bGibNFsN9D6tjToj5nHs5euzUMJ3AqHRcweGKFuuX0sqb8sSLTxU5/PXe2s2CDp6TQXB+yN5+HLT0GWsqmFE92tIuoFWzYr1DnivEMQTOhl3KzJ5t9y//nO9ae9nQUTmbXobDHxws1/lLJ50AZCBcCT6eH207WJegTMmtqa43FKp02TECGsUHOuxxCjNwF7gc7qTW7p8V/PPFvvJ6y8JSlSWb7cRnWdya8bwAM/w48CWHsdnew2kZcjzucrG6JXXJx9w2uHrzbFXz9iSLiqQVMDxa5xtf2RCHmw8Q8BYpKf4kCG0ejG122xOjbE0yZvQdVlWGRLtdtQZ9dwLCIra45B0HaZexQDOx3MgdAMT0YOyEO1j6kDVS8i2/mssfV5QlXCEmoWxWDciUMlHl4+7xAuRo3hTaCt0ZHdMQnU9w/gdRut689Z137PJnOfPttJoD43bfhV1B4FQnlrNitzbkhpqFJAP1s0D8U+BLH+RbcJLQqoW21LnndxuUb8wl8pMVkJPEExjdGYgZupeI+FJMdIRtz6i05nQjZfLyOcW1vYusbrEhONu+hWftnHf8y8B4Jrt/0Who1Wrvgn1RtWfdGIMe6iykN2PqGedF/4pxWiCD8JN3W6FCzV/8wHPIfv5Y6f+t1X7uQSKvVI6iFb+uvSD8JUGzDuTvZiNCb81aFU4FI61ZfKRvCv8M8FDn6J3WWG+EV+Rieg0N0hU/n+hvWX8+3uoVfaLj+afseamwTM4xbe525xHzut/AmRKs6ItN5rF3wsreCuOJamtXyG3hbPvb95ocownLsZ/JPAhQ0tIQKNxyZl+tKA7rlUqJy2kciG1R5IVDCa/Jroi0B8WbZON1fyK1VNq7qnJ5/bIUjYxxG+EU6S7IlQK8cXLpJPdV/oO7Yp5F6bm65gOu9THpFgF29FLwlzqzJCFtz/OqiXWfq9VCFZ58Z5MYvmapwoRL43TjQAGU2g+GFxggY6Q/pPvEOAfXl0OOxqvS5sxG9RP3Sk38k1iFzMYcWod7gJ/74Pi0UP9BQhgjBTgT2Fm5vD0/qWb+6ThUeL+MJgz3Fea9vyzs9mAFT7T936ykpmYpUN1WIl/AiJWoe57iR5VRY5Ikd43/USoIYnpUB9+s5qT0ctTOfiXnPK/vGWWNkvC02YdFbgn8I79NRdwA3PuMUbPUSzKlr0TmDHR21hb0XrZKv75q/r8zcE6lKNqrpzvxmPE4QX3QtdNcOVmNBVkNVM23FoO5ge4yWm80q7wyvDslVbkN1c2QkNRqKUvDC0WWBoiSXmibghG/WikxDXM86TU7rkdLUY4WVzKnk05IcX21r4X4ulOsdfzNyz8uaBE0mV2rMkMLnzdckw3QBinBw2y4grW1H/o7bW84lLcJmhBzhJ8j4RG9xRKVe6JE4CRg0fcZzTVHp3n0DvH/m3deZOmMyileej2qanF1y7kR5fsZIJC4Mro5nS0IHIVoci8LUMqjTqaKTbIgJGak2Bgjhr6VdxlB2YuWQaeRJZsV2c4J55bnEwYE7RXHVzZGZSVQuXcogxPPJ7gkkkWI0LrVkIdTHouQ5Ni7jAvkC2W1E3fqq8X4vsOTcx9cJVBp5v2yh6gTrKHJsYtVBh8PQ1V9NXSPJ5uJ8Y1ZBbamGcJNI9dMrcuhl105kk2O7rwnS+YFZfGFgRnqQQJweFJghNM9SOh9wKblcX5GXCpkvOVuJPKP29lafqUTmWUmUUyvy5u15IzDzAw4HAjLM+0Vmyjzhi8CboZd0Bl9rCIeUjfkxyQuajBldS1fmUMbiats0cc5b/i01WkEk9rFW3uFohw88AIS9Z0hK1BsaCg1Z7T2thdqJxc3pngIBUcz3erBe5V8Bc5bAWPFHDDcWxmW3HdBMLGH5RD0/4EC4f3szQH+8Is6YsEl3t7ndv7jZjObzCXo67P8Ne1gVMBAL5m9IAiqYAmip9LyAgPENKrw6HABhr+i6x20FryDgMOep4NXBHX0LejBRF385J5snP0QA6uL3mvT7swwbh+LQ4iYzOlOlx8+XmB7QbBMQMqD8vvcI/Y9MFe+JT1JFixRst7kuFp7Nf3aTS3StfuoSP5WuTVSy+0/zDwHMZ0uFabTIqErYQxUD5UkzDQnXnh8jlZNcQ0r6tvLD0ma4DgsH/e3SJkSKrX0lruJyYjn52vPQBAB+YrSfe4ktM8birzIrghl8CTD3kITBD65gXsXHGmXsS0DxZk9idKZEwaAk8eKp8dSAyiCKMRZ3jRnfsl0UUa6O4bfo04N1BPhmBPFRE8KXG8ZgcOW+iKZHRMQonBCs06fzW2LUEeXbRS3x0j8iKEEVATRqPC+ekuSjyJRGEwGRn863gdPD7We100qsOiNIUZGohEqYbxG/UdQp7ODW6LX0Ot8uv16fFu8iK5g4itqWDjNUQRlFAU387qB2di1waXW45cV503OP8nmBIl7gQGLOHpi70XLL7OEgpc/On55zVDAmDISO5zunf84myzG4BSDJnoFgFjUyIHzeEqt+ywYWL0gUHIxRHsvIzjfVJRdvW7kskdIClZZLrfrmNfgHEocfzBMF+sM8U6BqoQGdAtc6jGPPPgYQuj8dAIoTmyiiBlBJIjab5I5ZfKIQexRYRweg3bE5Lvc8JSr864wskpgaRSGJAeH4fctyRVQNnkzAI6qo0CTa2pDYBYuqk8vvLj7jHx1cZo8fJanBxWFHxsC4xRPLZyUXT6QCq1p20DgbL24IjGg1uUe4vTlPj/S3vJpOFR44GlL8/l5zwKntrawvb8PbTu+gmx+fDvGYGCx+ceVCn6IVHaFEnfmI3YB2+wGlKEqlcn4yT6jJLLvH3xK3jJ1UnFBAvAQYTdXto1XN3D9G37OrwnvmzvyyvXup5ffuHPfatauCfu+BYfWe1UfQ20Zok0djiOjRI91vjVt3JL7vVSR+3hp7m0I5TGWn5EQNs5IH7tZWPF7cu+Dx9fO1nMv1EDeNgyN+coJxtf98GeY5Fp+o4OK9mTKXFkOmV29EaKB3jL/rcMXAOgNwreeFVVrVROb3IWXW/5M75xufDc83Vu3M/H9AnfH92MS8tOddIz96xF9WGHpe/mjuWvOzRfFyyYreLz9udDcFKBP41kQh2p8qhWTNzZqqJNB/Uv19Qqi0AZeg9NILKU6MgJc8Bvbf0+ErQflOfc2np3QYPJ+t25qiHd7A9YsWvC2ZXucAR8IushnODSAQ0h9weVLmyfmM9rF46jngqJfZXX+MeIBT4XNA7teWLNvkG6YN18oZo5mbHruDZsNSwfwH1/Av2GL0wKn/6bjP2uMtg8BaDCkXsfnfya0eiEbyq02guZDbbiOjt0sYKq1WF8Z88TLpijuOUwb8dw0hj/einEFH3khJn49FW80uuT/ohQ2ldHtHoT0GalrKP86D37A6ue8ntxERqvvMFwXBQgA86DxVwiwUpTKMvi3HY9PFAl+GUZzKKPxzjw8uty/UNoPsK8XcQ7CoRNXuv23bocZofY2i3K3KopKROyTPHi4JZXmVMG8baXmkTF6nojyTl0dKor2UZ60oDvWrmicesstFKhWrYPGfY/ShxlCVQ6Uk4BAsGlmx294sV+hZbs9XALwXLj4O3biEd/9trAo7fuQCatMiycv/YkKJu0reXtH7osvgBWszSQ923vb6EZkRzNYYvR8DVL0tnuQlWEpY0pzirgXpqRGcdZwIqlILUUNaWwjP8jIgFIvLReSYMP9ggQ8jEZjLjVFNZJWEDPWKN2WluVY8wbJokWFxcdnZRkNOSWZq0Y53OQcPvU0v2F2SaZ54s/VUNAeZv6F3uawaVOa+ABQeoCcva35/xcJTOFdK64s80BeTIsvCKzVwwZTB3fVU9SK2LB4jii4oAGKnLgd7rcdUTiSmb8pvazv3J3d8y4OI/IVJhsrSuKQkc5TEJ55F3o4yKetURl0QY4SBs7drWO80fscH0z68FORDXcKBBUrlAsEr7jQNz5BvAEwyQlTKsyuag2C4C9mCi2vuaK9fhaNGcMx5KeFaiMK9tYXwHrSeoUV71P3p+HUwL7nS31DakW0mQaM1uVq55S1yzD3qNkZG5nzWMAPtIbwFrEIlVVYaEpPStaFUlQ9XEN+wLLsmAvr832em/5F4Az09RBQuh236Fp/nmm1HTyuGbF7VJ0lOKrcvOzQ4KWxTjkAHvSva95J1iK4C/3qoqn86u/xky1DvxbmZGSM3tZm9AOXzYuS6Lqddm1qWl56XlRLj7bOC7CXk+rRDngIpMKn3r0LJEIQVlJZHVElJKnQA/06M0FZ3omNSW7HgQGLqRGtX+41ZFTknnDZ3My9/HHncZwLw+WSvZN5k9nc4KTv4FF8517WSyBdzLMPcZIFonH5l39JgUbiJHG4vlfii9RQlOpKd1DHQ07pyeU906P7l52uKgQTEsVeBWYsTYrI6H2jGAW8ttpwXLanXSwVaSYCPsUaZj3jEOzd1o7T5CqRxZu0bU/3WAn3cqlvp/wBJNJ8EWElIACpKQuf6iYkeUppMXNafUIi9Jrh89Hz54D5UOkBDLr+uz+nQpZXnpeVlpUT7+KzwYmuyqXOBx1CrN6VQ+gjkBeXlkdUScjg6kH8+RmijO9k5qa2oO5CUdqC1u+OmRUXOScfN3YypD2sfZxwA7DC2GF2vdAjSG7ekpFQ/DG3XLB6sAbqGfSmSrdorLiWppghNuMKikag5OeghXARgTizvs60xkicjxnDzTB/PHmWlx/ACA2J5rPSzZd/nm3THkpF+YYBf/XlRmW+eKMOXSX7zpv4qOqVJrxvsNOiAKKBlSYY42pdAeToyext/j6fTD3UbAMUoO0jg9YISKGBzXnu9Iv4GVqirtfrImDym1qK93UL2JC4/Um95k5QWZ/kuvjAEiIxQqpSq1Eq0hRaSJulPvPgUORpA+XvHkvj4Y3b5JrEcDjum4JgdXxBL8vZHAWiKQgXEPA0IFdEneYpQid4nOJTDFYb5zL1XRpPyAbfNm9zToYWwEmiOa2IDLEkPvnivrBFhwGThC7D5qNTRUXCaa6FrETgHlFAPMUa6HZw53AA1oDI9CzzyYCljnl65c8pIxaRUnG+gsLW3esBPnV1CKCPkoF5H8y2q0UrUDOr3VCotcApvtqygVlMLSS7hm0dWoBmAv0+1ox/KsCynSVMLpUvIATol/oDrSzpdjvebtBWaFAE+9ObQINyAzcIX4PJRqUtHXU/jgMuDRridn2lfumQJ3QLN+/Q2qVtZSfai2LFVa7cZ02xSfEZG52MWUZxkxwYwUSZbScymql+/2dfOhCa/0I+jS9bHsyOOC4nJZqw7d3d85lhxcebG3YbcnOHYlDSyY2Kfu5OjYXnHsdnesRo/Dkfrx0n+kRqnZQEkcMmG+7qihabwuOxgVVGCUsk3ROlZegJNzmKwI5qU+aQdQUdaQnvVzR1H56WVbnsTVTEQHR5n0krTTTqaKE0TnVIYJg7pKJ0QLWZN1OhWplZ2Tc4u7Eg2ATuZz10G7c2LuQYqaSyY4ZAmN+jwNF+xH2Y9Aw05MNkU8vIx+7TlTs8AozX9XN/KW1nVD44MDz270eP/3BCq/N2Nf/hFT17kmbyzcDR0duxDN/qN46+G6Rw4cyYcdPocZdt/0OxtSB1zLIKK9b1HukqGoA9dL0MeQnnsK4wn3wiVX4xSEJvPD3L/hUYXvfIoA4h8UF8T0ttQe1bTdR63bVXw9M00je74d0UtKMVDX8uImcK1TXxH0/vHHAWBcbE+PLZJFNZEPtU4LrzZmGRMrNETpJE//wXjQyL6G6DHXWagV6BB7BmfbdCH4IWQK1Ce/xIfYE7M7XmXliOo7Hhtos7MLhFVNR9zzLuyadqUMZpbWFBhSmlsKM3kPidy2JnZfpYZ5Ew8jQUkUIadr4RKyxqlscp2cB28EsyPTKa8QRxGILPJy+OursvK4WR6RCqQ/M9H4aCLnly6JoEcmpVd4kuFehbutak4S4fCLsBmFZm5j7tzfQH1+RzL9VbV1Dg8RI18CI+5S4FbiqlxlCri+py8uRutaqnxRIk6eQaPOURBWIZQDZQa4qb2aLUhWSmXm7Uo0iu2t5zmbVSkSlsqhQphNP7TyZlO+W60NqvzmL6+51Fu49n27tqZlyGrGw/J0xYA7ntWG4f0uoWmeH3PkDoxaaFWN5CQoB0Y0ieN88J0fL5CExCgVAWLFDrAUvyCnZU3HbZu9fKGwkK7a852+/ZZudW6k/00KX4hCbVxUtiMpyUc/MTZT5qkiFWGCW7NfPwHQm/DkWdwkKJOl+Ty5cHRRR0lMWU3O8bpcutY8Pg8ILuaV3yioaLi+O39/d3XcotPNZaVH5s+cHlnK0w6q1JB4xrJyuxcUooQWVTwosCRrIzNQHsxUCRQyng4iJIidt7lc7pFvT4pJ23zIVOD2OAiACNcT3+F4h6CxeKZO+vLhfY4GTY0I7GMxg0UBlJwrUpS3gbq3ubQ4Whz5uip5J8iqzJzodSPjEigiFzWU/c2VU/Gt/ROtsa2Wh65kg4mVq7ymnaQrgRDDyyJ00mTPPyFCg4deUiA69vlc7pZtT7JnLbmHwMQtEZ12yeP6UOUkm4TiRIfZh4dFYf5Q/Q5ZLMnh4yaFfLAber1SG59yYmp3a0yrIBGJ3yosXs4i3CFUHJv7ms6mS33AcrC5NXMfeJ2Zr6/LidToc3OM1Lx5Ywh/I48s1S/tL5uf0Z4Sd9Y+/FAjuqDFDHrXyy2H/8i8BARJhwlhVX1Zs1Os55TqVnBDw8wbZLsv8rZ3zxDg448m/f9mDweAA9ZtOPO+eyerKP7jCWTN7vqip/cYywfoVZ70cgVPdtpNTT3LHAZYLl72hoSig9xPXllTzWTp9ws59HzDu25Bp4ntne0LL+phvGw+EUolB9gPcmQEWvEUpxGgTbw1M5CKPIPhscKE4iCw0KC9WubxsfXNqX5+kWVqozEdUeUjYounyiHcBbatbmvDOMomTPPj9KQWxUv0/qctbptbVcGxx4XBIhFgLt41os2GSmlpTi+6GDbxpHlKWp/bWiQSBjE8AerXRFQfrCkAUJHVHu6+qnt79rkKASsYJiRnh79Po77aQSv84R9SNeAbMBNtNztwavndabzDmT6LBT4yt4/S4fcghTNiiB67aUTtQr7ZtUtB7vroxGcuNAkeUwQD+WljQyhfKpN8zAjeNJmbCrKKWw+QAa5T6550OtIDMBFeUZ5aj0UaLGNFz8Td2OdXa6e0ObnnkBhsJgvpd15VFN1y4IdgI1GR3ksO3kKYWRhNub6iE2+RAB75XYwWArMa7bFRaWkauzFtJA9W5bJw8MJfdIVayxwyRcApeZ5QUMXknEW/VscTIUPU21eEfwcim00zJStACLlxj7o+VihzpF6dehAeIivn2+Ib/jCA5NUQCeKBVCgr2QpeocQAnl0aj5DmFqX0iTb+wJoIdDHe6k+opT61EZg1tAQN4z2mRrHZsdRP9PkgL3od2RKjF6XYoiMMRl0WlNcctRKMCo2mZQcBzh9fB/cnZGSMnwzMWd3ZhtNnVkZGNw9Iv4/HH41jrANeMEp56+NBrXv9zKmacN1jaba7HIJFfkRCnrzw2ANZjJcn3ogPL5eAsgnZ1G0OXHhLmLngILX3zVSLWopb/Oij5Y7bwNK6wFl/6txy48R6SWBWpQm9PurgEKRswqUEwsgmo5OQHaqGT8d5/B/DdhWCP1ZflRcMbDuAz6D7J9qBuAxB/CSIb/nQWluYk9GSFpteqPcW4Z6UQv1AYfQmOK0GnMjYD/4PibNoI9Ii4+JTY2P0EGujUkHlT5g+GoBnK6+C+pKTkzoMqVndaQa4jrSzPbIGDQmFoXkojEcQDS3PPBCPhREs5vr9+PdZX0sNYKj4ERQ/Sv56rzozidrHjAu7cLsfWJ6D/td8ttGobDsZlyEwjAnJc/CNVkNFbpRRTxqmA/3FUFY6PtCNnciFwXv3oTtPqwYoimnC+peEEcC1P1XJvPhx0JCwpHhdkKtxdNE2fXXxXU8wA2hyh68j9sJMP3Kf/lKF3c4UARWBO51Cdmf9x0YIPYjBDnSC+zYQInAc8316Af5FbtsJ/HGvUqH2L2OJzYYbvSnq4QA6K48sjNPN5MlEGAHl/a4CEWyOm7olqz5fPZs9gkHUKBd22vHLFPuH26rG9rmHHNEX+ZkJn8ADTDFmGhXvgpIzcyvqWivQlQTfnu82O+FJ6s5czm3A7Rxuwg2hJ1xtw2Szp9k1GS81/4XtD8EgHLYIwq+BxHlgY5E7IOzQOxXJf4RedIy3pcjPNnoRlAnoVxFc1tJRHTqi1dSfftVZ0KJYPxVEovJJ+OHZun3m8+pmlavacppeL+k6qez6eLQq1SGCP3Xirt8fjhXhEO4ILUhIwPDVews3NXPBcA5PqDPGTptaN/5qqDwZF0QJgDl5uoSqMmOSYvUhYn4WTVT+iVxSxkhHC8JZ8g3uv24MW0t0J29D6me3eoW527ilb2fXoSSW7S6m9yNvFI+fQ7IpWN/sWc4Xh5YErPQJ3r4ZXXDg0UtzbdfhKp90k/TQeuK7+dhEdhdysZNzjXCbX5E5qLJ+Jb2s2W513sGM59cDlvcfMiUshZAre8GLBVPnYolTxz6mq7DmT0MYC7NW/Fz4+8OwwPkiFPhD8fR2AVzdFvWP9CpZfX52wqTL3WuLH91M6TbRYhD6WQvAZdUImF7U5V/oz/kivR0q92nK7bNb5uq3w5XZ108XF2tLPGRJs4RMW2O7fq4rjuJTuyBo+6K5g05Og7f+FEdPLSs2P+ouoiAiHLS8EpZ27RGElzsKPx2/OC9mQCKx6PRCaFHNGXmGrQ6VTd+vc2+aTs8tufnl6G83kNPb0hW/BV5/xWIXdZRnkr9q8uYY6aGwgM3UoaOloJ2GpMXmiJNi2/F73yIGmqfPUpzN2SSSTg8Ki80GuaVRX4dARaBwtC/qEouQ8q23pR/NCNUGyejwuNkOjFupQRDcRhUQArj+fVqTp8HeupvUnSxIGCWek17vyW79zARjs7P5a4BcUNxUWMvWrh9FhkF3ZubDxsHsg0AFsvaWTWf6LLW2VhVLeiRKgAgxTPooYRqYpOHpCU7AASowynhRK5ljndkKj/8XyroluB6Fpe61qaFk7Yy2W52Bz3yVR0Y9MqPVR/2aUF1kbtKVPsHcGzMmqy2QBdsB6doZkX5orsUDh4RNxSi/WslJ4+yPhhn6XaO/3TRsbomBNgA53WPi43jkDjf5gKCCELaDh55ZiwLvreKTkkBYdCe87vMjNnp9rX7fwLgAr+jgTIAaNdcXH502dpX2KsjE3Aq8Ga7cPczr/DqYYB9venueqlyzx3uP/uGc6N7ud02/n+S6/izkGOyduDOQXEyEqIQjRjEIg7x/YTK+3wVj8Q8rZmkaFJk0OS4QlPiAU2NBW5afIDQJkQpAAhcBqoRWF3ACArhphqCjCaGPk3yNE32Dzd1zIhaLbJEo2EWQhjwDORENHoDnK1P+FwllohBSpsphs6AoRR0E5yN6ojDrDXAPPgtAoBaQbW4L+TXma+mzamQ2KB9F54ig6JRvtJoBaUYbWyLwIPSbnw49WnvJvgl3iI6DIZOgCHJqMvm7wrAV9tI1cDpbFS9WWntv5m+Rsjy+m+AxaeZWYOg1lRQJRQAlbAiPQCGzoARrAeNMerGOS0pqeAz0Kgg02hSN04KcjQyLfNxmpvNf6GvmzY/qwjE97uJFX9Bc3A/izLyJ8B451LQXMvZ7uzy/Gsp14FpRLvLdKcnfdodBwcWB8QBK6Cqt41YwX/63wMc+WZl24+y80NeQf+X0gB5936O4VBCv+yT2Du3/LH+Fje68lYu4hIWuX/edkRXozQ1+7bWticqKe+045MtF5fKup5L1q+cOq2rM807hpEHnzW5/YWzJW1HHaW6E17Pqf6WeHjdjb6WxVhy0r4atR4X2ddY7gqV2Kyg/YrJfo52+xoj/SRRe5cX+yLi9jEjexLVlWc+7VbkTFvXNWDfp2Lv6rJToB1Z8QD8J4tm52vyxfgCfcTJUOw0IRL0xexGMPIlHr4mXwxFnAVgR7BS8DUFY1iO3FV0pR8sAiVGNLq/aIOvyRfjCwoS2YXHSMPXNBCTBBDCA0L1qgDiB/sGfwP8E56nE5Q9SD9l92a9gVtjPwffSd8iX5JPkxo0zNxqh4l41LxN88F30rcoVgMHQN/czwn3DwlqyD4JY6OE3LMwR/hNTwJ8+5ZJI2Wj+znfSd+iYeAaTiNhx8O89530LcI1o/6/01Yxj0doWHw/wAj6Ycs0mv+/LFBxUC7zI6yiO52zs81pL2q3ilHnOq5vmbCTeTqxIC22LeGXepbnLj9o5bcGaj1uQ7ZptnlPl9N7bN/YMe3W2TPs1zm4OqSyTjoKHBc44ZzOOQc6b3N+DIoG7XJxd6lzeQ4OBK8Df3Qtc/1LHnc7674A4gwpg9RDTkGmIC+hblA0lAJlQxdBf8IosERYP+wwHALHwWnwXHg5fB18G/wB/BUiGmFCrERsQNxG2iNxSG+kBJmErEI2I3tRNNQyD6jHjGeYZ5XnETQLvRoDxrRiZrA+2A7sXewv3HwcCcfExeE6cEO4Lbi9uOO4N7iveA88ES/DawjzCQbCfWI18TmpnPQf6TXZipxMHvDy8Vrm7ejN9c73PkvxpNRQTlD+pcxQXlE+Un5R51LtqGAqgoqjUqhKai51CfUc9TkNQgukZdLaaZtpU7S/0QW6xsfKZwnDipHGOMA4wbjEuMV4yHjN+ML4w5zPdGbCmXgmncllipnhzChmEjODWcisYjYze5lLmSPMrcx9vizf9X4ufnl+J1gRrCHWMGsDazvrAOsk6xLrJus/1nPW/6wfIOLGf81/j6peNau5ar3aMsvNenO8Oc2cZy431ydXkrvJ0yQuSU8KksqjABBk9IMBVxdffoIVi0UMQwCCjHgw4BzhTME7HfaNz3nmerg/dWyt/8P67pT2El3OFhnic6DPZWc1CBMKi4hreMLKt5qxvuDtgr4COrmxz6Ea0VBXMe50wfTuWt3Ewo8G0bHn9plLH618zoySAXVrnlVBqlJ3aX6K/o31ZB1p6A+b26UklAHA7EBV2MFkuU2eRRrEQzteyBk5DDi24w5pDMpMuvCUxCcA3iMkosHqJscp4uFAUAFiyeKA1AzF8nwvBLfq3vrS9bUSAtcKCUZkwbVWWxzn9p9hIzAIodk87Syfu8zxVoaqj5qJkmj/uoGu3YtBQAmCdPSwsBpbPAuA5RUCKkEI/eEOKdJQV0cjhPnhwsEECtdZZKuFtBWzwMoymDWXXvpeC9vK9x4sQYRbGGQjvIYCj2b00XXAXRk3l+zq/B/7ytGcgpHdoLQlyk4sssv7cRqTsRB1fJLsSsdMNmMr18WWnQluDyRj78Vz6+rfr2EqPiCYf7QlOpqFwAigcpVapodb6ATZYdPDtuR8aTux9rk6AQNWtXWjuPBMm4Fbbo0pryqk82XB8FQDQsTrKCHdYKc4rLWbHafZB2afqQc7rMpajutry/T2cqXtEWTOIvz+WBnb7e45aytdBRqfQPg6WU/ewQ65GRGq7aQBAeqXENGuuG5tleZEMOjc7EBpHZoaPj8EnQVhDr19tvteDp1uWVJOTBPJG/Bkrmzzx8TJDB/1ZktxWatYxVl6BLOEEdJo8nv94VSeotZc7at1i0ELHnO2stZ6uMuIpESo8e8vhY4q5tpleqYWMMu3pk1ttRimM5iGrPl2TJCzukOCDc0iTbgM6+phwIiVRQ5CCjqi2HHRb0ypaNtbGmBlItndsYGLasS2AF1c47EEWe9K9Rw/WfCxV72al3WQ9V2rqE9SJBp+k58iy5BAb+vYMHabQeq01BZqGTv33E2nuMvHWslaA8xp52ubo6uZvdXSIazKLEy+xOAGrVRxZkK1eo53X3tOAcbBxeSrwaMaQadwPV1DAidpw/Wlu7J2mOzddrTZT1qHAqH4EiaK5fsd2+J9Abp03fKcdre3v3nX1Z8S4Vw6y5l0TtrDTqicbM9xWxN/XlWKKMxCG9AJs9DZW5HBzMObaID+4XJhpcW0smLyaLUAYzhaTRprTxKIj2pBjmmExG2JLDkZDii+uIq4jV1YajRIANbiR8FSQblery7TI610Ir+SKk4mZor19PqXj5/7LJo7/f4KlaERMEyy2nPZi20I1bO/3FSSzbDMrAzX0qXi6sJS3X5Itcj0+XzKtvIlsswKZ3veTIYvAKsXOBvDlHHTQPnCcL+gXyyAuC4GyYP/bkhryJYudRjW3p5uNq+2mWBglgFhnrBaBdo8GzODe98SaFNXHmOElMZxhVQaJaUmgj52YNYiBMmQH0xLsHsvbL+wSJzA2wEuyqul98iUMtQETgQ7+PZZnYa26lwiQ9u26tRVlS84GuCZZZRFIv+fhApssFBVQao8n17Hzoe++dM/avNvGB1qJ3BM0tjKRVAglUeJRaAkSxGrfWzVfpo3A9zyFwjltbLexiR3ydtPB7M4ozlljI+WIRrC5dzQxefYzeG0wKKEU9mWkQh1pL9exMTPSrd0QF2BYbZvUoCAg09cGlN1U4M53Jen3s2E8zuKoR9m59+0h9hC/BiiT/vdgP/ohkUFhaQCZGP+HNs3CccCs/I7fEpzo4GpGrTTI4f45pu+C1WlynYtLIbDy45K+BJHe5pzsX6GkEqKYwJf6ArsdgGGrhyH1MT52KDEGSybkAa9oboHag5uIRkDprN57MkCUN8Aik/62yJFfQfPwjCGGpgxrt/fEQLJSHB45qLo/gG6BYQgnuj7dvBD+vEVvemQzVgt631UvhsKRCxXSL8XG+4zoSC8ht//r8ueM9Q/5MTXUYEezPsLPnLEYdtaji7ycRX4GQ/GYP2FGtQe7ycvS/m5SjHpqfYInZKu89Z/ED9bHqqc2tvt4pMuedc6q6twGrEXyYW5GPGK7MbnR2bUYBvej7Ns3/E3HOybv/cGx4SJwcN6JpMt9nkcYAeL93pgMott5nC5CoVsyrxOop5/ItvVvFOeq6SnhUQCBLl/j+Xcjh/y5dZ6wT7X+SIr4xBJSQrv6K3BApVZox7U3s6dc3dFtRpJW/tbUM0WgNTRFJWfDP4JjqqDAk76Gx4YBDe7ABsTWeyQ74D2AOaJhPe65n2JRfjLOxtbaOeWYJbN12cfG7eZFJ6gW0LdgW76/S4xU6OfHtWOqGsfPypYveVPFDFQsbA2VF0x0vbGEKlhsy5Koia8bl9w4R7gmS9dJHjZ1tFSDAkGLJ+OLuLcEbia0Xc1mknJDinBbuVgwwhXE0LQuxgVbLZ5UEBq50A06hDuM0s6zwTS2Dw6c5Y+5jytqK31jWAjadVwDqs+Gbxs1PVCFoU4C+OUluFrGGz7yeaPxUEJ3nKm3/htujHvVJv0GA9sj6hZZYtszDsdiM5bvlcWZqamZleiQRYKm4/L/185pTHmiEOqHJ6zY4jOprsOQ4kZJYjpOP5x0AuZ8lrPYe4xF6OgjD4LFXdmPS9yYf2qcVGnws3VXDIF5/Vlz5vNcD+yjhPkKnuPqQJ7UTZTkn0fmPXgS5FkaQ0+yFk8VhpwXa2DkXmEQDYpf6YqIxbJFsa3Z44XRW+IBdekBy5ZgmXbotdrG3TrSSL+xXGDWEJt5lRJ4/UAlisdh1Pfk3acy8T8o3nXFRMcGrNHZScidGOX4lzBZVKFEwDJu10Qc8hnDnpmKJAUufBSVMgBhGERv8Qa/VieTqFck1RncE1mbHh6MfTYJ7hXP9eJUJ/gprarym9SGRWUX4DxOo6eWqp1NTtXEUuFwKbTJUANPG47MPqIG0mVXxgO+evPt/ofLEEIvuHexRiGG5HwaMzDXNSIKUuuE9Wzq+JkToLDdaQx2yFnkcur+1yBI9hRdVFIwsDpO4TXYkmJP0rYAOwzfUQB8/lsZBgqlVlTNnLaiN8uGxct3oTfIOwgaVp1tZoBObGABG124rJYe7kI13NLchhHVWkrmzMrmxgcWcWpufVbeZcygQWDulM8PTf6royjS9nIYjjK2b8kbo8bSG4u+l0rqwG9wDQTpbPl3vY/kN/xAmXnpfbh4NAz0wab/d5DKBWhIQ9ii5OpXtYaGrcsLm7AUtzHkBrOlOKXFNaMUclBQghRVbxehUibxTgB6r7VP90s03OwT17to6nYmzpAkCK70FxHeK1/+BAiV6FKM+WKJqIcw3EGUNgfkwcf7SKs2GB2Fs6PcCeIev2pyAh/GWfs+SS1Gja1YxICctDWKsLHEbslBsxapt0J0ZMJD31msjQ+GJJ5+7Dov0+GV3BBnr/XjBmZcJKAcykI69xeGorBNOfjeZ8keX3AURR07TeHydLHpM2aYRFttWfHxcnBCnU9LHnw1CZGJwAIayhcMXLCcI67E5oHQvNIg8HIaQEIR3jyZ7BgbPOV0pzdR0EQVA5+2htIJz8zonzcHJw0cSBiS79k4XjBKiQDqwYtW2ozE24ImqQjH2TsuiULLkXd2eytEA0NSy9AuKraIbEtLfQpjerjXl2J5IIZ48wHnRUQewXX/ZBQ/5Mfk83M5HgqGXfaLCQIQVCl94UQcAUkQxWBXQH9CHPmxmEFSfe7kkjz+8HpqZte6phV5mem81ZUw5aqQXBpIOzGHR9JD4y4NBxM7Y+86o7gayvh9uom3JVV4tqY8larlr0azfI/HCIqyemS8fdnX2zcLVLUWuzjwa+WWrJv/4zYKe+r+tAntaFU2MT3Zthf5KPyY1j8c4ejyIYurbU5ngYhESnoGCJi51n6DTNZ/7lYL+/ZFa3RGquDvuNNklJi/IVgiArsWInd7KfU0dL8KtL8rn9ybvL+VQmX+JimRblFzpwXoOCTjfrNj3IKGXdvWbBG4BJG+pmaWNm2OTRlHbe8vwSYnBiUmwEccy1MzfwoemyE6qlGChKQ5wHdK69asaoCY2NtyphE/LVXoJJiN1EVE25ABnCd/kvOnXaNuKWtq7q/5HIlfwBFi27coMHwZS5vdzYZMqMvaDGjBF8F8Lls4TqV4FHo+MRTc0A99u3iUa/LLGt86ZhsFW4rPfivHYCgtoiJywh0nDYSEqpTGtlAb+YlM8Lj70PIqGuYFueut8/ZFiCiS71hR00auk/gwYGBIUSRwbYJTiUeQl1wNl1B3l6jMZdCJYsTnFzsEkGoMoK+ZX7+HT4Sxdadj22HxQoJrFnzitIX7QmzSld2r9H4xoEc3dG/klghX3oji4UOJEcv8yGwPD+HghtE0tTwRj8i1wjVpsJDJtfmXZPUWH+U2d3FS+abEiy0miO9MBrC3EoRtiOAAYUIqDkW7+4MQUqME0wXB6VsyL/lKanALLJcUT02sieloepYM5FsgSr7jSrz3gDSdmgW1Bs2+mmVolFfXqhH3tdRuHowMPWAjsakxf003+/fli1dFTjIdl3sKgwtjrob7YWFxJmtNQE5exeNKkxJs98tGxWcuXVgY4Y7oGojkhnc6BelOHXZzCscfWmQHwce0jiWifLphLAdeItAZaefvE5dPXdCWjaDUXZHOFWINAjbmwy4qkNb0e2NTdO4J0uheSDUrb0jGiWnjo0+QHGXCiQExo7B4j6SOIhRX7ugI3frwt7gkh49rvUaWQgEqMB3bRNZMr3AuzSKfbeQKQFmy3PHrszQx0tbx663/ySosANkts1u9Ma+rGvDEkVWVTQAuCa+vTfLh3FcWfmKvR+9fHODi7w4WerdS5PrKrhP6LRcg4z266zf8qwksJNa3zDkt5l1yfnJ7/GAxjlp0yUdBszLoTF4qo0ZxGPH9kifS89GpFz48vFgwk3zOTilAeVWULelpEcNGrJlkDrR8E3Gk3EOrD2R9q4Z9P6BCdjIVpeNNo7d5Q4y/PpO9kcvCS1ii3i0YVog4I20qe45M2pEafFd+uvRYpiOYTSr9qOdS954kVYuqxhdUbHQkym4sdoHAtJgZomlvnMDBmqEE1uBXb4Ga1fAm+cshoZYVLxpNml6yuOCCUWN7uIyKwDLbU7/a5/wl7sv5Mn5rxbBZNt2eOb0eeW+9Fp1GsPEsQ6SMTX5jTPS0+K9r549v5NVE2dFm79ztFNBh9kRsn3Yzfila+GHwgM7HcloOASYoU01z1y9+HWXbE9Q/sjgctWBMops3ofdu9L209grvms/OqiVpz/cIrOVRXni4pmFTpB70pAQLq+qMRv5jPBQgKli0/J/C9UizeayJjOcs4ppPCbZ0EAbuyIVVBGoC/v/CRERrFZF2IoTLRlRKwJB8HhL3y0mGekGiEfOcJpRo9GZH6MEcKAK2fe3fSKQMCcMSatJYcEjgz7jbqpn9njRwCaMK7oCfpYXUT7FWDZ5DgiEEpnWf3h0G/2rcSwKKObgIYSqW3s/2/D1E1zUFeiojDFX0Zr0Wg7pvRVYczFlwB64m+I7S0jLRPdFEcRmEOmGnz+dOnv89BYxqdcturOV1AVTEduGlq0qSQ5sEYHtUUysJ1UWT1bpwU50Ndd+oG6Tzg4BRLxnBJ1xBaJtQQj6OlL+FPiprhy/64jgcLb8a1OTKXLAtt9/+IVjBwbH9shJOFvQIyq/JaJ3uOywuE2C1nSzRmWaCXVpnD5+wmbSWbVmTk1D4WsC+4RHAjkH2jzUsln1vPhZvvU+5TcB8bDLKQBUbMJ7nEJTVU+Rx2OEh2YqF66ebvh1kM9IEsI+5w4bi1hAtCuHbIfipAz5t/vZRAZzGyndDimQH/KJ79dZeQSi8th3V8b892NsKUoSA7Gsifl3e0EFZ8XmGqPJabWPDXhGeeepEnzaSbHqP5PAD3rYhuY7SUY9sKFtDkoKHx1syw/Yj23XKqdIXxpmgZVLwWxaoHokBQU2iN1nV6U/eGehE9Rp/+s+S9RzdgXdmUBH+tCSIpQrnWWkZbx8TcXlMqh8aMeL30P9xpl1/wz7RJLsgJSmnzDSVI0r5UK6FBUeGyJJfjapJzRt3bdPSpGlpgsGxCmWSgsRy4kVTO6VKw3N7CBksR2uVzuAf15tRhpCIa2g6bnSVrv5l2GfSDUUH1B7nbecQMOewXwB2eFqmPi1tKZwf2Q92awQ+LSUtMI4LnimG9kedhHFoQyTPLzZ4UJNSChkZePctFvOnD0i7SobBeoIxpfViOf4xdqD6vLqJbpDEzLm3lWNhGdZp/H0jY4b+sN3S6WRaxYK1/9wgOeAQnnZwT6tqhDB4OmbdbNd0jTtGVRQ1QjDJfePKoTi+pAqWyl2dbBtYebNk9g65vHnKm45d+4o2tUOCsxRIe1WZ2FhJjEKplgTO30vLb3vmskMy+JD2dUbTvtR1FhKBGevy6kETS3i9zmdkinAjyv1vg/Ze4XW4gDN/ljE+aSMx+HmrhkuSjvsvZoOOgQbT2fNIDRzmKIKkp4a3zU0mJohWzBGe6XTgczbFbeO+PXLtCbz3p2fHq9FJM7SRWxbkXZlfXgulw5HyMMHN3OtbGnWxKtRZNV4+a4V1kl4Opr2cGRkXbegFausW+QXwiK3G4zAXT3Tkq4ey/ZDx5VVuznSIWBY/fFJrXpF2cNUNZM89De9bK3GN5w2G5O9UFmZ4n77GKEhznenptk3HXsIlPQw+4VgVa0WzbOTE2lCM63SovwV1kTsE43eCNSdqnoGVOGIhmjN7hV047bJdOIr/BG/R8ZJpI/2Cq7Ej3rOsmtYv+5fN5gwe4dcIP/7ac6ucVSIqaBT2DIPx8YVMoxgxiKae2ypoZiEEieXMnoHZwH/oG9XC3ynInjMZXHFP58dQveaaWcbYuOXqvx4RY52yKN9wvWqOFBempeTW9lCv1HplREhbISwL6xrG+me0nBIb1g5cNFrwvkn8gOzhL5yvOOPpzPLw43eGKrnIfSwpmAfGeqjhRhZbmEXWRrOHmPoEV+lm0VOn0MVLRqXZPSzEsKjgZUN9ur1hhZ2kQqPAJf8mt6Z50Mn9m79eR8hfFyQlz3vkcGdsA+w2aCGNBQikHF9s/TiOlJ3GPm1LD2KQ0hKATMYD2ksu7KaYHEvZ6vIWrF1cBHL5co8fTT1XDfmtZk5OyN3e4WxXU7IbaN9N1kgyQfChLgRSPITBMY6reYBGoypr2fGCXkPC5rd6SrD/vL/2h9VbuLFh0ny7rNRMGubleHiwaE2ooNFj+9j1GfTufFUifnijIOteu2fVIEerqBm0z/HW46DueITi63yFuab8r7bPvUq2SyalAu+wt4DD+k1vlpxK3ijHY7DvRguwvXd/C8hEl7GFtk45/6SgL+0Paot5mcP8cxW2ePOz+dffffxenUOxyAqNqKRuwkCiRJfhXpbPCwF6uxRpE4JNnzzcLuUDrEtJ5zq8Ypy9vt8gNotrj2lOkASq5PrcGjJE+nam6TT772KyU86YThCPpgK/cxe8V376aGNomYyRua26UIUuFWHamltKCG70OMUWJprE3PQ5DqqGuewaq+NcaXACxKADPqhVM/bp+wCXKsIAYWuo2BeaAWTlvXR6JBj2tqxNlDn6ehuJmI6Jk3t7Vm664yM6JE9J/SUQx2BUsdD3rWQVrPcn1uxbKgvli+e6Rxn+80rpvSo8i8yhRjK5ThrIBsWBSHUAhxtqINYPL1zN4S7eaYpObnG7iXRGB6JfiYOnhdOF8pTtkRToJNiTsaYq58WgpJoB0D3ZnO0ZVaW3IeAQ4t/cIawXLaPts4K8xMxzru2Iqd82HZtMIWbnQtvcsgYoA7h0+ccqshE6xwChp8OvbjfXFdt0pOa7U98S4tXUTrDs/1RnA3dRm72JZvd43It1eNcQWmRcl3Z273BmB99gchkXfpSVbhnHPSHwoUfZ6ZUg6KHMxKfnrpulJoJEhuoWoycEgZRxeBPKgAn5LLJONP99CyFo2dDm/HDm85D8tAyiSCbiMziCYdtxds96MwVO50WYWHiHAsW3r750rK8z0UGEKyyUkrx4rwUwQBSddje4IWa/3yn0beWnZGo/o4+wctlXTTHUYm3mEOMTHRxTdKAsCVujmgcOOJNzlwMSnSVC/RZg+bzMaRTzJoqW+nCwkLbjhVmraO2W0pjrP5llwlYckHRx1EIAYq3TxlazeIZULC9msnWjlYp8e59a8p6GuW9sTIzztw1rtsn5zcYWu4hQWVkbC2HxUg4XRVyyi7t1cKGZaxQa3ZErmhDpFyn0RrkGIa2qa78vogbDw8E1YjZH9Vwb9BzwrpPX3fwlx2DPBpFCLn13RNsiE82mHSGdcMzR9k3WRR2SSpCshPR8c668dr6wagAiSRo06NfcqiokKjkhP2IsuFAHX84fsDvHojmrJi5odkkSGgDGUR/Nmr5INbuU5+j3/4y09+eeeRTVQ66urGtK9SnjlSRlejWpUfP4FDtVptSZGZat2Xw3UXH9Q7K6jYDWabNFFMUAFYR3HGxIdVYOxjhlWJuTY98y21onBynpEh7B6wmPXAtJc9xr5pWDTucuGF1fGpm5oEO0br6EqEX5ks+Gj2zb+y3kb/4zDGmKm/VGUwwazRXzzAojMMxaVPyNPcbsq5LvAL7VXb9spN/f/aRzzZDPutGPXVFVWdVUWKlY9Hriw8g2nf7fFBd+PWpt3485oLujagpKLJe3txmAMVlJUXlbtXZr/3sTKTeVxgMJs7CNNqAeEoZf2523Lkh/GjAM3Ygbk/C1pXVXtddV2fHdZkZHVU1YIRnwSXVac2mqt2IwasEUkboqln10LoWk1Kn5k2By+yOzm1s3GneR3g+NxvJs2roWMvqg7nmu1Ai5H79jbZIjuhxaBWHJqH2+vGUUMKBL9KHy2Gkcbx8TUbhkzU9xO740gvBpzkcuTFYRpE/z5RvIkqVDDH+2Pbn6U1ZmDLhBy7puEJTVPwrmqPqCb/f0dlGTvb3x+osjKZt19O/gb6v+/BOiGVz9Yrmy94v2lK6YMp9QILNXR625u0syFx684mIErXvFO4eimflBvruegbm9Wj1l0oZtfskG+1ibp3l3tbBmzaHFZbV71plVdQapBeP8l5RmUyUn23fUccPR6zJSqRx6ZnHD4FDumtlQpF527YRykriFAvVSB80s80Z3jqTaJFaxvIGkUCtaSGgOkJaP3NOZIOtPTps5e5GiFgDZpc2ajoIM0nRKH2RKiaUKfGEX+w97m48ZI+TwudNHKloWdpi2YL+ck1GxZtI1xEsK+jCbF739RsWObNiXJw2q2ldVY8/iC9crSlfuVa7Q1puXNSGwyS0ymkBGl+WrupFoI31/h9xL7CyUN+Qme6w8FuDwlStbkUzecqITET9k/v7Gms6UfczJAwqNAYqRatUzRNmKkuL1EtPwYIwFEQDBpavkqHiScVxZB3ut4PtrZa9lQwQIXptzmo7WMdpYXJSbNn+jeyo7nVcRAaNaIY9WDfQF13et+K0sHERp/CYrKIt7jk7LqMY2g2X0aUPAF2djWzkHwwUrvhMLL1IfaaNdSiBC6TN3eZuuEFPNH4WhPWIfc+X7SwSBg3ZYBk6APfrxzVAs42xWZzp+LyFUl7biMmketki1TN/orHLDasfPF7D/+snkcnF99fnwvFsgez+aveVXLRkZ2pw5mcWv7gbukgWKacMbgFMmKhl9RLWX5QZV+3vvEck9BFXMri791wbXfxjouTJRhZN4/Qq/UwVoxIaYxg6X7G1KhWwBXeELpb73sgebPXLWpwyc6/ad9a9ec5jqn3aVfQVhYPdjUiAHUlCgUme7jOGVMVmpyWdVthiAw6A9sz/p1SmSd9vNgwnm5s2i8s13TrbFJd2Z6tuqrYBbSZWMLEZTKmxZYbs+GWJyG5KOW/dGYqFOVQnwwZhC7BchsQy2Zg53Sar3X4jZc5rNo6Vlw0/cL3En1rcrTQG+g9TdSao3p6+5jTsZai7TVlK0CKXCcve9jrjDVkcTct+afxRTDNXDHh4xw7BFdjOCkFZxIs9WuLSfUriRNF8teVygZyA83yYFexqAZo/S6eMs4QN5P7eSn15dctU2dDIRt8wxk8hqOoD2zWzO/N9M+YrTPG9B+HICT14ydx6sFyyqWWSAzLnk/mkXh+gLyPdqMAiCnBvC4RU8XaVVtFDN8ZKyrQRSU2Ddf+4Ng7BVrRfPrE7csZFPCOlKDovt9GIUgAkNTO+f2dlAGIxfSNrhl2VIFNj1nlnxdOJ+fA28BJWRw92aUnZ0S4O3KD0VYkYILwc60cEicxUzLpmPEQm9T9+5l4Lx2+nsGw6qVSPpDxVEL0wKnbTbTrPlAe2zYe0/9G7IDFr5dB7SjbdmGwArL808ojPtBRAEOVGvX5aEZX2P3O1wM7yuK4M39t2L60SxZgBWgRnX9erwgAe/h3b/PLqTUcKwe9fYFqjIqDXevR08H/DM7gV5FYXKR4+tlEDI7fftMpqbat+doEMBMhOeZPsxER8cnxR1+3gjXmOsUH+kUgXzb7yJwayqOGplyk2Sy1vk7/Az9nd8kr+Hy0QYelBPOzOVn9A2uuwO27kgcLFlBrL1kRKcbN25Y7Hr+4M1bN2Smzj2pc8gNkYFhs77bgQuGlePmM+wvKSQuV1tq+rvcc0DNIkZict7II75OgZ5ykEmb6rMuZaBGoA/F9262HeWl3aaKIu0tfFH06HEXYDUkEmoASCKlyFG/V8UjrIAZdz0J2kpBvzibm6KTxEpyq2z0aK5ImjeQRcYxdXd6n1fn9OznZ2B4pClcGiFTzFWwGsuTrevN+WrCbq0oZZ8kL7uPCDKQUh1yElZASKIKCbcBkeCe1PdMA/jqdeCDyK7sLR9at+IKOqJs5tppx2zB3VgYld/s8+VTOGOO7152ajrNv8hg+UDvNv91wRFo2miww4qxs981plhV5sCrhuQkN71mnFriLyUS/R2uXot+5Cd6SclEZYdI3Gx7ZXL4R9TtaL/v8Xg/LsOgVxDPhikXSvTbkCkb+5WVrSq+vsytqim1fqc9wqrzqwSIjM9MIKllAIu6wLkx5uezKgnOBfb8rkBJqllvcQ9QMiMEBdF1wVyFq+VOibBbgLXR+AvuNZDSdmi82mCTBLm/0+da5LR5ct+vvTyRvCCKyj1p1e5GMfzkNcsrl7/gYD9uLI1TM50XlY6/JpNi0dqIG70crlpPXjfbB53kaSpuUiFcuscVMg3T8zAKzkBkg5sKG2lt/eH1ebsa1g6bbP0ror9ok/WAnhrb+0EeaCwFHWQDOsVdZcF5HqAjnc3doWfZproFWG/K2et0wFk8HV1fgVdG2SRmVUma/XOTiKK8Kx6EOXq8E9MseIzA196cvDBerMQAN0SQcF5JU2yBIjRcQcYsIb9qRgYWFWK3/pn6YWWGqKo+jAeA3wdYEoDOJ2ZFtpcQAqU6V/n3hAeCRnODwpBZXrp82q4f8v8rQ2qopWq/9R7EjVJoeWWvnmNDtY8nKt/2V6rDN+trbewCqbgaHk+Ff0ImZSgMQbkhGbmd8gdu/ccdpPojfXu/RM5N9M/rI6Q4NqDVyHvbXLArFk2JWIx2Y9kVJC6cMoO4Ua+M3q8pq1ZDpKOYW2suGBs6D1L5LO5Faw5x9geBrZif/tLGkh6vo16uAgRjLjQ0RR2lka1jfV7B4sJHh1MEUWOhUC0ph+6hU59r/CeizFMEt1c1qPa69EV0aCRghUAQVtU5PFNQ3ZRaO6MNsw67UeR632YekxeRKo7CR5ZrUvzN7R+cf0vu3Tc/Q2hrYfezTn6Np4MdxgZOT0W5ovAa4glIG/PNgXvWh4hMVyen0xLrByUS9z8CVMShAEsIBbIV6TzymKfj/ZDYsM6TynaF66gWFxxcACR7MNSuTr44X37Zom9x9/o6EE4LcEmTZ/9XzXitEzM0SpHsz+3TQUhNiNj89mxpZiEvvx0sWlFgsLIStLmoKXpI7TGsRfNKqV22gAE08ptZn0FUePm5dKebKsfKyPF3AkymaoTvmYuYfNAGW4EjAwnOr9rGlkmquuT2bj9MnBSs1s2VR9w0gLXf5u4wqfZwHa21a7AbPcBD62rzElSFbsiww//NARSzXS1arlbgGvsE1JLOSO/88lDBiWrLTjq0RDg6g1PVuxQZkYMUVaj6yW0hPIEocKDTOKRDfTMFlFLxcPSot4GHPCMTRLbuXvb+nUNg9vUX8ERva7knFlSXG6q5z8eaHl6r6QeLxmCneMFa+0avY/Jo16G4RQBXal/MVW54VZP/m4mK3y+1c2MUZlKU7yevuU5vQSH14fENdL6ES1VJeNgc5hYv4kBtrT85JZRUXsRjUvMzHGnfPTPEk7x2VwFfevkc+2XaEPXmAd6q2J3gaMVnykVhob2rD6TP8lJYcopbs/TLdIWa5kXR/+e2aEW10OJ8jyGuLSVP8zDk9qOIAV+No2jfVVOxMsvhntGL2KV8SvH6hpy4o5LKdD+lcfik3NJGaPhYebUsXBjAPIzf8XEku3iVvn+9aCbdVHcdor2b43PVEWyNeJIrOUDvzF2z0BvAwJxJGIqjyJjCZX6BhJ3GgLrNyYKVXtG/qvyhA5eqSMUI2AUttN/cx1B3P2Av+MOlTqo9DApNe/9pVClS3tXLn+6Uqol8hzCCzkcVoVp+ek7drTAOG/n/TNDsCu2KUTmxYJdN97mTXi3RPzgbwqGYrV/DLjE+b3zBgmDNQ0+T+uYD+C+PKUTAnjTOYPuqF0PoEG7s//l4qOLWbww/PVfdlWPHkOvlZofJehag2RUisiLATTFLMvoB+vn31liOUg7lxvYv6DclJMtm8Z2bhx/LD3yWe0Wl3GupE1Y9uVurjoKDnPk0xdfr/cvnXj6LYDhy8/ocb6eiR349FUd9eA/28R3Xw0q+ctFiwtiSsMy+0jGLQWWAfDbWPaW0KgTRWTz4MrY3p3wUm7c5vJhKhN2ckUuCWqed/ESOKeGcJyXf8k1nTv+comabXbQQGcuXKPNbUHnBKBh8FiEg4RoLq9ILJYNKbDeZDR6cNFJPUwTQ75REvFp6iXYic57uigBWie4tgL5YnZaNKKiSxR4s0NRb2n+IK9RaeDBZZLawi2FmlBrF9BVV1RYnZhro44c7Gle+AbLTjK+t3N7pa2xj1mhTmJRXVVpWq/WHqqBi5VBnv9AUmFLooONqZnGdUX3i119X8g8EC0en2jq7WjdfonKgxSW+lvEuXiVEf/5Heixz6uPKw+jV/pamtvO5CVk5EcK6L/mfOHkYVlIzDVBnODwUJFQDPs5AsgkCvCv9l36fYtL9zcoRQKBuNXIKR8vHHiJcsL4or+vJPdt5eRLQCWQzujdqMQB3G1fns5e2PDH7YQ6IXVsEW+LsAeaonW5MSh3k6PT9vbE3AlgFUPYjIReIGc9fHjbx5LLsAj6CxaoghYA1PQAvkM1PTAirUX/zrLfpJYc5UA6IJJdirn1b+VbzRFvnQh8vHRLnKKHdAHG6CLXhUUI6ER/34cvaIFkSICjkILdEIUmmDgqx3EosfH5ZY/grblJ300pg68bIt+HcBbj386Pi2kafZPBuDycPoLM/u9WIC2ze99ZMaH0mWRDILGLBDWmXVamufEIXsuJt8WnKg8uWStVHC98KEPjPvQho2tuxbOUXCuopjLZOh0bgp2IXhVwIvk+OZTpw0xbgZmx2f7yKMy5sxoPV3yaBDDK45mEywQfZ483Ne6kFjE0+fr9eHEkvyaGm3V7XOfGRgLhJJPyQ0HBqmYLjhRJuTwoSlmKRS3KZco6Cs2sv25ocP+O2ffdaKs3TgBBacjx01TFmkyiAFOlrus0laoy8yxhmWwMTogowcPA2Y7JlHJpd2CXUP84u561vXDvHXTBFZg6349igaDw/K6ClNcMn6DxtoeYNBYyH3t8SBVDYy/cMrg7aUjSrNg7ONDftYSGquqciM6Q6vdhgOq7iMq+APxnR9I6mBjIz97c3PEZ27l6Rv5GE9mywv5b0c4+g/bOILJUDLesZqkVLPGCsF7giAz0zlYKc/OfPEYTd7JcCpHLb62jJrNdlWqv0vYcCjPN9RLuHXDx1MJu985XbU9SDhxXBA4zqgutm9OX/6aZi1IOnA9YHU89JDsam3wXm+UJ5AG/dEtFjpZzeCVwWhRbeUbOZ/rKC0bgQvYY/1i5oy7hI2qbrDwo1qu50u1aBujbPgY1MDFYvip/49ot5tOYVNelOftjpn2QaUeW//1g0Jcka4GWFIhj6sgriY/zST+FU5rarSsSSqLtJyXDOE6AoSvF2VFkT26ipsBElj1SHNQrB7MLJO2tRUUiyOXeZjHIaVyrRnOr6UrFLHiJaIMp69n9LEPpb9RUpUzbguZmFo1L9x0S9JTHr2TY071opK2raALuY+LRWpqkcAEuK5V008Y9oyxCjmuJBPjdPm42OyStug0IltXZtm4h+qgqDBdacDs0iT8GTueWWFL8mRp/sHUNa6IE0iB7V+4zufVYQe//9V9ESvkZ0Ynu8UFeoFAuKEiQmTaRRCakNqy+HQjOBKDk8jVpCrZBNzQFOLRdEJhvU+7n1Ju69MLeyW/yjoOtb9T1C1RcecyNiqXvkyv3723F2p7qGw8UHoqYI3JYcTWMZqe5b3ySDhsGnVTzc1SdnV95RfVx3ZV9Ghyx43bUM2dimFR3SGtjkAnSOn03lmQde3rz8GJ+BOphrKhWWyuRTeqDM93QUFDNKfEVOXNKNp74odmvX7/HeRBK/a3RNZURhtR9ZAXUg2KfSoY60tz8nzXinUp2y9UOpe/gwfoM3UU/KxmB7gf/JbmQc1Dmt+BcujkNNJgtPtZFkGL8ZqxFeBgXrOCyulWsteCbXLDT6Gyr6RVFZKm4tdmCrDaGW7T4SLHswg8VIceYj8Ia1OSoM1K/ug001xhBkHKW6YBmBE9147VH7I9OPPhbqHZBlc0opPrgWRWsJzyHxtZg12aXDZmK7PE2BnUxLqS9IRLg7ZjWWyD7MZnBCzZ8hoW7I9mOrQ7WtlVtP46d8/r8JVctCzIg6eq65/XExE/avrpGy3w2ok7afSscQmrRgtN6FZPaB+Yw04u4OeQfy7VmyKJ1pXO8r1TxIo2F+Th1pjx2r7/y7p0OfhJvEaiCexy9XBi/AVzrNUQ1DhXMOTDLZ2U8n/MZIDsWulqg+MTXTYV27COlFtVkJvWY9zjO8F62OS3Wkx1KzyQmga/JqNkyljougS9co28lp/m9x6jBJazkMrhSFPNKhhKB7OtuweHBDsh5tLJZA8qC9WwmyBaAbC5csLSzvh3AVL09yGv9YqDOODOh/dRJh1iyYMgXg89lQHkgArsd1g4qX7oNh2n5CFJxQ4xxy+OyQ7xvu+Q3d/6QGwV+TY7siHt7vD5nNear/7+FJWTd93/ufxRWU5quxDlawfapxe9jsmJfrkCLXnX0kWL12dGahhTD/1pf8fMnbIkD0jmhi2VsxyEYFb3jR17ZNLR//7875upydsWFZO9NPH2i23gtyox4m2b5oOGfWYAPwVRc7RdUhEZ87z5urErc1og7SqvHbBLaBryjy+dOdNt1Tk8PBOmDwFrZburGx6nZ4ImYB7FrR5Xi8zPnxWcVKK6l93GoCBqRnssmxuNkcO1es9zZKZFwjTRH29u7sL875qwlDDwx/CJHn6sx7V1cKMaemxicFCiBsVRT+4f+yk4Ts6aOu23BRIIAhfTijEG7KnzvKZja0afYCue2lPF927YJOZBfP7O6616J0zO3WNibOp50zz4mem86Ut1vQ6zetvES6xEyHn3gDBlxlHIAQbxBd6AHl5U1n9hIeHNDPCtW2O/r+dToYCfxT/3qwC5bu8OHVTPFrtw3iALns9kRXd3eDzkc1rNKOo+yOF71WaZWCgQCKUaimZZ++/lAb/P5w+Ewqia2Ul93o9aS3kaGRc0hJJDVv9ANKgtORwv1LeLzxbfWez7ZdBmtMVroSwj3yrMyOba5+99VjRQJyn2E5ey9SkW/IZQdbYvR6aGaEHr1muK+gN+t8NqsdqcgXiuPD4E7UUu2BLqgu59QgfQ/kzWFK1ZVlhBC/P/s8F/9OjgKq6bUwl9N78QXCXLq3WDD0vlyvS15i4BP+vEjKJ3DRopj1kClpsrlhbnZ6cmxZDU7Jz9Md9njRCDwZGo4f8FlcqEk+2UjBhxOBYDGJ5MxoLLLv0c5ORiXRQFzv34xbLaY0gK1So79nK6USHyixEcpRghW57O/Mpui1e77SU4ckX9ysWVaVAYDRBV4BUlUu+oHE+1rHaND0uDKvzrS5nxlIE1Drk0NnXFyPH1uMMsf6cK4YZl/v/Ni4dG6iVf4cdA4ciode7gzKj3YSU8vjd8nf72EY3Ywm+f0Z9Mpfwm7Y7Aj9j4q9pgJ/UJRkAol+tTo6VToQWJw5EoACPurzRwjopr+qmjs5mNVnQP2W0a1Jt4pGgHxgj66Jw4F29tT6Zp09C1FFNQT9iTh9fAUhZbIE2yvAtKF58v2euS5i7MpMIhCtq3yTmJlEMW0KEuUjx7MD0sz1oA0MRs/q+ytik2S4ABW10zCW8o0dHxR/EKh0hjf161OLyj84dUbmP269dgp+RQKj+1HPBt/scF9+jSRoqYpJVzz8y1oJTx6lnsenERbfnh7/6WpaPge36jajCb5NiwxhiwhyhO7DxiY7mwjw3RrAm1m2fNlLmqfc3tOltI2/vPkVhrn9aC1WMSHR8qUJUoRERRkDGvZRReNUaR62FicLxgn1PDjrF22PiWur39/+zU0A0MEhuzSXii0V+dqMX/yK/C/UYfRB47gP+fgSeeQWFWVWAx6hCRlxkVVDQfWx8dDIlynSM9Z5vQxSllJHhe0E3U8SW1Rd2vexm4BTvj4zRPudzzVX6kRaZOuFQELc9byegB0qyKjxTkti5fPwOFJLGZa7TJScXF/gjegCbLM3d4HTCPCvvIZ6yUBVkjjZskagF5sQMJNHdMLaoXhjqXFsBpEVul8zuR5S5IwMZqG9xdQek6nI20BjGvGT32l9WjIUaHzrGhxW+duWLMLAoqvqrNgjw6pd+aDrL0fhm4GEaQhjqD2spqsCrZlrYKbxuptKdO6V1QT7Idx2LRzaIaukonSrtN7lsvoh5dV1jprcCiMpwEbAfE7D/1WVbV5yzJiNdrVHHoeKA1VwLcz0DM8cXqymexNqKrkCidggKaEaVb/adYjoQPfrEG5y4CueOZJT+uMwC01mbR/POrwyWu+3o6G/UiOrW0hssc2IYFtnrYQOTbGViMcyseyh6BKiZ2pOjJeUkQKCEgDcLV4WirG5aUwFGe3X52rC3LT/a7/OxdY/7CGu5Qy994z/KGgNXz14sVoPWeIla8b6UJVvBZMGiwHGS8C7YZxrroR5nJaygXFyoNJqJSSouoUtkGw9rxG2hWnEI7UQNatEPXtcwkneJgkru4vVp6PCIxRZMvIv8PCk8tTyGM/1B1ioLXk+zYdn0jIwR8yPbIl4OJVNImEcGWSMaT3ZHizsPFGhP7of422oySIlB1XxKPnImjMIK6ykv5Bpz8xwz+NT+y6LKBuyY+e3KkixX4f29pYANnt1MLx1VKX5wsOdHnzSgtKpVluC6rvfzmMKF+ZVr/5QeUUtulKFd/2ZzRDOB4KmVFYH+UNocke3HyLDUzdBLaFpWuIq3JrrYxXt17fLc+FjWQIZX17Di7Ja7ua/ZdQXGtIs+KLoN/TKuFGNvnfCXrIPG+Ftjz/6GUpig22j84LFqsZl3xMVjibI+NrigqbFeB3m83xmmkQ4w6kLGyh7tTJRODuxSlQjN7MrgBH7X8bOCiAY6/zij3VXd0UcQcqkJrwIgJaC5cbqVYtYeGSiV5gcX5+58LazZps7NBbZCnjDIwdevDY21evXueO1ZZ4xWxj91lWXDINr7jn6k38tPgsaItf2ct6yyM3q0xKKG3hFhtJY/A1Ys013saF9g0Ms5tSCz1WsdkT0tcMCirlFNUKVMrPOrbXB2PQr0kdmL417eKlyRcmX0wlZfzQZt7nf81o8Y5hErCkajjO+m4iu7U/3xg8YbbFtkLf15cu2mcA4+dGW/XtE1Ox4cuETRT677PglgmEFPSx87zHBiLuXfKRIGHyHwwkD4otN5Fbv4/eGCbweIysL3HV8WzyuI0s6cIRHJyt5ICJNawVVPK0aqIBf12rZdWRWDm3QUlEJbnww0fb6G1sl0DCdO1MMeKkbl/x76b9P5aYHMaiYbbNSfxU4ew4DDbRNOTlSyWt90um2RhU9JUllplg7ymSjCkJ1awM+52bQRV+RA7YGH4pE24nX3ZMFZ6rx0PB6gqWg8R8SBYtWOqu+2sBt1OzV8s38ktoWZqRKUNAe8MC0nhmwl0qTc6kHmCptcEGdPM6aM4BKWpdMvo3qMFeoG9/QyW70jGea3q7oDLwDZReybmUiefOnNpOyxMl+43Zx7gmENV1wI5LpZpLli2ZDAdNtsIqaMwwsYpnqRfw+QVNk58KV1N8DamokteGTknIJ+cCuQx7y4oMzuDISc/i6LppHQxNHBaiG593TwYy+7tTfyvCZS0uF24KK3SwRqoURMndEHUhOCsxfMVYAeAZ520WE7sb/m7jY6fmfIg0iPSHFpMJUbt8HUt78mNNhTmtsINrbeufULIMh5vwj0Rr54ZtpTyjc8ccxRMPISmF+Qvx1NlilIKl3kmHkDbmJrYjZ9vVocTRQJmcRuIMikc+ySZIgrQ2iZF6wQFYigZNXwITU1N1vPbBXunLwjJeCawOiOxDA3LS2+T4UKd9APVfWi7zz0juIW+CvaQlj9E/1OJOiV8oacfLUvBGiIdr5ME7TmJA5XhEKLgpdsNiahYJ8EfXkFCmJnL9Jyt2De7uLEw35Tfj3G06kvR20qJQkrw7sjQjuvR5ZlBr8d/fl8Rkw8HPbLgUQ0+QwkJTqskLyuHmFFxm9WDp+DVX6VhRV5MBkH97qlQvRV2hSVcCW90Zf4TvaU8OVwYT3H0aZLYGDgZpdAXkwtmq2DbgH884IWJ5CZPMFvRDSm7f2Q7RkKBaPK8sSKTxS2DPhhFpJeMgbvWgLcioUBU16Wr+dMOGDIcTL0+P3IOTM2McHsRjNKMotCQhGFxfVt05yY35udfwY5tSFb2paFrJ+cXkmFSKWs588uu8PSuwlCzmt1abZHiyqkCNu5P8kjwMlDsjSNgmew1qeQahy/df4xcclNGC6xSHEcUhrl/9eliwNm2XFxZONw+oZMG2wOj1Y2N5I6M8nBhN3vXpwYjeTJpQ74TDQeW8awcwhzhTCEbAk5/c/JOojggoFKNtJP835DmIXtS6wHVqZFBogj65802Jo6Cy5GIjwJ+4mjZYUiewAMXEOYk2828lNu/GMbBjl8rn4SDifyJBvbtZ2Q6qipAetQNNT1wPjiMmT5cXgHA/Ms5oHwasB1X/E9BS2upwy9GmH39SuCzzjo43nvzllpe1J07QKpeXGzY/hUoz1NB4DNcvGLiKcHhu1P43YOcw4BxG/NoZGWYLFEZtFss3PLlbqq5Ecyp89sO+2U092VUNnWJ6KD9ejy+PPUxPx1VWXTefPq6F5gwa33aCU6zN+AkUtxZz+ScSxbban48EzuAXNPzLln+cWTuaEE5ochsasGh4nPlESaekaSVhre59yZNXVhDS+Aq8S4MgM7PVSWZpQrb999FCUaZn4p4hWjCJK7pOFvpVw1Wk5v71ajFbjNj/lJQMlK4NvMwGU2kU179674sF9dS/UHOzC04MNFXmX/lLGlIlep5pSU+3NS0sLDhqfiFC8ESSyMUosXP6hhnQkvCWC4eEALN0kAoEJFhKE2i+EG58gv1IaDoXq1JqM7J9+nFcNqJ/i8rjuTIXGUf+CJfXL2vFo1s5C8vhaeA1+aN3kPq/4DEqwhWxfjatGTzniCH5GPVne3HNTC4P9aXvwPYBt70gR78ul8Lwd4Tp9FO69SwS/OZHhuqrMfLQA3cPz3XzyTnCJJdfT2TOyNJdDHRYbP4BgLSY7+U2/AMDloX3vOnuW6dHjZDNTZbz1AuQ5lZXmr/NlhR7biQxdQEo5L9sr0wdPrTDSGICzp3rZcFcrgBzPiG6GVis5qAzTVV31WmOxY6+jHOsj7lgkNDe7LInW0Z5XAdVv/hV9B2PytBzsVzh2gI5kq3Ae9bdYsDdatS73Lt+JJm0xU+gTVgFllulWXOqzbIxTXPfZv2I/P1dTvyn1gzehKJT570GWv+XG39zjOCT7vQKtYaMUzlyc89XmntHbsX8PqSFsn8X2ldSMbCCixHk6kJx2hle+UzUweGBnFDwAER9OIJG5MFz0X3QlVi7Yxon4a9FDnUR0OZizxZ0Ice7/SsAttSrFjcPnUrCVq9xizrqWz9Z0++jL34b88WfFHxXuouCVsEy1vD8ZcwLhSH2SlEmTGrCUsZvklj2ZbpmFYhlKmmOeB3/egzLfgX6Ak+PK99jVS4bKywY+zjC8xXBc3KaY0T5k2aG6VZup6iBG1u4gfMrF/MNi/Moem6CGdnUOcWvdniyeyj2Yb/luDufnVh8HQEFR+PanabfJj0ZogTUyij9IjNBd5rylh7uHxP1S/guss1tUlashpcCyLbAtPX57iu7LXQrAfMpieDPjDYsOQ1gyWLEvyaMlHm9TtTILOiA9XHwUA2WYL3bu+T/4r82Gw8CSNmn7Sp8TnMKaX0YmXa+H8FeNqxxJVQ0RJSl9GsX9HASS6U7IuSt1sHLuHG80ASpEhTdsLHPNC6Nb3Y/f4reOse1fCLYYOmZQPjTReB6pEchd5PaHfxi0cs7VQ4o4JD11Ejagb1q2ROGb1ocumzJuJKxNoTtgk5OsiNvVev3HaxR12+NGTGvhhGRnt1yPUYQzJCsWkQXZB+IWRmVtD+CSxDV0GE+ZHDUQHg0wOa/QvQcis5LIsqOOtf/SftmDZccY+0qWtr7wskUMw+YdcQcrhreeml1jOa3PfwjOn3DgvisYkDytzMMIGoJKdCYOuWwNbU3NHhVncRm9QjKcQm0ivOem94Qt6QutVxurNP8HvKIcmkOHiO3arAzhZ88TIrZdaR8GsNq1P914LSmaNQSKeVyZOu8LQBWKPtAlKGurLzvo4NCUDvdaZDPLwIQqY5dav5Gzw0r/0NetagxtkLdbKztOUBmLH/Eeza4pn9oIbUehIbwCgWXpP+Z7g+tuEwEPlbNPO2zWV87mPrDo+NqVCSfH9+beLv4h96+XXV+D9uX7QKb4imVyqmebInBXcurru5DWxp6XlLgy2VtqTXOB+RnxScpznw3MzZc9T3i+WtaGm6Bb2r7wH/FkHUxQ22lNrSWGMzD3WHEDzw6WZ0TxNmUKsduX8NwaPHMh2u1jt232z0xbBqsVtaGm/JHD0cIKMpvBUwf/L+2XIS3U5uV6Oegj+O7q9L1kzZ6ox1/q46S2E4URig6h8KuK7Y9N5XoeJNtdmNXUJDd4QsyhqZSSwmxWv8iDGyrg26FSFZBer5w7N7zLTz7a0ecb4RsmUnTmcj9HBFbF6Bwm3U/R2QkHgC++7qsvTNh8lf9v/Fzk1GhHFqdSAMHmvpu8UiY9wB6cLZXhPW5a2sMAI4UoP3ruPd7DrnT+I2a2SZzp+jnyaqaAyswQsDq+4F+q8ve/7Yyd+uMWCm65f9NGiXNedNGlVO4RSLVKx3BhZHr9WzclP6FWLYMBtlcepNdGHwGiPgc6CqSOYYTdA3REfuSTmMD7jQM+I1vJARYdt5M2l7lEiHVqRnIld6iN/awg+XU+GeheIAE6SkwcH3SPBQINyHpdHrhWis12vTfmjv/sPnCIUExq+x/X/aPOFf7dqn963dMsU7YgoQMfZ6GjsGvt8wheXqCTap7l9jcF7iP4xXk0PTEuwZG1ZzMnoItYZePD6c5SjfxjfHhYsEKmhaUH8cByeaa4mGa8eDxG3T81McTaAU5Loy2ejYNdWVa4jKgwQvLRn2AdXHUpJB6huYGhvbAtpg58xbF9CS6KJO5scQqdbGIh3n6K8IBLy0bcGKMgeMhFV7H2UK7qMUQ6nUwFUCiwzjys4Zuq1QEQYiQx9RmcB7XYuczPVvPALOO9T298dUFMeyNRT05Eunmu++H7u58KOfGAi2Adb8/fGpitCccug7q93Ww/RNFF+QMmlGRQfeiBsYDNhbl0kMkfDdtDIwlS97I9P3Lh/51kKUsUdIEeuXWCHVIepPXiJKYp2M6Cr3jl+cXdtt01XxiW+8zzVlzUw60Be19GlMkqSuh27ord93XifmSNSexJsfl6u9sC7bOqu4+KEOeTP/LjtzGLXB9tvKG/odCmNz4oxlaplg1/UsvNKVKqaZTBJPKfjmzz+ZmsNJF1jW7kljq3amayWDCaMeqRGdvXe4tk9YLmXIh464yawHpp5BbKuS/1ndYMDyqT122Gm7/YL4r01sU3o8n2CZZqXJh/gX4/dF8TP5QBvd62urAkNZUF5SnF87nWfnRM0tjb2nZ8LcpqccEpLpyR94WLBh95XvTgxtSlWFhvJE+NeRtOlm+cFti8tfcsqrDh29S/U4GSRisURqwEs9yg+vQYepvpYNyxxdxgc3jXZTxQ5K4y0DNYTm+KqaabT0wjl0YSwmGCFPEF//sBBFAAsOSoL1Mxe2YmRerfD0bioRT/KQeprN9Rvl3y/eVk83YkTA+ZEPpwL/+12uAbYN+FFHjUT36rDlHFSh8StM0i83HHnMQxI7J54ETrwI0/FhYlrihYlPQF08lrgvMTGxLvTHPwBZ/DwQ4rPEM4kXJpZLfObMNQXPXIrEPxNbQmJ87dx5IkSm09G9h3dr+88mMR92oYr3j0T+21n7Ve+2fZeKNHjRBoAIBXn8n97JnhihOY7oyzat0vbBlqgGRKsQVwn6VXa9CHtSTWERYf0QPpnUQX9LL9UhT7VO1hYuFmsIJ0f8BJfoB9hNzkJP/mo9Y9sDnw3l/pFK/0pr6QzFfoN2b8DrlpQrllftRKpOXEeICsTfIsCqgPRf6Nb/dLMJnKwcb9sbiBhbyAdKNswaq4Y36M9Tr1F67Q6+7tttS9tlwsamrK/hlGZUXNKo2FDsKhx1C7BgsYzxNIdebWRQrYyzh3OWE2QOVZbjpFl41uEsNjtYfLAKkkhPjkRLhLCHeAUdOG9FKI9xWJ9jPnY8/0PJ37uZ3yi1QNMUDrd/cNqzM92BzDeeL3FdTYWgTnvx2fs1anobZRt2ZNHFb7pnQd8KXXoLXnVA+sMx22n69Ren1Vpm3RtZE+y7rWmfJqzj1buLbOzHbM/n8+VepHbf6jnLuse5IindSEInx0oU21erOGl8dXcLrDtUu8TsehXvmrGy53Ltq6l1pGRZEU9/iJubvkKol5NAHXWg78foy+OH2QWe+SDNkTtn6DYxmzqddWpjMfXh/ActTwAEZtr5iSjPEjcHolr9yQfOVWKJjbniEKPza5jfY7TFl4FvurgzpJTF+yt2kwrViGBixwhMDYZeyQOsCFia2RZgZAsAbzqR0dMB4tqLUU+CN2S6H6Fo1rmmzVT7dDhsmYooYHpnwLmgHsQAQhRIbb1RMr0twOwWAIROzum5U+4hahW7872GXT7ElIMxx5BarsOeJ9yPMIy3fhQzfuTHuMaAn8Aq9H7cokD7icz872cy8mQ5W7gRZ54ASm6EP9Dd8Ce2U/0N1SF/IdvFJ9e7qXzJ85U3eMf4WsrriDe8NnwX8Zr492DF8z3ZS/j3YkTFe78RgKc8OYxyyRRPi2bLkCxcnq1F7bz/LBV0SuRLVUgnT5pi/uIQhQtz2MizZp5XeUpsZqocGSRX8OnTmRXTM1vEmSTPTfKizqMmOUdTFQFNoC3mYdxIVEpl4OKpRbgifcpRkhUCckRjENVRPHvih3k8PTR1mIRiWLKQUYlcyQXzrCuXYkyqdIH6RGiRXJAG7XN6iAmLtkvmzTPxl455NMN9I+6LBat5rAc91pvxsBZ5fE0S0QuowUoVUx8X2TPzVSicmJiHOEOkeaZ0Z6k8hPmIjWbzZEpNZcoVJZNknhbEqvjtJ4MulTChMjKiRBOCFKlw4oWiWSlWofHMtFJzJJCx/lDnvgYWEac+BiqeXYePHSVIdWkozpQI67yCXlUhJKR0JzaMPGYn5QsbTkUdc3jEXJ509CJEhiU/0WLEimMQzyoW+O5EEIPDTJ3bQ3IpUvUxX626eNdC+W29NHRWyhIkcVaym+fYYcMfTQ47ky6a5yJXXMMgB4MjkOpwX3gHJz081mKdLSN7391V6ActNK+7wx5RGZKIcHBeOLIwzzx3waVwDCeq1NdVcL1sitQf1y1zy5BhN4wZD1C4BDhcwy3cAxLQgAU8EIEMVHi4XKavPrqtSZoG6TZJvkPpPKJKadUhXVfaZkpPlTME3YT+zS7YK5GyfPNJlMvcZ3h6XVWgA+MAmbLkyJb7AKFgI0WKlShVpjywTlCpCpdlWWeBEF8UL3LvBgk3cPOJxsbJc6beXE9RnWN84Frt0uvpLcQPV/Zl9XiFl076I7txnPPVCQw/7qbUyEHHzI+NijNWPScQ6DkhQn7coaKXx+xomXmfKZnzSPf0osM9H7ZxLzqQ8kz6GSrj3a+zKqZcOadH89Od4cYO/yIR2j1UfN+xHNU58eC+zC9ppdy3shOeNESplZ6ciib5nuX6njFLnVvxkourLmi5xK1oVdIV5aydPb0yHY6aqJDqqJVo2p1rPownXSijyT2GLgw=")


@app.route("/icon.png")
def icon():
    return Response(ICON_PNG, mimetype="image/png",
                    headers={"Cache-Control": "max-age=86400"})


@app.route("/brand-font.woff2")
def brand_font():
    return Response(BRAND_FONT, mimetype="font/woff2",
                    headers={"Cache-Control": "max-age=604800"})


@app.route("/manifest.json")
def manifest():
    return jsonify(name=speaker_name(), short_name=speaker_name()[:12], start_url="/",
                   display="standalone", background_color="#F4EBDD",
                   theme_color="#4A3426",
                   icons=[{"src": "/icon.png", "sizes": "192x192", "type": "image/png"}])


# --------------------------------------------------------------------------
# Tiles
# --------------------------------------------------------------------------
@app.route("/tiles")
@needs_pin
def tiles_page():
    tokens = load_tokens()
    state = reader_state()
    on_reader = state.get("token")
    return render_template(
        "tiles.html", tab="tiles", tokens=tokens, on_reader=on_reader,
        on_reader_new=bool(on_reader and on_reader not in tokens and not refused_on_reader(state)),
        refused=refused_on_reader(state) or request.args.get("refused"),
        teaching=state.get("teaching"), reader_ok=state.get("reader_ok", True) is not False,
        saved=request.args.get("saved"), writing=request.args.get("writing"),
    )


@app.route("/coins")
@app.route("/coins/<path:_>")
def old_coins(_=None):
    return redirect(url_for("tiles_page"))


@app.route("/api/reader")
def api_reader():
    state = reader_state()
    return jsonify(token=state.get("token"), known=state.get("known"),
                   teaching=state.get("teaching"), write=state.get("write"),
                   refused=refused_on_reader(state),
                   reader_ok=state.get("reader_ok", True) is not False)


def ask_box_to_write(token_id, uri):
    """If the tile is sitting on the box, ask the tile program to save the
    music's link onto it. Returns the request id, or '' if the tile isn't there."""
    if local.is_local_uri(uri) or apple.is_apple_uri(uri):
        return ""          # a folder on this box's drive can't travel on the tile
    if reader_state().get("token") != token_id:
        return ""
    request_id = f"{time.time():.3f}"
    write_json(WRITE_REQUEST, {"token": token_id, "uri": uri, "id": request_id})
    return request_id


def save_tile(token_id, uri, name="", image=""):
    if tile_refused(token_id):
        return redirect(url_for("tiles_page", refused=1))
    if not name:
        name, image = describe(sp, uri)
    link_token(token_id, uri, name, image)
    if not setup_done() and pin_is_set():
        mark_setup_done()
    return redirect(url_for("tiles_page", saved=token_id,
                            writing=ask_box_to_write(token_id, uri) or None))


@app.route("/tiles/<token_id>", methods=["GET", "POST"])
@needs_pin
def tile_music_page(token_id):
    if tile_refused(token_id):
        return redirect(url_for("tiles_page", refused=1))
    query = request.values.get("q", "").strip()
    results, error = [], ""
    if request.method == "POST":
        uri = spotify_uri_from_link(request.form.get("link", ""))
        if not uri:
            error = ("That doesn't look like a Spotify link. In Spotify, open the album, "
                     "tap the three dots, then Share, then Copy link.")
        elif uri.split(":")[1] == "audiobook":
            error = ("That's an audiobook. Spotify doesn't let speakers like this one play "
                     "audiobooks yet. Albums, playlists, songs and podcasts all work.")
        else:
            return save_tile(token_id, uri)
    if query and signed_in():
        try:
            found = sp.search(q=query, type="album,playlist", limit=6)
            for album in (found.get("albums") or {}).get("items") or []:
                if not album:
                    continue
                artists = ", ".join(a["name"] for a in album.get("artists", []))
                results.append({
                    "uri": album["uri"], "kind": "Album",
                    "name": f"{album['name']} · {artists}" if artists else album["name"],
                    "image": (album.get("images") or [{}])[0].get("url", ""),
                })
            for pl in (found.get("playlists") or {}).get("items") or []:
                if not pl:
                    continue
                results.append({
                    "uri": pl["uri"], "kind": "Playlist", "name": pl["name"],
                    "image": (pl.get("images") or [{}])[0].get("url", ""),
                })
        except NotSignedIn:
            error = "Search needs the optional Spotify sign-in (Settings > Spotify)."
        except Exception as err:
            error = f"Search didn't work: {str(err)[:150]}"
    apple_on = apple_supported() and apple.configured()
    apple_results, apple_error = [], request.args.get("apple_error", "")
    aquery = request.args.get("aq", "").strip()
    if apple_on and aquery:
        try:
            apple_results = apple.search(aquery)
            if not apple_results:
                apple_error = "No Apple Music albums came back. Check Settings > Apple Music."
        except apple.AppleError as err:
            apple_error = f"Apple Music search didn't work: {str(err)[:150]}"
    current = load_tokens().get(token_id)
    try:
        shelves = artist_shelves(local.get_albums())
    except local.MPDError:
        shelves = []
    return render_template("tile_music.html", tab="tiles", token_id=token_id, query=query,
                           results=results, error=error, current=current,
                           can_search=signed_in(), shelves=shelves, dur=local.duration_text,
                           apple_on=apple_on, apple_results=apple_results,
                           apple_error=apple_error, aquery=aquery)


@app.route("/tiles/apple", methods=["POST"])
@needs_pin
def tile_apple():
    token_id = request.form["token"]
    uri = apple.parse_link(request.form.get("uri") or request.form.get("link", ""))
    if not uri:
        return redirect(url_for("tile_music_page", token_id=token_id, apple_error=(
            "That doesn't look like an Apple Music album or playlist link. In Apple Music, "
            "open it, tap the three dots, then Share, then Copy Link.")))
    name, image = request.form.get("name", ""), request.form.get("image", "")
    if not name and apple.configured():
        name, image = apple.describe_link(uri)
    return save_tile(token_id, uri, name or uri, image)


@app.route("/tiles/save", methods=["POST"])
@needs_pin
def tile_save():
    uri = request.form["uri"]
    if not spotify_uri_from_link(uri):
        abort(400)
    return save_tile(request.form["token"], uri, request.form.get("name", ""),
                     request.form.get("image", ""))


@app.route("/tiles/write", methods=["POST"])
@needs_pin
def tile_write():
    token_id = request.form["token"]
    entry = load_tokens().get(token_id)
    if not entry:
        abort(404)
    return redirect(url_for("tiles_page", writing=ask_box_to_write(token_id, entry["uri"]) or None,
                            saved=None))


@app.route("/tiles/rename", methods=["POST"])
@needs_pin
def tile_rename():
    tokens = load_tokens()
    token_id = request.form["token"]
    if token_id in tokens:
        tokens[token_id]["name"] = request.form.get("name", "").strip()[:80]
        save_tokens(tokens)
    return redirect(url_for("tile_page", token_id=token_id, renamed=1))


@app.route("/tile/<token_id>")
@needs_pin
def tile_page(token_id):
    tile = load_tokens().get(token_id)
    if not tile:
        return redirect(url_for("tiles_page"))
    return render_template("tile.html", tab="tiles", tid=token_id, t=tile,
                           on_reader=reader_state().get("token") == token_id,
                           renamed=request.args.get("renamed"), arterr=request.args.get("arterr"))


TILE_ART_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tile_art")
ART_EXTENSIONS = (".jpg", ".jpeg", ".png", ".webp", ".gif")


def album_art_url(key):
    """Web address of an album's cover picture, or '' if it has none."""
    if not key:
        return ""
    try:
        album = local.album_by_key(key)
        if album and local.cover_for(album):
            return "/art/album?key=" + urllib.parse.quote(key)
    except local.MPDError:
        pass
    return ""


@app.route("/art/album")
def art_album():
    try:
        album = local.album_by_key(request.args.get("key", ""))
        cover = local.cover_for(album) if album else None
    except local.MPDError:
        cover = None
    if not cover:
        return Response(status=404)
    return send_file(cover)


@app.route("/art/folder")
def art_folder():
    cover = local.find_cover(request.args.get("path", "").strip("/"))
    if not cover:
        abort(404)
    return send_file(cover)


def tile_art_file(token_id):
    if not re.fullmatch(r"[A-Za-z0-9]{2,40}", token_id or ""):
        return None
    for ext in ART_EXTENSIONS:
        path = os.path.join(TILE_ART_DIR, token_id + ext)
        if os.path.exists(path):
            return path
    return None


@app.route("/art/tile/<token_id>")
def art_tile(token_id):
    path = tile_art_file(token_id)
    if not path:
        abort(404)
    return send_file(path)


@app.route("/tile/<token_id>/art", methods=["POST"])
@needs_pin
def tile_art(token_id):
    tokens = load_tokens()
    entry = tokens.get(token_id)
    if not entry or not re.fullmatch(r"[A-Za-z0-9]{2,40}", token_id):
        abort(404)
    os.makedirs(TILE_ART_DIR, exist_ok=True)
    for ext in ART_EXTENSIONS:                      # drop any older picture
        try:
            os.remove(os.path.join(TILE_ART_DIR, token_id + ext))
        except OSError:
            pass
    if request.form.get("remove"):
        entry["image"] = album_art_url(local.path_of(entry["uri"])) if local.is_local_uri(entry["uri"]) else ""
        save_tokens(tokens)
        return redirect(url_for("tile_page", token_id=token_id, renamed=None))
    f = request.files.get("picture")
    name = (f.filename if f else "") or ""
    ext = os.path.splitext(name)[1].lower()
    if not f or ext not in ART_EXTENSIONS:
        return redirect(url_for("tile_page", token_id=token_id, arterr="Pick a picture (JPG or PNG)."))
    dest = os.path.join(TILE_ART_DIR, token_id + (".jpg" if ext == ".jpeg" else ext))
    raw = f.read(8 * 1024 * 1024 + 1)
    if len(raw) > 8 * 1024 * 1024:
        return redirect(url_for("tile_page", token_id=token_id, arterr="That picture is too big (8 MB at most)."))
    try:                                               # shrink phone photos if the box has Pillow
        import io
        from PIL import Image, ImageOps
        img = ImageOps.exif_transpose(Image.open(io.BytesIO(raw))).convert("RGB")
        img.thumbnail((700, 700))
        dest = os.path.join(TILE_ART_DIR, token_id + ".jpg")
        img.save(dest, "JPEG", quality=85)
    except ImportError:
        if len(raw) > 1_500_000:
            return redirect(url_for("tile_page", token_id=token_id,
                                    arterr="That picture is too big for this box (1.5 MB at most). Try a smaller one."))
        with open(dest, "wb") as out:
            out.write(raw)
    except Exception:
        return redirect(url_for("tile_page", token_id=token_id, arterr="That file isn't a picture the box can read."))
    entry["image"] = f"/art/tile/{token_id}?v={int(time.time())}"
    save_tokens(tokens)
    return redirect(url_for("tile_page", token_id=token_id, renamed=None))


def store_picture(upload, base):
    """Save an uploaded picture as base.jpg/.png (shrunk if Pillow is installed).
    Returns an error message, or None if it worked."""
    ext = os.path.splitext(upload.filename or "")[1].lower()
    if ext not in ART_EXTENSIONS:
        return "Pick a picture (JPG or PNG)."
    raw = upload.read(8 * 1024 * 1024 + 1)
    if len(raw) > 8 * 1024 * 1024:
        return "That picture is too big (8 MB at most)."
    os.makedirs(os.path.dirname(base), exist_ok=True)
    for old in ART_EXTENSIONS:
        try:
            os.remove(base + old)
        except OSError:
            pass
    try:
        import io
        from PIL import Image, ImageOps
        img = ImageOps.exif_transpose(Image.open(io.BytesIO(raw))).convert("RGB")
        img.thumbnail((700, 700))
        img.save(base + ".jpg", "JPEG", quality=85)
    except ImportError:
        if len(raw) > 1_500_000:
            return "That picture is too big for this box (1.5 MB at most). Try a smaller one."
        with open(base + (".jpg" if ext == ".jpeg" else ext), "wb") as out:
            out.write(raw)
    except Exception:
        return "That file isn't a picture the box can read."
    return None


@app.route("/music/cover", methods=["POST"])
@needs_pin
def music_cover():
    """Choose (or remove) the cover picture for an album."""
    key = request.form.get("key", "").strip("/")
    if not key or not local.safe_join(key.partition("|")[0]):
        abort(400)
    base = local.custom_cover_base(key)
    if request.form.get("remove"):
        for ext in ART_EXTENSIONS:
            try:
                os.remove(base + ext)
            except OSError:
                pass
    else:
        picture = request.files.get("picture")
        if not picture or not picture.filename:
            return redirect(url_for("music_album", key=key, error="Pick a picture first."))
        err = store_picture(picture, base)
        if err:
            return redirect(url_for("music_album", key=key, error=err))
    url = album_art_url(key)
    tokens = load_tokens()                         # tiles that play this album show it too
    for tid, entry in tokens.items():
        if entry.get("uri") == "local:" + key and not tile_art_file(tid):
            entry["image"] = url
    save_tokens(tokens)
    return redirect(url_for("music_album", key=key, message="Cover saved." if url else "Cover removed."))


@app.route("/tiles/delete", methods=["POST"])
@needs_pin
def tile_delete():
    tokens = load_tokens()
    tokens.pop(request.form["token"], None)
    save_tokens(tokens)
    return redirect(url_for("tiles_page"))


# --------------------------------------------------------------------------
# Local music: files on a USB stick or on the box's memory card
# --------------------------------------------------------------------------
UPLOAD_TEMP = os.path.join(os.path.dirname(os.path.abspath(__file__)), "uploads_tmp")
os.makedirs(UPLOAD_TEMP, exist_ok=True)
tempfile.tempdir = UPLOAD_TEMP      # big uploads wait on the memory card, not in memory
UPLOAD_EXTRAS = (".jpg", ".jpeg", ".png", ".cue")
SPACE_RESERVE = 300 * 1024 * 1024   # always leave this much free on the memory card


def safe_name(text):
    text = re.sub(r'[\x00-\x1f<>:"|?*\\]', "_", text or "").strip(". ")
    return text[:100]


def safe_folder(text):
    """'Bedtime / Stories' -> 'Bedtime/Stories'; never leaves the music folder."""
    parts = [safe_name(p) for p in (text or "").replace("\\", "/").split("/")]
    parts = [p for p in parts if p and p not in (".", "..")]
    if not parts or parts[0].lower() == "usb":
        parts = ["Uploads"] + parts[1:] if parts and parts[0].lower() == "usb" else ["Uploads"]
    return "/".join(parts[:3])


def card_root():
    """Where the real memory card is mounted while unplug protection is on (None when off)."""
    if os.environ.get("MB_SYSROOT"):          # simulation tests only
        lower = os.path.join(os.environ["MB_SYSROOT"], "lower")
        return lower if unplug_proof_on() and os.path.isdir(lower) else None
    try:
        with open("/proc/mounts") as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 4 and parts[1] == "/" and parts[2] == "overlay":
                    m = re.search(r"lowerdir=([^,]+)", parts[3])
                    if m:
                        return m.group(1).split(":")[0]
    except OSError:
        pass
    return None


def music_free_bytes():
    """Free room on the memory card for music (the real card, also under protection)."""
    lower = card_root()
    for path in ([lower + local.MUSIC_DIR, lower] if lower else []) + [local.MUSIC_DIR]:
        try:
            return shutil.disk_usage(path).free
        except OSError:
            continue
    return 0


def music_storage():
    """Where added music is written:
    'plain'  - unplug protection is off: the music folder is simply writable
    'card'   - protection is on and ~/Music is the memory card's own folder (2.5.5),
               unlocked by the helper while music is being added
    'memory' - protection is on but the box hasn't restarted since 2.5.5 (or the
               helper is older): music waits in memory until the save keeper copies it"""
    if not unplug_proof_on():
        return "plain"
    if os.environ.get("MB_SYSROOT"):          # simulation tests only
        bound = os.path.exists(os.path.join(os.environ["MB_SYSROOT"], "MUSIC_BOUND"))
    else:
        bound = os.path.ismount(local.MUSIC_DIR)
    return "card" if bound else "memory"


_card = {"until": 0.0}
_card_lock = threading.Lock()


def run_music_helper(command):
    test = os.environ.get("MB_TEST_ADMIN")    # simulation tests only
    cmd = ["python3", "-I", test, command] if test else ["sudo", "-n", ADMIN, command]
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=60).returncode
    except (OSError, subprocess.TimeoutExpired):
        return 1


def card_open():
    """Unlock the memory card for adding or removing music (a few minutes at a time,
    renewed while music keeps arriving). True when the music folder can be written."""
    if music_storage() != "card":
        return True
    with _card_lock:
        if time.time() < _card["until"] - 60:
            return True
        if run_music_helper("music-open") != 0:
            return False
        _card["until"] = time.time() + 180
        return True


def card_close():
    """Lock the memory card again (also happens by itself a few minutes later)."""
    if music_storage() != "card":
        return
    with _card_lock:
        if _card["until"] > time.time():
            run_music_helper("music-close")
        _card["until"] = 0.0


def upload_room_bytes():
    """While unplug protection is on, new files wait in the box's memory (RAM) until
    the save keeper copies them to the card, so that limits one upload too.
    (Not from 2.5.5 once the box has restarted: music goes straight to the card.)"""
    if music_storage() != "memory":
        return None
    try:
        tmpfs = shutil.disk_usage(local.MUSIC_DIR).free
    except OSError:
        tmpfs = 0
    # The memory layer's "free" can be larger than the memory really left (programs
    # use it too): a small board froze that way. Count what's actually available.
    return max(0, min(tmpfs, mem_available() - MEMORY_KEEP))


MEMORY_KEEP = 160 * 1024 * 1024     # memory always left for the box's own programs


def mem_available():
    """Bytes of memory the box can still use (MemAvailable)."""
    if os.environ.get("MB_TEST_MEMAVAIL"):     # simulation tests only
        return int(os.environ["MB_TEST_MEMAVAIL"])
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemAvailable:"):
                    return int(line.split()[1]) * 1024
    except (OSError, ValueError):
        pass
    return 0


def artist_shelves(albums):
    """[(artist, [albums oldest first])] in the order albums() already sorted them."""
    shelves = []
    for a in albums:
        name = a["artist"] or "Unknown artist"
        if shelves and shelves[-1][0] == name:
            shelves[-1][1].append(a)
        else:
            shelves.append((name, [a]))
    return shelves


def tiles_by_album():
    """{album key: [tile ids]} for tiles that play local albums."""
    out = {}
    for tid, entry in load_tokens().items():
        if local.is_local_uri(entry.get("uri", "")):
            out.setdefault(local.path_of(entry["uri"]), []).append(tid)
    return out


def local_playing_key():
    """The album key the box is playing (or paused on) from local music, or None."""
    try:
        if local.source() == "local" and local.status().get("state") in ("play", "pause"):
            return local.loaded_path()
    except Exception:
        pass
    return None


@app.route("/library")
@app.route("/music")
@needs_pin
def music_page():
    """The Library tab: every album and audiobook on the box (USB stick and memory card)."""
    os.makedirs(local.MUSIC_DIR, exist_ok=True)
    albums, player_ok, player = [], True, None
    try:
        albums = local.get_albums()
    except local.MPDError:
        player_ok = False
        player = player_info()
    places = local.load_places()
    books = [a for a in albums if a["book"]]
    progress = {a["key"]: local.book_progress(a, places) for a in books}
    started = sorted((a for a in books if progress[a["key"]]),
                     key=lambda a: -progress[a["key"]]["saved"])
    music = [a for a in albums if not a["book"]]
    return render_template(
        "music.html", tab="library", albums=music, shelves=artist_shelves(music),
        books=books, started=started[:6], progress=progress, player_ok=player_ok, player=player,
        dur=local.duration_text, album_count=len(albums), artist_count=len({a["artist"] for a in music}),
        tiled=tiles_by_album(), playing=local_playing_key(), usb=local.usb_present(),
        message=request.args.get("message"), error=request.args.get("error"))


MPD_UNIT = "/etc/systemd/system/musicbox-mpd.service"


def player_info():
    """The music player behind the Library (the box's own MPD): "ok", "stopped"
    (set up but not answering) or "missing" (never set up: boxes that only had
    updates before 2.5.7), and whether the app can fix it by itself."""
    sim = os.environ.get("MB_SYSROOT")          # simulation tests only
    unit = os.path.join(sim, MPD_UNIT.lstrip("/")) if sim else MPD_UNIT
    if local.ping():
        state = "ok"
    elif os.path.exists(unit):
        state = "stopped"
    else:
        state = "missing"
    protected = unplug_proof_on()
    return {"state": state, "job": job_view("player"), "admin": admin_ready(),
            "can_install": admin_ready() and helper_knows("player-install")
                           and (auto_ready() or not protected),
            "can_start": admin_ready() and helper_knows("player-start"),
            "quick": not protected and held()}


@app.route("/library/player", methods=["GET", "POST"])
@needs_pin
def library_player():
    """Set up the music player (one tap; the box restarts by itself), or start it
    again if it has stopped."""
    error = ""
    if request.method == "POST":
        info = player_info()
        action = request.form.get("action", "")
        if action == "start":
            if info["state"] == "ok":
                return redirect(url_for("music_page"))
            if not info["can_start"]:
                return redirect(url_for("music_page", error="Restart the box (Settings) to start the music player again."))
            ok, why = start_job("player-start")
            if ok:
                return redirect(url_for("music_page", message="The music player is running again."))
            if "not installed" in why:
                return redirect(url_for("music_page"))
            return redirect(url_for("music_page", error="The music player didn't start. Restart the box (Settings) and try again."))
        if info["job"]["running"]:
            return redirect(url_for("library_player"))
        if info["state"] == "ok":
            return redirect(url_for("music_page", message="The music player is already set up."))
        if not info["can_install"]:
            error = ("This box needs the latest box software before it can set up the music player "
                     "from the app. Check Settings > Software updates.")
        else:
            ok, why = start_install("player-install")
            if ok:
                time.sleep(1)
                return redirect(url_for("library_player"))
            error = f"Couldn't start setting up the music player ({why or 'no answer'})."
    return render_template("player_install.html", tab="library", error=error, player=player_info())


@app.route("/library/add")
@needs_pin
def library_add():
    """Adding music: USB stick, uploads from the phone, and looking for new files."""
    os.makedirs(local.MUSIC_DIR, exist_ok=True)
    return render_template(
        "music_add.html", tab="library", usb=local.usb_present(), storage=music_storage(),
        free_gb=round(music_free_bytes() / 1e9, 1), player_ok=local.ping(),
        message=request.args.get("message"), error=request.args.get("error"))


@app.route("/library/tile")
@needs_pin
def library_tile():
    """Make a tile for an album: set a tile on the box, then confirm."""
    key = request.args.get("key", "").strip("/")
    try:
        album = local.album_by_key(key)
    except local.MPDError:
        album = None
    if not album:
        return back_to_music(error="That album isn't on the box any more.")
    state = reader_state()
    token = state.get("token")
    tokens = load_tokens()
    return render_template(
        "music_tile.html", tab="library", a=album, art=album_art_url(key), token=token,
        current=tokens.get(token) if token else None,
        same=bool(token and tokens.get(token, {}).get("uri") == "local:" + key),
        refused=refused_on_reader(state),
        others=[tokens[t] | {"id": t} for t in tiles_by_album().get(key, []) if t in tokens],
        reader_ok=state.get("reader_ok", True) is not False)


@app.route("/music/album")
@needs_pin
def music_album():
    key = request.args.get("key", "").strip("/")
    try:
        album = local.album_by_key(key)
        songs = local.songs_in(key) if album else []
    except local.MPDError:
        album, songs = None, []
    if not album:
        return back_to_music(error="That album isn't on the box any more.")
    tracks = [{"i": i, "n": local.number_of(s.get("Track")) or i + 1,
               "title": s.get("Title") or os.path.splitext(os.path.basename(s["file"]))[0],
               "length": local.duration_text(local.seconds_of(s)) if local.seconds_of(s) else ""}
              for i, s in enumerate(songs)]
    tokens = load_tokens()
    tiles = [tokens[t] | {"id": t} for t in tiles_by_album().get(key, []) if t in tokens]
    playing = local_playing_key() == key
    now_file = local.current_song().get("file") if playing else None
    return render_template(
        "album.html", tab="library", a=album, tracks=tracks, dur=local.duration_text,
        art=album_art_url(key), remembered=key in local.load_places(), locked=False,
        progress=local.book_progress(album), tiles=tiles, playing=playing,
        now_index=next((i for i, s in enumerate(songs) if s["file"] == now_file), None),
        message=request.args.get("message"),
        error=request.args.get("error"), has_custom=bool(local.custom_cover(key)))


def back_to_music(**kw):
    return redirect(url_for("music_page", **kw))


def back_to_add(**kw):
    return redirect(url_for("library_add", **kw))


@app.route("/music/upload", methods=["POST"])
@needs_pin
def music_upload():
    # Check sizes BEFORE reading the form: reading it stores the files first (in the
    # box's memory under unplug protection), which is what froze a small board.
    if (request.content_length or 0) + SPACE_RESERVE > music_free_bytes():
        return back_to_add(error="There isn't enough room on the box's memory card for that. "
                                   "Try a USB stick instead.")
    # This older one-form upload waits in memory first (even when music goes to the
    # card), so it's only for a few songs; the Add music page sends in pieces instead.
    room = upload_room_bytes() if music_storage() == "memory" else (
        max(0, mem_available() - MEMORY_KEEP) if unplug_proof_on() else None)
    if room is not None and 2 * (request.content_length or 0) + 64 * 1024 * 1024 > room:
        return back_to_add(error="That's more than the box can take in one go. Add a few albums "
                                   "at a time (restarting the box first gives it the most room), "
                                   "or use a USB stick.")
    files = [f for f in request.files.getlist("files") if f and f.filename]
    if not files:
        return back_to_add(error="Pick some music files first.")
    fallback = safe_folder(request.form.get("folder"))     # only for files with no album tag
    if not local.safe_join(fallback):
        abort(400)
    incoming = os.path.join(UPLOAD_TEMP, f"incoming-{int(time.time() * 1000)}")
    os.makedirs(incoming, exist_ok=True)
    skipped = 0
    try:
        for f in files:
            name = safe_name(os.path.basename(f.filename.replace("\\", "/")))
            if not name.lower().endswith(local.AUDIO_EXTENSIONS + UPLOAD_EXTRAS):
                skipped += 1
                continue
            f.save(os.path.join(incoming, unique_incoming(incoming, name)))
        if not card_open():
            return back_to_add(error="The box couldn't get its memory card ready. Restart the box and try again.")
        try:
            result = local.file_batch(incoming, fallback)
        finally:
            card_close()
    finally:
        shutil.rmtree(incoming, ignore_errors=True)
    skipped += result["skipped"]
    if result["added"]:
        local.update_in_background()
    names = [(f"{a} \u00b7 {b}" if a else b) for a, b in result["albums"]]
    msg = f"Added {result['added']} track{'s' if result['added'] != 1 else ''}"
    if names:
        msg += " to " + ", ".join(names[:3]) + (f" and {len(names) - 3} more" if len(names) > 3 else "")
    msg += "."
    if skipped:
        msg += f" Skipped {skipped} that weren't music."
    if result["added"] and room is not None:
        msg += " Give it a minute to save before unplugging the box."
    return back_to_add(message=msg) if result["added"] else back_to_add(error="Nothing was added. " + msg)


# --------------------------------------------------------------------------
# Adding music from a computer (2.5.5): the page checks the files first, then
# sends them one at a time in small pieces straight into the music folder on the
# memory card. A piece that doesn't arrive is simply sent again, and a song that
# was half sent carries on from where it stopped (the same folder dropped again).
# --------------------------------------------------------------------------
INCOMING = os.path.join(local.MUSIC_DIR, ".incoming")   # half-sent songs (hidden from the player)
PIECE_MAX = 16 * 1024 * 1024
PICTURE_MAX = 20 * 1024 * 1024
WHY_TEXT = {
    "protected": "Locked by Apple: an Apple Music download or an older iTunes purchase. Only Apple's apps can play it.",
    "video": "A video, not music.",
    "not-music": "Not a music file the box can play.",
}


def incoming_path(rel, size):
    """Where a song being sent waits until it has fully arrived."""
    name = safe_name(os.path.basename(rel.replace("\\", "/"))) or "song"
    key = hashlib.sha1(f"{rel}\0{size}".encode()).hexdigest()[:20]
    return os.path.join(INCOMING, key, name), name


def fallback_folder(rel):
    """For songs with no album tag: the folders they were dragged in with (last two)."""
    parts = [p for p in rel.replace("\\", "/").split("/")[:-1] if p]
    return safe_folder("/".join(parts[-2:])) if parts else "Uploads"


def clear_old_incoming(days=7):
    try:
        for d in os.listdir(INCOMING):
            full = os.path.join(INCOMING, d)
            if time.time() - os.path.getmtime(full) > days * 86400:
                shutil.rmtree(full, ignore_errors=True)
    except OSError:
        pass


@app.route("/api/import/check", methods=["POST"])
@needs_pin
def import_check():
    """The page lists what it is about to send; say which songs the box already has
    and how far any half-sent ones got."""
    data = request.get_json(silent=True) or {}
    files = data.get("files") or []
    have = local.library_index()
    known, partial, need = [], {}, 0
    for i, item in enumerate(files[:50000]):
        try:
            rel, size = str(item[0]), int(item[1])
        except (TypeError, ValueError, IndexError):
            continue
        name = os.path.basename(rel.replace("\\", "/")).lower()
        if (name, size) in have:
            known.append(i)
            continue
        path, _ = incoming_path(rel, size)
        try:
            got = os.path.getsize(path)
            if 0 < got < size:
                partial[i] = got
        except OSError:
            pass
        need += size - partial.get(i, 0)
    free = max(0, music_free_bytes() - SPACE_RESERVE)
    room = upload_room_bytes()
    return jsonify({"have": known, "partial": partial, "need": need, "free": free,
                    "storage": music_storage(),
                    "memory": None if room is None else max(0, room - 64 * 1024 * 1024)})


@app.route("/api/import/send", methods=["POST"])
@needs_pin
def import_send():
    """One piece of one file: ?p=path as dragged&s=total size&o=where this piece starts.
    Pictures carry &dest=<album folder> (the folder its songs went to)."""
    rel = request.args.get("p", "")
    try:
        size, offset = int(request.args.get("s", "")), int(request.args.get("o", ""))
    except ValueError:
        abort(400)
    dest_rel = request.args.get("dest")
    path, name = incoming_path(rel, size)
    lower = name.lower()
    picture = dest_rel is not None
    if picture:
        dest = local.safe_join(dest_rel.strip("/"))
        if (not lower.endswith(local.IMAGE_EXTENSIONS) or size > PICTURE_MAX or not dest_rel.strip("/")
                or dest_rel.strip("/").split("/")[0] == "USB" or not dest or not os.path.isdir(dest)):
            return jsonify({"status": "skipped", "why": "not-music"})
    else:
        why = local.why_unplayable(name)
        if why:
            return jsonify({"status": "skipped", "why": why, "text": WHY_TEXT[why]})
    if size < 0 or offset < 0 or offset > size:
        abort(400)
    if offset == 0:
        if size + SPACE_RESERVE > music_free_bytes():
            return jsonify({"status": "full", "text": "The box's memory card is full."}), 507
        room = upload_room_bytes()
        if room is not None and size + 64 * 1024 * 1024 > room:
            return jsonify({"status": "memory", "text": "The box needs a restart before it can take more."}), 507
    room = upload_room_bytes()
    if room is not None and min(size - offset, PIECE_MAX) + 32 * 1024 * 1024 > room:
        return jsonify({"status": "memory", "text": "The box needs a restart before it can take more."}), 507
    if not card_open():
        return jsonify({"status": "locked", "text": "The box couldn't get its memory card ready."}), 503
    os.makedirs(os.path.dirname(path), exist_ok=True)
    try:
        got = os.path.getsize(path)
    except OSError:
        got = 0
    if got != offset:
        return jsonify({"status": "offset", "offset": got}), 409
    want = min(size - offset, PIECE_MAX)
    with open(path, "ab") as out:
        left = want
        while left > 0:
            piece = request.stream.read(min(left, 1024 * 1024))
            if not piece:
                break
            out.write(piece)
            left -= len(piece)
        if offset + want == size and left == 0:
            out.flush()
            os.fsync(out.fileno())
    got = os.path.getsize(path)
    if got < size:
        return jsonify({"status": "partial", "offset": got})
    folder = os.path.dirname(path)
    try:
        if picture:
            if os.path.exists(os.path.join(dest, name)):
                return jsonify({"status": "have"})
            shutil.move(path, os.path.join(dest, name))
            return jsonify({"status": "added", "folder": dest_rel.strip("/")})
        why = local.why_unplayable(path, name)
        if why:
            return jsonify({"status": "skipped", "why": why, "text": WHY_TEXT[why]})
        placed, (artist, album) = local.place_file(path, name, fallback_folder(rel))
        return jsonify({"status": "added", "folder": placed, "artist": artist, "album": album})
    finally:
        shutil.rmtree(folder, ignore_errors=True)


@app.route("/api/import/done", methods=["POST"])
@needs_pin
def import_done():
    """The page has sent everything (or stopped): look for the new music, lock the card."""
    if card_open():
        clear_old_incoming()
        try:
            os.rmdir(INCOMING)          # only when nothing is half sent
        except OSError:
            pass
    card_close()
    local.update_in_background()
    return jsonify({"ok": True})


def unique_incoming(folder, name):
    return local.unique_name(folder, name)


@app.route("/music/details", methods=["POST"])
@needs_pin
def music_details():
    """Show an album under a different name/artist/year (the files stay as they are)."""
    key = request.form.get("key", "").strip("/")
    if not key or not local.safe_join(key.partition("|")[0]):
        abort(400)
    local.set_override(key, request.form.get("album", ""), request.form.get("artist", ""),
                       request.form.get("year", ""))
    info = local.album_by_key(key)
    if info:                                       # tiles that play it carry the new name
        tokens = load_tokens()
        for entry in tokens.values():
            if entry.get("uri") == "local:" + key:
                entry["name"] = f"{info['album']} \u00b7 {info['artist']}" if info["artist"] else info["album"]
                entry["album"], entry["artist"] = info["album"], info["artist"]
        save_tokens(tokens)
    return redirect(url_for("music_album", key=key, message="Details saved."))


@app.route("/music/delete", methods=["POST"])
@needs_pin
def music_delete():
    rel = request.form.get("path", "").strip("/")
    full = local.safe_join(rel)
    if not rel or "|" in rel or rel.split("/")[0] == "USB" or not full or not os.path.isdir(full):
        abort(400)
    if not card_open():
        return back_to_music(error="The box couldn't get its memory card ready. Restart the box and try again.")
    try:
        shutil.rmtree(full, ignore_errors=True)
    finally:
        card_close()
    local.forget_place(rel)
    local.update_in_background()
    return back_to_music(message=f"Removed {rel}.")


@app.route("/music/play", methods=["POST"])
@needs_pin
def music_play():
    rel = request.form.get("path", "").strip("/")
    track = request.form.get("track", "")
    try:
        try:
            speaker_call("/player/pause")
        except SpeakerOffline:
            pass
        local.play_path(rel, start_at=int(track) if track.isdigit() else None)
    except (local.NoMusic, local.MPDError) as err:
        return back_to_music(error=str(err))
    now_cache["when"] = 0.0
    return redirect("/")


@app.route("/music/restart", methods=["POST"])
@needs_pin
def music_restart():
    rel = request.form.get("path", "").strip("/")
    local.forget_place(rel)
    if request.form.get("back") == "album":
        return redirect(url_for("music_album", key=rel, message="It will start from the beginning next time."))
    return back_to_music(message=f"{os.path.basename(rel)} will start from the beginning next time.")


@app.route("/music/rescan", methods=["POST"])
@needs_pin
def music_rescan():
    local.update(wait=True)
    local.forget_album_cache()
    return back_to_add(message="Looked for new music.")


@app.route("/tiles/local", methods=["POST"])
@needs_pin
def tile_local():
    rel = request.form.get("path", "").strip("/")
    if not rel or not local.safe_join(rel.partition("|")[0]):
        abort(400)
    folder, sep, album_name = rel.partition("|")
    if not local.safe_join(folder):
        abort(400)
    uri = local.make_uri(folder, album_name if sep else None)
    info = None
    try:
        info = local.album_by_key(rel)
    except local.MPDError:
        pass
    name = (f"{info['album']} \u00b7 {info['artist']}" if info and info["artist"]
            else info["album"] if info else os.path.basename(folder))
    if tile_refused(request.form["token"]):
        return redirect(url_for("tiles_page", refused=1))
    link_token(request.form["token"], uri, name, album_art_url(rel), on_tile=False)
    if info:                                  # so the tile can find its album again if files move
        tokens = load_tokens()
        tokens[request.form["token"]].update(album=info["album"], artist=info["artist"],
                                            kind="Audiobook" if info["book"] else "Album")
        save_tokens(tokens)
    if not setup_done() and pin_is_set():
        mark_setup_done()
    if request.form.get("back") == "album":
        return redirect(url_for("music_album", key=rel, message="Tile saved. Set it on the box any time to play this."))
    return redirect(url_for("tiles_page", saved=request.form["token"]))


# --------------------------------------------------------------------------
# Wi-Fi (NetworkManager, through the nmcli command)
# --------------------------------------------------------------------------
def nm(*args, timeout=30):
    try:
        result = subprocess.run(["nmcli", *args], capture_output=True, text=True,
                                timeout=timeout)
        return result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired:
        return 1, "", "timed out"


def split_terse(line):
    """nmcli -t output uses ':' between fields and '\\:' inside them."""
    parts, cur, escaped = [], "", False
    for ch in line:
        if escaped:
            cur += ch
            escaped = False
        elif ch == "\\":
            escaped = True
        elif ch == ":":
            parts.append(cur)
            cur = ""
        else:
            cur += ch
    parts.append(cur)
    return parts


def current_wifi():
    code, out, _ = nm("-t", "-f", "ACTIVE,SSID", "device", "wifi", "list", "--rescan", "no",
                      timeout=10)
    for line in out.splitlines():
        fields = split_terse(line)
        if len(fields) >= 2 and fields[0] == "yes":
            return fields[1]
    return ""


def wifi_connected():
    """True if wlan0 is joined to a normal network (not our setup hotspot)."""
    code, out, _ = nm("-t", "-f", "DEVICE,STATE,CONNECTION", "device", timeout=10)
    for line in out.splitlines():
        fields = split_terse(line)
        if len(fields) >= 3 and fields[0] == "wlan0":
            return fields[1] == "connected" and fields[2] != HOTSPOT_NAME
    return False


nearby_cache = {"list": [], "when": 0.0, "channel": 6}


def scan_nearby(fresh=True):
    """Networks around the box. fresh=False reads NetworkManager's last list,
    which is instant; a fresh scan can take up to 30 seconds."""
    code, out, _ = nm("-t", "-f", "SSID,SIGNAL,SECURITY,CHAN", "device", "wifi", "list",
                      "--rescan", "yes" if fresh else "no", timeout=30 if fresh else 8)
    best, crowd = {}, {1: 0, 6: 0, 11: 0}
    for line in out.splitlines():
        fields = split_terse(line)
        if len(fields) >= 4 and fields[3].isdigit():
            chan = int(fields[3])
            for c in crowd:                 # 2.4 GHz channels overlap 4 either side
                if abs(chan - c) < 5:
                    crowd[c] += 1 + int(fields[1] or 0) / 25
        if len(fields) < 3 or not fields[0] or fields[0].startswith(HOTSPOT_SSID_PREFIX):
            continue
        ssid, signal, security = fields[0], int(fields[1] or 0), fields[2]
        if ssid not in best or signal > best[ssid]["signal"]:
            best[ssid] = {"ssid": ssid, "signal": signal,
                          "secure": bool(security and security != "--")}
    if out.strip():
        nearby_cache["channel"] = min(crowd, key=crowd.get)
    if best:
        nearby_cache.update(list=sorted(best.values(), key=lambda n: -n["signal"]),
                            when=time.time())
    return nearby_cache["list"]


scan_lock = threading.Lock()


def scan_in_background():
    """Refresh the nearby list without making anyone wait for it."""
    def worker():
        if scan_lock.acquire(blocking=False):
            try:
                scan_nearby()
            finally:
                scan_lock.release()
    threading.Thread(target=worker, daemon=True).start()


@app.route("/api/wifi/nearby")
@needs_pin
def api_wifi_nearby():
    return jsonify(nearby=nearby_cache["list"], scanning=scan_lock.locked())


def saved_networks():
    code, out, _ = nm("-t", "-f", "NAME,TYPE", "connection", "show", timeout=10)
    networks = []
    for line in out.splitlines():
        fields = split_terse(line)
        if len(fields) >= 2 and fields[1] == "802-11-wireless" and fields[0] != HOTSPOT_NAME:
            _, ssid, _ = nm("-g", "802-11-wireless.ssid", "connection", "show", fields[0],
                            timeout=10)
            networks.append({"profile": fields[0], "ssid": ssid.strip() or fields[0]})
    return networks


def save_network(ssid, password):
    """Create (or replace) a saved network. Returns an error message or ''."""
    profile = f"Music Box: {ssid}"
    nm("connection", "delete", "id", profile, timeout=15)
    args = ["connection", "add", "type", "wifi", "ifname", "wlan0",
            "con-name", profile, "ssid", ssid, "connection.autoconnect", "yes"]
    if password:
        args += ["wifi-sec.key-mgmt", "wpa-psk", "wifi-sec.psk", password]
    code, _, err = nm(*args, timeout=20)
    return "" if code == 0 else (err.strip() or "Couldn't save that network.")


def join_later(ssid):
    """Leave setup mode and join the new network (after the page has loaded)."""
    def worker():
        time.sleep(3)
        setup.stop_hotspot()
        code, _, err = nm("connection", "up", "id", f"Music Box: {ssid}", timeout=45)
        if code != 0:
            print(f"Couldn't join {ssid}: {err.strip()}", flush=True)
        elif wifi_connected():
            check_after_joining()
    threading.Thread(target=worker, daemon=True).start()


@app.route("/wifi", methods=["GET", "POST"])
@needs_pin
def wifi_page():
    message, error = "", ""
    if request.method == "POST":
        ssid = (request.form.get("ssid_typed") or request.form.get("ssid") or "").strip()
        password = request.form.get("password", "")
        if not ssid:
            error = "Pick a network or type its name."
        elif password and len(password) < 8:
            error = "Wi-Fi passwords are at least 8 characters."
        else:
            error = save_network(ssid, password)
            if not error:
                if setup.hotspot_on:
                    join_later(ssid)
                    return render_template("joining.html", tab="", ssid=ssid, host=address(),
                                           fallback=fallback_host() + ".local",
                                           first_time=not setup_done())
                message = (f"Saved {ssid}. The box will use it whenever it's "
                           "nearby.")
    if setup.hotspot_on:
        nearby = nearby_cache["list"]          # can't scan while hosting the hotspot
    else:
        # This used to wait for a full Wi-Fi scan (up to 30 seconds), so tapping
        # Wi-Fi in Settings looked like it did nothing. Now the page opens at once
        # with the last known list, and a fresh scan fills in a moment later.
        nearby = scan_nearby(fresh=False) or nearby_cache["list"]
        scan_in_background()
    return render_template("wifi.html", tab="" if setup.hotspot_on else "settings",
                           nearby=nearby, saved=saved_networks(),
                           current=current_wifi(), setup_mode=setup.hotspot_on,
                           first_time=not setup_done(), step_count=len(SETUP_STEPS),
                           message=message, error=error)


@app.route("/wifi/forget", methods=["POST"])
@needs_pin
def wifi_forget():
    profile = request.form["profile"]
    code, out, _ = nm("-t", "-f", "NAME", "connection", "show", "--active", timeout=10)
    active = [split_terse(line)[0] for line in out.splitlines()]
    if profile not in active and profile != HOTSPOT_NAME:
        nm("connection", "delete", "id", profile, timeout=15)
    return redirect(url_for("wifi_page"))


def has_saved_networks():
    return bool(saved_networks())


def phones_on_hotspot():
    """How many phones are joined to our setup network right now."""
    try:
        r = subprocess.run(["iw", "dev", "wlan0", "station", "dump"], capture_output=True,
                           text=True, timeout=5)
        if r.returncode == 0:
            return r.stdout.count("Station ")
    except (OSError, subprocess.TimeoutExpired):
        pass
    try:                     # no "iw": fall back to who answered us lately
        r = subprocess.run(["ip", "neigh", "show", "dev", "wlan0"], capture_output=True,
                           text=True, timeout=5)
        return sum(1 for l in r.stdout.splitlines()
                   if l.startswith("10.42.0.") and any(w in l for w in ("REACHABLE", "DELAY", "PROBE")))
    except (OSError, subprocess.TimeoutExpired):
        return 0


class SetupMode:
    """Watches Wi-Fi. No known network for a while -> start the setup hotspot.

    The hotspot must never hang around for days (on 2026-11-12 a box stuck in
    setup mode wrecked the Wi-Fi of the box next to it), so:
      - while a phone is joined (or used the page in the last 2 minutes) it stays on;
      - otherwise, every 3 minutes it steps aside for 45 seconds to look for a saved network;
      - after 20 minutes with nobody joined it switches off for good and the box
        just keeps trying its saved Wi-Fi. Unplug/replug brings setup mode back.
    """

    def __init__(self):
        self.hotspot_on = False
        self.started = 0.0
        self.last_visit = 0.0
        self.last_peek = 0.0
        self.idle_since = 0.0
        self.gave_up = False
        self.has_saved = True
        self.offline_since = None

    def start_hotspot(self):
        scan_nearby()   # remember what's around; can't scan once the hotspot is up
        self.has_saved = has_saved_networks()
        nm("connection", "delete", "id", HOTSPOT_NAME, timeout=15)
        # Plain WPA2 (no WPA3/PMF): some phones won't join the Pi's hotspot otherwise.
        code, _, err = nm("connection", "add", "type", "wifi", "ifname", "wlan0",
                          "con-name", HOTSPOT_NAME, "autoconnect", "no", "ssid", setup_ssid(),
                          "802-11-wireless.mode", "ap", "802-11-wireless.band", "bg",
                          "802-11-wireless.channel", str(nearby_cache.get("channel", 6)),
                          "ipv4.method", "shared", "ipv4.addresses", f"{HOTSPOT_ADDRESS}/24",
                          "ipv6.method", "disabled",
                          "wifi-sec.key-mgmt", "wpa-psk", "wifi-sec.psk", HOTSPOT_PASSWORD,
                          "wifi-sec.proto", "rsn", "wifi-sec.pairwise", "ccmp",
                          "wifi-sec.group", "ccmp", "wifi-sec.pmf", "disable", timeout=20)
        if code == 0:
            code, _, err = nm("connection", "up", "id", HOTSPOT_NAME, timeout=30)
        if code == 0:
            now = time.time()
            self.hotspot_on, self.started, self.last_peek, self.idle_since = True, now, now, now
            print(f"No known Wi-Fi. Setup mode on: join '{setup_ssid()}' "
                  f"(channel {nearby_cache.get('channel', 6)}).", flush=True)
        else:
            print(f"Couldn't start setup mode: {err.strip()}", flush=True)

    def stop_hotspot(self):
        nm("connection", "down", "id", HOTSPOT_NAME, timeout=20)
        self.hotspot_on = False

    def peek_for_wifi(self):
        """Step out of setup mode briefly. True if a saved network came back."""
        print("Setup mode: checking for known Wi-Fi...", flush=True)
        self.stop_hotspot()
        nm("device", "wifi", "rescan", timeout=15)
        for _ in range(9):
            time.sleep(5)
            if wifi_connected():
                return True
        return False

    def tick(self, now):
        if not self.hotspot_on:
            if wifi_connected():
                self.offline_since = None
                if self.gave_up:
                    print("Back on Wi-Fi.", flush=True)
                self.gave_up = False
                return
            self.offline_since = self.offline_since or now
            if not self.gave_up and now - self.offline_since > OFFLINE_BEFORE_SETUP:
                self.start_hotspot()
            return
        # Setup mode is on.
        in_use = phones_on_hotspot() > 0 or now - self.last_visit < 120
        if in_use:
            self.idle_since = now
            return
        limit = SETUP_IDLE_LIMIT if self.has_saved else 3 * SETUP_IDLE_LIMIT
        if now - self.idle_since > limit:
            print(f"Nobody used setup mode for {limit // 60} minutes; switching it off. "
                  "The box keeps trying its saved Wi-Fi. Replug it to get setup mode back.",
                  flush=True)
            self.stop_hotspot()
            self.gave_up = True
            nm("device", "connect", "wlan0", timeout=30)    # let saved networks autoconnect
            return
        if self.has_saved and now - self.last_peek > SETUP_RETRY:
            if self.peek_for_wifi():
                print("Back on Wi-Fi.", flush=True)
                self.offline_since = None
            else:
                idle_since = self.idle_since          # the peek doesn't reset the 20 minutes
                self.start_hotspot()
                self.idle_since = idle_since
            self.last_peek = time.time()

    def loop(self):
        while True:
            try:
                self.tick(time.time())
            except Exception as err:
                print(f"Wi-Fi watcher hiccup: {err}", flush=True)
            time.sleep(10)


setup = SetupMode()


class SpeakerKeeper:
    """Every 2 minutes, make sure the speaker program is answering.
    If it misses two checks in a row, restart it."""
    CHECK_EVERY = 120

    def loop(self):
        missing = 0
        while True:
            time.sleep(self.CHECK_EVERY)
            try:
                speaker_call("/")
                missing = 0
            except SpeakerOffline:
                missing += 1
                if missing >= 2:
                    print("Speaker not answering; restarting it", flush=True)
                    systemctl("restart", SPEAKER_SERVICE)
                    missing = 0


keeper = SpeakerKeeper()


class Listening:
    """Listening stats for Settings > Listening. Nothing leaves the box.
    Every 30 seconds: if music is playing, add half a minute to today, to the
    album, to the tile on the box, and to the hour of day. A tile set down
    counts as one play. Saved to stats.json every 10 minutes (few card writes)."""
    EVERY = 30
    SAVE_EVERY = 600
    KEEP_DAYS = 120

    def __init__(self):
        self.stats = read_json(STATS_FILE, {})
        for k, v in (("days", {}), ("albums", {}), ("tiles", {}), ("hours", [0.0] * 24)):
            self.stats.setdefault(k, v)
        self.last_token = None
        self.lock = threading.Lock()

    def tick(self):
        now = time.localtime()
        day = time.strftime("%Y-%m-%d", now)
        token = (reader_state() or {}).get("token")
        try:
            status = speaker_status()
        except SpeakerOffline:
            return
        track = status.get("track")
        playing = bool(track) and not status.get("paused") and not status.get("stopped")
        with self.lock:
            st = self.stats
            d = st["days"].setdefault(day, {"minutes": 0.0, "plays": 0})
            if token and token != self.last_token and token in load_tokens():
                d["plays"] += 1
                t = st["tiles"].setdefault(token, {"minutes": 0.0, "plays": 0})
                t["plays"] += 1
            self.last_token = token
            if playing:
                step = self.EVERY / 60
                d["minutes"] += step
                st["hours"][now.tm_hour] += step
                album = f"{track.get('album_name', '')}\u2009\u2014\u2009{', '.join(track.get('artist_names') or [])}"
                st["albums"][album] = st["albums"].get(album, 0.0) + step
                if token:
                    st["tiles"].setdefault(token, {"minutes": 0.0, "plays": 0})["minutes"] += step

    def save(self):
        with self.lock:
            days = sorted(self.stats["days"])
            for old in days[:-self.KEEP_DAYS]:
                self.stats["days"].pop(old, None)
            if len(self.stats["albums"]) > 300:
                top = sorted(self.stats["albums"].items(), key=lambda kv: -kv[1])[:200]
                self.stats["albums"] = dict(top)
            write_json(STATS_FILE, self.stats)

    def loop(self):
        last_save = time.time()
        while True:
            time.sleep(self.EVERY)
            try:
                self.tick()
                if time.time() - last_save > self.SAVE_EVERY:
                    self.save()
                    last_save = time.time()
            except Exception as err:
                print(f"Stats hiccup: {err}", flush=True)


STATS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stats.json")
listening = Listening()


@app.route("/listening/share", methods=["POST"])
@needs_pin
def listening_share():
    settings = load_settings()
    settings["share_stats"] = request.form.get("share") == "on"
    save_settings(settings)
    return redirect(url_for("listening_page"))


@app.route("/listening")
@needs_pin
def listening_page():
    with listening.lock:
        st = json.loads(json.dumps(listening.stats))
    today = time.time()
    days = []
    for i in range(13, -1, -1):
        key = time.strftime("%Y-%m-%d", time.localtime(today - i * 86400))
        d = st["days"].get(key, {})
        days.append({"label": time.strftime("%a", time.localtime(today - i * 86400))[0],
                     "date": key, "minutes": round(d.get("minutes", 0)), "plays": d.get("plays", 0)})
    week = days[-7:]
    tokens = load_tokens()
    tiles = sorted(({"name": (tokens.get(t) or {}).get("name") or "Removed tile",
                     "image": (tokens.get(t) or {}).get("image", ""),
                     "plays": v.get("plays", 0), "minutes": round(v.get("minutes", 0))}
                    for t, v in st["tiles"].items()), key=lambda x: (-x["plays"], -x["minutes"]))[:8]
    albums = [{"name": k, "minutes": round(v)} for k, v in
              sorted(st["albums"].items(), key=lambda kv: -kv[1])[:8] if v >= 1]
    hours = st["hours"]
    peak = max(range(24), key=lambda h: hours[h]) if any(hours) else None
    return render_template("listening.html", tab="settings", days=days,
                           most=max([d["minutes"] for d in days] + [1]),
                           week_minutes=sum(d["minutes"] for d in week),
                           week_plays=sum(d["plays"] for d in week),
                           tiles=tiles, albums=albums, hours=[round(h) for h in hours],
                           hour_max=max(hours + [1]), peak=peak,
                           share=load_settings().get("share_stats", True))


@app.before_request
def note_setup_visitors():
    if setup.hotspot_on:
        setup.last_visit = time.time()
        # Phones check a web address when they join a network. Sending every
        # strange address to our Wi-Fi page makes the setup screen pop up.
        host = request.host.split(":")[0]
        mine = (HOTSPOT_ADDRESS, address(), current_host(), fallback_host() + ".local")
        if host not in mine:
            return redirect(f"http://{HOTSPOT_ADDRESS}/setup")


# --------------------------------------------------------------------------
# Spotify account
# --------------------------------------------------------------------------
login = {"auth": None}


def speaker_account():
    """(online, username) for the speaker inside the box."""
    try:
        return True, speaker_status().get("username", "")
    except SpeakerOffline:
        return False, ""


def pairing_code():
    """While the speaker waits to be paired: {"url", "code"}; otherwise None."""
    try:
        reply = speaker_call("/auth/code")
        return reply if reply.get("code") else None
    except SpeakerOffline:
        return None


@app.route("/apple", methods=["GET", "POST"])
@needs_pin
def apple_page():
    if not apple_supported():
        return render_template("apple.html", tab="settings", unsupported=True, url="",
                               has_token=False, message="", error="")
    message = error = ""
    report = ""
    if request.method == "POST":
        if "token" in request.form:
            token = request.form["token"].strip()
            apple.save_config(url=request.form.get("url", "") or apple.DEFAULT_URL,
                              token=token if token else None)
            message = "Saved."
        if request.form.get("action") == "remove":
            apple.save_config(token="", player_id="")
            message = "Apple Music turned off on this box."
        if request.form.get("action") == "test" or message == "Saved.":
            lines, ok = [], True
            try:
                found = apple.players()
                me = apple.find_player()
                lines.append(f"Music Assistant answered. Speakers it knows: "
                             f"{', '.join((p.get('display_name') or p.get('name') or '?') for p in found) or 'none'}.")
                if not me:
                    ok = False
                    lines.append(f"No speaker called '{apple.PLAYER_NAME}' yet. Is squeezelite running?")
                else:
                    lines.append(f"Found the speaker '{me.get('display_name') or me.get('name')}'.")
                if not apple.search("the beatles", 3):
                    ok = False
                    lines.append("Search found no Apple Music albums. Sign in to Apple Music inside Music Assistant.")
            except apple.AppleError as err:
                ok = False
                lines.append(str(err))
            report = " ".join(lines)
            if ok:
                message = "Apple Music is ready. " + report
                report = ""
            else:
                message, error = "", report
                report = ""
    cfg = apple.load_config()
    return render_template("apple.html", tab="settings", url=cfg["url"], has_token=bool(cfg["token"]),
                           message=message, error=error)


@app.route("/spotify")
@app.route("/account")
@needs_pin
def account_page():
    user, problem = "", ""
    if signed_in():
        try:
            me = sp.current_user()
            user = me.get("display_name") or me.get("id", "")
        except NotSignedIn:
            problem = "Not signed in."
        except Exception as err:
            problem = str(err)[:200]
            if "403" in problem or "not registered" in problem.lower():
                problem = ("Spotify says this account isn't on your app's User "
                           "Management list. Add it at developer.spotify.com, "
                           "Dashboard > your app > Settings > User Management.")
    return render_template("account.html", tab="settings", user=user, problem=problem,
                           signed_in=signed_in(), speaker=speaker_account()[0],
                           speaker_user=speaker_account()[1], pairing=pairing_code(),
                           client_id=CLIENT_ID, soloist=soloist_mode(),
                           need_install=not soloist_installed(), install=soloist_install_info(),
                           keyerror=request.args.get("keyerror"),
                           message=request.args.get("message", "")[:200])


def soloist_install_info():
    """For the 'Install Spotify's player' card."""
    return {"protected": unplug_proof_on(), "admin": admin_ready(), "auto": auto_ready(),
            "quick": not unplug_proof_on() and held(),
            "supported": os.uname().machine in SOLOIST_MACHINES, "job": job_view("soloist"),
            "installed": soloist_installed()}


@app.route("/spotify/install", methods=["GET", "POST"])
@needs_pin
def soloist_install_page():
    back = request.values.get("back", "/spotify")
    if back not in ("/spotify", "/setup"):
        back = "/spotify"
    error = ""
    if request.method == "POST":
        info = soloist_install_info()
        if info["job"]["running"]:
            return redirect(url_for("soloist_install_page", back=back))
        if not info["admin"]:
            error = ("This box is missing the app's install helper. Whoever set up the box needs to "
                     "install the latest box software once.")
        elif not info["supported"]:
            error = "Spotify's player doesn't run on this kind of box."
        else:
            ok, why = start_install("soloist-install")
            if not ok:
                error = why if why.startswith("Turn on") else f"Couldn't start the install ({why or 'no answer'})."
            else:
                time.sleep(1)
                return redirect(url_for("soloist_install_page", back=back))
    return render_template("soloist_install.html", tab="settings", back=back, error=error,
                           install=soloist_install_info())


@app.route("/api/job/<job>")
def api_job(job):
    if job not in JOBS:
        abort(404)
    if not session.get("ok"):
        return jsonify(error="locked"), 403
    state = job_view(job)
    if job == "player":
        state["player_ok"] = local.ping()
    if job == "soloist":
        state["installed"] = soloist_installed()
        state["has_key"] = os.path.exists(SOLOIST_KEY) and os.path.getsize(SOLOIST_KEY) > 0
    return jsonify(state)


# --------------------------------------------------------------------------
# Software updates (central releases, signed by Garrett; see musicbox_update.py)
# --------------------------------------------------------------------------
UPDATE_BACKUPS = os.path.expanduser("~/musicbox/update_backups")


def update_status():
    s = read_json(updates.status_file(os.path.expanduser("~")), {}) or {}
    s["current"] = APP_VERSION
    s["available"] = bool(s.get("latest")) and \
        updates.version_tuple(s["latest"]) > updates.version_tuple(APP_VERSION) and not s.get("error")
    return s


def last_backup():
    try:
        names = sorted(d for d in os.listdir(UPDATE_BACKUPS)
                       if os.path.isfile(os.path.join(UPDATE_BACKUPS, d, "backup.json")))
    except OSError:
        return None
    return read_json(os.path.join(UPDATE_BACKUPS, names[-1], "backup.json"), None) if names else None


@app.route("/updates", methods=["GET", "POST"])
@needs_pin
def updates_page():
    message, error = "", ""
    settings = load_settings()
    if request.method == "POST":
        action = request.form.get("action", "")
        if action == "check":
            r = updates.check(os.path.expanduser("~"))
            if r.get("error"):
                error = r["error"]
            elif r.get("available"):
                message = f"Version {r['latest']} is ready to install."
            else:
                message = "This box is up to date."
        elif action == "auto":
            settings["update_check"] = request.form.get("value") == "on"
            save_settings(settings)
            message = ("The box checks for updates once a day." if settings["update_check"]
                       else "Automatic checks off. You can still check here.")
        elif action in ("install", "rollback"):
            if job_view("update")["running"]:
                return redirect(url_for("updates_page"))
            if not admin_ready():
                error = "This box is missing the app's update helper. Install the latest box software by hand once."
            else:
                ok, why = start_install("update-apply" if action == "install" else "update-rollback")
                if ok:
                    time.sleep(1)
                    return redirect(url_for("updates_page"))
                error = why if why.startswith("This box") else f"Couldn't start ({why or 'no answer'})."
        settings = load_settings()
    return render_template("updates.html", tab="settings", status=update_status(),
                           result=read_json(updates.result_file(os.path.expanduser("~")), {}) or {},
                           job=job_view("update"), protected=unplug_proof_on(),
                           admin=admin_ready(), auto_ready=auto_ready(), backup=last_backup(),
                           quick=not unplug_proof_on() and held(),
                           finishing=not unplug_proof_on() and not held() and protection_installed(),
                           auto=settings.get("update_check", True), version=APP_VERSION,
                           message=message, error=error)


@app.route("/account/signin")
@needs_pin
def account_signin():
    login["auth"] = make_auth()
    url = login["auth"].get_authorize_url() + "&show_dialog=true"
    return render_template("signin.html", tab="settings", url=url, error="")


@app.route("/account/finish", methods=["POST"])
@needs_pin
def account_finish():
    pasted = request.form.get("pasted", "").strip()
    code = (parse_qs(urlparse(pasted).query).get("code") or [""])[0]
    auth = login.get("auth")
    if not auth or not code:
        return render_template(
            "signin.html", tab="settings",
            url=(auth.get_authorize_url() + "&show_dialog=true") if auth else "",
            error="That address doesn't have a sign-in code in it. Copy the whole "
                  "address from the page that wouldn't load.")
    try:
        auth.get_access_token(code=code, check_cache=False)
    except Exception as err:
        return render_template("signin.html", tab="settings",
                               url=auth.get_authorize_url() + "&show_dialog=true",
                               error=f"Spotify didn't accept that: {str(err)[:150]}. "
                                     "Tap the sign-in button again for a fresh code.")
    login["auth"] = None
    return redirect(url_for("account_page", message="Signed in. You're all set."))


@app.route("/account/soloist-key", methods=["POST"])
@needs_pin
def soloist_key():
    key = "".join(request.form.get("key", "").split())
    back = request.form.get("back") or url_for("account_page")
    if not back.startswith("/"):
        back = url_for("account_page")
    if not (16 <= len(key) <= 512) or not all(c.isprintable() for c in key):
        return redirect(back + ("&" if "?" in back else "?") + "keyerror=1")
    tmp = SOLOIST_KEY + ".tmp"
    with open(os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "w") as f:
        f.write(key + "\n")
    os.replace(tmp, SOLOIST_KEY)
    systemctl("restart", SPEAKER_SERVICE)
    time.sleep(2)
    return redirect(back)


@app.route("/account/speaker-signout", methods=["POST"])
@needs_pin
def speaker_signout():
    systemctl("stop", SPEAKER_SERVICE)
    if soloist_mode():
        import shutil
        shutil.rmtree(SOLOIST_DATA, ignore_errors=True)   # Soloist's saved sign-in
        os.makedirs(SOLOIST_DATA, exist_ok=True)
        systemctl("start", SPEAKER_SERVICE)
        time.sleep(3)
        return redirect(url_for("account_page",
                                message="Spotify disconnected. Connect again from the Spotify app."))
    try:
        os.remove(SPEAKER_STATE)          # the speaker's saved sign-in
    except FileNotFoundError:
        pass
    systemctl("start", SPEAKER_SERVICE)
    time.sleep(4)                         # give it a moment to make a pairing code
    return redirect(url_for("account_page",
                            message="Speaker signed out. Pair it with the code below."))


# --------------------------------------------------------------------------
# Settings and power
# --------------------------------------------------------------------------
def unplug_proof_on():
    """True when the system is read-only (root is an overlay)."""
    if os.environ.get("MB_SYSROOT"):         # simulation tests only
        return os.path.exists(os.path.join(os.environ["MB_SYSROOT"], "OVERLAY_ON"))
    try:
        with open("/proc/mounts") as f:
            return any(l.split()[1:3] == ["/", "overlay"] for l in f if len(l.split()) > 2)
    except OSError:
        return False


@app.route("/advanced")
@needs_pin
def advanced_page():
    """Troubleshooting only (not linked from the main screens): maintenance mode."""
    return render_template("advanced.html", tab="settings", protected=unplug_proof_on(),
                           held=held(), failed=protect_failed(),
                           can_protect=helper_knows("protect-on") or protection_installed(),
                           genuine_only=genuine.check_on(),
                           error=request.args.get("error", "")[:200])


@app.route("/advanced/tiles", methods=["POST"])
@needs_pin
def advanced_tiles():
    """Hidden testing switch: accept any NFC tile, or only genuine Music Boxx tiles."""
    settings = load_settings()
    settings["genuine_tiles_only"] = request.form.get("genuine_only") == "1"
    save_settings(settings)
    return redirect(url_for("advanced_page"))


@app.route("/maintenance/<mode>", methods=["POST"])
@needs_pin
def maintenance(mode):
    """Hidden troubleshooting switch. Maintenance ON = unplug protection OFF (system
    writable, and it stays that way until switched back), and the reverse."""
    if mode not in ("on", "off"):
        abort(404)
    command = "maintenance-on" if mode == "on" else "protect-on"
    if helper_knows(command):
        ok, why = start_job(command)
        if not ok:
            return redirect(url_for("advanced_page", error=f"Couldn't switch ({why or 'no answer'})."))
        if why.startswith(("already", "unplug protection is already")):
            return redirect(url_for("advanced_page"))
        return render_template("power.html", tab="settings", action="maintenance-" + mode)
    flag = "1" if mode == "on" else "0"

    def worker():
        time.sleep(2)
        subprocess.run(["sudo", "-n", "/usr/bin/raspi-config", "nonint", "do_overlayfs", flag])
        # do_overlayfs leaves /boot/firmware read-only; unlock it too in maintenance mode
        # so config.txt edits stick. (Needs the disable_bootro sudoers entry; harmless if missing.)
        if mode == "on":
            subprocess.run(["sudo", "-n", "/usr/bin/raspi-config", "nonint", "disable_bootro"])
        subprocess.run(["sudo", "-n", "/usr/sbin/shutdown", "-r", "now"])
    threading.Thread(target=worker, daemon=True).start()
    return render_template("power.html", tab="settings", action="maintenance-" + mode)


# --------------------------------------------------------------------------
# Erase this box (factory reset, 2.5.9). Three deliberate steps so a stray tap
# can never erase a box: (1) choices + the PIN again + typing RESET, (2) a final
# screen that lists exactly what goes (good for 5 minutes), (3) the helper does
# it as root, switching maintenance mode on by itself if unplug protection is on.
# Unplug protection comes back on by itself after the next owner's setup.
# --------------------------------------------------------------------------
RESET_WORD = "RESET"
RESET_WINDOW = 5 * 60
RESET_AFTER = ("shut-down", "restart")
ADMIN_PENDING = "/var/lib/musicbox-admin/pending.json"


def reset_supported():
    """The box's helper knows how to erase it (installed by the 2.5.9 update)."""
    return admin_ready() and helper_knows("auto-factory-reset") and (
        auto_ready() or not unplug_proof_on())


def reset_busy():
    """Something else is installing (the reset would stop it halfway)."""
    if read_json(ADMIN_PENDING, None):
        return True
    return any(job_view(j)["running"] for j in ("soloist", "update", "player"))


def reset_options(form):
    tiles = "erase-tiles" if form.get("erase_tiles") else "keep-tiles"
    music = "erase-music" if form.get("erase_music") else "keep-music"
    after = form.get("after") if form.get("after") in RESET_AFTER else "shut-down"
    return f"{tiles},{music},{after}"


def reset_plan_view(opts):
    tiles, music, after = opts.split(",")
    return {"opts": opts, "erase_tiles": tiles == "erase-tiles", "erase_music": music == "erase-music",
            "after": after, "tiles": len(load_tokens())}


def reset_job():
    """The reset's progress, or None when there's nothing recent to show."""
    j = job_view("reset")
    if not j["exists"]:
        return None
    if not j["running"] and time.time() - (j.get("ended") or j.get("started") or 0) > 12 * 3600:
        return None
    return j


@app.route("/reset", methods=["GET", "POST"])
@needs_pin
def reset_page():
    error = request.args.get("error", "")[:200]
    form = {"after": "shut-down"}
    if request.method == "POST":
        form = request.form
        pin = request.form.get("pin", "").strip()
        word = request.form.get("word", "").strip()
        if not reset_supported():
            error = "This box needs the latest software first: Settings, Software updates."
        elif reset_busy():
            error = "The box is installing something right now. Try again when it's finished."
        elif time.time() < failed_pins["until"]:
            error = "Too many tries. Wait a minute and try again."
        elif not check_pin(pin):
            failed_pins["count"] += 1
            if failed_pins["count"] >= 5:
                failed_pins.update(count=0, until=time.time() + 60)
            error = "Wrong PIN. Nothing was erased."
        elif word.upper() != RESET_WORD:
            error = f"Type the word {RESET_WORD} to go on. Nothing was erased."
        else:
            failed_pins["count"] = 0
            session["reset_ok"] = {"opts": reset_options(request.form),
                                   "until": time.time() + RESET_WINDOW,
                                   "nonce": secrets.token_urlsafe(16)}
            return redirect(url_for("reset_confirm"))
    job = reset_job()
    started = request.args.get("started")
    return render_template("reset.html", tab="settings", step="start", error=error, form=form,
                           job=job, started=started if started in RESET_AFTER else "",
                           supported=reset_supported(), protected=unplug_proof_on(),
                           tiles=len(load_tokens()))


@app.route("/reset/confirm", methods=["GET", "POST"])
@needs_pin
def reset_confirm():
    plan = session.get("reset_ok") or {}
    if not plan:
        return redirect(url_for("reset_page"))
    if time.time() > plan.get("until", 0):
        session.pop("reset_ok", None)
        return redirect(url_for("reset_page", error="That took a while, so for safety please start "
                                                    "again. Nothing was erased."))
    if request.method == "POST":
        if not hmac.compare_digest(request.form.get("nonce", ""), plan.get("nonce", "")):
            return redirect(url_for("reset_page", error="Please start again. Nothing was erased."))
        session.pop("reset_ok", None)
        if reset_busy():
            return redirect(url_for("reset_page", error="The box is installing something right now. "
                                                        "Try again when it's finished."))
        ok, why = start_install("factory-reset", plan["opts"])
        if not ok:
            return redirect(url_for("reset_page", error=f"Couldn't start the reset ({why or 'no answer'}). "
                                                        "Nothing was erased."))
        time.sleep(1)
        return redirect(url_for("reset_page", started=plan["opts"].split(",")[2]))
    return render_template("reset.html", tab="settings", step="confirm", plan=reset_plan_view(plan["opts"]),
                           nonce=plan["nonce"], protected=unplug_proof_on(),
                           minutes=max(1, int((plan["until"] - time.time()) // 60)))


@app.route("/settings", methods=["GET", "POST"])
@needs_pin
def settings_page():
    message, error = request.args.get("message", "")[:80], ""
    settings = load_settings()
    if request.method == "POST":
        if "volume_min" in request.form:
            try:
                low = max(0, min(100, int(request.form["volume_min"])))
                high = max(0, min(100, int(request.form["volume_max"])))
                if low > high:
                    error = "The lowest volume has to be below the highest."
                else:
                    settings.update(volume_min=low, volume_max=high)
                    save_settings(settings)
                    message = "Volume limits saved. The knob follows them right away."
            except ValueError:
                error = "Use whole numbers from 0 to 100."
        elif "line_out" in request.form and settings.get("product") == "pad":
            settings["line_out"] = "fixed" if request.form["line_out"] == "fixed" else "variable"
            save_settings(settings)
            message = ("The Pad stays at full volume now. Use your stereo's knob."
                       if settings["line_out"] == "fixed" else
                       "The Pad's knob and your phone set the volume again.")
        elif "resume_minutes" in request.form:
            try:
                minutes = max(0, min(240, int(request.form["resume_minutes"])))
                settings["resume_minutes"] = minutes
                save_settings(settings)
                message = "Saved."
            except ValueError:
                error = "Use a whole number of minutes."
        elif "startup_sound" in request.form:
            settings["startup_sound"] = request.form["startup_sound"] == "on"
            save_settings(settings)
            message = ("The box plays the chime when it's ready." if settings["startup_sound"]
                       else "Startup sound off.")
        elif "new_pin" in request.form:
            new_pin = request.form["new_pin"].strip()
            if not check_pin(request.form.get("old_pin", "").strip()):
                error = "Your current PIN wasn't right."
            elif not (new_pin.isdigit() and 4 <= len(new_pin) <= 8):
                error = "Use 4 to 8 numbers."
            else:
                set_pin(new_pin)
                message = "PIN changed."
        settings = load_settings()
    online, _ = speaker_account()
    spotify_line = ("Needs setting up" if not soloist_installed() else
                    "Not answering right now" if not online else
                    "Waiting to be connected" if pairing_code() else "Connected")
    upd = update_status()
    update_line = (f"{upd['latest']} ready" if upd["available"] else f"Up to date ({APP_VERSION})"
                   if upd.get("checked") and not upd.get("error") else APP_VERSION)
    try:
        attention = notices()
        state = reader_state()
        if state.get("reader_ok", True) is False:
            attention.append({"kind": "", "icon": "alert", "title": "The tile reader isn't answering",
                              "body": "Unplug the box, count to 10, and plug it back in."})
        if protect_failed():
            attention.append({"kind": "calm", "icon": "shield", "title": "Use Shut down before unplugging",
                              "body": "Pulling the plug could harm the box right now.",
                              "action": {"href": "/advanced", "label": "Try again"}})
    except Exception:
        attention = []
    return render_template("settings.html", tab="settings", notices=attention,
                           protected=unplug_proof_on(), wifi=current_wifi(),
                           speaker_host=address(),
                           sound_line=next((p["label"] for p in list_presets()
                                            if p["name"] == current_preset()), ""),
                           spotify_line=spotify_line, version=APP_VERSION, update_line=update_line,
                           apple_ok=apple_supported(),
                           apple_line="Set up" if apple.configured() else "Experimental",
                           startup_sound=settings.get("startup_sound", True),
                           resume_minutes=settings["resume_minutes"],
                           volume_min=settings["volume_min"], volume_max=settings["volume_max"],
                           is_pad=settings.get("product") == "pad",
                           line_out=settings.get("line_out", "variable"),
                           message=message, error=error)


# --------------------------------------------------------------------------
# Sound presets (CamillaDSP). Same files the `eq` command uses:
# /etc/camilladsp/musicbox.<name>.yml, copied over musicbox.yml by a root helper.
# --------------------------------------------------------------------------
EQ_DIR = "/etc/camilladsp"
PRESET_HELPER = "/usr/local/sbin/musicbox-set-preset"
PRESET_INFO = {   # name -> (label, one line, order). Unknown presets still show up.
    "echo": ("Full", "Big, warm sound tuned to match an Amazon Echo. The everyday pick.", 1),
    "echo_harmonics": ("Full + deeper bass", "Adds bass you can hear on small speakers, without straining them.", 2),
    "echo_harmonics_strong": ("Full + extra deep bass", "The same trick, stronger. Best for music with lots of bass.", 3),
    "echo_nolim": ("Full, no limiter", "Full without the loudness guard. Can crackle when turned way up.", 4),
    "split": ("Split", "Both speakers share the bass, one plays the highs.", 5),
    "flat": ("Flat", "No tuning. Useful for testing.", 9),
}


def list_presets():
    try:
        names = sorted(f[len("musicbox."):-len(".yml")] for f in os.listdir(EQ_DIR)
                       if f.startswith("musicbox.") and f.endswith(".yml") and f != "musicbox.yml")
    except OSError:
        return []
    names = [n for n in names if re.fullmatch(r"[a-z0-9_]{1,40}", n) and not n.startswith("before")]
    presets = []
    for n in names:
        label, line, order = PRESET_INFO.get(n, (n.replace("_", " ").capitalize(), "", 7))
        presets.append({"name": n, "label": label, "line": line, "order": order})
    return sorted(presets, key=lambda p: (p["order"], p["label"]))


def current_preset():
    try:
        with open(os.path.join(EQ_DIR, "current_preset")) as f:
            name = f.read().strip()
            if name:
                return name
    except OSError:
        pass
    try:                                  # picked with `eq` before: find the matching file
        with open(os.path.join(EQ_DIR, "musicbox.yml"), "rb") as f:
            live = f.read()
        for p in list_presets():
            with open(os.path.join(EQ_DIR, f"musicbox.{p['name']}.yml"), "rb") as f:
                if f.read() == live:
                    return p["name"]
    except OSError:
        pass
    return ""


@app.route("/sound", methods=["GET", "POST"])
@needs_pin
def sound_page():
    if load_settings().get("product") == "pad":
        return redirect("/settings")   # a Pad has no speakers, so no speaker presets
    message, error = "", ""
    presets = list_presets()
    if request.method == "POST":
        name = request.form.get("preset", "")
        if name not in [p["name"] for p in presets]:
            error = "That preset isn't on this box."
        elif not os.path.exists(PRESET_HELPER):
            error = "The sound helper isn't installed yet (run the update script)."
        else:
            try:
                r = subprocess.run(["sudo", "-n", PRESET_HELPER, name], capture_output=True,
                                   text=True, timeout=30)
                if r.returncode == 0:
                    label = next(p["label"] for p in presets if p["name"] == name)
                    message = f"Sound set to {label}."
                    now_cache["when"] = 0.0
                else:
                    error = (r.stderr or r.stdout).strip()[:200] or "Couldn't switch the sound."
            except subprocess.TimeoutExpired:
                error = "Switching took too long. Try Restart music in Settings."
    return render_template("sound.html", tab="settings", presets=presets, current=current_preset(),
                           message=message, error=error)


@app.route("/api/chime", methods=["POST"])
@needs_pin
def api_chime():
    threading.Thread(target=play_chime, daemon=True).start()
    return jsonify(ok=True)


@app.route("/power/<action>", methods=["POST"])
@needs_pin
def power(action):
    commands = {
        "restart-music": [["sudo", "-n", "/usr/bin/systemctl", "restart", SPEAKER_SERVICE],
                          ["sudo", "-n", "/usr/bin/systemctl", "restart", "musicbox"]],
        "reboot": [["sudo", "-n", "/usr/sbin/shutdown", "-r", "now"]],
        "shutdown": [["sudo", "-n", "/usr/sbin/shutdown", "-h", "now"]],
    }
    if action not in commands:
        abort(404)

    def worker():
        time.sleep(2)
        for command in commands[action]:
            subprocess.run(command)
    threading.Thread(target=worker, daemon=True).start()
    return render_template("power.html", tab="settings", action=action)


@app.errorhandler(404)
def not_found(_):
    if setup.hotspot_on:
        return redirect(f"http://{HOTSPOT_ADDRESS}/setup")
    return redirect("/")


# --------------------------------------------------------------------------
# Pages
# --------------------------------------------------------------------------
# Small line icons, drawn here so the app works with no internet (setup mode).
_ICON_PATHS = {
    "play": '<path d="M8 5.2v13.6a.8.8 0 0 0 1.2.7l11-6.8a.8.8 0 0 0 0-1.4l-11-6.8A.8.8 0 0 0 8 5.2z" fill="currentColor" stroke="none"/>',
    "pause": '<rect x="6.5" y="5" width="4" height="14" rx="1.2" fill="currentColor" stroke="none"/><rect x="13.5" y="5" width="4" height="14" rx="1.2" fill="currentColor" stroke="none"/>',
    "prev": '<path d="M18.5 6.2v11.6a.7.7 0 0 1-1.1.6L9.6 12.6a.7.7 0 0 1 0-1.2l7.8-5.8a.7.7 0 0 1 1.1.6z" fill="currentColor" stroke="none"/><path d="M6 6v12"/>',
    "next": '<path d="M5.5 6.2v11.6a.7.7 0 0 0 1.1.6l7.8-5.8a.7.7 0 0 0 0-1.2L6.6 5.6a.7.7 0 0 0-1.1.6z" fill="currentColor" stroke="none"/><path d="M18 6v12"/>',
    "now": '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="2.2"/>',
    "tiles": '<rect x="3.5" y="3.5" width="7" height="7" rx="1.8"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.8"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.8"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.8"/>',
    "settings": '<path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>',
    "wifi": '<path d="M2.5 9a14 14 0 0 1 19 0M5.5 12.3a9.5 9.5 0 0 1 13 0M8.6 15.6a5 5 0 0 1 6.8 0"/><circle cx="12" cy="19" r="1" fill="currentColor" stroke="none"/>',
    "music": '<path d="M9 18V5.5l11-2V16"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/>',
    "volume": '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11"/>',
    "chevron": '<path d="M9.5 6l6 6-6 6"/>',
    "back": '<path d="M14.5 6l-6 6 6 6"/>',
    "check": '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    "alert": '<path d="M12 4l9 16H3z"/><path d="M12 10v4.5"/><circle cx="12" cy="17.3" r=".6" fill="currentColor"/>',
    "plus": '<path d="M12 5v14M5 12h14"/>',
    "power": '<path d="M12 3.5v8"/><path d="M7 6.5a7.5 7.5 0 1 0 10 0"/>',
    "restart": '<path d="M4.5 12a7.5 7.5 0 1 0 2.2-5.3"/><path d="M4.5 4.5v4h4"/>',
    "shield": '<path d="M12 3.5l7.5 3v5.5c0 4.5-3.2 7.6-7.5 8.5-4.3-.9-7.5-4-7.5-8.5V6.5z"/>',
    "lock": '<rect x="5" y="10.5" width="14" height="10" rx="2.5"/><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5"/>',
    "link": '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
    "pencil": '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    "trash": '<path d="M4.5 7h15M9.5 7V4.5h5V7M6.5 7l1 13h9l1-13"/>',
    "list": '<path d="M9 6.5h11M9 12h11M9 17.5h11"/><circle cx="4.5" cy="6.5" r="1" fill="currentColor"/><circle cx="4.5" cy="12" r="1" fill="currentColor"/><circle cx="4.5" cy="17.5" r="1" fill="currentColor"/>',
    "library": '<rect x="4" y="4" width="4" height="16" rx="1.2"/><rect x="10" y="4" width="4" height="16" rx="1.2"/><path d="M16.3 5.2l3.6-1 4 15.3-3.6 1z" transform="translate(-2.2 .3)"/>',
    "search": '<circle cx="10.5" cy="10.5" r="6"/><path d="M15 15l5 5"/>',
    "book": '<path d="M5 4.5h10.5a3 3 0 0 1 3 3V20H8a3 3 0 0 1-3-3z"/><path d="M5 17a3 3 0 0 1 3-3h10.5"/>',
    "save": '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M8 4v5h7V4M8 20v-6h8v6"/>',
}


def icon(name, size=24, cls=""):
    from markupsafe import Markup
    return Markup(
        f'<svg class="icon {cls}" width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" '
        f'stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" '
        f'aria-hidden="true">{_ICON_PATHS[name]}</svg>')


app.jinja_env.globals["icon"] = icon

# Music Boxx mark C "Stack": one tile set down in front of another. One color (currentColor).
from markupsafe import Markup  # noqa: E402
BRAND_MARK = Markup('<svg viewBox="0 0 100 100" aria-hidden="true"><defs><mask id="mbx-stack" '
    'maskUnits="userSpaceOnUse" x="0" y="0" width="100" height="100"><rect width="100" height="100" '
    'fill="#fff"/><circle cx="42" cy="58" r="12" fill="#000"/></mask></defs><rect x="26" y="8" '
    'width="66" height="66" rx="17" fill="none" stroke="currentColor" stroke-width="8"/><rect x="6" '
    'y="26" width="72" height="68" rx="18" fill="currentColor" mask="url(#mbx-stack)"/></svg>')
BRAND_NAME = "Music Boxx"
app.jinja_env.globals["brand_mark"] = BRAND_MARK
app.jinja_env.globals["brand_name"] = BRAND_NAME
app.jinja_env.filters["kind"] = kind_of
app.jinja_env.filters["badge"] = tile_badge


@app.context_processor
def speaker_context():
    return {"box_name": speaker_name(), "box_id": box_id(), "setup_ssid": setup_ssid(),
            "box_address": address(), "box_fallback": fallback_host() + ".local",
            "attention": needs_attention}
app.jinja_env.globals["icon_svgs"] = {name: str(icon(name)) for name in _ICON_PATHS}

# Spotify's round icon, unaltered (only its color changes: black on light pages,
# white on dark, as Spotify's design guidelines allow). Shown with "Playing from
# Spotify" whenever Spotify music is on. Never smaller than 21px (their minimum).
SPOTIFY_ICON = ('<svg class="icon spot" width="{size}" height="{size}" viewBox="0 0 24 24" '
                'fill="currentColor" aria-hidden="true"><path d="M12 0C5.4 0 0 5.4 0 12s5.4 '
                '12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36'
                '-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 '
                '11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58'
                '-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 '
                '12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181'
                '-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 '
                '1.56-.299.421-1.02.599-1.559.3z"/></svg>')
app.jinja_env.globals["spotify_svg"] = SPOTIFY_ICON.format(size=24)

PAGES = {}

PAGES["base.html"] = """<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{{ box_name }}</title>
<link rel="manifest" href="/manifest.json">
<link rel="apple-touch-icon" href="/icon.png">
<link rel="icon" href="/icon.png">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="apple-mobile-web-app-title" content="{{ box_name }}">
<meta name="theme-color" content="#F4EBDD" media="(prefers-color-scheme: light)" id="tc-light">
<meta name="theme-color" content="#1C1A19" media="(prefers-color-scheme: dark)" id="tc-dark">
<script>
/* Appearance: "auto", "light" or "dark", remembered on this phone. */
function applyTheme(t) {
  const root = document.documentElement;
  if (t === "light" || t === "dark") root.dataset.theme = t; else delete root.dataset.theme;
  const color = t === "dark" ? "#1C1A19" : "#F4EBDD";
  for (const id of ["tc-light", "tc-dark"]) {
    const m = document.getElementById(id);
    if (!m) continue;
    if (t === "light" || t === "dark") { m.content = color; m.removeAttribute("media"); }
    else { m.content = id === "tc-dark" ? "#1C1A19" : "#F4EBDD";
           m.media = id === "tc-dark" ? "(prefers-color-scheme: dark)" : "(prefers-color-scheme: light)"; }
  }
}
let savedTheme = "auto";
try { savedTheme = localStorage.getItem("theme") || "auto"; } catch (e) {}
applyTheme(savedTheme);
</script>
<style>
:root{
  /* Music Boxx colors: cream, walnut, vinyl black, soft teal accent. (--marigold is the
     accent's old name; it is teal now.) */
  --paper:#F4EBDD; --surface:#FBF6EE; --sunk:#EADFCC; --ink:#2A211B; --muted:#76624F;
  --line:#DCCDB6; --raised:#FBF6EE; --marigold:#2F7F79; --marigold-press:#266A65; --on-marigold:#FBF6EE;
  --walnut:#4A3426; --link:#23625D; --good:#2C7A57; --bad:#B23E28;
  --shadow-tile:0 1px 2px rgba(42,33,27,.12),0 8px 24px -8px rgba(42,33,27,.32);
  --r-lg:22px; --r-md:14px; --r-sm:10px;
  --font:ui-rounded,"SF Pro Rounded",system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;
  --display:"Music Boxx Serif",ui-serif,Georgia,serif;
}
@font-face{font-family:"Music Boxx Serif";src:url(/brand-font.woff2) format("woff2");
  font-weight:700 800;font-display:swap}
@media (prefers-color-scheme:dark){:root:not([data-theme=light]){
  --paper:#1C1A19; --surface:#25211E; --sunk:#2E2925; --ink:#F1E7D8; --muted:#B09F8B;
  --line:#3A332D; --raised:#3F3832; --marigold:#3B958E; --marigold-press:#327F79; --walnut:#F1E7D8;
  --link:#7CC6BE; --good:#6FCB9C; --bad:#F08A78;
  --shadow-tile:0 1px 2px rgba(0,0,0,.4),0 10px 28px -8px rgba(0,0,0,.7); color-scheme:dark;
}}
:root[data-theme=dark]{
  --paper:#1C1A19; --surface:#25211E; --sunk:#2E2925; --ink:#F1E7D8; --muted:#B09F8B;
  --line:#3A332D; --raised:#3F3832; --marigold:#3B958E; --marigold-press:#327F79; --walnut:#F1E7D8;
  --link:#7CC6BE; --good:#6FCB9C; --bad:#F08A78;
  --shadow-tile:0 1px 2px rgba(0,0,0,.4),0 10px 28px -8px rgba(0,0,0,.7); color-scheme:dark;
}
:root[data-theme=light]{color-scheme:light}
*{box-sizing:border-box}
html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--paper);color:var(--ink);font:400 16px/1.45 var(--font);
  -webkit-font-smoothing:antialiased}
main{max-width:540px;margin:0 auto;padding:calc(14px + env(safe-area-inset-top)) 18px 112px}
h1{font-family:var(--display);font-size:30px;line-height:1.1;font-weight:800;letter-spacing:-.01em;margin:10px 0 18px}
.brand{display:inline-flex;align-items:center;gap:8px;font:800 19px/1 var(--display);color:var(--walnut);white-space:nowrap}
.brand svg{width:24px;height:24px;color:var(--marigold);flex:none}
h2{font-size:15px;font-weight:700;color:var(--muted);margin:28px 4px 8px}
p{margin:0}
a{color:var(--link)}
.muted{color:var(--muted)}
.small{font-size:14px}
.icon{flex:none;display:block}
:focus-visible{outline:3px solid var(--marigold);outline-offset:2px}

/* Buttons */
.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:48px;
  padding:0 20px;border-radius:999px;border:0;font:700 16px var(--font);text-decoration:none;
  cursor:pointer;background:var(--marigold);color:var(--on-marigold);-webkit-tap-highlight-color:transparent}
.btn:active{background:var(--marigold-press)}
.btn.plain{background:var(--sunk);color:var(--ink)}
.btn.wide{display:flex;width:100%}
.btn.small{min-height:38px;padding:0 14px;font-size:15px}
.btn[disabled]{opacity:.6}

/* Grouped lists (Settings, tile details) */
.group{background:var(--surface);border-radius:var(--r-md);overflow:hidden;margin:0 0 12px}
.item{display:flex;align-items:center;gap:14px;min-height:56px;padding:12px 16px;width:100%;
  border:0;background:none;color:var(--ink);font:inherit;text-align:left;text-decoration:none}
.item+.item,.item+form .item,form+.item,form+form .item{border-top:1px solid var(--line)}
.item .label{flex:1;min-width:0}
.item .value{color:var(--muted);font-size:15px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:55%}
.item .chev{color:var(--muted)}
.item.danger{color:var(--bad)}
.item .badge{width:32px;height:32px;border-radius:9px;display:grid;place-items:center;
  background:var(--sunk);color:var(--ink)}
button.item{cursor:pointer}
button.item.action{justify-content:center;color:var(--link);font-weight:700}
.note{font-size:14px;color:var(--muted);margin:0 6px 4px;line-height:1.4}
.progress{display:flex;gap:6px;margin:18px 0 6px}
.progress span{flex:1;height:6px;border-radius:3px;background:var(--line)}
.progress span.on{background:var(--marigold)}
.stepnum{color:var(--muted);font-weight:700;font-size:14px}
.chips{display:flex;flex-wrap:wrap;gap:8px}
.chips button{border:1.5px solid var(--line);background:var(--surface);color:var(--ink);border-radius:999px;
  padding:8px 14px;font:inherit;font-size:15px;cursor:pointer}
.addr{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:15px;word-break:break-all}
form{margin:0}
.pad{padding:16px}
.seg{display:flex;background:var(--sunk);border-radius:999px;padding:3px;gap:2px}
.seg button{flex:1;min-height:40px;border:0;border-radius:999px;background:none;color:var(--muted);
  font:600 15px var(--font);cursor:pointer}
.seg button[aria-checked=true]{background:var(--raised);color:var(--ink);box-shadow:0 1px 3px rgba(0,0,0,.15)}
.group.pad .seg{margin:0}
.switch{flex:none;width:50px;height:30px;border-radius:999px;background:var(--line);position:relative;transition:background .15s}
.switch::after{content:"";position:absolute;top:3px;left:3px;width:24px;height:24px;border-radius:50%;
  background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.25);transition:transform .15s}
.switch.on{background:var(--good)}
.switch.on::after{transform:translateX(20px)}
.stack>*+*{margin-top:12px}

/* Inputs */
input[type=text],input[type=password],input[type=number],input[type=search],input[type=url],select{
  width:100%;min-height:48px;padding:0 14px;border:1.5px solid var(--line);border-radius:var(--r-sm);
  background:var(--paper);color:var(--ink);font:16px var(--font)}
input:focus,select:focus{border-color:var(--marigold);outline:none}
input.num{width:84px;text-align:center;font-weight:700}

/* Messages */
.toast{display:flex;gap:10px;align-items:center;padding:12px 14px;border-radius:var(--r-md);
  background:color-mix(in srgb,var(--good) 14%,var(--surface));margin:0 0 14px;font-weight:600}
.toast.bad{background:color-mix(in srgb,var(--bad) 14%,var(--surface))}
.toast .icon{color:var(--good)}
.toast.bad .icon{color:var(--bad)}

/* Alerts on Now */
.alerts{background:var(--surface);border-radius:var(--r-md);overflow:hidden;margin:0 0 16px}
.alert{display:flex;gap:12px;padding:14px 16px;align-items:flex-start}
.alert+.alert{border-top:1px solid var(--line)}
.alert .dot{width:34px;height:34px;border-radius:50%;display:grid;place-items:center;flex:none;
  background:color-mix(in srgb,var(--bad) 16%,transparent);color:var(--bad)}
.alert.go .dot{background:color-mix(in srgb,var(--marigold) 30%,transparent);color:var(--ink)}
.alert.calm .dot{background:var(--sunk);color:var(--muted)}
.alert .body{flex:1;min-width:0}
.alert .body b{display:block}
.alert .body .small{margin-top:2px}
.alert .btn{margin-top:10px}
.tabs .pill{position:relative}
.tabdot{position:absolute;top:2px;right:8px;width:9px;height:9px;border-radius:50%;
  background:#D9462B;box-shadow:0 0 0 2px var(--bg)}
.code{font-size:34px;font-weight:800;letter-spacing:.12em;margin:8px 0 2px;font-variant-numeric:tabular-nums}

/* Tiles: square art, like the real ones */
.art{display:block;width:100%;aspect-ratio:1;object-fit:cover;border-radius:var(--r-md);
  background:var(--sunk);box-shadow:var(--shadow-tile)}
.art.blank{display:grid;place-items:center;color:var(--muted)}

/* Bottom tabs */
nav.tabs{position:fixed;left:0;right:0;bottom:0;z-index:5;display:flex;justify-content:center;
  background:color-mix(in srgb,var(--paper) 88%,transparent);backdrop-filter:blur(16px);
  -webkit-backdrop-filter:blur(16px);border-top:1px solid var(--line);
  padding:6px 8px calc(6px + env(safe-area-inset-bottom))}
nav.tabs a{flex:1;min-width:0;max-width:140px;display:flex;flex-direction:column;align-items:center;gap:3px;
  color:var(--muted);text-decoration:none;font-size:12px;font-weight:600;padding:4px 0}
nav.tabs a span.pill{display:grid;place-items:center;width:56px;height:30px;border-radius:999px}
nav.tabs a.on{color:var(--ink)}
nav.tabs a.on span.pill{background:var(--marigold);color:var(--on-marigold)}
.backlink{display:inline-flex;align-items:center;gap:2px;color:var(--ink);text-decoration:none;
  font-weight:600;margin:4px 0 0 -6px}
@media (prefers-reduced-motion:reduce){*{transition:none!important;animation:none!important}}
{% block style %}{% endblock %}
</style></head><body><main>
{% block body %}{% endblock %}
</main>
{% if tab %}<nav class="tabs">
<a href="/" class="{{ 'on' if tab=='now' }}"><span class="pill">{{ icon('now') }}</span>Now</a>
<a href="/tiles" class="{{ 'on' if tab=='tiles' }}"><span class="pill">{{ icon('tiles') }}</span>Tiles</a>
<a href="/library" class="{{ 'on' if tab=='library' }}"><span class="pill">{{ icon('library') }}</span>Library</a>
<a href="/settings" class="{{ 'on' if tab=='settings' }}"><span class="pill">{{ icon('settings') }}{% if attention() %}<i class="tabdot" aria-label="Needs attention"></i>{% endif %}</span>Settings</a>
</nav>{% endif %}
</body></html>"""

PAGES["pin.html"] = """{% extends "base.html" %}
{% block style %}
.mark{width:64px;height:64px;border-radius:18px;margin:28px 0 4px;box-shadow:var(--shadow-tile)}
{% endblock %}{% block body %}
<img class="mark" src="/icon.png" alt="">
{% if first_time %}
<h1>Welcome to your <span style="white-space:nowrap">{{ brand_name }}</span></h1>
<form method="post" class="stack">
<input type="hidden" name="next" value="{{ next }}">
<p class="muted">Setup takes about 5 minutes: a PIN, a name for your speaker, your Wi-Fi, Spotify, and your first tile.</p>
<p class="muted small">The box shares anonymous usage (on/off and how long tiles play, never song names) with its maker. You can turn that off in Settings &gt; Listening.</p>
<p>First, choose a PIN. Grown-ups use it to change tiles and settings. Playing music never needs it.</p>
<input type="password" name="pin" inputmode="numeric" autocomplete="new-password" placeholder="4 to 8 numbers" aria-label="PIN" autofocus>
<input type="password" name="pin2" inputmode="numeric" autocomplete="new-password" placeholder="Same PIN again" aria-label="PIN again">
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}{{ error }}</div>{% endif %}
<button class="btn wide">Save PIN</button>
</form>
{% else %}
<h1>Enter your PIN</h1>
<form method="post" class="stack">
<input type="hidden" name="next" value="{{ next }}">
<input type="password" name="pin" inputmode="numeric" autocomplete="current-password" placeholder="PIN" aria-label="PIN" autofocus>
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}{{ error }}</div>{% endif %}
<button class="btn wide">Unlock</button>
<p class="muted small">Forgot it? Whoever set up the box can reset it.</p>
</form>
{% endif %}
{% endblock %}"""

PAGES["soloist_pair.html"] = """{% if pairing.needs_key %}
<div class="group pad stack">
<b>Step 1: your Spotify player key</b>
<p>The box plays through Spotify's own player, which needs a free key from your <b>Spotify Premium</b> account. On a phone or computer:</p>
<ol style="margin:0 0 0 20px;padding:0">
<li>Open <a href="https://developer.spotify.com/dashboard/soloist" target="_blank" rel="noopener">developer.spotify.com/dashboard/soloist</a> and log in with your Spotify Premium account.</li>
<li>Accept the terms if it asks, then generate a key.</li>
<li>Copy the key and paste it here.</li>
</ol>
{% if keyerror %}<div class="toast bad">That doesn't look like a whole key. Copy it again and paste the full thing.</div>{% endif %}
<form method="post" action="/account/soloist-key" class="stack">
<input type="hidden" name="back" value="{{ back }}">
<input type="password" name="key" autocomplete="off" placeholder="Paste your key" aria-label="Soloist key" required>
<button class="btn wide">Save key</button>
</form>
</div>
<p class="note">The key stays on this box. Don't share it; each person makes their own.</p>
{% else %}
<div class="group pad stack">
<b>Connect your Spotify account</b>
{% if pairing.running %}
<p>On your phone (on the same Wi-Fi), open the <b>Spotify</b> app, play any song, tap the <b>speaker icon</b>, and pick <b>{{ pairing.name }}</b>.</p>
<p class="muted small" id="wait">The box connects to that account and remembers it. This page moves on by itself.</p>
{% else %}
<p>Starting Spotify's player on the box. This takes up to a minute.</p>
<p class="muted small">Still stuck after a minute? The key may be wrong. Paste it again below.</p>
{% endif %}
{% if pairing.problem %}<p class="muted small">Spotify's player said: {{ pairing.problem }}</p>{% endif %}
</div>
{% if not pairing.running %}<script>setTimeout(() => location.reload(), 5000)</script>{% endif %}
<details style="margin-top:10px"><summary class="small" style="color:var(--link);cursor:pointer;margin:0 6px">Change the player key</summary>
<form method="post" action="/account/soloist-key" class="group pad stack" style="margin-top:10px">
<input type="hidden" name="back" value="{{ back }}">
<input type="password" name="key" autocomplete="off" placeholder="Paste your key" aria-label="Soloist key" required>
<button class="btn plain wide">Save new key</button>
</form></details>
{% endif %}"""

PAGES["soloist_install_card.html"] = """<div class="group pad stack">
<b>Step 1: put Spotify's player on the box</b>
<p>The box plays Spotify through Spotify's own player. It downloads straight from Spotify onto this box and takes 2 to 5 minutes. After that you add your free player key and pick the box in the Spotify app.</p>
{% if install.job.running %}
<a class="btn wide" href="/spotify/install?back={{ back }}">Installing... see progress</a>
{% elif not install.supported %}
<p class="small muted">Spotify's player doesn't run on this kind of box. Local music still works.</p>
{% elif not install.admin %}
<p class="small muted">This box needs the latest box software before it can install Spotify's player from the app. Ask whoever set up the box.</p>
{% elif install.protected and not install.auto %}
<p class="small muted">This box's helper is out of date, so it can't install Spotify's player from the app yet. Ask whoever set up the box.</p>
{% elif not install.quick %}
<form method="post" action="/spotify/install" onsubmit="return confirm('Install now? The box restarts during the install (about 10 minutes in all).')"><input type="hidden" name="back" value="{{ back }}">
<button class="btn wide">Install Spotify's player</button></form>
<p class="small muted">About 10 minutes in all. The box restarts during the install and this page follows along. Please don't unplug it meanwhile.</p>
{% if install.job.failed and install.job.error %}<p class="small muted">Last try stopped: {{ install.job.error }}</p>{% endif %}
{% else %}
<form method="post" action="/spotify/install"><input type="hidden" name="back" value="{{ back }}">
<button class="btn wide">Install Spotify's player</button></form>
{% if install.job.failed and install.job.error %}<p class="small muted">Last try stopped: {{ install.job.error }}</p>{% endif %}
{% endif %}
</div>
<p class="note">Needs a Spotify Premium account. Nothing about your account leaves the box except to Spotify.</p>"""

PAGES["player_card.html"] = """{% if player and player.state == 'stopped' %}
<div class="group pad stack">
<b>The music player has stopped</b>
<p>Your music and audiobooks are still on the box. Start the player again to see and play them.</p>
{% if player.can_start %}
<form method="post" action="/library/player"><input type="hidden" name="action" value="start"><button class="btn wide">Start the music player</button></form>
{% else %}
<p class="small muted">Restart the box (Settings) to start it again.</p>
{% endif %}
</div>
{% elif player %}
<div class="group pad stack">
<b>Set up the music player</b>
<p>Your own music and audiobooks play through a small music player on the box. This box doesn't have it yet. It downloads by itself and takes a few minutes.</p>
{% if player.job.running %}
<a class="btn wide" href="/library/player">Setting up... see progress</a>
{% elif not player.can_install %}
<p class="small muted">This box needs the latest box software first. Check Settings &gt; Software updates, or ask whoever set up the box.</p>
{% elif player.quick %}
<form method="post" action="/library/player"><input type="hidden" name="action" value="install"><button class="btn wide">Set up the music player</button></form>
{% else %}
<form method="post" action="/library/player" onsubmit="return confirm('Set up the music player now? The box restarts twice while it does (about 5 to 10 minutes).')"><input type="hidden" name="action" value="install">
<button class="btn wide">Set up the music player</button></form>
<p class="small muted">About 5 to 10 minutes. The box restarts twice and the page follows along. Please don't unplug it meanwhile.</p>
{% endif %}
{% if player.job.failed and player.job.error and not player.job.running %}<p class="small muted">Last try stopped: {{ player.job.error }}</p>{% endif %}
</div>
{% else %}
<div class="toast bad">{{ icon('alert', 20) }}<span>The music player isn't answering. Restart the box (Settings) and try again.</span></div>
{% endif %}"""

PAGES["player_install.html"] = """{% extends "base.html" %}
{% block style %}.bar{height:10px;border-radius:6px;background:var(--sunk);overflow:hidden}
.bar span{display:block;height:100%;background:var(--marigold);transition:width .4s}{% endblock %}
{% block body %}
<a class="backlink" href="/library">{{ icon('back', 22) }}Library</a>
<h1>Setting up the music player</h1>
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
{% if player.job.running or player.job.exists %}
{% set job = player.job %}{% include "jobprogress.html" %}
<script>
function jobFinished(d){
  function esc(s){ return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[c]); }
  const end = document.getElementById("jobend");
  document.getElementById("jobnote").textContent = "";
  if (d.ok) {
    end.innerHTML = `<div class="toast">{{ icon('check', 20) }}<span>${d.auto_message ? esc(d.auto_message) : "The music player is set up."}</span></div>
      <a class="btn wide" href="/library">Go to your Library</a>`;
  } else {
    end.innerHTML = `<div class="toast bad">{{ icon('alert', 20) }}<span>${d.error ? esc(d.error) : "Setting up stopped. Open Details below to see why."}</span></div>
      <form method="post" action="/library/player"><input type="hidden" name="action" value="install"><button class="btn wide">Try again</button></form>`;
  }
}
</script>
{% set jobname = "player" %}{% include "jobscript.html" %}
{% elif player.state == 'ok' %}
<div class="toast">{{ icon('check', 20) }}<span>The music player is set up.</span></div>
<a class="btn wide" href="/library">Go to your Library</a>
{% else %}
{% include "player_card.html" %}
{% endif %}
{% endblock %}"""

PAGES["jobprogress.html"] = """<div class="group pad stack" id="job">
<div class="bar"><span id="jobbar" style="width:{{ (100 * job.num / job.total) if job.total else 4 }}%"></span></div>
<p id="jobstep"><b>{{ job.step }}</b></p>
<p class="small muted" id="jobnote">{{ job.note or "Keep this page open, or come back to it later. Please don't unplug the box." }}</p>
</div>
<div id="jobend"></div>
<details style="margin-top:10px"><summary class="small" style="color:var(--link);cursor:pointer;margin:0 6px">Details</summary>
<pre class="small" id="joblog" style="white-space:pre-wrap;overflow-wrap:anywhere;max-height:300px;overflow:auto">{{ job.log }}</pre></details>"""

PAGES["jobscript.html"] = """<script>
(function(){
  const JOB = {{ jobname|tojson }};
  function esc(s){ return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[c]); }
  async function poll(){
    let d;
    try { const r = await fetch("/api/job/" + JOB, {cache: "no-store"}); if (!r.ok) throw 0; d = await r.json(); }
    catch (e) { document.getElementById("jobnote").textContent = "Waiting for the box to answer (it may be restarting). This page reconnects by itself."; return setTimeout(poll, 3000); }
    document.getElementById("jobbar").style.width = (d.total ? Math.max(4, 100 * d.num / d.total) : 4) + "%";
    document.getElementById("jobstep").innerHTML = "<b>" + esc(d.step) + "</b>";
    document.getElementById("joblog").textContent = d.log;
    if (d.running || !d.exists) { document.getElementById("jobnote").textContent = d.note || "Keep this page open, or come back to it later. Please don't unplug the box."; return setTimeout(poll, d.auto ? 3000 : 2000); }
    jobFinished(d);
  }
  setTimeout(poll, 1500);
})();
</script>"""

PAGES["soloist_install.html"] = """{% extends "base.html" %}
{% block style %}.bar{height:10px;border-radius:6px;background:var(--sunk);overflow:hidden}
.bar span{display:block;height:100%;background:var(--marigold);transition:width .4s}{% endblock %}
{% block body %}
<a class="backlink" href="{{ back }}">{{ icon('back', 22) }}{{ 'Setup' if back == '/setup' else 'Spotify' }}</a>
<h1>Installing Spotify's player</h1>
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
{% if not install.job.exists and not error %}
<p>Nothing is installing right now.</p><a class="btn wide" href="{{ back }}">Back</a>
{% elif error and not install.job.running %}
{% set back = back %}{% include "soloist_install_card.html" %}
{% else %}
{% set job = install.job %}{% include "jobprogress.html" %}
<script>
function jobFinished(d){
  const end = document.getElementById("jobend");
  if (d.ok) {
    document.getElementById("jobnote").textContent = "";
    end.innerHTML = `<div class="toast">{{ icon('check', 20) }}<span>${d.auto_message ? esc(d.auto_message) : "Spotify's player is on the box."}</span></div>
      <div class="group pad stack"><b>Next: ${d.has_key ? "pick this box in the Spotify app" : "add your Spotify player key"}</b>
      <p class="small">${d.has_key ? "Your key is already saved. Open Spotify on your phone, tap the speaker icon, and pick this box." : "It's free and takes a minute. The next page shows you how."}</p>
      <a class="btn wide" href="{{ back }}">Continue</a></div>`;
  } else {
    document.getElementById("jobnote").textContent = "";
    end.innerHTML = `<div class="toast bad">{{ icon('alert', 20) }}<span>${d.error ? esc(d.error) : "The install stopped. Open Details below to see why."}</span></div>
      <form method="post" action="/spotify/install"><input type="hidden" name="back" value="{{ back }}"><button class="btn wide">Try again</button></form>`;
  }
  function esc(s){ return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[c]); }
}
</script>
{% set jobname = "soloist" %}{% include "jobscript.html" %}
{% if install.job.ok or install.job.failed %}<script>/* already finished: the first poll shows the result */</script>{% endif %}
{% endif %}
{% endblock %}"""

PAGES["updates.html"] = """{% extends "base.html" %}
{% block style %}.bar{height:10px;border-radius:6px;background:var(--sunk);overflow:hidden}
.bar span{display:block;height:100%;background:var(--marigold);transition:width .4s}
.notes{white-space:pre-wrap}{% endblock %}
{% block body %}
<a class="backlink" href="/settings">{{ icon('back', 22) }}Settings</a>
<h1>Software updates</h1>
{% if message %}<div class="toast">{{ icon('check', 20) }}<span>{{ message }}</span></div>{% endif %}
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}

{% if job.running %}
<h2>{{ 'Going back to the earlier version' if job.command == 'update-rollback' else 'Installing the update' }}</h2>
{% include "jobprogress.html" %}
<script>function jobFinished(d){ location.replace("/updates"); }</script>
{% set jobname = "update" %}{% include "jobscript.html" %}
{% else %}

{% if job.auto in ('done', 'attention') %}
<div class="toast {{ '' if job.ok else 'bad' }}">{{ icon('check' if job.ok else 'alert', 20) }}<span>{{ job.auto_message }}</span></div>
{% elif result.message and job.exists %}
<div class="toast {{ '' if result.ok else 'bad' }}">{{ icon('check' if result.ok else 'alert', 20) }}<span>{{ result.message }}{% if result.ok and finishing %} The box restarts once more in a moment to finish.{% endif %}</span></div>
{% endif %}

<div class="group">
<div class="item"><span class="badge">{{ icon('settings', 18) }}</span><span class="label">This box</span><span class="value">Version {{ version }}</span></div>
{% if status.available %}
<div class="item"><span class="badge" style="color:var(--good)">{{ icon('plus', 18) }}</span><span class="label"><b>Version {{ status.latest }} is ready</b>{% if status.released %}<br><span class="small muted">Released {{ status.released }}</span>{% endif %}</span></div>
{% elif status.checked and not status.error %}
<div class="item"><span class="badge" style="color:var(--good)">{{ icon('check', 18) }}</span><span class="label">Up to date</span></div>
{% endif %}
</div>
{% if status.error %}<p class="note">Last check: {{ status.error }}</p>{% endif %}

{% if status.available %}
{% if status.notes %}<div class="group pad"><b>What's new</b><p class="small notes">{{ status.notes }}</p></div>{% endif %}
<div class="group pad stack">
{% if not admin %}
<p class="small">This box is missing the update helper. Whoever set up the box needs to install the latest box software by hand once.</p>
{% elif protected and not auto_ready %}
<p class="small">This box's helper is out of date, so it can't install updates from the app yet. Whoever set up the box needs to update it by hand once.</p>
{% elif not quick %}
<p class="small">About 10 minutes in all. Music stops, the box restarts during the install, and this page follows along. It keeps a copy of the current version and goes back to it by itself if the new one doesn't start properly.</p>
<form method="post" onsubmit="return confirm('Install version {{ status.latest }} now? The box restarts during the install (about 10 minutes in all).')"><input type="hidden" name="action" value="install"><button class="btn wide">Install {{ status.latest }}</button></form>
{% else %}
<p class="small">Takes a minute or two. The box keeps a copy of the current version and goes back to it by itself if the new one doesn't start properly. Music may stop for a moment.</p>
<form method="post" onsubmit="return confirm('Install version {{ status.latest }} now?')"><input type="hidden" name="action" value="install"><button class="btn wide">Install {{ status.latest }}</button></form>
{% endif %}
</div>
{% endif %}

<form method="post" class="group"><input type="hidden" name="action" value="check">
<button class="item"><span class="badge">{{ icon('restart', 18) }}</span><span class="label">Check now</span>{% if status.checked %}<span class="value" data-when="{{ status.checked }}"></span>{% endif %}</button></form>

<form method="post" class="group"><input type="hidden" name="action" value="auto"><input type="hidden" name="value" value="{{ 'off' if auto else 'on' }}">
<button class="item"><span class="badge">{{ icon('check' if auto else 'alert', 18) }}</span><span class="label">Check once a day<br><span class="small muted">{{ 'On. Tap to turn off.' if auto else 'Off. Tap to turn on.' }}</span></span></button></form>
<p class="note">Checking downloads one small public file from the Music Boxx update page. It sends nothing about this box, its music or its owner. Updates are only installed when you tap Install, and only if they carry the Music Boxx release signature.</p>

{% if backup %}
<details style="margin-top:22px"><summary class="small" style="color:var(--link);cursor:pointer;margin:0 6px">Go back to version {{ backup['from'] }}</summary>
<div class="group pad stack" style="margin-top:10px">
<p class="small">Undoes the last update. Your tiles, settings, Wi-Fi and Spotify stay as they are.</p>
{% if protected and not auto_ready %}<p class="small muted">This box's helper is out of date, so it can't do this from the app.</p>
{% elif admin %}{% if not quick %}<p class="small muted">The box restarts during this (about 10 minutes in all).</p>{% endif %}<form method="post" onsubmit="return confirm('Go back to version {{ backup['from'] }}?')"><input type="hidden" name="action" value="rollback"><button class="btn plain wide">Go back to {{ backup['from'] }}</button></form>{% endif %}
</div></details>
{% endif %}
{% endif %}
<script>
document.querySelectorAll("[data-when]").forEach(el => {
  const t = new Date(1000 * +el.dataset.when);
  el.textContent = "Last " + t.toLocaleDateString([], {month: "short", day: "numeric"}) + " " + t.toLocaleTimeString([], {hour: "numeric", minute: "2-digit"});
});
</script>
{% endblock %}"""

PAGES["progress.html"] = """<div class="progress">{% for i in range(step_count) %}<span class="{{ 'on' if i < step_num }}"></span>{% endfor %}</div>
<p class="stepnum">Step {{ step_num }} of {{ step_count }}</p>"""

PAGES["setup.html"] = """{% extends "base.html" %}
{% block style %}
.slot{width:180px;aspect-ratio:1;margin:8px auto 18px;border-radius:var(--r-md);
  border:2.5px dashed var(--line);display:grid;place-items:center;color:var(--muted)}
.slot.found{border-color:var(--marigold);color:var(--ink);background:color-mix(in srgb,var(--marigold) 18%,transparent)}
{% endblock %}{% block body %}
{% include "progress.html" %}
{% if step == "spotify" and need_install %}
<h1>Connect Spotify</h1>
{% set back = "/setup" %}{% include "soloist_install_card.html" %}
<p class="note"><a href="/setup?finish=1">Skip Spotify for now</a> (local music and radio still work)</p>
{% elif step == "spotify" and pairing and pairing.soloist %}
<h1>Connect Spotify</h1>
{% set back = "/setup" %}{% include "soloist_pair.html" %}
{% elif step == "spotify" %}
<h1>Connect Spotify</h1>
<div class="group pad stack">
<p>The box plays from a Spotify Premium account. On your phone, open
<a href="{{ pairing.url }}" target="_blank" rel="noopener">spotify.com/pair</a>, sign in, and type this code:</p>
<p class="code">{{ pairing.code }}</p>
<p class="muted small" id="wait">This page moves on by itself once Spotify says yes.</p>
</div>
<p class="note">Your Spotify password only goes to Spotify. The box never sees it.</p>
{% elif step == "speaker" %}
<h1>Waking up the speaker</h1>
<div class="group pad stack"><p>This takes up to a minute after plugging in. This page moves on by itself.</p>
<button class="btn plain small" onclick="fix(this)">{{ icon('restart', 18) }}Restart music</button></div>
{% else %}
<h1>Add your first tile</h1>
{% if tile %}
<div class="slot found">{{ icon('check', 56) }}</div>
<p style="text-align:center;margin-bottom:16px">Tile found. Now give it some music.</p>
<a class="btn wide" href="/tiles/{{ tile }}">Pick its music</a>
{% else %}
<div class="slot">{{ icon('tiles', 48) }}</div>
<p style="text-align:center">Set a blank tile on the box.<br><span class="muted">This page notices it right away.</span></p>
{% endif %}
{% endif %}
<p style="margin-top:28px;text-align:center"><a href="/setup?finish=1" class="muted small">Skip setup for now</a></p>
<script>
async function fix(b){ b.disabled = true; await fetch("/api/fix/restart-music",{method:"POST"}); }
const step = {{ step|tojson }}, tile = {{ (tile or "")|tojson }};
setInterval(async () => {
  try {
    const d = await (await fetch("/api/now")).json();
    if (step === "spotify" && d.signed_in) location.reload();
    if (step === "speaker" && d.speaker) location.reload();
    if (step === "tile" && (d.tile || "") !== tile) location.reload();
  } catch (e) {}
}, 2500);
</script>
{% endblock %}"""

PAGES["now.html"] = """{% extends "base.html" %}
{% block style %}
.top{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:6px}
h1.boxname{margin:12px 0 6px}
.net{display:flex;align-items:center;gap:6px;color:var(--muted);font-size:14px;font-weight:600;
  max-width:50%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.stage{position:relative;isolation:isolate;padding:22px 0 0}
.glow{position:absolute;z-index:-1;left:8%;right:8%;top:10px;aspect-ratio:1;border-radius:40px;
  background-size:cover;background-position:center;filter:blur(42px) saturate(1.5);opacity:.55}
.stage .art{width:min(84%,44vh);margin:0 auto;border-radius:var(--r-lg)}
.glow{left:50%!important;right:auto!important;width:min(84%,44vh);transform:translateX(-50%)}
.meta{text-align:center;margin:26px 8px 0}
.meta .title{font-family:var(--display);font-size:25px;font-weight:800;letter-spacing:-.01em;line-height:1.2;
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.meta .kind{color:var(--muted);font-size:13px;font-weight:700;margin-bottom:4px}
.meta .by{font-size:17px;font-weight:600;margin-top:4px}
.meta .album{color:var(--muted);font-size:15px;margin-top:2px}
.meta .by,.meta .album{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.transport{display:flex;align-items:center;justify-content:center;gap:28px;margin:22px 0 4px}
.transport button{border:0;background:none;color:var(--ink);cursor:pointer;display:grid;place-items:center;
  width:64px;height:64px;border-radius:50%;-webkit-tap-highlight-color:transparent}
.transport button:active{background:var(--sunk)}
.transport .main{width:84px;height:84px;background:var(--marigold);color:var(--on-marigold);
  box-shadow:0 6px 18px -6px color-mix(in srgb,var(--marigold) 80%,transparent)}
.transport .main:active{background:var(--marigold-press)}
.vol{display:flex;align-items:center;gap:12px;margin:22px 10px 0;color:var(--muted)}
.ticks{flex:1;display:flex;gap:3px;height:16px;align-items:flex-end}
.ticks i{flex:1;height:100%;border-radius:2px;background:var(--line)}
.ticks i.on{background:var(--ink)}
.vol b{color:var(--ink);font-variant-numeric:tabular-nums;min-width:2ch;text-align:right}
.idle{text-align:center;padding:16px 0 0}
.idle .slot{width:72%;margin:0 auto 22px;aspect-ratio:1;border-radius:var(--r-lg);
  border:2.5px dashed var(--line);display:grid;place-items:center;color:var(--muted)}
.idle h2{all:unset;display:block;font-size:22px;font-weight:800}
/* Spotify attribution: Spotify's icon, black on light pages, white on dark, with
   clear space of half its height around it. Spotify art is shown as it comes:
   no blurred glow behind it, small rounded corners, and it opens Spotify. */
.spot{color:#000}
@media (prefers-color-scheme:dark){:root:not([data-theme=light]) .spot{color:#fff}}
:root[data-theme=dark] .spot{color:#fff}
.stage.sp .art{border-radius:8px}
.stage .artlink{display:block;-webkit-tap-highlight-color:transparent}
.from{display:flex;align-items:center;justify-content:center;gap:12px;margin:16px auto 0;
  padding:12px;font-size:14px;font-weight:700;color:var(--ink);text-decoration:none;max-width:100%}
.from span{white-space:nowrap}
.from .open{color:var(--link);font-weight:600}
.from.plain{gap:8px;color:var(--muted)}
.from .open::before{content:"\\00b7";color:var(--muted);margin-right:10px}
@media (max-width:359px){.from{flex-wrap:wrap;row-gap:2px}.from .open{flex-basis:100%;text-align:center}
  .from .open::before{display:none}}
#about{margin-top:26px}
#about h2{margin-top:0}
#about .facts{color:var(--muted);font-size:14px;font-weight:600;margin:-4px 6px 12px}
#about .blurb{font-size:15px;line-height:1.5}
#about .src{font-size:13px;margin-top:8px}
#about dl{margin:0;display:grid;grid-template-columns:auto 1fr;gap:8px 14px;font-size:15px}
#about dt{color:var(--muted);font-weight:600}
#about dd{margin:0}
#about .sub{font-size:13px;font-weight:700;color:var(--muted);margin:0 0 8px;text-transform:uppercase;letter-spacing:.04em}
#about .sub .len{float:right;text-transform:none;letter-spacing:0;font-weight:600}
#about ol.tracks{list-style:none;margin:0;padding:0;font-size:15px}
#about ol.tracks li{display:flex;gap:12px;align-items:baseline;padding:7px 8px;margin:0 -8px;border-radius:var(--r-sm)}
#about ol.tracks .n{color:var(--muted);font-variant-numeric:tabular-nums;min-width:2ch;text-align:right;font-size:13px;font-weight:600}
#about ol.tracks .t{flex:1;min-width:0}
#about ol.tracks .d{color:var(--muted);font-variant-numeric:tabular-nums;font-size:13px}
#about ol.tracks li.on{background:color-mix(in srgb,var(--marigold) 22%,var(--surface));font-weight:700}
#about ol.tracks li.on .n,#about ol.tracks li.on .d{color:var(--ink)}
#about .disc{font-size:13px;font-weight:700;color:var(--muted);margin:12px 0 4px}
#about details.more summary{cursor:pointer;color:var(--link);font-weight:600;font-size:14px;padding:8px 0 0;list-style:none}
#about details.more summary::-webkit-details-marker{display:none}
#about details.more[open] summary{display:none}
{% endblock %}{% block body %}
<header class="top"><span class="brand">{{ brand_mark }}{{ brand_name }}</span><span class="net" id="net"></span></header>
<h1 class="boxname">{{ box_name }}</h1>
<div id="alerts"></div>
<section id="stage"><div class="idle"><div class="slot"></div></div></section>
<section id="about"></section>
<script>
const VERSION = {{ version|tojson }};
const ICON = {{ icon_svgs|tojson }};
const SPOTIFY = {{ spotify_svg|tojson }};
const $ = s => document.querySelector(s);
const esc = s => String(s || "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
let shown = "";
async function control(action){
  await fetch("/api/control/" + action, {method: "POST"});
  setTimeout(refresh, 450);
}
async function fixMusic(btn){
  btn.disabled = true; btn.textContent = "Restarting...";
  await fetch("/api/fix/restart-music", {method: "POST"});
  setTimeout(refresh, 15000);
}
function alert_(kind, icon, title, body, action){
  return `<div class="alert ${kind}"><span class="dot">${ICON[icon]}</span><div class="body">
    <b>${title}</b>${body ? `<p class="small muted">${body}</p>` : ""}${action || ""}</div></div>`;
}
async function noticeDone(btn, url){
  btn.disabled = true;
  try { await fetch(url, {method: "POST"}); } catch (e) {}
  refresh();
}
function render(html){ if (html !== shown) { $("#stage").innerHTML = html; shown = html; } }
async function refresh(){
  let d;
  try { d = await (await fetch("/api/now", {cache: "no-store"})).json(); }
  catch (e) {
    $("#alerts").innerHTML = `<div class="alerts">${alert_("", "wifi", "Can't reach the music box",
      "Make sure this phone is on the same Wi-Fi as the box. Just plugged in? Give it a minute.")}</div>`;
    return;
  }
  if (d.version && d.version !== VERSION) { location.reload(); return; }
  $("#net").innerHTML = d.wifi && !d.setup_mode ? ICON.wifi.replace('width="24" height="24"', 'width="16" height="16"') + esc(d.wifi) : "";

  let a = "";
  if (d.setup_mode) a += alert_("", "wifi", "The box needs Wi-Fi",
      "It couldn't find a network it knows.", `<a class="btn small" href="/wifi">Set up Wi-Fi</a>`);
  else if (!d.speaker) a += alert_("", "music", "The speaker isn't answering",
      "Normal for about a minute after plugging in.",
      `<button class="btn small" onclick="fixMusic(this)">Restart music</button>`);
  else if (!d.signed_in && d.pairing && d.pairing.soloist && !d.pairing.needs_key && d.pairing.running === false)
    a += alert_("", "music", "Spotify's player has stopped",
      "Tiles with Spotify music won't play until it's running again.",
      `<button class="btn small" onclick="fixMusic(this)">Restart music</button>`);
  else if (!d.signed_in && d.pairing && d.pairing.soloist) a += alert_("go", "link", "Connect Spotify",
      d.pairing.needs_key ? "The box needs your Spotify player key first."
        : `On your phone, open Spotify, tap the speaker icon, and pick <b>${esc(d.pairing.name)}</b>.`,
      `<a class="btn small" href="/account">Show me how</a>`);
  else if (!d.signed_in && d.pairing) a += alert_("go", "link", "Connect Spotify",
      `On your phone, open <a href="${esc(d.pairing.url)}" target="_blank" rel="noopener">spotify.com/pair</a> and type this code:`,
      `<p class="code">${esc(d.pairing.code)}</p>`);
  for (const n of (d.notices || [])) {
    const act = !n.action ? "" : n.action.post
      ? `<button class="btn small plain" onclick="noticeDone(this, '${esc(n.action.post)}')">${esc(n.action.label)}</button>`
      : `<a class="btn small plain" href="${esc(n.action.href)}">${esc(n.action.label)}</a>`;
    a += alert_(n.kind, n.icon, esc(n.title), esc(n.body), act);
  }
  if (!d.reader_ok) a += alert_("", "alert", "The tile reader isn't answering",
      "Unplug the box, count to 10, and plug it back in.");
  if (d.fake_tile) a += alert_("", "alert", "That isn't a Music Boxx tile",
      "This box only plays tiles from Music Boxx. Tiles it already played keep working.");
  if (d.new_tile) a += alert_("go", "plus", "New tile on the box",
      d.teaching ? "Pick its music here, or play something on " + esc({{ box_name|tojson }}) + " from the Spotify app in the next minute." : "Pick its music and it's ready to go.",
      `<a class="btn small" href="/tiles/${esc(d.tile)}">Pick its music</a>`);
  if (d.update) a += alert_("calm", "restart", "Software update ready",
      `Version ${esc(d.update)} is available for this box.`,
      `<a class="btn small plain" href="/updates">See what's new</a>`);
  if (d.maintenance) a += alert_("calm", "shield", "Maintenance mode is on",
      "Use Shut down before unplugging. Switch it off when you're done.",
      `<a class="btn small plain" href="/advanced">Open</a>`);
  else if (d.protect_failed) a += alert_("calm", "shield", "Use Shut down before unplugging",
      "Pulling the plug could harm the box right now. Tap Try again to fix that.",
      `<a class="btn small plain" href="/advanced">Try again</a>`);
  $("#alerts").innerHTML = a ? `<div class="alerts">${a}</div>` : "";

  if (!d.on_box) {
    render(`<div class="idle"><div class="slot">${ICON.tiles.replace(/"24"/g, '"56"')}</div>
      <h2>Set a tile on the box</h2><p class="muted">It starts playing right away.</p></div>`);
    return;
  }
  let art = d.image
    ? `<div class="glow" style="background-image:url('${esc(d.image)}')"></div><img class="art" src="${esc(d.image)}" alt="">`
    : `<div class="art blank" style="width:84%;margin:0 auto">${ICON.music}</div>`;
  let from = "";
  if (d.spotify) {
    const link = esc(d.link || "https://open.spotify.com/");
    if (d.image) art = `<a class="artlink" href="${link}" target="_blank" rel="noopener" aria-label="Open in Spotify">` +
      `<img class="art" src="${esc(d.image)}" alt=""></a>`;
    from = `<a class="from" href="${link}" target="_blank" rel="noopener">${SPOTIFY}` +
      `<span>Playing from Spotify</span><span class="open">Open Spotify</span></a>`;
  } else if (d.source) {
    from = `<div class="from plain">${ICON.music.replace(/"24"/g, '"20"')}<span>Playing from ${esc(d.source)}</span></div>`;
  }
  let vol = "";
  if (d.volume !== undefined) {
    const lit = Math.round(d.volume / 5);
    vol = `<div class="vol" aria-label="Volume ${d.volume}">${ICON.volume}<div class="ticks">` +
      Array.from({length: 20}, (_, i) => `<i class="${i < lit ? "on" : ""}" style="height:${40 + i * 3}%"></i>`).join("") +
      `</div><b>${d.volume}</b></div>`;
  }
  render(`<div class="stage${d.spotify ? " sp" : ""}">${art}
    <div class="meta">${d.kind ? `<div class="kind">Playing ${esc(d.kind.toLowerCase())}</div>` : ""}<div class="title">${esc(d.track)}</div><div class="by">${esc(d.artist)}</div>
    <div class="album">${esc(d.album)}</div></div>${from}
    <div class="transport">
      <button onclick="control('back')" aria-label="Back">${ICON.prev.replace(/"24"/g, '"32"')}</button>
      <button class="main" onclick="control('${d.playing ? "pause" : "play"}')" aria-label="${d.playing ? "Pause" : "Play"}">${(d.playing ? ICON.pause : ICON.play).replace(/"24"/g, '"34"')}</button>
      <button onclick="control('next')" aria-label="Next">${ICON.next.replace(/"24"/g, '"32"')}</button>
    </div>${vol}</div>`);
}
/* About this album: fetched once per album, hidden when nothing is known. */
let aboutKey = "", aboutTimer = null;
function credits(rows) {
  return `<dl>${rows.map(r => `<dt>${esc(r.role)}</dt><dd>${r.names.map(esc).join(", ")}</dd>`).join("")}</dl>`;
}
function mmss(ms) {
  if (!ms) return "";
  const s = Math.round(ms / 1000);
  return s >= 3600 ? `${Math.floor(s / 3600)}:${String(Math.floor(s / 60) % 60).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`
    : `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}
/* Track list, with the song that's on now highlighted. Long lists (box sets)
   show the first 15 and a "Show all" link, unless the song on now is further down. */
function trackList(list) {
  if (!list || !list.length) return "";
  const discs = new Set(list.map(t => t.disc)).size > 1;
  const total = list.reduce((sum, t) => sum + (t.ms || 0), 0);
  const on = list.findIndex(t => t.playing);
  const cut = list.length > 20 && on < 15 ? 15 : list.length;
  const rows = part => {
    let h = "", disc = null;
    for (const t of part) {
      if (discs && t.disc !== disc) { if (h) h += "</ol>"; h += `<p class="disc">Disc ${esc(t.disc)}</p><ol class="tracks">`; disc = t.disc; }
      else if (!h) h += `<ol class="tracks">`;
      h += `<li class="${t.playing ? "on" : ""}"${t.playing ? ' aria-current="true"' : ""}><span class="n">${esc(t.n)}</span>` +
        `<span class="t">${esc(t.title)}</span><span class="d">${t.playing ? ICON.volume.replace(/"24"/g, '"14"') : mmss(t.ms)}</span></li>`;
    }
    return h + "</ol>";
  };
  let h = `<div class="group pad"><p class="sub">Tracks${total ? `<span class="len">${list.length} songs &middot; ${mmss(total)}</span>` : ""}</p>${rows(list.slice(0, cut))}`;
  if (cut < list.length) h += `<details class="more"><summary>Show all ${list.length} songs</summary>${rows(list.slice(cut))}</details>`;
  return h + "</div>";
}
async function loadAbout(key, tries) {
  clearTimeout(aboutTimer);
  let a;
  try { a = await (await fetch("/api/about", {cache: "no-store"})).json(); } catch (e) { return; }
  if (key !== aboutKey) return;
  if (a.status === "loading") { if (tries < 40) aboutTimer = setTimeout(() => loadAbout(key, tries + 1), 3000); return; }
  if (a.status !== "ok") { $("#about").innerHTML = ""; return; }
  const facts = [a.year, a.label, a.type && a.type !== "Album" ? a.type : ""].filter(Boolean).map(esc).join(" &middot; ");
  const wiki = a.wiki || a.artist_wiki;
  let h = `<h2>About this ${a.type === "EP" ? "EP" : a.type === "Single" ? "single" : "album"}</h2>`;
  if (facts) h += `<p class="facts">${facts}</p>`;
  if (wiki) h += `<div class="group pad">${a.artist_wiki && !a.wiki ? `<p class="sub">About ${esc(a.artist_wiki.name)}</p>` : ""}
    <p class="blurb">${esc(wiki.text)}</p>
    <p class="src muted">From <a href="${esc(wiki.link)}" target="_blank" rel="noopener">Wikipedia</a> (CC BY-SA)</p></div>`;
  h += trackList(a.tracklist);
  if (a.track_credits && a.track_credits.length)
    h += `<div class="group pad"><p class="sub">This song</p>${credits(a.track_credits)}</div>`;
  if (a.credits && a.credits.length)
    h += `<div class="group pad"><p class="sub">Album credits</p>${credits(a.credits)}</div>`;
  h += `<p class="note">${(a.tracklist || []).length ? "Tracks and credits" : "Credits"} from <a href="${esc(a.mb)}" target="_blank" rel="noopener">MusicBrainz</a>, the free music encyclopedia.</p>`;
  $("#about").innerHTML = (facts || wiki || (a.tracklist || []).length || (a.credits || []).length || (a.track_credits || []).length) ? h : "";
}
const _refresh = refresh;
refresh = async function () {
  await _refresh();
  const t = document.querySelector("#stage .meta");
  const key = t ? t.textContent : "";
  if (!t) { aboutKey = ""; $("#about").innerHTML = ""; return; }
  if (key !== aboutKey) { aboutKey = key; loadAbout(key, 0); }
};
refresh();
setInterval(() => { if (!document.hidden) refresh(); }, 4000);
document.addEventListener("visibilitychange", () => { if (!document.hidden) refresh(); });
</script>
{% endblock %}"""

PAGES["tiles.html"] = """{% extends "base.html" %}
{% block style %}
.head{display:flex;align-items:baseline;justify-content:space-between}
.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:22px 16px}
@media (min-width:500px){.grid{grid-template-columns:repeat(3,1fr)}}
.tile{display:block;color:var(--ink);text-decoration:none;min-width:0}
.tile .name{font-weight:700;font-size:15px;line-height:1.25;margin-top:10px;
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.tile .where{display:flex;align-items:center;gap:4px;font-size:13px;color:var(--muted);margin-top:3px}
.tile .where.any{color:var(--good)}
.tile.here .art{outline:3px solid var(--marigold);outline-offset:3px}
.tile.new .art{box-shadow:none;border:2.5px dashed var(--marigold);background:color-mix(in srgb,var(--marigold) 14%,transparent);color:var(--ink)}
.tile .chev{display:none}
.tile .kind{font-size:12px;font-weight:700;color:var(--muted);margin-top:10px}
.tile .kind+.name{margin-top:1px}
html[data-view=list] .tile .kind{margin-top:0}
.viewswitch{display:inline-flex;background:var(--sunk);border-radius:999px;padding:3px;gap:2px}
.viewswitch button{border:0;background:none;color:var(--muted);width:40px;height:32px;border-radius:999px;
  display:grid;place-items:center;cursor:pointer}
.viewswitch button[aria-pressed=true]{background:var(--raised);color:var(--ink);box-shadow:0 1px 3px rgba(0,0,0,.15)}
.count{margin:-8px 4px 14px}
/* Compact list view */
html[data-view=list] .grid{display:block;background:var(--surface);border-radius:var(--r-md);overflow:hidden}
html[data-view=list] .tile{display:flex;align-items:center;gap:14px;padding:10px 14px}
html[data-view=list] .tile+.tile{border-top:1px solid var(--line)}
html[data-view=list] .tile .art{width:48px;flex:none;border-radius:8px;box-shadow:none}
html[data-view=list] .tile .art .icon{width:22px;height:22px}
html[data-view=list] .tile .txt{flex:1;min-width:0}
html[data-view=list] .tile .name{margin-top:0;-webkit-line-clamp:1}
html[data-view=list] .tile .where{margin-top:1px}
html[data-view=list] .tile .chev{display:block;color:var(--muted)}
html[data-view=list] .tile.here{background:color-mix(in srgb,var(--marigold) 14%,transparent)}
html[data-view=list] .tile.here .art{outline:none}
html[data-view=list] .tile.new .art{border-width:2px}
.empty{text-align:center;padding:30px 10px}
.empty .art{width:120px;margin:0 auto 16px;box-shadow:none;border:2.5px dashed var(--line);background:none}
{% endblock %}{% block body %}
<script>try { document.documentElement.dataset.view = localStorage.getItem("tileView") || "grid"; } catch (e) {}</script>
<div class="head"><h1>Tiles</h1>{% if tokens %}<div class="viewswitch" role="group" aria-label="View">
<button type="button" data-v="grid" aria-label="Album view" title="Album view">{{ icon('tiles', 20) }}</button>
<button type="button" data-v="list" aria-label="List view" title="List view">{{ icon('list', 20) }}</button></div>{% endif %}</div>
{% if tokens %}<p class="count muted small">{{ tokens|length }} tile{{ 's' if tokens|length != 1 }}</p>{% endif %}
{% if writing %}
<div class="toast" id="writing">{{ icon('save', 20) }}Saving onto the tile. Keep it on the box for a moment.</div>
{% elif request.args.get('failed') %}
<div class="toast bad">{{ icon('alert', 20) }}<span>Saved for this box, but it didn't save onto the tile. Keep the tile still and try again from its page.</span></div>
{% elif saved %}<div class="toast">{{ icon('check', 20) }}Saved. Set the tile on the box to play it.</div>{% endif %}
{% if refused %}<div class="toast bad">{{ icon('alert', 20) }}<span>The tile on the box isn't a Music Boxx tile, so it can't be given music. Tiles from Music Boxx work, and so do tiles this box already played.</span></div>{% endif %}
{% if not reader_ok %}
<div class="alerts"><div class="alert"><span class="dot">{{ icon('alert', 20) }}</span><div class="body">
<b>The tile reader isn't answering</b><p class="small muted">Unplug the box, count to 10, and plug it back in.</p></div></div></div>
{% endif %}

{% if tokens or on_reader_new %}
<div class="grid">
{% if on_reader_new %}
<a class="tile new" href="/tiles/{{ on_reader }}">
<div class="art blank">{{ icon('plus', 40) }}</div>
<div class="txt"><div class="name">New tile on the box</div><div class="where">Tap to pick its music</div></div>
<span class="chev">{{ icon('chevron', 18) }}</span></a>
{% endif %}
{% for tid, t in tokens.items() %}
<a class="tile {{ 'here' if tid == on_reader }}" href="/tile/{{ tid }}">
{% if t.image %}<img class="art" src="{{ t.image }}" alt="" loading="lazy">{% else %}<div class="art blank">{{ icon('music', 36) }}</div>{% endif %}
<div class="txt"><div class="kind">{{ t|badge }}</div><div class="name">{{ t.name or "Untitled tile" }}</div>
{% if tid == on_reader %}<div class="where">{{ icon('now', 14) }}On the box now</div>
{% endif %}</div>
<span class="chev">{{ icon('chevron', 18) }}</span>
</a>
{% endfor %}
</div>
{% if teaching and on_reader_new %}<p class="note" style="margin-top:20px">Shortcut: play any album on {{ box_name }} from the Spotify app in the next minute and the new tile learns it.</p>{% endif %}
{% else %}
<div class="empty"><div class="art"></div><b>No tiles yet</b><p class="muted">Set a blank tile on the box and it shows up here.</p></div>
{% endif %}
<script>
function showView(v) {
  document.documentElement.dataset.view = v;
  document.querySelectorAll(".viewswitch button").forEach(b => b.setAttribute("aria-pressed", b.dataset.v === v));
  try { localStorage.setItem("tileView", v); } catch (e) {}
}
document.querySelectorAll(".viewswitch button").forEach(b => b.onclick = () => showView(b.dataset.v));
showView(document.documentElement.dataset.view || "grid");
let last = {{ (on_reader or "")|tojson }};
const writing = {{ (writing or "")|tojson }};
setInterval(async () => {
  try {
    const d = await (await fetch("/api/reader")).json();
    if (writing && d.write && d.write.id === writing) {
      location.replace(d.write.ok ? "/tiles?saved=1" : "/tiles?failed=1");
      return;
    }
    if (!writing && (d.token || "") !== last) location.replace("/tiles");
  } catch (e) {}
}, 1500);
{% if writing %}setTimeout(() => location.replace("/tiles?failed=1"), 15000);{% endif %}
</script>
{% endblock %}"""

PAGES["tile.html"] = """{% extends "base.html" %}
{% block style %}
.hero{width:62%;margin:14px auto 18px}
.kindline{text-align:center;color:var(--muted);font-size:14px;font-weight:700;margin-bottom:2px}
.title{text-align:center;font-size:22px;font-weight:800;line-height:1.25;margin:0 8px}
.where{display:flex;justify-content:center;align-items:center;gap:5px;color:var(--muted);font-size:14px;margin:6px 0 22px}
.where.any{color:var(--good)}
{% endblock %}{% block body %}
<a class="backlink" href="/tiles">{{ icon('back', 22) }}Tiles</a>
{% if renamed %}<div class="toast" style="margin-top:12px">{{ icon('check', 20) }}Renamed.</div>{% endif %}
<div class="hero">{% if t.image %}<img class="art" src="{{ t.image }}" alt="">{% else %}<div class="art blank">{{ icon('music', 44) }}</div>{% endif %}</div>
<p class="kindline">{{ t|badge }}</p>
<p class="title">{{ t.name or "Untitled tile" }}</p>
{% if on_reader %}<p class="where">{{ icon('now', 15) }}On the box now</p>
{% else %}<p class="where"></p>{% endif %}

<div class="group">
<a class="item" href="/tiles/{{ tid }}"><span class="badge">{{ icon('music', 18) }}</span><span class="label">Change its music</span><span class="chev">{{ icon('chevron', 18) }}</span></a>
</div>

{% if t.uri.startswith("local:") %}
{% if arterr %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ arterr }}</span></div>{% endif %}
<h2>Picture</h2>
<form method="post" action="/tile/{{ tid }}/art" enctype="multipart/form-data" class="group pad stack">
<input type="file" name="picture" accept="image/*" aria-label="Picture" required>
<button class="btn plain wide">Use this picture</button>
{% if t.image %}<button class="btn plain wide" name="remove" value="1" formnovalidate>Remove picture</button>{% endif %}
</form>
<p class="note">Or put a picture named cover.jpg in the music folder and link the tile again.</p>
{% endif %}

<h2>Name</h2>
<form method="post" action="/tiles/rename" class="group pad" style="display:flex;gap:10px">
<input type="hidden" name="token" value="{{ tid }}">
<input type="text" name="name" value="{{ t.name }}" aria-label="Tile name">
<button class="btn plain">Rename</button></form>

<div class="group" style="margin-top:28px">
<form method="post" action="/tiles/delete" onsubmit="return confirm('Remove this tile from the list?')">
<input type="hidden" name="token" value="{{ tid }}">
<button class="item danger"><span class="badge" style="color:var(--bad)">{{ icon('trash', 18) }}</span><span class="label">Remove tile</span></button></form>
</div>
<p class="note" style="margin-top:18px">Tile ID {{ tid }}</p>
{% endblock %}"""

PAGES["tile_music.html"] = """{% extends "base.html" %}
{% block style %}
.current{display:flex;align-items:center;gap:14px}
.current .art{width:64px;flex:none;border-radius:var(--r-sm)}
ol.how{margin:0;padding:0;list-style:none;counter-reset:s}
ol.how li{counter-increment:s;display:flex;gap:12px;align-items:flex-start;padding:6px 0}
ol.how li::before{content:counter(s);flex:none;width:26px;height:26px;border-radius:50%;
  background:var(--sunk);display:grid;place-items:center;font-weight:800;font-size:14px}
.result{display:flex;align-items:center;gap:12px}
.result .art{width:56px;flex:none;border-radius:var(--r-sm);box-shadow:none}
.result .label{flex:1;min-width:0;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
{% endblock %}{% block body %}
<a class="backlink" href="{{ '/tile/' ~ token_id if current else '/tiles' }}">{{ icon('back', 22) }}{{ "Tile" if current else "Tiles" }}</a>
<h1>{{ "Change its music" if current else "Pick its music" }}</h1>
{% if current %}<div class="group pad current">
{% if current.image %}<img class="art" src="{{ current.image }}" alt="">{% else %}<div class="art blank">{{ icon('music') }}</div>{% endif %}
<div style="min-width:0"><div class="small muted">Plays this {{ (current.uri|kind or "music")|lower }} now</div><b>{{ current.name or current.uri }}</b></div></div>{% endif %}
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
<h2>Spotify</h2>
<form method="post" class="group pad stack" id="paste">
<ol class="how">
<li><span>In Spotify, open an album, playlist, song, artist or podcast.</span></li>
<li><span>Tap the three dots, then <b>Share</b>, then <b>Copy link</b>.</span></li>
<li><span>Paste it here.</span></li></ol>
<button type="button" class="btn wide" id="pastebtn" hidden>{{ icon('link', 20) }}Paste link</button>
<input type="url" name="link" placeholder="https://open.spotify.com/album/..." aria-label="Spotify link" autocomplete="off">
<button class="btn plain wide">Save</button>
</form>
{% if can_search %}
<h2>Search Spotify</h2>
<form method="get" style="display:flex;gap:10px"><input type="search" name="q" value="{{ query }}" placeholder="Album, artist, or playlist" aria-label="Search">
<button class="btn plain">Search</button></form>
{% if results %}<div class="group" style="margin-top:12px">
{% for r in results %}
<form method="post" action="/tiles/save">
<input type="hidden" name="token" value="{{ token_id }}"><input type="hidden" name="uri" value="{{ r.uri }}">
<input type="hidden" name="name" value="{{ r.name }}"><input type="hidden" name="image" value="{{ r.image }}">
<button class="item result">{% if r.image %}<img class="art" src="{{ r.image }}" alt="">{% else %}<span class="art blank"></span>{% endif %}
<span class="label">{{ r.name }}<br><span class="small muted" style="font-weight:400">{{ r.kind }}</span></span>
<span class="btn small">Use</span></button></form>
{% endfor %}</div>{% endif %}
{% endif %}
{% if apple_on %}
<h2>Apple Music <span class="small muted" style="font-weight:400">experimental</span></h2>
{% if apple_error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ apple_error }}</span></div>{% endif %}
<form method="post" action="/tiles/apple" class="group pad stack">
<input type="hidden" name="token" value="{{ token_id }}">
<p class="small muted">In Apple Music, open an album or playlist, tap the three dots, <b>Share</b>, <b>Copy Link</b>, and paste it here.</p>
<input type="url" name="link" placeholder="https://music.apple.com/us/album/..." aria-label="Apple Music link" autocomplete="off">
<button class="btn plain wide">Save</button>
</form>
<form method="get" style="display:flex;gap:10px;margin-top:12px"><input type="search" name="aq" value="{{ aquery }}" placeholder="Search Apple Music albums" aria-label="Search Apple Music">
<button class="btn plain">Search</button></form>
{% if apple_results %}<div class="group" style="margin-top:12px">
{% for r in apple_results %}
<form method="post" action="/tiles/apple">
<input type="hidden" name="token" value="{{ token_id }}"><input type="hidden" name="uri" value="{{ r.uri }}">
<input type="hidden" name="name" value="{{ r.name }}{% if r.artist %} · {{ r.artist }}{% endif %}"><input type="hidden" name="image" value="{{ r.image }}">
<button class="item result">{% if r.image %}<img class="art" src="{{ r.image }}" alt="">{% else %}<span class="art blank"></span>{% endif %}
<span class="label">{{ r.name }}<br><span class="small muted" style="font-weight:400">{{ r.artist }}{% if r.year %} · {{ r.year }}{% endif %}</span></span>
<span class="btn small">Use</span></button></form>
{% endfor %}</div>{% endif %}
{% endif %}
<h2>Local music</h2>
{% if shelves %}<div class="group">
{% for artist, albums in shelves %}{% for f in albums %}
<form method="post" action="/tiles/local">
<input type="hidden" name="token" value="{{ token_id }}"><input type="hidden" name="path" value="{{ f.key }}">
<button class="item result"><span class="art blank" style="position:relative;overflow:hidden">{{ icon('music', 24) }}<img src="/art/album?key={{ f.key|urlencode }}" alt="" loading="lazy" onerror="this.remove()" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:inherit"></span>
<span class="label">{{ f.album }}<br><span class="small muted" style="font-weight:400">{{ f.artist or "Unknown artist" }}{% if f.year %} · {{ f.year }}{% endif %} · {{ f.tracks }} track{{ 's' if f.tracks != 1 }}{% if f.book %} · Audiobook{% endif %}</span></span>
<span class="btn small">Use</span></button></form>
{% endfor %}{% endfor %}</div>
{% else %}<p class="note">Nothing yet. <a href="/library/add">Add music</a> from a USB stick or your phone.</p>{% endif %}
<script>
const box = document.querySelector("#paste input[name=link]");
const btn = document.getElementById("pastebtn");
if (navigator.clipboard && navigator.clipboard.readText) {
  btn.hidden = false;
  btn.onclick = async () => {
    try {
      box.value = (await navigator.clipboard.readText()).trim();
      if (box.value.includes("spotify")) document.getElementById("paste").submit();
    } catch (e) { box.focus(); }
  };
}
</script>
{% endblock %}"""

PAGES["music.html"] = """{% extends "base.html" %}
{% block style %}
.head{display:flex;align-items:center;justify-content:space-between;gap:12px}
.head .btn{flex:none}
.count{margin:-10px 4px 14px}
.findbox{position:relative;margin:0 0 14px}
.findbox .icon{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:var(--muted);pointer-events:none}
.findbox input{padding-left:42px;background:var(--surface);border-color:transparent}
.findbox input:focus{border-color:var(--marigold)}
.seg{margin:0 0 18px}
.cover{position:relative;display:block;width:100%;aspect-ratio:1;border-radius:var(--r-md);overflow:hidden;
  background:var(--sunk);box-shadow:var(--shadow-tile);display:grid;place-items:center;color:var(--muted)}
.cover img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:22px 16px}
@media (min-width:500px){.grid{grid-template-columns:repeat(3,minmax(0,1fr))}}
.card{position:relative;min-width:0}
.card a{display:block;color:var(--ink);text-decoration:none}
.card a.cover{display:grid}
.coverwrap{position:relative}
.coverwrap form{position:absolute;right:8px;bottom:8px;margin:0}
.card .name{font-weight:700;font-size:15px;line-height:1.25;margin-top:10px;
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.card .by{font-size:13px;color:var(--muted);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.playbtn{width:44px;height:44px;border-radius:50%;border:0;display:grid;place-items:center;cursor:pointer;
  background:var(--marigold);color:var(--on-marigold);box-shadow:0 2px 8px rgba(0,0,0,.3)}
.playbtn:active{background:var(--marigold-press)}
.chip{display:inline-flex;align-items:center;gap:4px;font-size:12px;font-weight:700;border-radius:999px;
  padding:3px 8px;background:var(--sunk);color:var(--ink);vertical-align:middle}
.chip.live{background:var(--marigold);color:var(--on-marigold)}
.card .chips2{position:absolute;left:8px;top:8px;display:flex;gap:4px;flex-wrap:wrap}
.card .chips2 .chip{background:color-mix(in srgb,var(--surface) 88%,transparent);backdrop-filter:blur(6px)}
.card .chips2 .chip.live{background:var(--marigold)}
.row{display:flex;align-items:center;gap:12px}
.row .cover{width:52px;height:52px;flex:none;border-radius:var(--r-sm);box-shadow:none}
.row .label{flex:1;min-width:0;font-weight:700}
.row .label .small{font-weight:400;display:block}
.row .playbtn{width:40px;height:40px;box-shadow:none}
.row>a{display:flex;align-items:center;gap:12px;flex:1;min-width:0;color:var(--ink);text-decoration:none}
h3.artist{font-size:14px;font-weight:800;color:var(--muted);margin:22px 4px 8px;text-transform:uppercase;letter-spacing:.04em}
h3.artist:first-child{margin-top:0}
.bar{height:5px;border-radius:3px;background:var(--line);overflow:hidden;margin-top:6px}
.bar span{display:block;height:100%;background:var(--marigold)}
.cont{display:flex;gap:14px;overflow-x:auto;scroll-snap-type:x mandatory;margin:0 -18px 6px;padding:2px 18px 10px;
  scrollbar-width:none}
.cont::-webkit-scrollbar{display:none}
.cont .card{flex:none;width:148px;scroll-snap-align:start}
.hint{font-size:13px;color:var(--muted);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.nores{text-align:center;padding:26px 10px}
.empty{text-align:center;padding:30px 10px}
.empty .cover{width:120px;margin:0 auto 16px;box-shadow:none;border:2.5px dashed var(--line);background:none}
.empty .btn{margin-top:16px}
{% endblock %}{% block body %}
<script>try { document.documentElement.dataset.lib = localStorage.getItem("libView") || "albums"; } catch (e) {}</script>
<div class="head"><h1>Library</h1><a class="btn small plain" href="/library/add">{{ icon('plus', 18) }}Add music</a></div>
{% if album_count %}<p class="count muted small">{{ albums|length }} album{{ 's' if albums|length != 1 }}{% if artist_count %} · {{ artist_count }} artist{{ 's' if artist_count != 1 }}{% endif %}{% if books %} · {{ books|length }} audiobook{{ 's' if books|length != 1 }}{% endif %}{% if usb %} · USB stick in{% endif %}</p>{% endif %}
{% if message %}<div class="toast">{{ icon('check', 20) }}<span>{{ message }}</span></div>{% endif %}
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
{% if not player_ok %}{% include "player_card.html" %}{% endif %}

{% macro playform(a, cls='playbtn', label='Play') %}<form method="post" action="/music/play"><input type="hidden" name="path" value="{{ a.key }}"><button class="{{ cls }}" aria-label="{{ label }} {{ a.album }}" title="{{ label }}">{{ icon('play', 20) }}</button></form>{% endmacro %}
{% macro coverimg(a, size=36) %}{{ icon('book' if a.book else 'music', size) }}<img src="/art/album?key={{ a.key|urlencode }}" alt="" loading="lazy" onerror="this.remove()">{% endmacro %}

{% if album_count %}
<div class="findbox">{{ icon('search', 20) }}<input type="search" id="find" placeholder="Search artists, albums, songs" aria-label="Search your library" autocomplete="off"></div>

{% if started %}<div id="continue">
<h2 style="margin-top:0">Continue listening</h2>
<div class="cont">
{% for a in started %}{% set p = progress[a.key] %}
<div class="card"><div class="coverwrap"><a class="cover" href="/music/album?key={{ a.key|urlencode }}" aria-hidden="true" tabindex="-1">{{ coverimg(a) }}</a>{{ playform(a, label='Carry on with') }}</div>
<a href="/music/album?key={{ a.key|urlencode }}"><div class="name">{{ a.album }}</div>
<div class="bar" aria-label="{{ p.percent }}% listened"><span style="width:{{ p.percent }}%"></span></div>
<div class="by">{{ dur(p.left) }} left</div></a>
</div>
{% endfor %}</div></div>{% endif %}

<div class="seg" role="radiogroup" aria-label="Show">
<button type="button" role="radio" data-v="albums">Albums</button>
<button type="button" role="radio" data-v="artists">Artists</button>
{% if books %}<button type="button" role="radio" data-v="books">Audiobooks</button>{% endif %}
</div>

<section data-view="albums">
{% if albums %}<div class="grid">
{% for a in albums %}
<div class="card" data-find="{{ ((a.artist or '') ~ ' ' ~ a.album)|lower }}" data-songs="{{ a.titles }}">
<div class="coverwrap"><a class="cover" href="/music/album?key={{ a.key|urlencode }}" aria-hidden="true" tabindex="-1">{{ coverimg(a) }}
{% if playing == a.key or tiled.get(a.key) %}<span class="chips2">{% if playing == a.key %}<span class="chip live">{{ icon('now', 12) }}Playing</span>{% endif %}{% if tiled.get(a.key) %}<span class="chip">{{ icon('tiles', 12) }}Tile</span>{% endif %}</span>{% endif %}</a>{{ playform(a) }}</div>
<a href="/music/album?key={{ a.key|urlencode }}"><div class="name">{{ a.album }}</div>
<div class="by">{{ a.artist or "Unknown artist" }}{% if a.year %} · {{ a.year }}{% endif %}</div>
<div class="hint" hidden></div></a>
</div>
{% endfor %}</div>
{% else %}<p class="note">No albums yet, only audiobooks.</p>{% endif %}
</section>

<section data-view="artists" hidden>
{% for artist, list in shelves %}
<div class="shelf"><h3 class="artist">{{ artist }}</h3>
<div class="group">
{% for a in list %}
<div class="item row" data-find="{{ ((a.artist or '') ~ ' ' ~ a.album)|lower }}" data-songs="{{ a.titles }}">
<a href="/music/album?key={{ a.key|urlencode }}"><span class="cover">{{ coverimg(a, 22) }}</span>
<span class="label">{{ a.album }}<span class="small muted">{% if playing == a.key %}Playing · {% endif %}{% if a.year %}{{ a.year }} · {% endif %}{{ a.tracks }} track{{ 's' if a.tracks != 1 }}{% if a.seconds %} · {{ dur(a.seconds) }}{% endif %}{% if a.usb %} · USB{% endif %}{% if tiled.get(a.key) %} · On a tile{% endif %}</span><span class="hint" hidden></span></span></a>
{{ playform(a) }}</div>
{% endfor %}</div></div>
{% endfor %}
</section>

{% if books %}<section data-view="books" hidden>
<div class="group">
{% for a in books %}{% set p = progress[a.key] %}
<div class="item row" data-find="{{ ((a.artist or '') ~ ' ' ~ a.album)|lower }}" data-songs="{{ a.titles }}">
<a href="/music/album?key={{ a.key|urlencode }}"><span class="cover">{{ coverimg(a, 22) }}</span>
<span class="label">{{ a.album }}<span class="small muted">{% if a.artist %}{{ a.artist }} · {% endif %}{% if p %}{{ dur(p.left) }} left{% if p.chapters > 1 %} · part {{ p.chapter }} of {{ p.chapters }}{% endif %}{% else %}{{ dur(a.seconds) }} · not started{% endif %}{% if tiled.get(a.key) %} · On a tile{% endif %}</span>
{% if p %}<div class="bar"><span style="width:{{ p.percent }}%"></span></div>{% endif %}<span class="hint" hidden></span></span></a>
{{ playform(a, label='Carry on with' if p else 'Play') }}</div>
{% endfor %}</div>
<p class="note" style="margin-top:8px">Audiobooks pick up where you stopped, from a tile or from here.</p>
</section>{% endif %}
<div class="nores" id="nores" hidden><b>Nothing found</b><p class="muted small">Try part of a name, or <a href="/library/add">add more music</a>.</p></div>

<script>
const views = [...document.querySelectorAll("section[data-view]")];
const segs = [...document.querySelectorAll(".seg button")];
function show(v) {
  if (!segs.some(b => b.dataset.v === v)) v = "albums";
  segs.forEach(b => b.setAttribute("aria-checked", b.dataset.v === v));
  views.forEach(s => s.hidden = s.dataset.view !== v);
  try { localStorage.setItem("libView", v); } catch (e) {}
  search();
}
segs.forEach(b => b.onclick = () => show(b.dataset.v));
const find = document.getElementById("find");
function search() {
  const q = find.value.trim().toLowerCase();
  const cont = document.getElementById("continue");
  if (cont) cont.hidden = !!q;
  const view = views.find(s => !s.hidden);
  let any = false;
  view.querySelectorAll("[data-find]").forEach(r => {
    const hint = r.querySelector(".hint");
    let ok = !q || r.dataset.find.includes(q), song = "";
    if (q && !ok) {
      song = (r.dataset.songs || "").split("\\n").find(t => t.toLowerCase().includes(q)) || "";
      ok = !!song;
    }
    r.hidden = !ok;
    if (hint) { hint.hidden = !song; hint.textContent = song ? "Has “" + song + "”" : ""; }
    any = any || ok;
  });
  view.querySelectorAll(".shelf").forEach(s => s.hidden = ![...s.querySelectorAll("[data-find]")].some(r => !r.hidden));
  document.getElementById("nores").hidden = any;
}
find.addEventListener("input", search);
show(document.documentElement.dataset.lib || "albums");
</script>
{% elif player_ok %}
<div class="empty"><span class="cover">{{ icon('library', 40) }}</span><b>No music yet</b>
<p class="muted">Plug a USB stick with music into the box, or add albums and audiobooks from your phone.</p>
<a class="btn" href="/library/add">{{ icon('plus', 20) }}Add music</a></div>
{% endif %}
{% endblock %}"""

PAGES["album.html"] = """{% extends "base.html" %}
{% block style %}
.hero{width:62%;max-width:300px;margin:14px auto 18px;aspect-ratio:1;position:relative}
.hero .art{width:100%;height:100%;object-fit:cover}
.hero .blank{display:grid;place-items:center}
.title{text-align:center;font-size:22px;font-weight:800;line-height:1.25;margin:0 8px}
.by{text-align:center;color:var(--muted);font-size:15px;font-weight:600;margin:4px 0 18px}
ol.tracks{list-style:none;margin:0;padding:0}
ol.tracks li+li{border-top:1px solid var(--line)}
ol.tracks button{display:flex;gap:12px;align-items:baseline;padding:11px 14px;width:100%;border:0;background:none;
  color:var(--ink);font:inherit;text-align:left;cursor:pointer}
ol.tracks .n{color:var(--muted);min-width:2ch;text-align:right;font-variant-numeric:tabular-nums;font-size:14px}
ol.tracks .t{flex:1;min-width:0}
ol.tracks .d{color:var(--muted);font-size:14px;font-variant-numeric:tabular-nums}
ol.tracks li.on button{background:color-mix(in srgb,var(--marigold) 16%,transparent);font-weight:700}
ol.tracks li.on .n{color:var(--ink)}
.acts2{display:flex;gap:10px;flex-wrap:wrap;margin:0 0 12px}
.acts2>*{flex:1;min-width:140px;margin:0}
.prog{margin:0 0 16px}
.bar{height:6px;border-radius:3px;background:var(--line);overflow:hidden;margin:8px 0 4px}
.bar span{display:block;height:100%;background:var(--marigold)}
{% endblock %}{% block body %}
<a class="backlink" href="/library">{{ icon('back', 22) }}Library</a>
{% if message %}<div class="toast">{{ icon('check', 20) }}<span>{{ message }}</span></div>{% endif %}
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
<div class="hero">{% if art %}<img class="art" src="{{ art }}" alt="">{% else %}<div class="art blank">{{ icon('book' if a.book else 'music', 44) }}</div>{% endif %}</div>
<p class="title">{{ a.album }}</p>
<p class="by">{{ a.artist or "Unknown artist" }}{% if a.year %} · {{ a.year }}{% endif %}{% if a.book %} · Audiobook{% endif %}</p>
{% if progress %}<div class="group pad prog">
<b>{{ "Listening now" if playing else "You stopped " ~ dur(progress.at) ~ " in" }}</b>
<div class="bar"><span style="width:{{ progress.percent }}%"></span></div>
<div class="small muted">{{ dur(progress.left) }} left{% if progress.chapters > 1 %} · part {{ progress.chapter }} of {{ progress.chapters }}{% endif %}</div>
</div>{% endif %}
<div class="acts2">
<form method="post" action="/music/play"><input type="hidden" name="path" value="{{ a.key }}"><button class="btn wide">{{ icon('play', 20) }}{{ "Carry on" if progress else "Play now" }}</button></form>
<a class="btn plain wide" href="/library/tile?key={{ a.key|urlencode }}">{{ icon('tiles', 20) }}Make a tile</a>
</div>
{% if a.book and remembered %}<form method="post" action="/music/restart" style="margin:0 0 12px"><input type="hidden" name="path" value="{{ a.key }}"><input type="hidden" name="back" value="album"><button class="btn plain wide small">Start over from the beginning</button></form>{% endif %}
{% if tiles %}<p class="note">On {{ "a tile" if tiles|length == 1 else tiles|length ~ " tiles" }}: {% for t in tiles %}<a href="/tile/{{ t.id }}">{{ t.name or "Untitled tile" }}</a>{{ ", " if not loop.last }}{% endfor %}</p>{% endif %}
<h2>{{ tracks|length }} {{ ("part" if a.book else "track") ~ ('s' if tracks|length != 1 else '') }}{% if a.seconds %} · {{ dur(a.seconds) }}{% endif %}</h2>
<div class="group"><ol class="tracks">
{% for t in tracks %}<li class="{{ 'on' if t.i == now_index }}"><form method="post" action="/music/play"><input type="hidden" name="path" value="{{ a.key }}"><input type="hidden" name="track" value="{{ t.i }}">
<button aria-label="Play {{ t.title }}"><span class="n">{{ t.n }}</span><span class="t">{{ t.title }}</span><span class="d">{{ t.length }}</span></button></form></li>{% endfor %}
</ol></div>
<p class="note" style="margin-top:6px">Tap a {{ "part" if a.book else "song" }} to play from there.</p>
<h2>Cover</h2>
<form method="post" action="/music/cover" enctype="multipart/form-data" class="group pad stack">
<input type="hidden" name="key" value="{{ a.key }}">
<input type="file" name="picture" accept="image/*" aria-label="Cover picture" required>
<button class="btn plain wide">{{ "Change cover" if art else "Add cover" }}</button>
{% if has_custom %}<button class="btn plain wide" name="remove" value="1" formnovalidate>Remove my cover</button>{% endif %}
</form>
<p class="note">Pick a picture from your phone. It's saved on the box, so it works for USB albums too.</p>
<h2>Details</h2>
<form method="post" action="/music/details" class="group pad stack">
<input type="hidden" name="key" value="{{ a.key }}">
<input type="text" name="album" value="{{ a.album }}" placeholder="Album" aria-label="Album">
<input type="text" name="artist" value="{{ a.artist }}" placeholder="Artist" aria-label="Artist">
<input type="text" name="year" value="{{ a.year or '' }}" placeholder="Year" inputmode="numeric" aria-label="Year">
<button class="btn plain wide">Save details</button>
</form>
<p class="note">This changes how the album is listed and sorted here. The music files aren't changed.</p>
{% if not a.usb and not a.multi and not locked %}
<div class="group" style="margin-top:28px"><form method="post" action="/music/delete" onsubmit="return confirm('Remove this album from the box?')">
<input type="hidden" name="path" value="{{ a.folder }}"><button class="item danger"><span class="badge" style="color:var(--bad)">{{ icon('trash', 18) }}</span><span class="label">Remove album from the box</span></button></form></div>
{% endif %}
<p class="note">Folder: {{ a.folder }}</p>
{% endblock %}"""

PAGES["music_add.html"] = """{% extends "base.html" %}
{% block style %}
.drop{border:2.5px dashed var(--line);border-radius:var(--r-md);padding:26px 16px;text-align:center;
  background:var(--surface);transition:border-color .15s,background .15s}
.drop.over{border-color:var(--marigold);background:color-mix(in srgb,var(--marigold) 10%,var(--surface))}
.drop .big{width:56px;height:56px;margin:0 auto 10px;border-radius:50%;display:grid;place-items:center;
  background:var(--sunk);color:var(--ink)}
.drop .row{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-top:14px}
.drop input{display:none}
.bar{height:10px;border-radius:6px;background:var(--sunk);overflow:hidden;margin:10px 0 6px}
.bar i{display:block;height:100%;width:0;background:var(--marigold);transition:width .3s}
.albums .item{align-items:flex-start}
.albums .label b{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.albums .value{white-space:nowrap}
.st-done{color:var(--good)} .st-bad{color:var(--bad)}
.why li{margin:4px 0}
.why{margin:6px 0 0;padding-left:20px}
summary{color:var(--link);cursor:pointer}
{% endblock %}
{% block body %}
<a class="backlink" href="/library">{{ icon('back', 22) }}Library</a>
<h1>Add music</h1>
{% if message %}<div class="toast">{{ icon('check', 20) }}<span>{{ message }}</span></div>{% endif %}
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
{% if not player_ok %}<div class="toast bad">{{ icon('alert', 20) }}<span>The music player isn't working, so new music won't show up yet. <a href="/library">Fix it on the Library page</a>.</span></div>{% endif %}
{% if storage == "memory" %}<div class="toast bad">{{ icon('alert', 20) }}<span>Restart the box (Settings) before adding a lot of music. Until then it can only take a few songs at a time.</span></div>{% endif %}
<p class="muted" style="margin:0 4px 14px">Your own music files and audiobooks play from the box itself, with no streaming service.</p>

<div id="pick">
<h2>From a computer or phone</h2>
<div class="drop" id="drop">
<div class="big">{{ icon('music', 28) }}</div>
<b class="only-wide">Drag albums or your whole music folder here</b>
<b class="only-narrow">Pick the songs to add</b>
<div class="row">
<label class="btn plain only-wide">Choose a folder<input type="file" id="pickdir" webkitdirectory multiple></label>
<label class="btn plain">Choose songs<input type="file" id="pickfiles" multiple accept="audio/*,.m4a,.m4b,.flac,.opus,.mp3,.ogg,.wav,.aiff,.aif,.wma,image/*"></label>
</div>
</div>
<details class="only-wide" style="margin:10px 6px 0"><summary class="small">Where is my music on a Mac?</summary>
<p class="small muted">In Finder, open your <b>Music</b> folder, then <b>Music &rsaquo; Media &rsaquo; Music</b> (on older Macs: <b>iTunes &rsaquo; iTunes Media &rsaquo; Music</b>). Drag that folder here, or just the artist and album folders you want. Songs the box can't play are pointed out before anything is sent.</p></details>
</div>

<div id="check" hidden><h2>Checking your music</h2>
<div class="group pad"><b id="checktext">Looking at the files…</b><div class="bar"><i id="checkbar"></i></div></div></div>

<div id="review" hidden><h2>Ready to add</h2>
<div class="group pad stack" id="reviewbox"></div>
<div class="row" style="display:flex;gap:10px;margin-top:12px">
<button class="btn wide" id="go">Add music</button>
<button class="btn plain" id="cancel" type="button" style="white-space:nowrap">Start over</button></div>
</div>

<div id="send" hidden><h2 id="sendtitle">Adding music</h2>
<div class="group pad"><b id="sendtext">Starting…</b><div class="bar"><i id="sendbar"></i></div>
<p class="small muted" id="sendnote">Keep this page open and the box plugged in until it finishes. If the page closes, add the same music again and it carries on where it stopped.</p>
<div id="sendactions" hidden style="margin-top:10px"><button class="btn" id="retry" type="button">Try again</button></div></div>
<div class="group albums" id="albumlist"></div>
</div>

<h2>USB stick</h2>
<div class="group">
<div class="item"><span class="badge">{{ icon('save', 18) }}</span><span class="label">USB stick</span><span class="value">{{ "Plugged in" if usb else "Not plugged in" }}</span></div>
<form method="post" action="/music/rescan"><button class="item action">Look for new music</button></form>
</div>
<p class="note">Plug a stick with music into the box. Its albums appear in the Library within a minute and play while the stick stays in; tap <b>Look for new music</b> if they don't.</p>
<div class="group"><div class="item"><span class="badge">{{ icon('music', 18) }}</span><span class="label">Room on the box</span><span class="value">{{ free_gb }} GB</span></div></div>
<p class="note">The box files each song under Artist / Album using its tags. Albums play in track order. Long ones (about 90 minutes or more) count as audiobooks and pick up where you stopped.</p>
<noscript><p class="note">This page needs JavaScript to send music.</p></noscript>
<script>
(() => {
const AUDIO = [".mp3",".m4a",".m4b",".aac",".flac",".ogg",".oga",".opus",".wav",".wma",".aiff",".aif"];
const PICS = [".jpg",".jpeg",".png",".webp",".gif"];
const VIDEO = [".m4v",".mp4",".mov",".mkv",".avi"];
const COVERS = ["cover","folder","front","album","albumart","artwork","art"];
const JUNK = /^(\\.|desktop\\.ini$|thumbs\\.db$|icon\\r?$)/i;
const WHY = {
  protected: "Locked by Apple: Apple Music downloads and older iTunes purchases (.m4p) only play in Apple's apps. Songs you bought from the iTunes Store since 2009 are fine.",
  video: "Videos, not music.",
  "not-music": "Not music files the box can play."
};
const PIECE = 4 * 1024 * 1024;
const ICON_OK = {{ icon('check', 18)|tojson }}, ICON_MUSIC = {{ icon('music', 18)|tojson }};
const $ = id => document.getElementById(id);
const wide = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
document.querySelectorAll(".only-wide").forEach(e => { if (!wide) e.style.display = "none"; });
document.querySelectorAll(".only-narrow").forEach(e => { if (wide) e.style.display = "none"; });
const ext = n => { const i = n.lastIndexOf("."); return i < 0 ? "" : n.slice(i).toLowerCase(); };
const base = p => p.split("/").pop();
const stem = n => { const i = n.lastIndexOf("."); return (i < 0 ? n : n.slice(0, i)).toLowerCase(); };
const parent = p => p.split("/").slice(0, -1).join("/");
const gb = b => b >= 1e9 ? (b / 1e9).toFixed(1) + " GB" : Math.max(1, Math.round(b / 1e6)) + " MB";
const plural = (n, one, many) => n + " " + (n === 1 ? one : (many || one + "s"));
const esc = t => String(t).replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
function show(id) { for (const s of ["pick","check","review","send"]) $(s).hidden = s !== id; }

// ---------- collecting files (drag and drop, folder picker, file picker)
function readAll(reader) {
  return new Promise((ok, fail) => {
    const out = [];
    const more = () => reader.readEntries(batch => { if (!batch.length) ok(out); else { out.push(...batch); more(); } }, fail);
    more();
  });
}
async function walk(entry, list) {
  if (JUNK.test(entry.name)) return;
  if (entry.isFile) {
    const file = await new Promise((ok, fail) => entry.file(ok, fail)).catch(() => null);
    if (file) list.push({file, path: entry.fullPath.replace(/^\\/+/, "")});
  } else if (entry.isDirectory) {
    for (const e of await readAll(entry.createReader()).catch(() => [])) await walk(e, list);
  }
}
const drop = $("drop");
["dragenter","dragover"].forEach(t => drop.addEventListener(t, e => { e.preventDefault(); drop.classList.add("over"); }));
["dragleave","drop"].forEach(t => drop.addEventListener(t, () => drop.classList.remove("over")));
window.addEventListener("dragover", e => e.preventDefault());
window.addEventListener("drop", e => e.preventDefault());
drop.addEventListener("drop", async e => {
  e.preventDefault();
  const entries = [...e.dataTransfer.items].map(i => i.webkitGetAsEntry && i.webkitGetAsEntry()).filter(Boolean);
  show("check"); $("checktext").textContent = "Finding the files…";
  const list = [];
  if (entries.length) { for (const en of entries) await walk(en, list); }
  else for (const f of e.dataTransfer.files) list.push({file: f, path: f.name});
  start(list);
});
for (const id of ["pickdir", "pickfiles"]) $(id).addEventListener("change", e => {
  const list = [...e.target.files].filter(f => !JUNK.test(f.name)).map(f => ({file: f, path: f.webkitRelativePath || f.name}));
  e.target.value = "";
  start(list);
});

// ---------- checking: FairPlay-locked songs carry a 'drms'/'enca' sample entry
const BOXES = new Set(["moov","trak","mdia","minf","stbl"]);
async function bytes(file, at, n) { return new DataView(await file.slice(at, at + n).arrayBuffer()); }
async function sampleType(file) {
  async function scan(start, stop, depth) {
    let pos = start;
    while (pos + 8 <= stop && depth < 8) {
      const h = await bytes(file, pos, 16);
      if (h.byteLength < 8) return null;
      let size = h.getUint32(0), hdr = 8;
      const kind = String.fromCharCode(h.getUint8(4), h.getUint8(5), h.getUint8(6), h.getUint8(7));
      if (size === 1) { if (h.byteLength < 16) return null; size = h.getUint32(8) * 4294967296 + h.getUint32(12); hdr = 16; }
      else if (size === 0) size = stop - pos;
      if (size < hdr) return null;
      if (BOXES.has(kind)) { const f = await scan(pos + hdr, Math.min(pos + size, stop), depth + 1); if (f) return f; }
      else if (kind === "stsd") {
        const e = await bytes(file, pos + hdr + 8, 8);
        return e.byteLength === 8 ? String.fromCharCode(e.getUint8(4), e.getUint8(5), e.getUint8(6), e.getUint8(7)) : null;
      }
      pos += size;
    }
    return null;
  }
  try { return await scan(0, file.size, 0); } catch (e) { return null; }
}
async function why(item) {
  const x = ext(item.path);
  if (x === ".m4p") return "protected";
  if (VIDEO.includes(x)) return "video";
  if (!AUDIO.includes(x)) return "not-music";
  if ([".m4a",".m4b",".aac"].includes(x) && ["drms","enca","drmi"].includes(await sampleType(item.file))) return "protected";
  return null;
}

let plan = null, stopped = false;
async function post(url, body, type) {
  const r = await fetch(url, {method: "POST", body, headers: {"Content-Type": type || "application/octet-stream"}, credentials: "same-origin"});
  let data = null;
  try { data = await r.json(); } catch (e) { data = {status: "signin"}; }
  return {code: r.status, data};
}

async function start(list) {
  if (!list.length) { show("pick"); return; }
  show("check");
  const songs = [], pics = [], bad = {protected: [], video: [], "not-music": []};
  let done = 0;
  const queue = list.slice();
  async function worker() {
    while (queue.length) {
      const it = queue.shift();
      it.size = it.file.size;
      if (PICS.includes(ext(it.path))) pics.push(it);
      else { const w = await why(it); if (w) bad[w].push(it); else songs.push(it); }
      done++;
      if (done % 25 === 0 || done === list.length) {
        $("checktext").textContent = "Checking " + done + " of " + list.length + " files…";
        $("checkbar").style.width = (100 * done / list.length) + "%";
      }
    }
  }
  await Promise.all([1,2,3,4,5,6].map(worker));
  songs.sort((a, b) => a.path.localeCompare(b.path, undefined, {numeric: true}));
  let info = {have: [], partial: {}, need: 0, free: 0};
  if (songs.length) {
    const r = await post("/api/import/check", JSON.stringify({files: songs.map(s => [s.path, s.size])}), "application/json");
    if (r.data.status === "signin") { location.href = "/pin?next=/library/add"; return; }
    info = r.data;
  }
  const have = new Set(info.have);
  const todo = songs.filter((s, i) => { s.offset = (info.partial || {})[i] || 0; return !have.has(i); });
  // albums = folders the songs came from
  const albums = new Map();
  for (const s of todo) {
    const key = parent(s.path);
    if (!albums.has(key)) albums.set(key, {key, songs: [], pics: [], bytes: 0});
    const a = albums.get(key); a.songs.push(s); a.bytes += s.size - s.offset;
  }
  for (const p of pics) {
    const a = albums.get(parent(p.path));
    if (a && p.size < 20e6) a.pics.push(p);
  }
  for (const a of albums.values()) {
    const named = a.pics.filter(p => COVERS.includes(stem(base(p.path))));
    a.pics = (named.length ? named : a.pics).slice(0, 2);
  }
  plan = {albums: [...albums.values()], need: info.need || 0, free: info.free || 0, memory: info.memory,
          skipped: have.size, bad};
  review();
}

function albumName(key) {
  const parts = key.split("/").filter(Boolean);
  if (!parts.length) return {title: "Loose songs", sub: ""};
  return {title: parts[parts.length - 1], sub: parts.length > 1 ? parts[parts.length - 2] : ""};
}

function review() {
  const p = plan, box = $("reviewbox");
  const count = p.albums.reduce((n, a) => n + a.songs.length, 0);
  let html = "";
  const limit = p.memory != null ? Math.min(p.free, p.memory) : p.free;
  const fits = p.need <= limit;
  if (count) html += `<p><b>${plural(count, "song")} in ${plural(p.albums.length, "folder")}</b> <span class="muted">(${gb(p.need)})</span></p>`;
  else html += `<p><b>Nothing new to add.</b></p>`;
  if (p.skipped) html += `<p class="small muted">${plural(p.skipped, "song")} already on the box, so they're skipped.</p>`;
  for (const k of ["protected", "video", "not-music"]) {
    const items = p.bad[k];
    if (!items.length) continue;
    const names = items.slice(0, 40).map(i => `<li>${esc(i.path)}</li>`).join("") + (items.length > 40 ? `<li>and ${items.length - 40} more</li>` : "");
    html += `<details><summary class="small"><b>${plural(items.length, "file")} can't play</b>: ${esc(WHY[k])}</summary><ul class="why small muted">${names}</ul></details>`;
  }
  if (count && !fits) {
    html += p.memory != null && p.memory < p.free
      ? `<p class="st-bad small"><b>That's more than the box can take right now.</b> Restart the box (Settings), then add it again.${limit > 20e6 ? " Or add fewer albums at a time (up to " + gb(limit) + ")." : ""}</p>`
      : `<p class="st-bad small"><b>Not enough room:</b> this needs ${gb(p.need)} and the box has ${gb(p.free)} free. Add fewer albums, or remove some from the Library first.</p>`;
  }
  box.innerHTML = html;
  $("go").hidden = !count;
  $("go").disabled = !fits;
  $("go").textContent = p.albums.length === 1 ? "Add this music" : "Add " + plural(p.albums.length, "folder");
  show("review");
}
$("cancel").addEventListener("click", () => { plan = null; show("pick"); });

// ---------- sending
let sent = 0, total = 0, busy = false, wake = null;
function rowHtml(a) {
  const n = albumName(a.key);
  const label = a.result ? esc(a.result) : esc(n.title);
  return `<div class="item"><span class="badge">${a.state === "done" ? ICON_OK : ICON_MUSIC}</span>
    <span class="label"><b>${label}</b><span class="small muted">${esc(a.status || "Waiting")}</span></span></div>`;
}
function drawRows() { $("albumlist").innerHTML = plan.albums.map(rowHtml).join(""); }
function drawBar() { $("sendbar").style.width = total ? (100 * sent / total) + "%" : "100%"; }
window.addEventListener("beforeunload", e => { if (busy) { e.preventDefault(); e.returnValue = ""; } });

async function sendFile(item, extra) {
  let offset = item.offset || 0, tries = 0;
  while (true) {
    const url = "/api/import/send?p=" + encodeURIComponent(item.path) + "&s=" + item.size + "&o=" + offset + (extra || "");
    let r;
    try {
      r = await post(url, item.file.slice(offset, Math.min(offset + PIECE, item.size)));
    } catch (e) {
      tries++;
      if (tries > 8) throw {pause: "Lost touch with the box. Check it's on and on the same Wi-Fi, then try again."};
      $("sendtext").textContent = "Lost touch with the box. Trying again…";
      await new Promise(ok => setTimeout(ok, Math.min(30, 2 ** tries) * 1000));
      continue;
    }
    const d = r.data;
    if (d.status === "signin") throw {pause: "Please enter the box's PIN again, then add the same music to carry on.", signin: true};
    if (r.code === 507 || r.code === 503) throw {pause: d.text || "The box can't take more right now."};
    if (r.code >= 400 && d.status !== "offset") {
      tries++;
      if (tries > 3) return {status: "skipped", why: "not-music"};
      await new Promise(ok => setTimeout(ok, 2000));
      continue;
    }
    tries = 0;
    if (d.status === "partial" || d.status === "offset") {
      sent += Math.max(0, d.offset - offset);
      offset = d.offset; item.offset = offset;
      drawBar();
      continue;
    }
    sent += Math.max(0, item.size - offset);
    item.offset = item.size;
    drawBar();
    return d;
  }
}

async function run() {
  busy = true; stopped = false;
  show("send"); $("sendactions").hidden = true; $("sendtitle").textContent = "Adding music";
  try { wake = navigator.wakeLock ? await navigator.wakeLock.request("screen") : null; } catch (e) { wake = null; }
  total = plan.albums.reduce((n, a) => n + a.songs.reduce((m, s) => m + s.size, 0), 0);
  sent = plan.albums.reduce((n, a) => n + a.songs.reduce((m, s) => m + (s.offset || 0), 0), 0);
  drawRows(); drawBar();
  let added = 0, skippedNow = 0, pause = null;
  outer:
  for (const a of plan.albums) {
    if (a.state === "done") continue;
    a.added = a.added || 0; a.skipped = a.skipped || 0;
    for (const [i, s] of a.songs.entries()) {
      if (s.done) continue;
      a.status = "Adding " + (i + 1) + " of " + a.songs.length; drawRows();
      $("sendtext").textContent = "Adding " + albumName(a.key).title + " (" + gb(sent) + " of " + gb(total) + ")";
      let d;
      try { d = await sendFile(s); } catch (e) { pause = e; a.status = "Paused"; drawRows(); break outer; }
      s.done = true;
      if (d.status === "added") {
        a.added++; added++;
        if (d.folder && !a.folder) a.folder = d.folder;
        if (d.album && !a.result) a.result = d.album + (d.artist ? " · " + d.artist : "");
      } else if (d.status === "skipped") { a.skipped++; skippedNow++; }
    }
    if (a.folder) for (const p of a.pics) { try { await sendFile(p, "&dest=" + encodeURIComponent(a.folder)); } catch (e) {} }
    a.state = "done";
    a.status = a.added ? "Added " + plural(a.added, "song") + (a.skipped ? ", " + a.skipped + " couldn't play" : "") : "Nothing added: the box can't play these";
    drawRows();
  }
  await post("/api/import/done", "", "application/json").catch(() => null);
  busy = false;
  if (wake) { try { wake.release(); } catch (e) {} }
  if (pause) {
    $("sendtitle").textContent = "Paused";
    $("sendtext").textContent = pause.pause;
    $("sendactions").hidden = !!pause.signin;
    if (pause.signin) location.href = "/pin?next=/library/add";
    return;
  }
  const albums = plan.albums.filter(a => a.added).length;
  $("sendtitle").textContent = "Done";
  $("sendtext").innerHTML = added ? `Added ${plural(albums, "album")}. <a href="/library">Open the Library</a>` : "Nothing was added.";
  $("sendnote").textContent = "The new music shows in the Library within a minute.";
  sent = total; drawBar();
}
$("go").addEventListener("click", run);
$("retry").addEventListener("click", run);
})();
</script>
{% endblock %}"""


PAGES["music_tile.html"] = """{% extends "base.html" %}
{% block style %}
.pair{display:flex;align-items:center;gap:14px}
.pair .cover{width:72px;height:72px;flex:none;border-radius:var(--r-sm);overflow:hidden;position:relative;
  background:var(--sunk);display:grid;place-items:center;color:var(--muted)}
.pair .cover img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.wait{text-align:center;padding:26px 16px}
.wait .slot{width:110px;height:110px;margin:0 auto 16px;border-radius:var(--r-md);border:2.5px dashed var(--marigold);
  display:grid;place-items:center;color:var(--ink);background:color-mix(in srgb,var(--marigold) 12%,transparent);
  animation:pulse 1.6s ease-in-out infinite}
@keyframes pulse{50%{transform:scale(.95);opacity:.7}}
{% endblock %}{% block body %}
<a class="backlink" href="/music/album?key={{ a.key|urlencode }}">{{ icon('back', 22) }}{{ a.album }}</a>
<h1>Make a tile</h1>
<div class="group pad pair"><span class="cover">{{ icon('book' if a.book else 'music', 28) }}{% if art %}<img src="{{ art }}" alt="">{% endif %}</span>
<div style="min-width:0"><b>{{ a.album }}</b><div class="small muted">{{ a.artist or "Unknown artist" }}{% if a.book %} · Audiobook{% endif %}</div></div></div>
{% if not reader_ok %}<div class="toast bad">{{ icon('alert', 20) }}<span>The tile reader isn't answering. Unplug the box, count to 10, and plug it back in.</span></div>{% endif %}
{% if not token %}
<div class="group wait"><div class="slot">{{ icon('tiles', 40) }}</div>
<b>Set a tile on the box</b>
<p class="muted small" style="margin-top:4px">A blank tile, or one you want to change. This page carries on by itself.</p></div>
{% elif refused %}
<div class="toast bad">{{ icon('alert', 20) }}<span>The tile on the box isn't a Music Boxx tile. Set down a Music Boxx tile, or one this box already plays.</span></div>
{% elif same %}
<div class="toast">{{ icon('check', 20) }}<span>The tile on the box already plays this {{ "audiobook" if a.book else "album" }}.</span></div>
<a class="btn plain wide" href="/tile/{{ token }}">Open the tile</a>
{% else %}
<div class="group pad stack">
{% if current %}<p><b>The tile on the box plays {{ current.name or "something else" }}.</b></p>
<p class="small muted">Using it for {{ a.album }} replaces that.</p>
{% else %}<p><b>A new tile is on the box.</b></p>{% endif %}
<form method="post" action="/tiles/local"><input type="hidden" name="token" value="{{ token }}"><input type="hidden" name="path" value="{{ a.key }}"><input type="hidden" name="back" value="album">
<button class="btn wide">{{ "Use this tile instead" if current else "Make it play " ~ a.album }}</button></form>
</div>
{% endif %}
{% if others %}<h2>Already on a tile</h2><div class="group">
{% for t in others %}<a class="item" href="/tile/{{ t.id }}"><span class="badge">{{ icon('tiles', 18) }}</span><span class="label">{{ t.name or "Untitled tile" }}</span><span class="chev">{{ icon('chevron', 18) }}</span></a>{% endfor %}
</div>{% endif %}
<p class="note" style="margin-top:12px">Local music stays on this box: the tile plays it here, not on another Music Boxx.</p>
<script>
const last = {{ (token or "")|tojson }};
setInterval(async () => {
  try {
    const d = await (await fetch("/api/reader")).json();
    if ((d.token || "") !== last) location.reload();
  } catch (e) {}
}, 1500);
</script>
{% endblock %}"""

PAGES["wifi.html"] = """{% extends "base.html" %}{% block body %}
{% if not setup_mode %}<a class="backlink" href="/settings">{{ icon('back', 22) }}Settings</a>{% endif %}
{% if setup_mode and first_time %}{% with step_num = 2 %}{% include "progress.html" %}{% endwith %}{% endif %}
<h1>{{ "Connect to your Wi-Fi" if setup_mode and first_time else "Wi-Fi" }}</h1>
{% if setup_mode %}<p style="margin-bottom:18px">{% if first_time %}Pick your home network so {{ box_name }} can reach Spotify.{% else %}The box couldn't find a Wi-Fi network it knows, so it made its own. Pick your home network to get it online.{% endif %}</p>{% endif %}
{% if message %}<div class="toast">{{ icon('check', 20) }}<span>{{ message }}</span></div>{% endif %}
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
{% if not setup_mode %}
<div class="group"><div class="item"><span class="badge">{{ icon('wifi', 18) }}</span><span class="label">Connected to</span><span class="value">{{ current or "Nothing" }}</span></div></div>
{% endif %}
<h2>{{ "Your network" if setup_mode else "Add a network" }}</h2>
<form method="post" class="group pad stack" autocomplete="off">
{% if nearby %}<select name="ssid" aria-label="Network">
<option value="">Choose a network</option>
{% for n in nearby %}<option value="{{ n.ssid }}">{{ n.ssid }}{% if not n.secure %} (open){% endif %}</option>{% endfor %}
</select>
<details><summary class="small" style="color:var(--link);cursor:pointer">Not listed? Type the name</summary>
<input type="text" name="ssid_typed" placeholder="Network name" style="margin-top:10px" aria-label="Network name"></details>
{% else %}<input type="text" name="ssid_typed" placeholder="Network name" aria-label="Network name">{% endif %}
<input type="password" name="password" placeholder="Password (blank for open networks)" aria-label="Password">
<button class="btn wide">{{ "Join" if setup_mode else "Save network" }}</button>
</form>
{% if not setup_mode %}<script>
(function () {
  const sel = document.querySelector('select[name="ssid"]');
  let tries = 0;
  async function poll() {
    try {
      const d = await (await fetch("/api/wifi/nearby", {cache: "no-store"})).json();
      if (sel && d.nearby.length && document.activeElement !== sel && !sel.value) {
        const keep = sel.options[0].outerHTML;
        sel.innerHTML = keep + d.nearby.map(n => {
          const o = document.createElement("option"); o.value = n.ssid;
          o.textContent = n.ssid + (n.secure ? "" : " (open)"); return o.outerHTML; }).join("");
      }
      if (d.scanning && ++tries < 15) setTimeout(poll, 2000);
    } catch (e) {}
  }
  setTimeout(poll, 1500);
})();
</script>{% endif %}
<p class="note">The box uses 2.4 GHz Wi-Fi, which most home routers have. For an iPhone hotspot, turn on Maximize Compatibility.</p>
{% if not setup_mode %}
<h2>Saved networks</h2>
<div class="group">
{% for n in saved %}
<div class="item"><span class="label">{{ n.ssid }}</span>
{% if n.ssid == current %}<span class="value" style="color:var(--good)">Connected</span>
{% else %}<form method="post" action="/wifi/forget" onsubmit='return confirm({{ ("Forget " ~ n.ssid ~ "?")|tojson }})'>
<input type="hidden" name="profile" value="{{ n.profile }}"><button class="btn small plain" style="color:var(--bad)">Forget</button></form>{% endif %}</div>
{% else %}<div class="item muted">None yet</div>{% endfor %}
</div>
<p class="note">Taking the box somewhere new? Add that Wi-Fi here before you go. Or plug it in there: after about 2 minutes it makes a network called {{ setup_ssid }} (password musicbox) so you can add it. If nobody joins within 20 minutes it switches that off again; unplug and replug the box to bring it back.</p>
{% endif %}
{% endblock %}"""

PAGES["joining.html"] = """{% extends "base.html" %}
{% block style %}
ol.how{margin:0;padding:0;list-style:none;counter-reset:s}
ol.how li{counter-increment:s;display:flex;gap:12px;padding:6px 0}
ol.how li::before{content:counter(s);flex:none;width:26px;height:26px;border-radius:50%;
  background:var(--sunk);display:grid;place-items:center;font-weight:800;font-size:14px}
{% endblock %}{% block body %}
<h1>Joining {{ ssid }}</h1>
<div class="group pad stack">
<p>Your phone drops off {{ setup_ssid }} in a few seconds. That's expected.</p>
<ol class="how">
<li><span>Put your phone back on <b>{{ ssid }}</b>.</span></li>
<li><span>Wait a minute, then open <a class="addr" href="http://{{ host }}">http://{{ host }}</a>{% if first_time %} to finish setup{% endif %}.</span></li></ol>
</div>
<p class="note">Screenshot this page so you have the address. If it doesn't open, try <span class="addr">http://{{ fallback }}</span> (it always works), and make sure the address starts with http, not https.</p>
<p class="note">If the password was wrong, {{ setup_ssid }} comes back in about 2 minutes. Join it again and retry.</p>
{% endblock %}"""

PAGES["name.html"] = """{% extends "base.html" %}{% block body %}
{% if in_setup %}{% with step_num = 1 %}{% include "progress.html" %}{% endwith %}
{% else %}<a class="backlink" href="/settings">{{ icon('back', 22) }}Settings</a>{% endif %}
<h1>{{ "Name your speaker" if in_setup else "Speaker name" }}</h1>
<p style="margin-bottom:16px">This is what Spotify shows in its list of speakers, and what this app calls the box.</p>
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
<form method="post" class="group pad stack" autocomplete="off">
<input type="hidden" name="setup" value="{{ '1' if in_setup else '' }}">
<input type="text" name="name" id="name" value="{{ name }}" maxlength="{{ max_len }}" placeholder="For example: Ava's Room" aria-label="Speaker name" required>
<div class="chips">{% for idea in ideas %}<button type="button" data-n="{{ idea }}">{{ idea }}</button>{% endfor %}</div>
<p class="small muted">Web address: <span class="addr" id="addr">http://{{ host }}.local</span></p>
<button class="btn wide">{{ "Next" if in_setup else "Save name" }}</button>
</form>
<p class="note">Box ID {{ box }}. <span class="addr">http://{{ fallback }}.local</span> always reaches this box, whatever its name.{% if not in_setup %} After a rename, re-add the app to your home screen from the new address.{% endif %}</p>
<script>
(function () {
  const input = document.getElementById("name"), addr = document.getElementById("addr");
  let timer;
  function preview() {
    clearTimeout(timer);
    timer = setTimeout(async () => {
      if (!input.value.trim()) return;
      try {
        const d = await (await fetch("/api/name-preview?name=" + encodeURIComponent(input.value))).json();
        addr.textContent = "http://" + d.host + ".local";
      } catch (e) {}
    }, 250);
  }
  input.addEventListener("input", preview);
  document.querySelectorAll(".chips button").forEach(b => b.onclick = () => { input.value = b.dataset.n; preview(); });
  if (input.value) preview();
})();
</script>
{% endblock %}"""

PAGES["renamed.html"] = """{% extends "base.html" %}
{% block style %}
.wait{text-align:center;padding-top:40px}
.spin{width:44px;height:44px;margin:0 auto 22px;border-radius:50%;border:4px solid var(--line);
  border-top-color:var(--marigold);animation:spin 1s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
{% endblock %}{% block body %}
<div class="wait"><div class="spin"></div>
<h1>Now called {{ name }}</h1>
<p>Its new address is</p>
<p><a class="addr" style="font-size:20px" href="http://{{ host }}.local/{{ 'setup' if in_setup else 'settings' }}">http://{{ host }}.local</a></p>
<p class="muted small">This page moves there in about 15 seconds. Spotify shows the new name within a minute.</p>
</div>
<p class="note">If the new address doesn't open, use <span class="addr">http://{{ fallback }}.local</span>, which always works.</p>
<script>
setTimeout(() => location.replace("http://{{ host }}.local/{{ 'setup' if in_setup else 'settings' }}"), 15000);
</script>
{% endblock %}"""

PAGES["sound.html"] = """{% extends "base.html" %}{% block body %}
<a class="backlink" href="/settings">{{ icon('back', 22) }}Settings</a>
<h1>Sound</h1>
{% if message %}<div class="toast">{{ icon('check', 20) }}<span>{{ message }}</span></div>{% endif %}
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
{% if presets|length > 1 %}
<form method="post" class="group" id="presets">
{% for p in presets %}
<button class="item" name="preset" value="{{ p.name }}" {% if p.name == current %}aria-current="true"{% endif %}>
<span class="label">{% if p.name == current %}<b>{{ p.label }}</b>{% else %}{{ p.label }}{% endif %}{% if p.line %}<br><span class="small muted">{{ p.line }}</span>{% endif %}</span>
{% if p.name == current %}<span class="value" style="color:var(--good)">{{ icon('check', 20) }}</span>{% endif %}
</button>
{% endfor %}
</form>
<p class="note">Music pauses for about 2 seconds while the box switches. It remembers your pick after a restart.</p>
<script>
document.getElementById("presets").addEventListener("submit", () => {
  document.querySelectorAll("#presets button").forEach(b => b.style.opacity = .5);
});
</script>
{% else %}
<div class="group pad"><p>This box has one sound setting, tuned for its speakers.</p></div>
{% endif %}
{% endblock %}"""

PAGES["listening.html"] = """{% extends "base.html" %}
{% block style %}
.bars{display:flex;align-items:flex-end;gap:5px;height:120px;padding:16px 16px 0}
.bars div{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%;gap:6px}
.bars i{display:block;width:100%;border-radius:4px 4px 2px 2px;background:var(--marigold);min-height:2px}
.bars span{font-size:12px;color:var(--muted);font-weight:700;padding-bottom:10px}
.hours{display:flex;align-items:flex-end;gap:2px;height:56px;padding:14px 16px 0}
.hours i{flex:1;background:var(--ink);opacity:.75;border-radius:2px;min-height:2px}
.hlabels{display:flex;justify-content:space-between;font-size:12px;color:var(--muted);padding:6px 16px 12px}
.big{display:flex;gap:12px}
.big .group{flex:1;margin:0}
.big b{display:block;font-size:30px;font-weight:800;font-variant-numeric:tabular-nums}
.thumb{width:40px;height:40px;border-radius:8px;object-fit:cover;flex:none;background:var(--sunk)}
{% endblock %}{% block body %}
<a class="backlink" href="/settings">{{ icon('back', 22) }}Settings</a>
<h1>Listening</h1>
<div class="big">
<div class="group pad"><b>{{ (week_minutes / 60)|round(1) if week_minutes >= 60 else week_minutes }}</b><span class="muted small">{{ "hours" if week_minutes >= 60 else "minutes" }} this week</span></div>
<div class="group pad"><b>{{ week_plays }}</b><span class="muted small">tiles played this week</span></div>
</div>
<h2>Last 2 weeks</h2>
<div class="group"><div class="bars" role="img" aria-label="Minutes of music per day">
{% for d in days %}<div title="{{ d.date }}: {{ d.minutes }} min, {{ d.plays }} tiles"><i style="height:{{ (d.minutes / most * 100)|round }}%"></i><span>{{ d.label }}</span></div>{% endfor %}
</div></div>
{% if peak is not none %}
<h2>Time of day</h2>
<div class="group"><div class="hours" role="img" aria-label="Listening by hour">
{% for h in hours %}<i style="height:{{ (h / hour_max * 100)|round }}%"></i>{% endfor %}</div>
<div class="hlabels"><span>12a</span><span>6a</span><span>12p</span><span>6p</span><span>11p</span></div></div>
<p class="note">Busiest around {{ ((peak + 11) % 12) + 1 }} {{ "am" if peak < 12 else "pm" }}.</p>
{% endif %}
<h2>Favorite tiles</h2>
<div class="group">
{% for t in tiles %}<div class="item">{% if t.image %}<img class="thumb" src="{{ t.image }}" alt="">{% else %}<span class="thumb"></span>{% endif %}
<span class="label">{{ t.name }}<br><span class="small muted">{{ t.plays }} play{{ "s" if t.plays != 1 }} &middot; {{ t.minutes }} min</span></span></div>
{% else %}<div class="item muted">No tiles played yet</div>{% endfor %}
</div>
{% if albums %}<h2>Most played</h2>
<div class="group">{% for a in albums %}<div class="item"><span class="label">{{ a.name }}</span><span class="value">{{ a.minutes }} min</span></div>{% endfor %}</div>{% endif %}
<p class="note">Counted on this box since the update, including music started from the Spotify app.</p>
<h2>Help improve Music Boxx</h2>
<div class="group">
<form method="post" action="/listening/share"><input type="hidden" name="share" value="{{ 'off' if share else 'on' }}">
<button class="item"><span class="label">Share anonymous usage<br><span class="small muted">Whether the box is on, its software version, and how long each tile plays (tiles are sent as scrambled codes)</span></span>
<span class="switch {{ 'on' if share }}" role="switch" aria-checked="{{ 'true' if share else 'false' }}"></span></button></form>
</div>
<p class="note">Never shared: song, album or tile names, the speaker's name, your Wi-Fi, or your Spotify account.</p>
{% endblock %}"""

PAGES["apple.html"] = """{% extends "base.html" %}{% block body %}
<a class="backlink" href="/settings">{{ icon('back', 22) }}Settings</a>
<h1>Apple Music</h1>
{% if message %}<div class="toast">{{ icon('check', 20) }}<span>{{ message }}</span></div>{% endif %}
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
{% if unsupported %}
<p class="note">Apple Music isn't available on this box. It needs more powerful hardware than this box has. Spotify and your own music work as usual.</p>
{% else %}
<p class="note">Experimental. Apple doesn't support speakers like this one, so this works through a free program called Music Assistant that runs on the box. It needs an Apple Music subscription, and Apple may break it at any time.</p>
<form method="post" class="group pad stack">
<ol class="how">
<li><span>Install Music Assistant on the box (<code>install_apple_music.sh</code>).</span></li>
<li><span>Open Music Assistant at <b>http://{{ request.host.split(':')[0] }}:8095</b>, add the Apple Music provider and sign in.</span></li>
<li><span>In Music Assistant, make an access token (profile menu, Long-lived access token) and paste it below.</span></li></ol>
<label class="small muted">Music Assistant address</label>
<input type="url" name="url" value="{{ url }}" aria-label="Music Assistant address">
<label class="small muted">Access token {% if has_token %}(saved; leave blank to keep it){% endif %}</label>
<input type="password" name="token" value="" placeholder="{{ 'saved' if has_token else 'paste token' }}" autocomplete="off" aria-label="Access token">
<button class="btn wide">Save and test</button>
</form>
{% if has_token %}
<form method="post" class="group pad stack"><input type="hidden" name="action" value="test"><button class="btn plain wide">Test again</button></form>
<form method="post" class="group pad stack"><input type="hidden" name="action" value="remove"><button class="btn plain wide">Turn off Apple Music</button></form>
{% endif %}
{% endif %}
{% endblock %}"""

PAGES["account.html"] = """{% extends "base.html" %}{% block body %}
<a class="backlink" href="/settings">{{ icon('back', 22) }}Settings</a>
<h1>Spotify</h1>
{% if message %}<div class="toast">{{ icon('check', 20) }}<span>{{ message }}</span></div>{% endif %}
{% if need_install %}
{% set back = "/spotify" %}{% include "soloist_install_card.html" %}
{% elif pairing and pairing.soloist %}
{% set back = "/account" %}{% include "soloist_pair.html" %}
{% elif pairing %}
<div class="group pad stack">
<b>Connect Spotify</b>
<p>On your phone, open <a href="{{ pairing.url }}" target="_blank" rel="noopener">spotify.com/pair</a>, sign in, and type this code:</p>
<p class="code">{{ pairing.code }}</p>
</div>
<p class="note">Your password only goes to Spotify. Codes expire after a few minutes; reload this page for a new one.</p>
{% elif speaker %}
<div class="group">
<div class="item"><span class="badge" style="color:var(--good)">{{ icon('check', 18) }}</span><span class="label">Connected</span>{% if speaker_user %}<span class="value">{{ speaker_user }}</span>{% endif %}</div>
<form method="post" action="/account/speaker-signout" onsubmit="return confirm('Disconnect Spotify? You will connect it again {{ 'from the Spotify app' if soloist else 'with a code' }}.')">
<button class="item danger"><span class="badge" style="color:var(--bad)">{{ icon('power', 18) }}</span><span class="label">Disconnect</span></button></form>
</div>
<p class="note">To switch Spotify accounts, disconnect, then connect again {{ 'by picking this box in the Spotify app' if soloist else 'with the code that appears' }}.</p>
{% else %}
<div class="group">
<div class="item"><span class="badge" style="color:var(--bad)">{{ icon('alert', 18) }}</span><span class="label">The speaker isn't answering</span></div>
<form method="post" action="/power/restart-music"><button class="item"><span class="badge">{{ icon('restart', 18) }}</span><span class="label">Restart music</span></button></form>
</div>
{% endif %}
{% if not need_install %}
<details style="margin-top:28px"><summary class="small" style="color:var(--link);cursor:pointer;margin:0 6px">Advanced: reinstall Spotify's player</summary>
<div class="group pad stack" style="margin-top:10px">
<p class="small">Downloads Spotify's player again from Spotify and sets it up fresh. Your key and Spotify connection stay. Use it if Spotify stops working after a restart.</p>
{% if install.protected and not install.auto %}<p class="small muted">This box's helper is out of date, so it can't do this from the app.</p>
{% else %}{% if not install.quick %}<p class="small muted">The box restarts during this (about 10 minutes in all).</p>{% endif %}<form method="post" action="/spotify/install"><input type="hidden" name="back" value="/spotify"><button class="btn plain small">Reinstall Spotify's player</button></form>{% endif %}
</div></details>
{% endif %}
<details style="margin-top:12px"><summary class="small" style="color:var(--link);cursor:pointer;margin:0 6px">Advanced: search inside the app</summary>
<div class="group pad stack" style="margin-top:10px">
<p class="small">Optional. Pasting links works without this. Searching inside the app needs a free Spotify developer app (Client ID {{ client_id }}).</p>
{% if user %}<p class="small">Search is on, signed in as <b>{{ user }}</b>.</p>
{% elif problem %}<div class="toast bad">{{ problem }}</div>{% endif %}
<a class="btn plain small" href="/account/signin">{{ "Sign in again" if user else "Turn on search" }}</a>
</div></details>
{% endblock %}"""

PAGES["signin.html"] = """{% extends "base.html" %}
{% block style %}
ol.how{margin:0;padding:0;list-style:none;counter-reset:s}
ol.how li{counter-increment:s;display:flex;gap:12px;padding:8px 0}
ol.how li::before{content:counter(s);flex:none;width:26px;height:26px;border-radius:50%;
  background:var(--sunk);display:grid;place-items:center;font-weight:800;font-size:14px}
{% endblock %}{% block body %}
<a class="backlink" href="/spotify">{{ icon('back', 22) }}Spotify</a>
<h1>Turn on search</h1>
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
<div class="group pad">
<ol class="how">
<li><span>Open Spotify's sign-in page and approve. Your password goes to Spotify only.<br>
<a class="btn small" style="margin-top:10px" href="{{ url }}" target="_blank" rel="noopener">Open Spotify sign-in</a></span></li>
<li><span>You land on a page that won't load (something like "can't connect to 127.0.0.1"). That's expected.</span></li>
<li><span>Copy that page's whole web address and paste it below. It holds a one-time code, not your password.</span></li>
</ol>
<form method="post" action="/account/finish" class="stack" style="margin-top:12px">
<input type="text" name="pasted" placeholder="http://127.0.0.1:8888/callback?code=..." autocomplete="off" aria-label="Address">
<button class="btn wide">Finish</button></form>
</div>
<p class="note">The account must be on your developer app's User Management list.</p>
{% endblock %}"""

PAGES["settings.html"] = """{% extends "base.html" %}{% block body %}
<h1>Settings</h1>
{% if message %}<div class="toast">{{ icon('check', 20) }}<span>{{ message }}</span></div>{% endif %}
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
{% if notices %}<h2>Needs attention</h2>
<div class="alerts">{% for n in notices %}<div class="alert {{ n.kind }}"><span class="dot">{{ icon(n.icon) }}</span><div class="body">
<b>{{ n.title }}</b><p class="small muted">{{ n.body }}</p>
{% if n.action and n.action.post %}<form method="post" action="{{ n.action.post }}?back=settings"><button class="btn small plain">{{ n.action.label }}</button></form>
{% elif n.action %}<a class="btn small plain" href="{{ n.action.href }}">{{ n.action.label }}</a>{% endif %}
</div></div>{% endfor %}</div>{% endif %}
<div class="group">
<a class="item" href="/name"><span class="badge">{{ icon('music', 18) }}</span><span class="label">Speaker name</span><span class="value">{{ box_name }}</span><span class="chev">{{ icon('chevron', 18) }}</span></a>
{% if not is_pad %}<a class="item" href="/sound"><span class="badge">{{ icon('volume', 18) }}</span><span class="label">Sound</span><span class="value">{{ sound_line or "Choose" }}</span><span class="chev">{{ icon('chevron', 18) }}</span></a>{% endif %}
<a class="item" href="/library/add"><span class="badge">{{ icon('music', 18) }}</span><span class="label">Add music</span><span class="value">USB and uploads</span><span class="chev">{{ icon('chevron', 18) }}</span></a>
<a class="item" href="/wifi"><span class="badge">{{ icon('wifi', 18) }}</span><span class="label">Wi-Fi</span><span class="value">{{ wifi or "Not connected" }}</span><span class="chev">{{ icon('chevron', 18) }}</span></a>
<a class="item" href="/spotify"><span class="badge">{{ icon('music', 18) }}</span><span class="label">Spotify</span><span class="value">{{ spotify_line }}</span><span class="chev">{{ icon('chevron', 18) }}</span></a>
<a class="item" href="/updates"><span class="badge">{{ icon('restart', 18) }}</span><span class="label">Software updates</span><span class="value">{{ update_line }}</span><span class="chev">{{ icon('chevron', 18) }}</span></a>
{% if apple_ok %}<a class="item" href="/apple"><span class="badge">{{ icon('music', 18) }}</span><span class="label">Apple Music</span><span class="value">{{ apple_line }}</span><span class="chev">{{ icon('chevron', 18) }}</span></a>
{% else %}<div class="item" aria-disabled="true" style="opacity:.45;cursor:default"><span class="badge">{{ icon('music', 18) }}</span><span class="label">Apple Music</span><span class="value">Needs upgraded hardware</span></div>{% endif %}
</div>

<div class="group">
<a class="item" href="/listening"><span class="badge">{{ icon('now', 18) }}</span><span class="label">Listening</span><span class="value">Stats</span><span class="chev">{{ icon('chevron', 18) }}</span></a>
</div>

{% if is_pad %}
<h2>Volume control</h2>
<div class="group">
<form method="post"><input type="hidden" name="line_out" value="variable">
<button class="item" {% if line_out != 'fixed' %}aria-current="true"{% endif %}><span class="label">Pad's knob</span><span class="value">Knob and phone set the volume</span>{% if line_out != 'fixed' %}<span class="chev">{{ icon('check', 18) }}</span>{% endif %}</button></form>
<form method="post"><input type="hidden" name="line_out" value="fixed">
<button class="item" {% if line_out == 'fixed' %}aria-current="true"{% endif %}><span class="label">Stereo's knob</span><span class="value">Pad stays at full volume</span>{% if line_out == 'fixed' %}<span class="chev">{{ icon('check', 18) }}</span>{% endif %}</button></form>
</div>
<p class="note">Pick which knob you'll turn. "Stereo's knob" sends the cleanest signal and turns the Pad's knob off. Turn your stereo down before you pick it: the Pad jumps to full right away.</p>
{% endif %}
{% if not (is_pad and line_out == 'fixed') %}
<h2>Volume limits</h2>
<form method="post" class="group">
<div class="item"><span class="label">Lowest</span><input class="num" type="number" name="volume_min" value="{{ volume_min }}" min="0" max="100" aria-label="Lowest volume"></div>
<div class="item"><span class="label">Highest</span><input class="num" type="number" name="volume_max" value="{{ volume_max }}" min="0" max="100" aria-label="Highest volume"></div>
<button class="item action">Save limits</button>
</form>
<p class="note">The knob and any phone stay between these (0 to 100). The lowest keeps the box from seeming broken; the highest keeps little hands from cranking it.</p>
{% endif %}

<h2>Pick up where it left off</h2>
<form method="post" class="group">
<div class="item"><span class="label">Within</span><input class="num" type="number" name="resume_minutes" value="{{ resume_minutes }}" min="0" max="240" aria-label="Minutes"><span class="muted">min</span></div>
<button class="item action">Save</button>
</form>
<p class="note">Put the same tile back within this time and it keeps going. After that it starts over.</p>

<h2>Startup sound</h2>
<div class="group">
<form method="post"><input type="hidden" name="startup_sound" value="{{ 'off' if startup_sound else 'on' }}">
<button class="item"><span class="badge">{{ icon('volume', 18) }}</span><span class="label">Chime when ready</span>
<span class="switch {{ 'on' if startup_sound }}" role="switch" aria-checked="{{ 'true' if startup_sound else 'false' }}"></span></button></form>
<button type="button" class="item action" onclick="this.disabled=true;fetch('/api/chime',{method:'POST'}).finally(()=>setTimeout(()=>this.disabled=false,2500))">Play it</button>
</div>
<p class="note">Plays once after the box is plugged in, as soon as it's ready for a tile.</p>

<h2>Appearance</h2>
<div class="group pad">
<div class="seg" role="radiogroup" aria-label="Appearance">
<button type="button" role="radio" data-t="auto">Automatic</button>
<button type="button" role="radio" data-t="light">Light</button>
<button type="button" role="radio" data-t="dark">Dark</button>
</div></div>
<p class="note">Automatic follows this phone's own setting. Each phone remembers its choice.</p>
<script>
(function () {
  const buttons = document.querySelectorAll(".seg button");
  function mark(t) { buttons.forEach(b => b.setAttribute("aria-checked", b.dataset.t === t)); }
  buttons.forEach(b => b.onclick = () => {
    try { localStorage.setItem("theme", b.dataset.t); } catch (e) {}
    applyTheme(b.dataset.t); mark(b.dataset.t);
  });
  mark(savedTheme);
})();
</script>

<h2>Power</h2>
<div class="group">
<form method="post" action="/power/restart-music"><button class="item"><span class="badge">{{ icon('music', 18) }}</span><span class="label">Restart music<br><span class="small muted">Fixes most problems in about 20 seconds</span></span></button></form>
<form id="power" method="post" action="/power/reboot" onsubmit="return confirm('Restart the whole box?')"><button class="item"><span class="badge">{{ icon('restart', 18) }}</span><span class="label">Restart box</span></button></form>
<form method="post" action="/power/shutdown" onsubmit="return confirm('Shut the box down?')"><button class="item danger"><span class="badge" style="color:var(--bad)">{{ icon('power', 18) }}</span><span class="label">Shut down</span></button></form>
</div>
<p class="note">{% if protected %}Simply unplugging the box is fine too.{% else %}After Shut down, wait 30 seconds before unplugging.{% endif %}</p>

<h2>PIN</h2>
<form method="post" class="group" autocomplete="off">
<div class="item"><input type="password" name="old_pin" inputmode="numeric" placeholder="Current PIN" aria-label="Current PIN"></div>
<div class="item"><input type="password" name="new_pin" inputmode="numeric" placeholder="New PIN (4 to 8 numbers)" aria-label="New PIN"></div>
<button class="item action">Change PIN</button>
</form>
<form method="post" action="/lock" class="group"><button class="item"><span class="badge">{{ icon('lock', 18) }}</span><span class="label">Lock this phone</span></button></form>

<h2>Setup</h2>
<form method="post" action="/setup/again" class="group" onsubmit="return confirm('Walk through setup again? Your tiles, Wi-Fi and Spotify stay as they are.')">
<button class="item"><span class="badge">{{ icon('restart', 18) }}</span><span class="label">Run setup again</span></button></form>
<div class="group"><a class="item danger" href="/reset"><span class="badge" style="color:var(--bad)">{{ icon('trash', 18) }}</span><span class="label">Erase this box<br><span class="small muted">Factory reset, for giving it to someone new</span></span><span class="chev">{{ icon('chevron', 18) }}</span></a></div>

<p class="note" style="margin-top:22px">Put the app on your home screen: in Safari, tap Share, then Add to Home Screen.<br>
Address: <span class="addr">http://{{ speaker_host }}</span> &middot; also <span class="addr">http://{{ box_fallback }}</span><br>
Box ID {{ box_id }} &middot; <a href="/advanced" style="color:inherit;text-decoration:none">Music Boxx app {{ version }}</a></p>
{% endblock %}"""

PAGES["advanced.html"] = """{% extends "base.html" %}{% block body %}
<h1>Advanced</h1>
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
<p class="muted">For troubleshooting. Nothing here is needed for updates or installs: the box looks after that by itself.</p>
<h2>Unplug protection</h2>
<div class="group">
<div class="item"><span class="badge" style="color:{{ 'var(--good)' if protected else 'var(--bad)' }}">{{ icon('shield', 18) }}</span>
<span class="label">{% if protected %}On<br><span class="small muted">Pulling the plug can't hurt the box. Tiles, settings, Wi-Fi, Spotify and music added here still save.</span>
{% elif held %}Off: maintenance mode<br><span class="small muted">Changes to the system stick. Use Shut down before unplugging.</span>
{% elif failed %}Off<br><span class="small muted">The box couldn't switch it on by itself. Use Shut down before unplugging.</span>
{% else %}Off<br><span class="small muted">The box switches it on by itself at its next restart.</span>{% endif %}</span></div>
{% if protected and can_protect %}
<form method="post" action="/maintenance/on" onsubmit="return confirm('Restart in maintenance mode? The box stays there until you switch it off here.')">
<button class="item"><span class="badge">{{ icon('restart', 18) }}</span><span class="label">Turn on maintenance mode<br><span class="small muted">For changing the system by hand</span></span></button></form>
{% elif not protected and can_protect %}
<form method="post" action="/maintenance/off" onsubmit="return confirm('Turn unplug protection on? The box restarts, which can take a few minutes.')">
<button class="item"><span class="badge" style="background:var(--marigold);color:var(--on-marigold)">{{ icon('shield', 18) }}</span><span class="label"><b>{{ 'Switch off maintenance mode' if held else 'Turn unplug protection on' }}</b></span></button></form>
{% endif %}
</div>
<p class="note">Over SSH: <span class="addr">sudo musicbox-admin maintenance-on</span> and <span class="addr">sudo musicbox-admin protect-on</span> do the same.</p>
<h2>Tiles</h2>
<form method="post" action="/advanced/tiles" class="group">
<button class="item" name="genuine_only" value="{{ 0 if genuine_only else 1 }}"><span class="badge">{{ icon('tiles', 18) }}</span>
<span class="label">{% if genuine_only %}Only Music Boxx tiles<br><span class="small muted">Other NFC tiles are ignored, except ones this box already played. Tap to accept any tile.</span>
{% else %}Any NFC tile<br><span class="small muted">For testing. Tap to go back to Music Boxx tiles only.</span>{% endif %}</span></button></form>
<h2>Factory reset</h2>
<div class="group"><a class="item danger" href="/reset"><span class="badge" style="color:var(--bad)">{{ icon('trash', 18) }}</span><span class="label">Erase this box<br><span class="small muted">Asks for your PIN, the word RESET and a final yes</span></span><span class="chev">{{ icon('chevron', 18) }}</span></a></div>
{% endblock %}"""

PAGES["reset.html"] = """{% extends "base.html" %}
{% block style %}
.btn.danger{background:var(--bad);color:var(--paper)}
.choice{cursor:pointer}
.choice input{flex:none;width:22px;height:22px;margin:0;accent-color:var(--marigold)}
.erase li,.keep li{display:flex;gap:10px;align-items:flex-start;padding:10px 16px;margin:0}
.erase li+li,.keep li+li{border-top:1px solid var(--line)}
.erase ul,.keep ul{list-style:none;margin:0;padding:4px 0}
.erase .icon{color:var(--bad);flex:none;margin-top:2px}
.keep .icon{color:var(--good);flex:none;margin-top:2px}
.word{text-transform:uppercase;letter-spacing:.12em}
.word::placeholder{text-transform:none;letter-spacing:normal}
.bar{height:10px;border-radius:6px;background:var(--sunk);overflow:hidden}
.bar span{display:block;height:100%;background:var(--bad);transition:width .4s}
.steps{font-size:14px;color:var(--muted);margin:-4px 4px 16px}
{% endblock %}
{% block body %}
{% if step == "confirm" %}
<a class="backlink" href="/reset">{{ icon('back', 22) }}Back</a>
<h1>Last check</h1>
<p class="steps">Step 2 of 2. This can't be undone.</p>
<h2>Erased from {{ box_name }}</h2>
<div class="group erase"><ul>
<li>{{ icon('trash', 18) }}<span>The name <b>{{ box_name }}</b> and its address (it goes back to Music Box, {{ box_fallback }})</span></li>
<li>{{ icon('trash', 18) }}<span>Your PIN. Every phone using this app is signed out, this one too</span></li>
<li>{{ icon('trash', 18) }}<span>Spotify on this box: the pairing, the player key and the sign-in</span></li>
<li>{{ icon('trash', 18) }}<span>The Apple Music link, if there is one</span></li>
<li>{{ icon('trash', 18) }}<span>Every saved Wi-Fi network</span></li>
<li>{{ icon('trash', 18) }}<span>Listening history and the sharing choice</span></li>
{% if plan.erase_tiles %}<li>{{ icon('trash', 18) }}<span>The music on {{ 'your 1 tile' if plan.tiles == 1 else ('both tiles' if plan.tiles == 2 else 'all ' ~ plan.tiles ~ ' tiles') }}. The tiles become blank and can be set up again</span></li>{% endif %}
{% if plan.erase_music %}<li>{{ icon('trash', 18) }}<span>Music and audiobooks added to the box (a plugged-in USB stick is not touched)</span></li>{% endif %}
</ul></div>
<h2>Stays</h2>
<div class="group keep"><ul>
{% if not plan.erase_tiles %}<li>{{ icon('check', 18) }}<span>Tiles: they keep playing the same albums</span></li>{% endif %}
{% if not plan.erase_music %}<li>{{ icon('check', 18) }}<span>Music and audiobooks added to the box</span></li>{% endif %}
<li>{{ icon('check', 18) }}<span>Sound settings, volume limits and the box's software</span></li>
</ul></div>
<p class="note" style="margin-bottom:16px">{% if protected %}The box restarts first to get ready (2 to 5 minutes), then erases everything above and {% else %}The box erases everything above and then {% endif %}{{ 'shuts down.' if plan.after == 'shut-down' else 'restarts into setup.' }}</p>
<form method="post" action="/reset/confirm" onsubmit="this.querySelector('button').disabled=true">
<input type="hidden" name="nonce" value="{{ nonce }}">
<button class="btn wide danger">Erase {{ box_name }}</button></form>
<a class="btn wide plain" href="/settings" style="margin-top:10px">Cancel, keep everything</a>
<p class="note" style="margin-top:12px">For safety this screen only works for {{ minutes }} more minute{{ 's' if minutes != 1 }}.</p>

{% elif started or (job and job.running) %}
<h1>Erasing {{ box_name }}</h1>
<div class="group pad stack" id="job">
<div class="bar"><span id="jobbar" style="width:4%"></span></div>
<p id="jobstep"><b>{{ job.step if job else 'Starting...' }}</b></p>
<p class="small muted" id="jobnote">{{ (job.note if job else '') or "Please don't unplug the box." }}</p>
</div>
<div id="jobend"></div>
<script>
(function(){
  const AFTER = {{ (started or 'shut-down')|tojson }};
  const SSID = {{ setup_ssid|tojson }};
  let stage = "", misses = 0, seen = false;
  const $ = id => document.getElementById(id);
  function esc(t){ return String(t).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[c]); }
  function finished(){
    $("jobbar").style.width = "100%";
    $("jobstep").innerHTML = "<b>Erasing now</b>";
    $("jobnote").textContent = "";
    $("jobend").innerHTML = AFTER === "restart"
      ? `<div class="group pad stack"><b>The box restarts by itself</b><p class="small">In about 2 minutes, join the Wi-Fi network <b>${esc(SSID)}</b> (password <b>musicbox</b>) on this phone, and setup opens.</p></div>`
      : `<div class="group pad stack"><b>The box shuts itself down</b><p class="small">Give it a minute, then it's safe to unplug. The next owner plugs it in, waits 2 minutes and joins the Wi-Fi network <b>${esc(SSID)}</b> (password <b>musicbox</b>).</p></div>`;
  }
  async function poll(){
    let r, d;
    try { r = await fetch("/api/job/reset", {cache: "no-store"}); }
    catch (e) { r = null; }
    if (!r || (r.status >= 500)) {
      misses++;
      if (stage === "pausing" || !seen) { $("jobnote").textContent = "The box is restarting to get ready (2 to 5 minutes). This page follows along by itself."; return setTimeout(poll, 4000); }
      if (misses >= 2) return finished();
      return setTimeout(poll, 3000);
    }
    if (r.status === 403) return finished();    // every phone was signed out: the reset ran
    misses = 0;
    try { d = await r.json(); } catch (e) { return setTimeout(poll, 3000); }
    seen = true;
    if (d.ok) return finished();
    if (d.failed) {
      $("jobnote").textContent = "";
      $("jobend").innerHTML = `<div class="toast bad">{{ icon('alert', 20) }}<span>${esc(d.error || "The reset stopped before it finished.")}</span></div><a class="btn wide plain" href="/reset">Back</a>`;
      return;
    }
    stage = d.auto || (d.running ? "working" : stage);
    $("jobbar").style.width = (d.total ? Math.max(4, 100 * d.num / d.total) : 4) + "%";
    $("jobstep").innerHTML = "<b>" + esc(d.step) + "</b>";
    if (d.note) $("jobnote").textContent = d.note;
    setTimeout(poll, 3000);
  }
  setTimeout(poll, 1500);
})();
</script>

{% else %}
<a class="backlink" href="/settings">{{ icon('back', 22) }}Settings</a>
<h1>Erase this box</h1>
<p class="steps">Step 1 of 2. Nothing is erased until the last screen.</p>
{% if error %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ error }}</span></div>{% endif %}
{% if job and job.failed %}<div class="toast bad">{{ icon('alert', 20) }}<span>{{ job.error or "The last reset stopped before it finished." }}</span></div>{% endif %}
<p>Gets the box ready for someone new, or for you to set up from scratch. Its name, your PIN, Spotify, Wi-Fi and listening history are erased.</p>
{% if not supported %}
<div class="toast bad">{{ icon('alert', 20) }}<span>This box needs the latest software first.</span></div>
<a class="btn wide" href="/updates">Software updates</a>
{% else %}
<form method="post" autocomplete="off" id="resetform">
<h2>Also erase</h2>
<div class="group">
<label class="item choice"><input type="checkbox" name="erase_tiles" value="1"{{ ' checked' if form.get('erase_tiles') }}><span class="label">The tiles' music<br><span class="small muted">{% if tiles %}Left off, your {{ tiles }} tile{{ 's' if tiles != 1 }} keep playing the same albums for the next owner.{% else %}No tiles are set up.{% endif %}</span></span></label>
<label class="item choice"><input type="checkbox" name="erase_music" value="1"{{ ' checked' if form.get('erase_music') }}><span class="label">Music and audiobooks added to the box<br><span class="small muted">A plugged-in USB stick is never touched.</span></span></label>
</div>
<h2>When it's done</h2>
<div class="group">
<label class="item choice"><input type="radio" name="after" value="shut-down"{{ ' checked' if form.get('after', 'shut-down') != 'restart' }}><span class="label">Shut down<br><span class="small muted">For giving or selling the box</span></span></label>
<label class="item choice"><input type="radio" name="after" value="restart"{{ ' checked' if form.get('after') == 'restart' }}><span class="label">Restart into setup<br><span class="small muted">To set it up again yourself</span></span></label>
</div>
<h2>Make sure it's you</h2>
<div class="group">
<div class="item"><input type="password" name="pin" id="pin" inputmode="numeric" placeholder="Your PIN" aria-label="Your PIN" autocomplete="off"></div>
<div class="item"><input type="text" name="word" id="word" class="word" placeholder="Type RESET" aria-label="Type RESET" autocomplete="off" autocapitalize="characters" autocorrect="off" spellcheck="false"></div>
</div>
<button class="btn wide danger" id="go" disabled>Continue</button>
</form>
<p class="note" style="margin-top:12px">The next screen lists everything that will be erased and asks one last time.</p>
<script>
(function(){
  const pin = document.getElementById("pin"), word = document.getElementById("word"), go = document.getElementById("go");
  function check(){ go.disabled = !(pin.value.trim().length >= 4 && word.value.trim().toUpperCase() === "RESET"); }
  pin.oninput = word.oninput = check; check();
})();
</script>
{% endif %}
{% endif %}
{% endblock %}"""

PAGES["power.html"] = """{% extends "base.html" %}
{% block style %}
.wait{text-align:center;padding-top:60px}
.spin{width:44px;height:44px;margin:0 auto 22px;border-radius:50%;border:4px solid var(--line);
  border-top-color:var(--marigold);animation:spin 1s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
{% endblock %}{% block body %}
<div class="wait">
{% if action != "shutdown" %}<div class="spin"></div>{% endif %}
{% if action == "shutdown" %}<h1>Shutting down</h1>
<p>Wait about 30 seconds, until the green light on the Pi stops blinking, then unplug it.</p>
{% elif action == "reboot" %}<h1>Restarting</h1><p class="muted">About a minute. This page reconnects by itself.</p>
{% elif action == "maintenance-on" %}<h1>Restarting in maintenance mode</h1><p class="muted">2 to 5 minutes. It stays in maintenance mode until you switch it off on the Advanced page. This page reconnects by itself.</p>
{% elif action == "maintenance-off" %}<h1>Turning unplug protection on</h1><p class="muted">Up to 5 minutes. Please don't unplug it meanwhile. This page reconnects by itself.</p>
{% else %}<h1>Restarting music</h1><p class="muted">About 20 seconds. This page goes back to Now by itself.</p>{% endif %}
</div>
{% if action != "shutdown" %}<script>
setTimeout(function wait(){
  fetch("/api/now", {cache: "no-store"}).then(r => r.ok ? location.replace("/") : setTimeout(wait, 3000))
    .catch(() => setTimeout(wait, 3000));
}, {{ 20000 if action == "restart-music" else 30000 }});
</script>{% endif %}
{% endblock %}"""

app.jinja_loader = DictLoader(PAGES)


if __name__ == "__main__":
    threading.Thread(target=setup.loop, daemon=True).start()
    threading.Thread(target=keeper.loop, daemon=True).start()
    threading.Thread(target=publisher.loop, daemon=True).start()
    threading.Thread(target=listening.loop, daemon=True).start()
    app.run(host="0.0.0.0", port=PORT, threaded=True)
