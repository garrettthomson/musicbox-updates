"""
musicbox_genuine.py
Genuine Music Boxx tiles: only tiles we made (or tiles this box already knew)
can be given music.

How it works
  Every NFC chip has a serial number (its UID) burned in at the chip factory.
  When we make a tile, the factory tool signs that serial number with our
  private tile key and writes the 64-byte signature into the tile's last
  user pages (112-127), then locks those pages so nothing can change them.

  A box only holds the PUBLIC key. It reads the UID and the signature and
  checks one against the other. A store-bought NFC sticker has no signature,
  and copying a signature onto another sticker fails because that sticker's
  serial number is different. Taking a box apart doesn't help anyone make
  tiles either: the private key is never on a box.

  The music a tile plays is NOT signed: the owner can change it any time.
  The NFC link the box writes lives in pages 4-111, well clear of the
  signature.

  Tiles this box already had linked before this check existed keep working
  (they're in tokens.json). Setting "genuine_tiles_only": false on the
  hidden Advanced page switches the check off.

Needs openssl (already used for software updates).
"""

import os
import subprocess
import tempfile

from musicbox_common import HERE, load_settings, load_tokens, read_json, write_json

# Serial numbers of genuine tiles this box has seen, so the phone app can let
# them take music even after they're lifted off the box.
SEEN_FILE = os.path.join(HERE, "genuine_tiles.json")

# Where the signature lives on an NTAG215 (pages are 4 bytes).
SIG_FIRST_PAGE = 112
SIG_PAGES = 16                     # 64 bytes, one Ed25519 signature
SIG_LAST_PAGE = SIG_FIRST_PAGE + SIG_PAGES - 1
NDEF_LAST_PAGE = SIG_FIRST_PAGE - 1   # links written by the box must end before this
LOCK_PAGE = 130                    # NTAG215 dynamic lock bytes
LOCK_BITS = bytes([0x40, 0x00, 0x00, 0x00])   # byte 0 bit 6 = lock pages 112-127

MESSAGE_PREFIX = b"MusicBoxx tile v1\x00"

# Public keys of genuine tiles. A new key can be added here (for example a
# second factory) without breaking tiles signed with the older ones.
TILE_PUBLIC_KEYS = [
    """-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEABzmHFYmzs0E9mmB6aUmoe3mgVUOhf4ya46joq+GeWbU=
-----END PUBLIC KEY-----
""",
]

_cache = {}    # uid -> True/False, so a tile is only checked once per run


def uid_bytes(uid):
    """'04:A1:B2:...' -> bytes"""
    return bytes(int(part, 16) for part in uid.split(":"))


def message_for(uid):
    return MESSAGE_PREFIX + uid_bytes(uid)


def _openssl(args, files):
    with tempfile.TemporaryDirectory(dir="/dev/shm" if os.path.isdir("/dev/shm") else None) as tmp:
        paths = {}
        for name, content in files.items():
            paths[name] = os.path.join(tmp, name)
            with open(paths[name], "wb") as f:
                f.write(content)
        args = [paths.get(a, a) for a in args]
        try:
            return subprocess.run(["openssl"] + args, capture_output=True, timeout=10)
        except (OSError, subprocess.TimeoutExpired):
            return None


def verify(uid, signature):
    """True if signature is ours for this tile's serial number."""
    if not uid or not signature or len(signature) != 64 or signature == bytes(64) \
            or signature == b"\xff" * 64:
        return False
    try:
        msg = message_for(uid)
    except ValueError:
        return False
    for pem in TILE_PUBLIC_KEYS:
        r = _openssl(["pkeyutl", "-verify", "-pubin", "-inkey", "pub.pem", "-rawin",
                      "-in", "msg", "-sigfile", "sig"],
                     {"pub.pem": pem.encode(), "msg": msg, "sig": signature})
        if r is not None and r.returncode == 0:
            return True
    return False


def sign_bytes(uid, private_key_path):
    """Factory only: the 64-byte signature for this tile's serial number."""
    with tempfile.TemporaryDirectory() as tmp:
        msg_path = os.path.join(tmp, "msg")
        with open(msg_path, "wb") as f:
            f.write(message_for(uid))
        try:
            r = subprocess.run(["openssl", "pkeyutl", "-sign", "-inkey", os.path.abspath(private_key_path),
                                "-rawin", "-in", msg_path], capture_output=True, timeout=10)
        except (OSError, subprocess.TimeoutExpired) as err:
            raise RuntimeError(f"Couldn't sign: {err}")
    if r.returncode != 0 or len(r.stdout) != 64:
        raise RuntimeError("Couldn't sign: " + r.stderr.decode(errors="replace").strip())
    return r.stdout


def check_on(enabled=None):
    if enabled is None:
        enabled = load_settings().get("genuine_tiles_only", True)
    return bool(enabled)


def is_genuine(reader, uid):
    """Read the tile's signature and check it (cached per serial number).
    Returns True or False."""
    if uid in _cache:
        return _cache[uid]
    sig = None
    for _ in range(3):
        try:
            sig = reader.read_signature()
            break
        except (RuntimeError, OSError):
            pass
    if sig is None:
        # Not cached: a smaller chip (NTAG213) never answers here, but a
        # wobbly read might, so setting the tile down again tries again.
        return False
    ok = verify(uid, sig)
    _cache[uid] = ok
    if ok:
        seen = read_json(SEEN_FILE, [])
        if uid not in seen:
            try:
                write_json(SEEN_FILE, seen + [uid])
            except OSError:
                pass
    return ok


def may_take_music(uid):
    """For the phone app: may this tile be given music on this box?"""
    return (not check_on() or uid in load_tokens() or uid in read_json(SEEN_FILE, []))


def allowed(reader, uid):
    """(allowed, genuine). A tile may play and take new music if it's genuine,
    or this box already knew it, or the check is switched off."""
    genuine = is_genuine(reader, uid)
    if genuine:
        return True, True
    return (not check_on() or uid in load_tokens()), False
